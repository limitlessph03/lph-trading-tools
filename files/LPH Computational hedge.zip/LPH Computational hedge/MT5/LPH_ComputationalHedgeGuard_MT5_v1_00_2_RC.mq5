//+------------------------------------------------------------------+
//| LPH_ComputationalHedgeGuard_MT5_v1.00.2_RC.mq5                     |
//| Adaptive hedging + margin-survival guard for MT5 hedging accounts|
//| Experimental research build. Validate in Strategy Tester/demo.    |
//+------------------------------------------------------------------+
#property strict
#property version   "1.002"
#property description "Dual-mode release-candidate hedge guard with neutral and thesis-invalidation leaning profiles."

#include <Trade/Trade.mqh>

CTrade trade;

enum ENUM_CORE_SCOPE
  {
   CORE_ALL_EXCEPT_SELF = 0,   // Treat every position on the managed symbol except this EA's hedge positions as core
   CORE_MANUAL_ONLY     = 1,   // Only magic=0 positions are core
   CORE_SPECIFIC_MAGIC  = 2    // Only InpCoreMagic positions are core
  };

enum ENUM_HEDGE_MODE
  {
   HEDGE_MODE_NEUTRAL = 0,
   HEDGE_MODE_LEANING = 1
  };

//-------------------- Operational Inputs -----------------------------
// Risk/hedge parameters are intentionally hard-coded below as the LPH
// fixed profile. Only account/scope/mode and panel placement remain user inputs.
input group "Operational"
input string          InpManagedSymbol              = "";        // Blank = chart symbol
input ENUM_CORE_SCOPE InpCoreScope                  = CORE_ALL_EXCEPT_SELF;
input long            InpCoreMagic                  = 0;
input long            InpHedgeMagic                 = 26091701;
input ENUM_HEDGE_MODE InpHedgeMode                  = HEDGE_MODE_NEUTRAL;
input bool            InpEnableAutoTrading          = false;     // Recommended default: advisory only
input bool            InpHighVolatilityMode         = false;     // Set true manually for FOMC/CPI/NFP
input double          InpMaxHedgeLots               = 0.00;      // 0.00 = uncapped (current behavior)

input group "Leaning Mode (ignored in Neutral)"
input ENUM_TIMEFRAMES InpInvalidationTimeframe      = PERIOD_CURRENT; // REQUIRED: explicitly select H1/H4/D1 per scoped branch
input bool            InpRequireTDIConfirm          = false;     // TODO: wire only after indicator file/buffer is supplied

input group "Dashboard Placement"
input ENUM_BASE_CORNER InpDashboardCorner           = CORNER_LEFT_UPPER;
input int              InpDashboardX                = 8;
input int              InpDashboardY                = 24;

//---------------------- FIXED LPH PROFILE ----------------------------
// Hedge response
const double CFG_HEDGE_START_CORE_LOSS_PCT    = 2.00;
const double CFG_HEDGE_FULL_CORE_LOSS_PCT     = 8.00;
const double CFG_RECOVERY_CORE_LOSS_PCT       = 0.75;
const double CFG_BASE_HEDGE_RATIO             = 0.50;
const double CFG_MAX_HEDGE_RATIO              = 0.90;
const double CFG_MAX_MANAGED_GROSS_LOTS       = 0.00; // no arbitrary lot cap

// Leaning mode thesis-invalidation profile (kept separate from Neutral).
const int    CFG_INVALIDATION_EMA_PERIOD       = 50;
const double CFG_LEANING_STAGE1_BASE_RATIO     = 0.30;
const double CFG_LEANING_STAGE1_MAX_RATIO      = 0.60;
const double CFG_LEANING_BUFFER_ATR_MULT       = 1.0;
const int    CFG_LEANING_CONFIRM_BARS          = 2;
const double CFG_LEANING_STAGE1_ENTRY_ATR_MULT = 0.25; // v1.00.2: close must be this far beyond EMA to enter Stage 1
const double CFG_LEANING_STAGE1_EXIT_ATR_MULT  = 0.10; // v1.00.2: close must recover this far past EMA to exit Stage 1

// Margin survival
const double CFG_MIN_MARGIN_LEVEL_NORMAL       = 200.0;
const double CFG_MIN_MARGIN_LEVEL_HIGH_VOL     = 300.0;
const double CFG_EMERGENCY_DELEVERAGE_LEVEL    = 150.0;
const double CFG_EMERGENCY_TARGET_LEVEL        = 200.0;
const double CFG_STOP_OUT_BUFFER_PCT_POINTS    = 50.0;
const double CFG_STOP_OUT_MONEY_BUFFER         = 0.0;
const bool   CFG_USE_CONSERVATIVE_MARGIN_GATE  = true;
const bool   CFG_ALLOW_EMERGENCY_DELEVERAGE    = true;
const bool   CFG_AUTO_COMPACT_OWN_HEDGES       = true;

// Stress / spread
const ENUM_TIMEFRAMES CFG_ATR_TIMEFRAME        = PERIOD_M5;
const int             CFG_ATR_PERIOD           = 14;
const double          CFG_STRESS_ATR_MULTIPLE  = 1.50;
const double          CFG_STRESS_SPREAD_MULT   = 2.00;
const double          CFG_MIN_STRESS_NORMAL    = 150.0;
const double          CFG_MIN_STRESS_HIGH_VOL  = 200.0;
const double          CFG_MAX_SPREAD_ATR_FRAC  = 0.15; // normal hedge hard gate
const double          CFG_EMERGENCY_MAX_SPREAD_ATR_FRAC = 0.25; // only if survival improves
const double          CFG_EMERGENCY_MIN_ML_IMPROVEMENT  = 5.0;  // percentage points
const double          CFG_EMERGENCY_MIN_SO_BUFFER_PCT_POINTS = 25.0;

// Execution cadence
const int    CFG_TIMER_SECONDS                 = 1;
const int    CFG_MIN_SECONDS_BETWEEN_ACTIONS   = 3;
const int    CFG_DEVIATION_POINTS              = 50;
const int    CFG_FAILED_ACTION_BACKOFF_SECONDS = 5;    // v1.00.1: pause after a failed trade/close request
const bool   CFG_VERBOSE_LOG                   = true;
const int    CFG_REPEAT_STATUS_LOG_SECONDS       = 60;   // de-duplicate unchanged status/warning messages
const bool   CFG_SHOW_DASHBOARD                = true;

// Fixed dashboard dimensions chosen to avoid clipping on standard MT5 charts.
const int    DASH_WIDTH                        = 570;
const int    DASH_HEIGHT                       = 555;
const int    DASH_FONT_SIZE                    = 11;
const int    DASH_ACTION_FONT_SIZE             = 16;

//--------------------------- State ----------------------------------
string   g_symbol = "";
int      g_atr_handle = INVALID_HANDLE;
int      g_invalidation_atr_handle = INVALID_HANDLE;
int      g_invalidation_ema_handle = INVALID_HANDLE;
datetime g_last_action_time = 0;
datetime g_next_attempt_time = 0;   // v1.00.1: failure backoff
string   g_last_action = "None";
string   g_last_block_reason = "";
bool     g_emergency_active = false;
string   g_last_status_log = "";
datetime g_last_status_log_time = 0;

enum ENUM_INVALIDATION_STATE
  {
   INVAL_NONE = 0,
   INVAL_STAGE1,
   INVAL_STAGE2
  };

struct InvalidationScopeState
  {
   long                    core_magic;
   int                     core_direction;
   ENUM_INVALIDATION_STATE state;
   int                     consecutive_buffer_bars;
   datetime                last_closed_bar_time;
   double                  stage2_ratio;
  };

InvalidationScopeState g_invalidation;

struct ExposureStats
  {
   double core_buy;
   double core_sell;
   double core_net;
   double core_gross;
   double core_profit;
   int    core_positions;

   double hedge_buy;
   double hedge_sell;
   double hedge_net;
   double hedge_gross;
   double hedge_profit;
   int    hedge_positions;

   double combined_net;
   double combined_gross;
   double combined_profit;
  };

struct GateResult
  {
   bool   allowed;
   string reason;
   double check_margin;
   double check_free_margin;
   double check_margin_level;
   double conservative_margin_level;
   double stress_equity;
   double stress_margin_level;
   double standalone_margin;
  };

enum ENUM_DECISION_STATE
  {
   DECISION_BLOCKED = 0,
   DECISION_SAFE_HOLD,
   DECISION_HEDGE_REQUIRED,
   DECISION_HEDGE_BLOCKED,
   DECISION_REDUCE_HEDGE,
   DECISION_EMERGENCY
  };

enum ENUM_RECOMMENDED_ACTION
  {
   ACTION_NONE = 0,
   ACTION_OPEN_BUY_HEDGE,
   ACTION_OPEN_SELL_HEDGE,
   ACTION_REDUCE_BUY_HEDGE,
   ACTION_REDUCE_SELL_HEDGE,
   ACTION_COMPACT_SELF_HEDGES,
   ACTION_EMERGENCY_OPEN_BUY_HEDGE,
   ACTION_EMERGENCY_OPEN_SELL_HEDGE
  };

struct Recommendation
  {
   ENUM_DECISION_STATE state;
   ENUM_RECOMMENDED_ACTION action;
   string state_text;
   string action_text;
   string reason;
   bool   action_needed;
   bool   can_execute;
   ENUM_ORDER_TYPE candidate_type;
   double candidate_volume;
   double target_ratio;
   double current_ratio;
   double desired_hedge_net;
   double delta;
   GateResult gate;
  };

const string DASH_PREFIX="LPH_HG90_";


//--------------------------- Helpers --------------------------------
double Clamp(const double x,const double lo,const double hi)
  {
   if(x<lo) return lo;
   if(x>hi) return hi;
   return x;
  }

int VolumeDigits(const double step)
  {
   int d=0;
   double v=step;
   while(d<8 && MathAbs(v-MathRound(v))>1e-9)
     {
      v*=10.0;
      d++;
     }
   return d;
  }

double NormalizeVolumeFloor(const double requested)
  {
   const double minv=SymbolInfoDouble(g_symbol,SYMBOL_VOLUME_MIN);
   const double maxv=SymbolInfoDouble(g_symbol,SYMBOL_VOLUME_MAX);
   const double step=SymbolInfoDouble(g_symbol,SYMBOL_VOLUME_STEP);
   if(step<=0.0 || requested<minv-1e-12)
      return 0.0;

   double v=MathFloor((requested+1e-12)/step)*step;
   v=MathMin(v,maxv);
   if(v<minv-1e-12)
      return 0.0;
   return NormalizeDouble(v,VolumeDigits(step));
  }

bool IsCoreMagic(const long magic)
  {
   if(magic==InpHedgeMagic)
      return false;

   switch(InpCoreScope)
     {
      case CORE_MANUAL_ONLY:    return (magic==0);
      case CORE_SPECIFIC_MAGIC: return (magic==InpCoreMagic);
      case CORE_ALL_EXCEPT_SELF:
      default:                  return true;
     }
  }

bool IsHedgingAccount()
  {
   return ((ENUM_ACCOUNT_MARGIN_MODE)AccountInfoInteger(ACCOUNT_MARGIN_MODE)==ACCOUNT_MARGIN_MODE_RETAIL_HEDGING);
  }

bool ActionCooldownPassed()
  {
   if(TimeCurrent()<g_next_attempt_time) return false;
   if(g_last_action_time==0) return true;
   return ((TimeCurrent()-g_last_action_time)>=CFG_MIN_SECONDS_BETWEEN_ACTIONS);
  }

void LogStatusThrottled(const string text,const bool force=false)
  {
   if(!CFG_VERBOSE_LOG || text=="")
      return;

   const datetime now=TimeCurrent();
   const bool changed=(text!=g_last_status_log);
   const bool heartbeat=(g_last_status_log_time==0 ||
                         (now-g_last_status_log_time)>=CFG_REPEAT_STATUS_LOG_SECONDS);
   if(!force && !changed && !heartbeat)
      return;

   Print("[HedgeGuard] ",text);
   g_last_status_log=text;
   g_last_status_log_time=now;
  }

void MarkFailure()
  {
   g_next_attempt_time=TimeCurrent()+CFG_FAILED_ACTION_BACKOFF_SECONDS;
  }

void MarkAction(const string text)
  {
   g_last_action_time=TimeCurrent();
   g_last_action=text;
   if(CFG_VERBOSE_LOG)
      Print("[HedgeGuard] ",text);
  }

bool BuildExposure(ExposureStats &s)
  {
   ZeroMemory(s);

   const int total=PositionsTotal();
   for(int i=0;i<total;i++)
     {
      const ulong ticket=PositionGetTicket(i);
      if(ticket==0 || !PositionSelectByTicket(ticket))
         continue;

      const string sym=PositionGetString(POSITION_SYMBOL);
      if(sym!=g_symbol)
         continue;

      const long magic=(long)PositionGetInteger(POSITION_MAGIC);
      const ENUM_POSITION_TYPE type=(ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      const double vol=PositionGetDouble(POSITION_VOLUME);
      const double pnl=PositionGetDouble(POSITION_PROFIT)+PositionGetDouble(POSITION_SWAP);

      if(magic==InpHedgeMagic)
        {
         if(type==POSITION_TYPE_BUY) s.hedge_buy+=vol;
         if(type==POSITION_TYPE_SELL) s.hedge_sell+=vol;
         s.hedge_gross+=vol;
         s.hedge_profit+=pnl;
         s.hedge_positions++;
        }
      else if(IsCoreMagic(magic))
        {
         if(type==POSITION_TYPE_BUY) s.core_buy+=vol;
         if(type==POSITION_TYPE_SELL) s.core_sell+=vol;
         s.core_gross+=vol;
         s.core_profit+=pnl;
         s.core_positions++;
        }
     }

   s.core_net=s.core_buy-s.core_sell;
   s.hedge_net=s.hedge_buy-s.hedge_sell;
   s.combined_net=s.core_net+s.hedge_net;
   s.combined_gross=s.core_gross+s.hedge_gross;
   s.combined_profit=s.core_profit+s.hedge_profit;
   return true;
  }

double CurrentATR()
  {
   if(g_atr_handle==INVALID_HANDLE)
      return 0.0;
   double buf[2];
   if(CopyBuffer(g_atr_handle,0,0,2,buf)<1)
      return 0.0;
   return buf[0];
  }

string HedgeModeText()
  {
   return (InpHedgeMode==HEDGE_MODE_LEANING ? "LEANING" : "NEUTRAL");
  }

string InvalidationStateText()
  {
   switch(g_invalidation.state)
     {
      case INVAL_STAGE1: return "STAGE 1 — EMA BREACH";
      case INVAL_STAGE2: return "INVALIDATED — CLOSE MANUALLY";
      case INVAL_NONE:
      default:           return "VALID";
     }
  }

void ResetInvalidationState(const bool preserve_bar_time=true)
  {
   const datetime last_bar=(preserve_bar_time ? g_invalidation.last_closed_bar_time : 0);
   g_invalidation.core_magic=InpCoreMagic;
   g_invalidation.core_direction=0;
   g_invalidation.state=INVAL_NONE;
   g_invalidation.consecutive_buffer_bars=0;
   g_invalidation.stage2_ratio=0.0;
   g_invalidation.last_closed_bar_time=last_bar;
  }

// Stage-2 latch persistence: survives EA restart, chart/timeframe change, recompile
// and terminal restart. Cleared only when core goes flat or core direction flips.
string Stage2LatchKey()
  {
   const string key=StringFormat("LPH_HG_S2_%I64d_%s_%I64d_%I64d",
                                 (long)AccountInfoInteger(ACCOUNT_LOGIN),g_symbol,InpHedgeMagic,InpCoreMagic);
   return StringSubstr(key,0,63); // terminal global-variable name limit
  }

void SaveStage2Latch(const int direction)
  {
   GlobalVariableSet(Stage2LatchKey(),(double)direction);
  }

void ClearStage2Latch()
  {
   const string key=Stage2LatchKey();
   if(GlobalVariableCheck(key))
      GlobalVariableDel(key);
  }

void RestoreStage2Latch()
  {
   const string key=Stage2LatchKey();
   if(!GlobalVariableCheck(key))
      return;
   const int dir=(int)MathRound(GlobalVariableGet(key));
   if(dir!=1 && dir!=-1)
      return;
   g_invalidation.core_direction=dir;
   g_invalidation.state=INVAL_STAGE2;
   g_invalidation.stage2_ratio=CFG_LEANING_STAGE1_MAX_RATIO;
   g_invalidation.consecutive_buffer_bars=CFG_LEANING_CONFIRM_BARS;
   Print("[HedgeGuard] Restored Stage 2 invalidation latch (core direction ",(dir>0 ? "BUY" : "SELL"),")");
  }

// Deliberate stub: Coach T must supply the custom TDI file and buffer index.
// Until then this adds no gate, including when InpRequireTDIConfirm=true.
bool TDIConfirmsAgainstCore(const int core_direction)
  {
   return true;
  }

bool ReadClosedInvalidationBar(datetime &bar_time,double &bar_close,double &ema,double &atr)
  {
   if(g_invalidation_ema_handle==INVALID_HANDLE || g_invalidation_atr_handle==INVALID_HANDLE)
      return false;

   datetime times[1];
   double closes[1],emas[1],atrs[1];
   if(CopyTime(g_symbol,InpInvalidationTimeframe,1,1,times)!=1 ||
      CopyClose(g_symbol,InpInvalidationTimeframe,1,1,closes)!=1 ||
      CopyBuffer(g_invalidation_ema_handle,0,1,1,emas)!=1 ||
      CopyBuffer(g_invalidation_atr_handle,0,1,1,atrs)!=1)
      return false;

   bar_time=times[0];
   bar_close=closes[0];
   ema=emas[0];
   atr=atrs[0];
   return (bar_time>0 && atr>0.0);
  }

double CurrentMarginLevel()
  {
   const double margin=AccountInfoDouble(ACCOUNT_MARGIN);
   if(margin<=0.0)
      return 999999.0;
   const double ml=AccountInfoDouble(ACCOUNT_MARGIN_LEVEL);
   if(ml>0.0)
      return ml;
   return AccountInfoDouble(ACCOUNT_EQUITY)/margin*100.0;
  }

double CurrentStopOutDistanceMoney()
  {
   const double equity=AccountInfoDouble(ACCOUNT_EQUITY);
   const double margin=AccountInfoDouble(ACCOUNT_MARGIN);
   const double so=AccountInfoDouble(ACCOUNT_MARGIN_SO_SO);
   const ENUM_ACCOUNT_STOPOUT_MODE mode=(ENUM_ACCOUNT_STOPOUT_MODE)AccountInfoInteger(ACCOUNT_MARGIN_SO_MODE);

   if(mode==ACCOUNT_STOPOUT_MODE_PERCENT)
      return equity-(margin*so/100.0);
   return equity-so;
  }

double RequiredNewHedgeMarginLevel()
  {
   double required=(InpHighVolatilityMode ? CFG_MIN_MARGIN_LEVEL_HIGH_VOL : CFG_MIN_MARGIN_LEVEL_NORMAL);
   const ENUM_ACCOUNT_STOPOUT_MODE mode=(ENUM_ACCOUNT_STOPOUT_MODE)AccountInfoInteger(ACCOUNT_MARGIN_SO_MODE);
   if(mode==ACCOUNT_STOPOUT_MODE_PERCENT)
     {
      const double so=AccountInfoDouble(ACCOUNT_MARGIN_SO_SO);
      required=MathMax(required,so+CFG_STOP_OUT_BUFFER_PCT_POINTS);
     }
   return required;
  }

double RequiredStressMarginLevel()
  {
   return (InpHighVolatilityMode ? CFG_MIN_STRESS_HIGH_VOL : CFG_MIN_STRESS_NORMAL);
  }

double CoreLossPct(const ExposureStats &s)
  {
   const double balance=AccountInfoDouble(ACCOUNT_BALANCE);
   if(balance<=0.0 || s.core_profit>=0.0)
      return 0.0;
   return (-s.core_profit/balance)*100.0;
  }

double CurrentCoverageRatio(const ExposureStats &s)
  {
   if(MathAbs(s.core_net)<1e-12)
      return 0.0;
   if(s.core_net*s.hedge_net>=0.0)
      return 0.0;
   return MathAbs(s.hedge_net/s.core_net);
  }

double ComputeNeutralTargetHedgeRatio(const ExposureStats &s)
  {
   if(MathAbs(s.core_net)<1e-12)
      return 0.0;

   const double loss=CoreLossPct(s);
   const double current=CurrentCoverageRatio(s);

   // Hysteresis: fully unwind only after recovery threshold is crossed.
   if(loss<=CFG_RECOVERY_CORE_LOSS_PCT)
      return 0.0;

   // Between recovery and start, hold the current coverage instead of oscillating.
   if(loss<CFG_HEDGE_START_CORE_LOSS_PCT)
      return Clamp(current,0.0,CFG_MAX_HEDGE_RATIO);

   double pressure=1.0;
   if(CFG_HEDGE_FULL_CORE_LOSS_PCT>CFG_HEDGE_START_CORE_LOSS_PCT)
      pressure=Clamp((loss-CFG_HEDGE_START_CORE_LOSS_PCT)/(CFG_HEDGE_FULL_CORE_LOSS_PCT-CFG_HEDGE_START_CORE_LOSS_PCT),0.0,1.0);

   const double target=CFG_BASE_HEDGE_RATIO+pressure*(CFG_MAX_HEDGE_RATIO-CFG_BASE_HEDGE_RATIO);
   return Clamp(target,0.0,CFG_MAX_HEDGE_RATIO);
  }

double ComputeLeaningTargetRatio(const ExposureStats &s)
  {
   if(MathAbs(s.core_net)<1e-12)
     {
      ResetInvalidationState();
      ClearStage2Latch();
      return 0.0;
     }

   const int direction=(s.core_net>0.0 ? 1 : -1);
   if(g_invalidation.core_magic!=InpCoreMagic ||
      (g_invalidation.core_direction!=0 && g_invalidation.core_direction!=direction))
     {
      ResetInvalidationState(false);
      ClearStage2Latch();
     }
   g_invalidation.core_magic=InpCoreMagic;
   g_invalidation.core_direction=direction;

   if(g_invalidation.state==INVAL_STAGE2)
      return g_invalidation.stage2_ratio;

   datetime bar_time=0;
   double bar_close=0.0,ema=0.0,atr=0.0;
   if(!ReadClosedInvalidationBar(bar_time,bar_close,ema,atr))
      return (g_invalidation.state==INVAL_STAGE1 ? CFG_LEANING_STAGE1_BASE_RATIO : 0.0);

   // State transitions happen only once per newly closed bar.
   if(bar_time!=g_invalidation.last_closed_bar_time)
     {
      g_invalidation.last_closed_bar_time=bar_time;
      const double adverse_distance=(direction>0 ? ema-bar_close : bar_close-ema);

      // Hysteresis: enter Stage 1 only beyond the entry buffer; exit only after a
      // recovery past the EMA by the exit buffer; hold state in between.
      const double entry_buf=CFG_LEANING_STAGE1_ENTRY_ATR_MULT*atr;
      const double exit_buf=CFG_LEANING_STAGE1_EXIT_ATR_MULT*atr;

      if(g_invalidation.state==INVAL_NONE && adverse_distance<entry_buf)
         return 0.0;

      if(g_invalidation.state==INVAL_STAGE1 && adverse_distance<=-exit_buf)
        {
         ResetInvalidationState();
         g_invalidation.core_direction=direction;
         return 0.0;
        }

      if(g_invalidation.state==INVAL_NONE)
         g_invalidation.state=INVAL_STAGE1;

      const double buffer=CFG_LEANING_BUFFER_ATR_MULT*atr;
      if(adverse_distance>=buffer)
         g_invalidation.consecutive_buffer_bars++;
      else
         g_invalidation.consecutive_buffer_bars=0;

      if(g_invalidation.consecutive_buffer_bars>=CFG_LEANING_CONFIRM_BARS &&
         (!InpRequireTDIConfirm || TDIConfirmsAgainstCore(direction)))
        {
         const double scaled=CFG_LEANING_STAGE1_BASE_RATIO+
                             Clamp(adverse_distance/buffer,0.0,1.0)*
                             (CFG_LEANING_STAGE1_MAX_RATIO-CFG_LEANING_STAGE1_BASE_RATIO);
         g_invalidation.stage2_ratio=Clamp(scaled,CFG_LEANING_STAGE1_BASE_RATIO,CFG_LEANING_STAGE1_MAX_RATIO);
         g_invalidation.state=INVAL_STAGE2;
         SaveStage2Latch(direction);
         return g_invalidation.stage2_ratio;
        }
     }

   if(g_invalidation.state==INVAL_NONE)
      return 0.0;

   const double adverse_distance=(direction>0 ? ema-bar_close : bar_close-ema);
   const double buffer=CFG_LEANING_BUFFER_ATR_MULT*atr;
   const double scaled=CFG_LEANING_STAGE1_BASE_RATIO+
                       Clamp(adverse_distance/buffer,0.0,1.0)*
                       (CFG_LEANING_STAGE1_MAX_RATIO-CFG_LEANING_STAGE1_BASE_RATIO);
   return Clamp(scaled,CFG_LEANING_STAGE1_BASE_RATIO,CFG_LEANING_STAGE1_MAX_RATIO);
  }

double ComputeTargetHedgeRatio(const ExposureStats &s)
  {
   if(InpHedgeMode==HEDGE_MODE_LEANING)
      return ComputeLeaningTargetRatio(s);
   return ComputeNeutralTargetHedgeRatio(s);
  }

ENUM_ORDER_TYPE_FILLING ResolveFillingMode()
  {
   const long flags=SymbolInfoInteger(g_symbol,SYMBOL_FILLING_MODE);
   if((flags & SYMBOL_FILLING_FOK)==SYMBOL_FILLING_FOK)
      return ORDER_FILLING_FOK;
   if((flags & SYMBOL_FILLING_IOC)==SYMBOL_FILLING_IOC)
      return ORDER_FILLING_IOC;
   return ORDER_FILLING_RETURN;
  }

bool SpreadGatePassLimit(const double max_frac,double &spread_atr_frac,string &reason)
  {
   spread_atr_frac=0.0;
   reason="";
   if(max_frac<=0.0)
      return true;

   MqlTick tick;
   if(!SymbolInfoTick(g_symbol,tick))
     {
      reason="No market tick";
      return false;
     }

   const double atr=CurrentATR();
   if(atr<=0.0)
     {
      reason="ATR unavailable";
      return false;
     }

   const double spread=MathMax(0.0,tick.ask-tick.bid);
   spread_atr_frac=spread/atr;
   if(spread_atr_frac>max_frac)
     {
      reason=StringFormat("Spread/ATR %.3f > %.3f",spread_atr_frac,max_frac);
      return false;
     }
   return true;
  }

bool SpreadGatePass(double &spread_atr_frac,string &reason)
  {
   return SpreadGatePassLimit(CFG_MAX_SPREAD_ATR_FRAC,spread_atr_frac,reason);
  }

string SpreadBandText(const double frac)
  {
   if(frac<=0.05) return "TIGHT";
   if(frac<=0.10) return "NORMAL";
   if(frac<=0.15) return "ELEVATED";
   if(frac<=0.25) return "HIGH";
   return "EXTREME";
  }

// Estimates account equity after an adverse move on the managed symbol only.
// Other symbols are assumed unchanged. This is a scenario check, not a broker guarantee.
bool EstimateStressEquity(const ENUM_ORDER_TYPE candidate_type,
                          const double candidate_volume,
                          const double candidate_entry,
                          double &stress_equity)
  {
   MqlTick tick;
   if(!SymbolInfoTick(g_symbol,tick))
      return false;

   const double atr=CurrentATR();
   if(atr<=0.0)
      return false;

   ExposureStats s;
   BuildExposure(s);

   double net_after=s.combined_net;
   if(candidate_type==ORDER_TYPE_BUY)  net_after+=candidate_volume;
   if(candidate_type==ORDER_TYPE_SELL) net_after-=candidate_volume;

   double direction_ref=net_after;
   if(MathAbs(direction_ref)<1e-12)
      direction_ref=s.core_net;
   if(MathAbs(direction_ref)<1e-12)
      direction_ref=1.0;

   const double current_spread=MathMax(0.0,tick.ask-tick.bid);
   const double stressed_spread=current_spread*MathMax(1.0,CFG_STRESS_SPREAD_MULT);
   const double current_mid=(tick.ask+tick.bid)*0.5;
   const double adverse_move=atr*MathMax(0.0,CFG_STRESS_ATR_MULTIPLE);
   const double stressed_mid=(direction_ref>0.0 ? current_mid-adverse_move : current_mid+adverse_move);
   const double stressed_bid=stressed_mid-stressed_spread*0.5;
   const double stressed_ask=stressed_mid+stressed_spread*0.5;

   double delta_existing=0.0;
   const int total=PositionsTotal();
   for(int i=0;i<total;i++)
     {
      const ulong ticket=PositionGetTicket(i);
      if(ticket==0 || !PositionSelectByTicket(ticket))
         continue;
      if(PositionGetString(POSITION_SYMBOL)!=g_symbol)
         continue;

      const ENUM_POSITION_TYPE ptype=(ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      const double volume=PositionGetDouble(POSITION_VOLUME);
      const double open_price=PositionGetDouble(POSITION_PRICE_OPEN);

      const ENUM_ORDER_TYPE otype=(ptype==POSITION_TYPE_BUY ? ORDER_TYPE_BUY : ORDER_TYPE_SELL);
      const double now_close=(ptype==POSITION_TYPE_BUY ? tick.bid : tick.ask);
      const double stress_close=(ptype==POSITION_TYPE_BUY ? stressed_bid : stressed_ask);

      double pnl_now=0.0,pnl_stress=0.0;
      if(!OrderCalcProfit(otype,g_symbol,volume,open_price,now_close,pnl_now))
         return false;
      if(!OrderCalcProfit(otype,g_symbol,volume,open_price,stress_close,pnl_stress))
         return false;
      delta_existing+=(pnl_stress-pnl_now);
     }

   double candidate_stress_pnl=0.0;
   if(candidate_volume>0.0)
     {
      const double candidate_close=(candidate_type==ORDER_TYPE_BUY ? stressed_bid : stressed_ask);
      if(!OrderCalcProfit(candidate_type,g_symbol,candidate_volume,candidate_entry,candidate_close,candidate_stress_pnl))
         return false;
     }

   stress_equity=AccountInfoDouble(ACCOUNT_EQUITY)+delta_existing+candidate_stress_pnl;
   return true;
  }

bool BuildMarketCheckRequest(const ENUM_ORDER_TYPE type,const double volume,MqlTradeRequest &req)
  {
   ZeroMemory(req);
   MqlTick tick;
   if(!SymbolInfoTick(g_symbol,tick))
      return false;

   req.action=TRADE_ACTION_DEAL;
   req.magic=(ulong)InpHedgeMagic;
   req.symbol=g_symbol;
   req.volume=volume;
   req.type=type;
   req.price=(type==ORDER_TYPE_BUY ? tick.ask : tick.bid);
   req.deviation=(ulong)MathMax(0,CFG_DEVIATION_POINTS);
   req.type_filling=ResolveFillingMode();
   req.type_time=ORDER_TIME_GTC;
   req.comment="LPH HedgeGuard";
   return true;
  }

// OrderCheck().margin is the margin required by the checked order ONLY, not the
// account total. Projected total margin is derived from the broker's post-trade
// equity / margin level (captures hedge margin offsets); falls back to
// current account margin + order margin when margin level is unavailable.
double ProjectedTotalMarginFromCheck(const MqlTradeCheckResult &check)
  {
   if(check.margin_level>0.0 && check.equity>0.0)
      return check.equity/check.margin_level*100.0;
   return AccountInfoDouble(ACCOUNT_MARGIN)+MathMax(0.0,check.margin);
  }

bool CheckCandidate(const ENUM_ORDER_TYPE type,const double volume,GateResult &g)
  {
   ZeroMemory(g);
   g.allowed=false;

   if(volume<=0.0)
     {
      g.reason="Volume below symbol minimum";
      return false;
     }

   if(!IsHedgingAccount())
     {
      g.reason="Account is not MT5 retail hedging mode";
      return false;
     }

   ExposureStats s;
   BuildExposure(s);
   if(CFG_MAX_MANAGED_GROSS_LOTS>0.0 && s.combined_gross+volume>CFG_MAX_MANAGED_GROSS_LOTS+1e-12)
     {
      g.reason=StringFormat("Gross cap %.2f lots would be exceeded",CFG_MAX_MANAGED_GROSS_LOTS);
      return false;
     }

   if(InpMaxHedgeLots>0.0 && s.hedge_gross+volume>InpMaxHedgeLots+1e-12)
     {
      g.reason=StringFormat("Hedge cap %.2f lots would be exceeded",InpMaxHedgeLots);
      return false;
     }

   MqlTradeRequest req;
   if(!BuildMarketCheckRequest(type,volume,req))
     {
      g.reason="Unable to build market request";
      return false;
     }

   MqlTradeCheckResult check;
   ZeroMemory(check);
   ResetLastError();
   if(!OrderCheck(req,check))
     {
      g.reason=StringFormat("OrderCheck failed (%d): %s",GetLastError(),check.comment);
      return false;
     }

   g.check_margin=check.margin;
   g.check_free_margin=check.margin_free;
   g.check_margin_level=check.margin_level;

   MqlTick tick;
   if(!SymbolInfoTick(g_symbol,tick))
     {
      g.reason="No tick for margin estimate";
      return false;
     }
   const double entry=(type==ORDER_TYPE_BUY ? tick.ask : tick.bid);

   g.standalone_margin=0.0;
   if(OrderCalcMargin(type,g_symbol,volume,entry,g.standalone_margin) && CFG_USE_CONSERVATIVE_MARGIN_GATE)
     {
      const double projected_margin=AccountInfoDouble(ACCOUNT_MARGIN)+g.standalone_margin;
      g.conservative_margin_level=(projected_margin>0.0 ? AccountInfoDouble(ACCOUNT_EQUITY)/projected_margin*100.0 : 999999.0);
     }
   else
     {
      g.conservative_margin_level=check.margin_level;
     }

   g.stress_equity=0.0;
   if(!EstimateStressEquity(type,volume,entry,g.stress_equity))
     {
      g.reason="Stress scenario unavailable";
      return false;
     }

   // Normal path stays conservative: larger of broker-derived and no-offset margin.
   const double stress_margin=MathMax(ProjectedTotalMarginFromCheck(check),
                                      AccountInfoDouble(ACCOUNT_MARGIN)+MathMax(g.standalone_margin,check.margin));
   g.stress_margin_level=(stress_margin>0.0 ? g.stress_equity/stress_margin*100.0 : 999999.0);

   // Calculate all projections first so advisory mode can show the post-trade
   // state even when a market-condition gate (for example spread) blocks entry.
   double spread_frac=0.0;
   string spread_reason="";
   if(!SpreadGatePass(spread_frac,spread_reason))
     {
      g.reason=spread_reason;
      return false;
     }

   if(check.margin_free<0.0)
     {
      g.reason="Projected free margin is negative";
      return false;
     }

   const ENUM_ACCOUNT_STOPOUT_MODE so_mode=(ENUM_ACCOUNT_STOPOUT_MODE)AccountInfoInteger(ACCOUNT_MARGIN_SO_MODE);
   const double required_ml=RequiredNewHedgeMarginLevel();

   if(so_mode==ACCOUNT_STOPOUT_MODE_PERCENT)
     {
      if(check.margin>0.0 && check.margin_level<required_ml)
        {
         g.reason=StringFormat("Projected margin level %.1f%% < %.1f%%",check.margin_level,required_ml);
         return false;
        }
      if(CFG_USE_CONSERVATIVE_MARGIN_GATE && g.conservative_margin_level<required_ml)
        {
         g.reason=StringFormat("Conservative margin level %.1f%% < %.1f%%",g.conservative_margin_level,required_ml);
         return false;
        }
      if(g.stress_margin_level<RequiredStressMarginLevel())
        {
         g.reason=StringFormat("Stress margin level %.1f%% < %.1f%%",g.stress_margin_level,RequiredStressMarginLevel());
         return false;
        }
     }
   else
     {
      const double stopout=AccountInfoDouble(ACCOUNT_MARGIN_SO_SO);
      const double required_equity=stopout+MathMax(0.0,CFG_STOP_OUT_MONEY_BUFFER);
      if(check.equity<=required_equity)
        {
         g.reason=StringFormat("Projected equity %.2f <= money stopout buffer %.2f",check.equity,required_equity);
         return false;
        }
      if(g.stress_equity<=required_equity)
        {
         g.reason=StringFormat("Stress equity %.2f <= money stopout buffer %.2f",g.stress_equity,required_equity);
         return false;
        }
     }

   g.allowed=true;
   g.reason="PASS";
   return true;
  }

bool TradeRetcodeOK()
  {
   const uint rc=trade.ResultRetcode();
   return (rc==TRADE_RETCODE_DONE || rc==TRADE_RETCODE_DONE_PARTIAL || rc==TRADE_RETCODE_PLACED);
  }

bool CheckEmergencyCandidate(const ENUM_ORDER_TYPE type,const double volume,GateResult &g)
  {
   ZeroMemory(g);
   g.allowed=false;

   if(volume<=0.0)
     {
      g.reason="Invalid emergency hedge volume";
      return false;
     }
   if(!IsHedgingAccount())
     {
      g.reason="MT5 retail hedging account required";
      return false;
     }

   ExposureStats s;
   BuildExposure(s);
   const double signed_volume=(type==ORDER_TYPE_BUY ? volume : -volume);
   const double net_after=s.combined_net+signed_volume;
   if(MathAbs(net_after)>=MathAbs(s.combined_net)-1e-12)
     {
      g.reason="Emergency candidate does not reduce net directional exposure";
      return false;
     }

   MqlTradeRequest req;
   if(!BuildMarketCheckRequest(type,volume,req))
     {
      g.reason="Unable to build emergency market request";
      return false;
     }

   MqlTradeCheckResult check;
   ZeroMemory(check);
   ResetLastError();
   if(!OrderCheck(req,check))
     {
      g.reason=StringFormat("Emergency OrderCheck failed (%d): %s",GetLastError(),check.comment);
      return false;
     }

   g.check_margin=check.margin;
   g.check_free_margin=check.margin_free;
   g.check_margin_level=check.margin_level;

   MqlTick tick;
   if(!SymbolInfoTick(g_symbol,tick))
     {
      g.reason="No tick for emergency margin estimate";
      return false;
     }
   const double entry=(type==ORDER_TYPE_BUY ? tick.ask : tick.bid);

   g.standalone_margin=0.0;
   g.conservative_margin_level=g.check_margin_level;

   if(!EstimateStressEquity(type,volume,entry,g.stress_equity))
     {
      g.reason="Emergency stress scenario unavailable";
      return false;
     }
   const double stress_margin=ProjectedTotalMarginFromCheck(check);
   g.stress_margin_level=(stress_margin>0.0 ? g.stress_equity/stress_margin*100.0 : 999999.0);

   double spread_frac=0.0;
   string spread_reason="";
   if(!SpreadGatePassLimit(CFG_EMERGENCY_MAX_SPREAD_ATR_FRAC,spread_frac,spread_reason))
     {
      g.reason="Emergency hedge blocked: "+spread_reason;
      return false;
     }

   const double current_ml=CurrentMarginLevel();
   const double current_free=AccountInfoDouble(ACCOUNT_MARGIN_FREE);
   if(g.check_margin_level<current_ml+CFG_EMERGENCY_MIN_ML_IMPROVEMENT)
     {
      g.reason=StringFormat("Emergency hedge does not improve margin enough: %.1f%% -> %.1f%%",current_ml,g.check_margin_level);
      return false;
     }
   if(g.check_free_margin<=current_free+0.01)
     {
      g.reason=StringFormat("Emergency hedge does not improve free margin: %.2f -> %.2f",current_free,g.check_free_margin);
      return false;
     }

   const ENUM_ACCOUNT_STOPOUT_MODE so_mode=(ENUM_ACCOUNT_STOPOUT_MODE)AccountInfoInteger(ACCOUNT_MARGIN_SO_MODE);
   const double so=AccountInfoDouble(ACCOUNT_MARGIN_SO_SO);
   if(so_mode==ACCOUNT_STOPOUT_MODE_PERCENT)
     {
      const double current_so_distance=CurrentStopOutDistanceMoney();
      const double projected_so_distance=check.equity-(stress_margin*so/100.0);
      const double stress_floor=so+CFG_EMERGENCY_MIN_SO_BUFFER_PCT_POINTS;
      if(projected_so_distance<=current_so_distance+0.01)
        {
         g.reason="Emergency hedge does not improve stop-out distance";
         return false;
        }
      if(g.stress_margin_level<stress_floor)
        {
         g.reason=StringFormat("Emergency stress margin %.1f%% < survival floor %.1f%%",g.stress_margin_level,stress_floor);
         return false;
        }
     }
   else
     {
      const double required_equity=so+MathMax(0.0,CFG_STOP_OUT_MONEY_BUFFER);
      if(g.stress_equity<=required_equity)
        {
         g.reason=StringFormat("Emergency stress equity %.2f <= stopout buffer %.2f",g.stress_equity,required_equity);
         return false;
        }
     }

   g.allowed=true;
   g.reason="PASS_EMERGENCY_SURVIVAL_IMPROVEMENT";
   return true;
  }

bool OpenHedge(const ENUM_ORDER_TYPE type,const double requested_volume,const bool emergency=false)
  {
   const double volume=NormalizeVolumeFloor(requested_volume);
   if(volume<=0.0)
     {
      g_last_block_reason="Requested hedge is below minimum lot";
      return false;
     }

   GateResult gate;
   const bool gate_ok=(emergency ? CheckEmergencyCandidate(type,volume,gate) : CheckCandidate(type,volume,gate));
   if(!gate_ok || !gate.allowed)
     {
      g_last_block_reason=gate.reason;
      LogStatusThrottled((emergency ? "Emergency hedge blocked: " : "New hedge blocked: ")+gate.reason);
      return false;
     }

   trade.SetExpertMagicNumber((ulong)InpHedgeMagic);
   trade.SetDeviationInPoints((ulong)MathMax(0,CFG_DEVIATION_POINTS));
   trade.SetTypeFillingBySymbol(g_symbol);

   bool sent=false;
   if(type==ORDER_TYPE_BUY)
      sent=trade.Buy(volume,g_symbol,0.0,0.0,0.0,"LPH HedgeGuard");
   else
      sent=trade.Sell(volume,g_symbol,0.0,0.0,0.0,"LPH HedgeGuard");

   if(!sent || !TradeRetcodeOK())
     {
      g_last_block_reason=StringFormat("Trade failed: %u %s",trade.ResultRetcode(),trade.ResultRetcodeDescription());
      MarkFailure();
      LogStatusThrottled(g_last_block_reason);
      return false;
     }

   MarkAction(StringFormat("Opened %s%s hedge %.2f lots; projected ML %.1f%%, stress ML %.1f%%",
                           (emergency ? "EMERGENCY " : ""),(type==ORDER_TYPE_BUY ? "BUY" : "SELL"),volume,gate.check_margin_level,gate.stress_margin_level));
   g_last_block_reason="";
   return true;
  }

bool IsOwnedHedgeTicket(const ulong ticket)
  {
   if(ticket==0 || !PositionSelectByTicket(ticket))
      return false;
   return (PositionGetString(POSITION_SYMBOL)==g_symbol &&
           (long)PositionGetInteger(POSITION_MAGIC)==InpHedgeMagic);
  }

bool SafeCloseOwnHedge(const ulong ticket)
  {
   if(!IsOwnedHedgeTicket(ticket))
     {
      g_last_block_reason=StringFormat("SAFETY BLOCK: close ticket #%I64u is not owned by InpHedgeMagic",ticket);
      LogStatusThrottled(g_last_block_reason);
      return false;
     }
   return trade.PositionClose(ticket,(ulong)MathMax(0,CFG_DEVIATION_POINTS));
  }

bool SafeCloseOwnHedgePartial(const ulong ticket,const double volume)
  {
   if(!IsOwnedHedgeTicket(ticket))
     {
      g_last_block_reason=StringFormat("SAFETY BLOCK: partial-close ticket #%I64u is not owned by InpHedgeMagic",ticket);
      LogStatusThrottled(g_last_block_reason);
      return false;
     }
   return trade.PositionClosePartial(ticket,volume,(ulong)MathMax(0,CFG_DEVIATION_POINTS));
  }

bool SafeCloseByOwnHedges(const ulong first_ticket,const ulong second_ticket)
  {
   const bool first_owned=IsOwnedHedgeTicket(first_ticket);
   const bool second_owned=IsOwnedHedgeTicket(second_ticket);
   if(!first_owned || !second_owned)
     {
      g_last_block_reason=StringFormat("SAFETY BLOCK: CloseBy tickets #%I64u/#%I64u must both use InpHedgeMagic",first_ticket,second_ticket);
      LogStatusThrottled(g_last_block_reason);
      return false;
     }
   return trade.PositionCloseBy(first_ticket,second_ticket);
  }

// Close up to requested volume from this EA's positions of a specific type.
bool ReduceOwnHedge(const ENUM_POSITION_TYPE type,const double requested_volume)
  {
   double remaining=NormalizeVolumeFloor(requested_volume);
   if(remaining<=0.0)
      return false;

   const double minv=SymbolInfoDouble(g_symbol,SYMBOL_VOLUME_MIN);
   bool acted=false;

   // One trade action per timer cycle keeps behavior deterministic and easier to audit.
   const int total=PositionsTotal();
   for(int i=total-1;i>=0;i--)
     {
      const ulong ticket=PositionGetTicket(i);
      if(ticket==0 || !PositionSelectByTicket(ticket))
         continue;
      if(PositionGetString(POSITION_SYMBOL)!=g_symbol)
         continue;
      if((long)PositionGetInteger(POSITION_MAGIC)!=InpHedgeMagic)
         continue;
      if((ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE)!=type)
         continue;

      const double posvol=PositionGetDouble(POSITION_VOLUME);
      double closevol=MathMin(posvol,remaining);
      closevol=NormalizeVolumeFloor(closevol);
      if(closevol<=0.0)
         continue;

      // Avoid leaving an invalid dust remainder.
      if(posvol-closevol>1e-12 && posvol-closevol<minv-1e-12)
         closevol=posvol;

      trade.SetExpertMagicNumber((ulong)InpHedgeMagic);
      trade.SetDeviationInPoints((ulong)MathMax(0,CFG_DEVIATION_POINTS));
      trade.SetTypeFillingBySymbol(g_symbol);

      bool ok=false;
      if(MathAbs(closevol-posvol)<1e-12)
         ok=SafeCloseOwnHedge(ticket);
      else
         ok=SafeCloseOwnHedgePartial(ticket,closevol);

      if(ok && TradeRetcodeOK())
        {
         MarkAction(StringFormat("Reduced %s hedge %.2f lots",(type==POSITION_TYPE_BUY ? "BUY" : "SELL"),closevol));
         g_last_block_reason="";
         acted=true;
        }
      else
        {
         g_last_block_reason=StringFormat("Hedge reduction failed: %u %s",trade.ResultRetcode(),trade.ResultRetcodeDescription());
         MarkFailure();
         LogStatusThrottled(g_last_block_reason);
        }
      break;
     }
   return acted;
  }

bool CloseBySupported()
  {
   const long mode=SymbolInfoInteger(g_symbol,SYMBOL_ORDER_MODE);
   return ((mode & SYMBOL_ORDER_CLOSEBY)==SYMBOL_ORDER_CLOSEBY);
  }

// Removes one opposing pair created by this EA. This preserves hedge net lots
// while reducing gross inventory and usually saves one spread versus two closes.
bool CompactOwnHedgePair()
  {
   if(!CFG_AUTO_COMPACT_OWN_HEDGES || !CloseBySupported())
      return false;

   ulong buy_ticket=0,sell_ticket=0;
   double buy_vol=0.0,sell_vol=0.0;
   const int total=PositionsTotal();

   for(int i=0;i<total;i++)
     {
      const ulong ticket=PositionGetTicket(i);
      if(ticket==0 || !PositionSelectByTicket(ticket))
         continue;
      if(PositionGetString(POSITION_SYMBOL)!=g_symbol)
         continue;
      if((long)PositionGetInteger(POSITION_MAGIC)!=InpHedgeMagic)
         continue;

      const ENUM_POSITION_TYPE type=(ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      const double v=PositionGetDouble(POSITION_VOLUME);
      if(type==POSITION_TYPE_BUY && v>buy_vol)
        {
         buy_vol=v;
         buy_ticket=ticket;
        }
      else if(type==POSITION_TYPE_SELL && v>sell_vol)
        {
         sell_vol=v;
         sell_ticket=ticket;
        }
     }

   if(buy_ticket==0 || sell_ticket==0)
      return false;

   trade.SetExpertMagicNumber((ulong)InpHedgeMagic);
   const bool ok=SafeCloseByOwnHedges(buy_ticket,sell_ticket);
   if(ok && TradeRetcodeOK())
     {
      MarkAction(StringFormat("Compacted self-hedges BUY #%I64u vs SELL #%I64u",buy_ticket,sell_ticket));
      g_last_block_reason="";
      return true;
     }

   g_last_block_reason=StringFormat("Self-hedge compaction failed: %u %s",trade.ResultRetcode(),trade.ResultRetcodeDescription());
   MarkFailure();
   LogStatusThrottled(g_last_block_reason);
   return false;
  }

void EvaluateRecommendation(const ExposureStats &s,Recommendation &r)
  {
   ZeroMemory(r);
   r.state=DECISION_SAFE_HOLD;
   r.action=ACTION_NONE;
   r.state_text="HEDGE SAFE / HOLD";
   r.action_text="NO HEDGE ACTION";
   r.reason="No hedge adjustment required";
   r.can_execute=true;
   r.action_needed=false;
   r.current_ratio=CurrentCoverageRatio(s);
   r.target_ratio=ComputeTargetHedgeRatio(s);
   r.desired_hedge_net=-s.core_net*r.target_ratio;

   if(InpMaxHedgeLots>0.0)
      r.desired_hedge_net=Clamp(r.desired_hedge_net,-InpMaxHedgeLots,InpMaxHedgeLots);
   r.delta=r.desired_hedge_net-s.hedge_net;

   if(!IsHedgingAccount())
     {
      r.state=DECISION_BLOCKED;
      r.state_text="BLOCKED";
      r.action_text="NO EXECUTION";
      r.reason="MT5 retail hedging account required";
      r.can_execute=false;
      return;
     }

   const double current_ml=CurrentMarginLevel();
   if(current_ml<CFG_EMERGENCY_DELEVERAGE_LEVEL)
      g_emergency_active=true;
   if(g_emergency_active && current_ml>=CFG_EMERGENCY_TARGET_LEVEL)
      g_emergency_active=false;

   const double step=SymbolInfoDouble(g_symbol,SYMBOL_VOLUME_STEP);
   const double epsilon=MathMax(1e-12,step*0.49);

   // Opposing hedge positions created by this EA add gross exposure without
   // changing hedge net. Compact them before proposing any new inventory.
   if(CFG_AUTO_COMPACT_OWN_HEDGES && s.hedge_buy>epsilon && s.hedge_sell>epsilon)
     {
      const double matched=NormalizeVolumeFloor(MathMin(s.hedge_buy,s.hedge_sell));
      r.state=DECISION_REDUCE_HEDGE;
      r.action=ACTION_COMPACT_SELF_HEDGES;
      r.state_text="REDUCE HEDGE";
      r.action_needed=true;
      r.candidate_volume=matched;
      r.can_execute=(CloseBySupported() && matched>0.0);
      r.action_text=(matched>0.0 ? StringFormat("COMPACT %.2f LOT SELF-HEDGE",matched) : "COMPACT SELF-HEDGES");
      r.reason=(CloseBySupported() ? "Opposing self-hedges increase gross exposure" : "Close By unsupported; reduce opposing self-hedges manually");
      return;
     }

   // Margin survival outranks hedge coverage, but emergency mode is no longer
   // a blanket veto. A new opposite hedge is allowed only when OrderCheck proves
   // that it improves margin/free-margin/stop-out survival.
   if(CFG_ALLOW_EMERGENCY_DELEVERAGE && g_emergency_active)
     {
      r.state=DECISION_EMERGENCY;
      r.state_text="EMERGENCY";
      r.action_needed=true;

      const double loss=CoreLossPct(s);
      const bool mode_entry=(InpHedgeMode==HEDGE_MODE_LEANING ? r.target_ratio>0.0 : loss>=CFG_HEDGE_START_CORE_LOSS_PCT);
      if(MathAbs(s.core_net)>epsilon && mode_entry && MathAbs(r.delta)>epsilon)
        {
         const ENUM_ORDER_TYPE etype=(r.delta>0.0 ? ORDER_TYPE_BUY : ORDER_TYPE_SELL);
         const double evol=NormalizeVolumeFloor(MathAbs(r.delta));
         if(evol>0.0)
           {
            GateResult egate;
            const bool epass=CheckEmergencyCandidate(etype,evol,egate) && egate.allowed;
            r.gate=egate;
            r.candidate_type=etype;
            r.candidate_volume=evol;
            if(epass)
              {
               r.action=(etype==ORDER_TYPE_BUY ? ACTION_EMERGENCY_OPEN_BUY_HEDGE : ACTION_EMERGENCY_OPEN_SELL_HEDGE);
               r.can_execute=true;
               r.action_text=StringFormat("EMERGENCY %s HEDGE %.2f LOT",(etype==ORDER_TYPE_BUY ? "BUY" : "SELL"),evol);
               r.reason=StringFormat("Survival improves: margin %.1f%% -> %.1f%%",current_ml,egate.check_margin_level);
               return;
              }
            r.action=ACTION_NONE;
            r.can_execute=false;
            r.action_text="NO SAFE AUTO ACTION";
            r.reason=(egate.reason!="" ? egate.reason : "Emergency hedge fails survival-improvement test");
            return;
           }
        }

      r.action=ACTION_NONE;
      r.candidate_volume=0.0;
      r.can_execute=false;
      r.action_text="MANUAL DELEVERAGE REQUIRED";
      r.reason="Emergency margin state; core positions require manual deleveraging and no survival-improving hedge is available";
      return;
     }

   // No core net exposure means any remaining self-hedge is orphaned inventory.
   if(MathAbs(s.core_net)<=epsilon)
     {
      if(s.hedge_net>epsilon)
        {
         r.state=DECISION_REDUCE_HEDGE;
         r.action=ACTION_REDUCE_BUY_HEDGE;
         r.state_text="REDUCE HEDGE";
         r.candidate_volume=NormalizeVolumeFloor(s.hedge_net);
         r.action_needed=(r.candidate_volume>0.0);
         r.can_execute=r.action_needed;
         r.action_text=StringFormat("CLOSE BUY HEDGE %.2f LOT",r.candidate_volume);
         r.reason="Core net exposure is flat; BUY hedge is orphaned";
         return;
        }
      if(s.hedge_net<-epsilon)
        {
         r.state=DECISION_REDUCE_HEDGE;
         r.action=ACTION_REDUCE_SELL_HEDGE;
         r.state_text="REDUCE HEDGE";
         r.candidate_volume=NormalizeVolumeFloor(MathAbs(s.hedge_net));
         r.action_needed=(r.candidate_volume>0.0);
         r.can_execute=r.action_needed;
         r.action_text=StringFormat("CLOSE SELL HEDGE %.2f LOT",r.candidate_volume);
         r.reason="Core net exposure is flat; SELL hedge is orphaned";
         return;
        }

      r.reason="No core net exposure and no orphaned hedge";
      return;
     }

   if(MathAbs(r.delta)<=epsilon)
     {
      if(InpHedgeMode==HEDGE_MODE_LEANING)
        {
         if(g_invalidation.state==INVAL_NONE)
            r.reason="No closed-bar EMA invalidation";
         else if(g_invalidation.state==INVAL_STAGE1)
            r.reason="Stage 1 leaning hedge is at target";
         else
            r.reason="Stage 2 ratio is frozen; close invalidated core manually";
        }
      else
        {
         const double loss=CoreLossPct(s);
         if(loss<=CFG_RECOVERY_CORE_LOSS_PCT)
            r.reason="Core loss is below recovery threshold";
         else if(loss<CFG_HEDGE_START_CORE_LOSS_PCT)
            r.reason="Inside hedge hysteresis band; hold current coverage";
         else
            r.reason="Current hedge coverage is at target";
        }
      return;
     }

   // Prefer reducing an existing hedge before opening an opposite hedge.
   if(r.delta>epsilon && s.hedge_net<0.0)
     {
      const double v=NormalizeVolumeFloor(MathMin(r.delta,MathAbs(s.hedge_net)));
      r.state=DECISION_REDUCE_HEDGE;
      r.action=ACTION_REDUCE_SELL_HEDGE;
      r.state_text="REDUCE HEDGE";
      r.candidate_volume=v;
      r.action_needed=(v>0.0);
      r.can_execute=r.action_needed;
      r.action_text=(v>0.0 ? StringFormat("CLOSE SELL HEDGE %.2f LOT",v) : "HOLD");
      r.reason=(v>0.0 ? "Current SELL hedge exceeds required coverage" : "Required hedge reduction is below broker minimum lot");
      return;
     }

   if(r.delta<-epsilon && s.hedge_net>0.0)
     {
      const double v=NormalizeVolumeFloor(MathMin(MathAbs(r.delta),MathAbs(s.hedge_net)));
      r.state=DECISION_REDUCE_HEDGE;
      r.action=ACTION_REDUCE_BUY_HEDGE;
      r.state_text="REDUCE HEDGE";
      r.candidate_volume=v;
      r.action_needed=(v>0.0);
      r.can_execute=r.action_needed;
      r.action_text=(v>0.0 ? StringFormat("CLOSE BUY HEDGE %.2f LOT",v) : "HOLD");
      r.reason=(v>0.0 ? "Current BUY hedge exceeds required coverage" : "Required hedge reduction is below broker minimum lot");
      return;
     }

   r.candidate_type=(r.delta>0.0 ? ORDER_TYPE_BUY : ORDER_TYPE_SELL);
   r.candidate_volume=NormalizeVolumeFloor(MathAbs(r.delta));

   if(r.candidate_volume<=0.0)
     {
      const double minv=SymbolInfoDouble(g_symbol,SYMBOL_VOLUME_MIN);
      r.state=DECISION_HEDGE_BLOCKED;
      r.state_text="HEDGE BLOCKED";
      r.action_text="WAIT - LOT GRANULARITY";
      r.reason=StringFormat("Required %.3f lot is below broker minimum %.3f",MathAbs(r.delta),minv);
      r.can_execute=false;
      return;
     }

   GateResult gate;
   const bool pass=CheckCandidate(r.candidate_type,r.candidate_volume,gate) && gate.allowed;
   r.gate=gate;
   r.action_needed=true;

   if(pass)
     {
      r.state=DECISION_HEDGE_REQUIRED;
      r.action=(r.candidate_type==ORDER_TYPE_BUY ? ACTION_OPEN_BUY_HEDGE : ACTION_OPEN_SELL_HEDGE);
      r.state_text="HEDGE REQUIRED";
      r.action_text=StringFormat("%s HEDGE %.2f LOT %s",
                                 (r.candidate_type==ORDER_TYPE_BUY ? "BUY" : "SELL"),
                                 r.candidate_volume,g_symbol);
      r.reason="All execution and margin-survival gates passed";
      r.can_execute=true;
     }
   else
     {
      r.state=DECISION_HEDGE_BLOCKED;
      r.action=ACTION_NONE;
      r.state_text="HEDGE BLOCKED";
      r.action_text="WAIT - DO NOT ADD HEDGE";
      r.reason=(gate.reason!="" ? gate.reason : "Candidate hedge failed execution gate");
      r.can_execute=false;
     }
  }

bool ExecuteRecommendation(const Recommendation &r)
  {
   // Defense in depth: every OrderSend-equivalent action remains behind the
   // same explicit user-controlled auto-trading gate as OnTimer.
   if(!InpEnableAutoTrading)
      return false;
   if(!r.action_needed || !r.can_execute || !ActionCooldownPassed())
      return false;

   switch(r.action)
     {
      case ACTION_OPEN_BUY_HEDGE:
         return OpenHedge(ORDER_TYPE_BUY,r.candidate_volume);
      case ACTION_OPEN_SELL_HEDGE:
         return OpenHedge(ORDER_TYPE_SELL,r.candidate_volume);
      case ACTION_REDUCE_BUY_HEDGE:
         return ReduceOwnHedge(POSITION_TYPE_BUY,r.candidate_volume);
      case ACTION_REDUCE_SELL_HEDGE:
         return ReduceOwnHedge(POSITION_TYPE_SELL,r.candidate_volume);
      case ACTION_COMPACT_SELF_HEDGES:
         return CompactOwnHedgePair();
      case ACTION_EMERGENCY_OPEN_BUY_HEDGE:
         return OpenHedge(ORDER_TYPE_BUY,r.candidate_volume,true);
      case ACTION_EMERGENCY_OPEN_SELL_HEDGE:
         return OpenHedge(ORDER_TYPE_SELL,r.candidate_volume,true);
      case ACTION_NONE:
      default:
         return false;
     }
  }

void ManageHedge()
  {
   ExposureStats s;
   BuildExposure(s);

   Recommendation r;
   EvaluateRecommendation(s,r);

   if(r.state==DECISION_HEDGE_BLOCKED || r.state==DECISION_BLOCKED)
     {
      g_last_block_reason=r.reason;
      return;
     }

   if(r.state==DECISION_EMERGENCY && !r.can_execute)
     {
      g_last_block_reason=r.reason;
      LogStatusThrottled(g_last_block_reason);
      return;
     }

   if(r.action_needed)
      ExecuteRecommendation(r);
   else
      g_last_block_reason="";
  }

string StopOutModeText()
  {
   const ENUM_ACCOUNT_STOPOUT_MODE mode=(ENUM_ACCOUNT_STOPOUT_MODE)AccountInfoInteger(ACCOUNT_MARGIN_SO_MODE);
   return (mode==ACCOUNT_STOPOUT_MODE_PERCENT ? "PERCENT" : "MONEY");
  }

color DecisionColor(const ENUM_DECISION_STATE state)
  {
   switch(state)
     {
      case DECISION_SAFE_HOLD:      return clrLimeGreen;
      case DECISION_HEDGE_REQUIRED: return clrDeepSkyBlue;
      case DECISION_HEDGE_BLOCKED:  return clrGold;
      case DECISION_REDUCE_HEDGE:   return clrAqua;
      case DECISION_EMERGENCY:      return clrTomato;
      case DECISION_BLOCKED:
      default:                      return clrTomato;
     }
  }

void DeleteDashboardObjects()
  {
   const int total=ObjectsTotal(0,0,-1);
   for(int i=total-1;i>=0;i--)
     {
      const string name=ObjectName(0,i,0,-1);
      if(StringFind(name,DASH_PREFIX,0)==0)
         ObjectDelete(0,name);
     }
  }

void UpsertPanel(const string suffix)
  {
   const string name=DASH_PREFIX+suffix;
   if(ObjectFind(0,name)<0)
      ObjectCreate(0,name,OBJ_RECTANGLE_LABEL,0,0,0);

   ObjectSetInteger(0,name,OBJPROP_CORNER,InpDashboardCorner);
   ObjectSetInteger(0,name,OBJPROP_XDISTANCE,InpDashboardX);
   ObjectSetInteger(0,name,OBJPROP_YDISTANCE,InpDashboardY);
   ObjectSetInteger(0,name,OBJPROP_XSIZE,MathMax(300,DASH_WIDTH));
   ObjectSetInteger(0,name,OBJPROP_YSIZE,MathMax(260,DASH_HEIGHT));
   ObjectSetInteger(0,name,OBJPROP_BGCOLOR,clrBlack);
   ObjectSetInteger(0,name,OBJPROP_BORDER_COLOR,clrDimGray);
   ObjectSetInteger(0,name,OBJPROP_BACK,false);
   ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
   ObjectSetInteger(0,name,OBJPROP_SELECTED,false);
   ObjectSetInteger(0,name,OBJPROP_HIDDEN,true);
   ObjectSetInteger(0,name,OBJPROP_ZORDER,0);
  }

void UpsertLabel(const string suffix,const int x,const int y,const string text,
                 const int font_size,const color clr,const bool bold=false)
  {
   const string name=DASH_PREFIX+suffix;

   // MT5 can display the default word "Label" when a newly created OBJ_LABEL
   // is assigned an empty string. Remove empty rows instead of creating them.
   if(StringLen(text)==0)
     {
      if(ObjectFind(0,name)>=0)
         ObjectDelete(0,name);
      return;
     }

   if(ObjectFind(0,name)<0)
      ObjectCreate(0,name,OBJ_LABEL,0,0,0);

   ObjectSetInteger(0,name,OBJPROP_CORNER,InpDashboardCorner);
   ObjectSetInteger(0,name,OBJPROP_XDISTANCE,InpDashboardX+x);
   ObjectSetInteger(0,name,OBJPROP_YDISTANCE,InpDashboardY+y);
   ObjectSetInteger(0,name,OBJPROP_COLOR,clr);
   ObjectSetInteger(0,name,OBJPROP_FONTSIZE,MathMax(8,font_size));
   ObjectSetInteger(0,name,OBJPROP_ANCHOR,ANCHOR_LEFT_UPPER);
   ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
   ObjectSetInteger(0,name,OBJPROP_SELECTED,false);
   ObjectSetInteger(0,name,OBJPROP_HIDDEN,true);
   ObjectSetInteger(0,name,OBJPROP_ZORDER,1);
   ObjectSetString(0,name,OBJPROP_FONT,(bold ? "Arial Bold" : "Arial"));
   ObjectSetString(0,name,OBJPROP_TEXT,text);
  }

string NetSideText(const double net)
  {
   const double step=SymbolInfoDouble(g_symbol,SYMBOL_VOLUME_STEP);
   const double eps=MathMax(1e-12,step*0.49);
   if(net>eps) return StringFormat("+%.2f BUY",net);
   if(net<-eps) return StringFormat("%.2f SELL",net);
   return "0.00 FLAT";
  }

string DirectionalRiskText(const ExposureStats &s)
  {
   const double step=SymbolInfoDouble(g_symbol,SYMBOL_VOLUME_STEP);
   const double eps=MathMax(1e-12,step*0.49);
   if(MathAbs(s.combined_net)<=eps) return "NEUTRAL";
   return (s.combined_net>0.0 ? "LONG EXPOSURE" : "SHORT EXPOSURE");
  }

string MarginRiskText(const double margin_level,const double gross_lots)
  {
   const double step=SymbolInfoDouble(g_symbol,SYMBOL_VOLUME_STEP);
   const double eps=MathMax(1e-12,step*0.49);
   if(gross_lots<=eps) return "NONE";

   // Classification is relative to the active operating mode. A normal-vol
   // account above the 200% floor should not be labelled CAUTION merely
   // because it is below the separate 300% event-mode floor.
   const double floor=RequiredNewHedgeMarginLevel();
   if(margin_level<CFG_EMERGENCY_DELEVERAGE_LEVEL) return "EMERGENCY";
   if(margin_level<floor) return "HIGH";
   if(margin_level<floor+50.0) return "CAUTION";
   return "CONTROLLED";
  }

color MarginRiskColor(const double margin_level,const double gross_lots)
  {
   const double step=SymbolInfoDouble(g_symbol,SYMBOL_VOLUME_STEP);
   const double eps=MathMax(1e-12,step*0.49);
   if(gross_lots<=eps) return clrLimeGreen;

   const double floor=RequiredNewHedgeMarginLevel();
   if(margin_level<CFG_EMERGENCY_DELEVERAGE_LEVEL) return clrTomato;
   if(margin_level<floor) return clrOrangeRed;
   if(margin_level<floor+50.0) return clrGold;
   return clrLimeGreen;
  }

void SplitDashboardText(const string src,const int max_chars,string &line1,string &line2)
  {
   line1=src;
   line2="";
   const int n=StringLen(src);
   if(n<=max_chars) return;

   int cut=max_chars;
   for(int i=max_chars;i>0;i--)
     {
      if(StringSubstr(src,i,1)==" ")
        {
         cut=i;
         break;
        }
     }
   line1=StringSubstr(src,0,cut);
   line2=StringSubstr(src,cut);
   StringTrimLeft(line2);
  }

void UpdateDashboard()
  {
   if(!CFG_SHOW_DASHBOARD)
     {
      DeleteDashboardObjects();
      Comment("");
      return;
     }

   Comment("");

   ExposureStats s;
   BuildExposure(s);
   Recommendation r;
   EvaluateRecommendation(s,r);

   const double balance=AccountInfoDouble(ACCOUNT_BALANCE);
   const double equity=AccountInfoDouble(ACCOUNT_EQUITY);
   const double margin=AccountInfoDouble(ACCOUNT_MARGIN);
   const double free_margin=AccountInfoDouble(ACCOUNT_MARGIN_FREE);
   const double ml=CurrentMarginLevel();
   const double so=AccountInfoDouble(ACCOUNT_MARGIN_SO_SO);
   const double so_distance=CurrentStopOutDistanceMoney();
   const double loss_pct=CoreLossPct(s);
   const double coverage=CurrentCoverageRatio(s)*100.0;
   const double target=r.target_ratio*100.0;
   const double atr=CurrentATR();

   MqlTick tick;
   double spread=0.0,spread_frac=0.0;
   if(SymbolInfoTick(g_symbol,tick))
     {
      spread=MathMax(0.0,tick.ask-tick.bid);
      if(atr>0.0) spread_frac=spread/atr;
     }

   string projected="N/A (no new hedge)";
   string stressed="N/A (no new hedge)";
   if(r.candidate_volume>0.0 && r.gate.check_margin_level>0.0)
      projected=StringFormat("%.1f%%",r.gate.check_margin_level);
   if(r.candidate_volume>0.0 && r.gate.stress_margin_level!=0.0)
      stressed=StringFormat("%.1f%%",r.gate.stress_margin_level);

   string reason1="",reason2="";
   SplitDashboardText("Reason: "+r.reason,66,reason1,reason2);

   const color state_color=DecisionColor(r.state);
   const color normal_text=clrWhite;
   const color muted=clrSilver;
   const color margin_color=MarginRiskColor(ml,s.combined_gross);
   const bool spread_ok=(atr>0.0 && spread_frac<=CFG_MAX_SPREAD_ATR_FRAC);
   const color gate_color=(atr<=0.0 ? clrGold : (spread_frac<=0.10 ? clrLimeGreen : (spread_frac<=CFG_EMERGENCY_MAX_SPREAD_ATR_FRAC ? clrGold : clrRed)));
   const string spread_band=(atr<=0.0 ? "ATR UNAVAILABLE" : SpreadBandText(spread_frac));
   double need_hedge=r.desired_hedge_net;
   if(MathAbs(need_hedge)<1e-9) need_hedge=0.0;

   UpsertPanel("BG");
   const string mode_state=(InpHedgeMode==HEDGE_MODE_LEANING ?
                            HedgeModeText()+" | "+InvalidationStateText() : HedgeModeText());
   const color mode_color=(g_invalidation.state==INVAL_STAGE2 && InpHedgeMode==HEDGE_MODE_LEANING ? clrTomato :
                           (g_invalidation.state==INVAL_STAGE1 && InpHedgeMode==HEDGE_MODE_LEANING ? clrGold : muted));
   UpsertLabel("TITLE",14,10,"LPH COMPUTATIONAL HEDGE GUARD  v1.00.2 RC",DASH_FONT_SIZE+1,normal_text,true);
   UpsertLabel("MODE",14,32,StringFormat("%s  |  %s  |  %s  |  %s",
               (InpEnableAutoTrading?"AUTO EXECUTION":"ADVISORY"),
               (InpHighVolatilityMode?"HIGH VOL":"NORMAL VOL"),g_symbol,mode_state),
               DASH_FONT_SIZE,mode_color,(g_invalidation.state==INVAL_STAGE2 && InpHedgeMode==HEDGE_MODE_LEANING));

   UpsertLabel("STATE_CAP",14,58,"HEDGE STATE",DASH_FONT_SIZE,muted,true);
   UpsertLabel("STATE",14,76,r.state_text,DASH_ACTION_FONT_SIZE,state_color,true);
   UpsertLabel("ACTION_CAP",14,104,"ACTION",DASH_FONT_SIZE,muted,true);
   UpsertLabel("ACTION",14,122,r.action_text,DASH_ACTION_FONT_SIZE,state_color,true);
   UpsertLabel("REASON1",14,151,reason1,DASH_FONT_SIZE,normal_text,false);
   UpsertLabel("REASON2",14,170,reason2,DASH_FONT_SIZE,normal_text,false);

   UpsertLabel("EXPOSURE_HDR",14,197,"EXPOSURE",DASH_FONT_SIZE,muted,true);
   UpsertLabel("EXPOSURE1",14,216,StringFormat("Core Net: %s   |   Core Gross: %.2f",NetSideText(s.core_net),s.core_gross),DASH_FONT_SIZE,normal_text,false);
   UpsertLabel("EXPOSURE2",14,235,StringFormat("Hedge Net: %s   |   Hedge Gross: %.2f",NetSideText(s.hedge_net),s.hedge_gross),DASH_FONT_SIZE,normal_text,false);
   UpsertLabel("EXPOSURE3",14,254,StringFormat("Combined Net: %s   |   Combined Gross: %.2f",NetSideText(s.combined_net),s.combined_gross),DASH_FONT_SIZE,normal_text,false);
   UpsertLabel("EXPOSURE4",14,273,StringFormat("Coverage: %.1f%% -> %.1f%%   |   Need Hedge: %.3f",coverage,target,need_hedge),DASH_FONT_SIZE,normal_text,false);
   UpsertLabel("EXPOSURE5",14,292,StringFormat("Core Floating Loss: %.2f%%",loss_pct),DASH_FONT_SIZE,normal_text,false);

   UpsertLabel("RISK_HDR",14,319,"RISK / SURVIVAL",DASH_FONT_SIZE,muted,true);
   UpsertLabel("RISK_STATUS",14,338,StringFormat("Directional: %s   |   Gross / Margin: %s",DirectionalRiskText(s),MarginRiskText(ml,s.combined_gross)),DASH_FONT_SIZE,margin_color,true);
   UpsertLabel("RISK1",14,357,StringFormat("Margin: %.1f%%   |   New-Hedge Floor: %.1f%%",ml,RequiredNewHedgeMarginLevel()),DASH_FONT_SIZE,normal_text,false);
   UpsertLabel("RISK2",14,376,StringFormat("Emergency: %.1f%%   |   Broker SO: %.1f%%",CFG_EMERGENCY_DELEVERAGE_LEVEL,so),DASH_FONT_SIZE,normal_text,false);
   UpsertLabel("RISK3",14,395,StringFormat("Projected: %s   |   Stress: %s",projected,stressed),DASH_FONT_SIZE,normal_text,false);
   UpsertLabel("RISK4",14,414,StringFormat("SO Distance: %.2f   |   Free Margin: %.2f",so_distance,free_margin),DASH_FONT_SIZE,normal_text,false);

   UpsertLabel("MARKET_HDR",14,441,"MARKET / GATE",DASH_FONT_SIZE,muted,true);
   UpsertLabel("MARKET1",14,460,StringFormat("ATR(M5): %.5f   |   Spread: %.5f",atr,spread),DASH_FONT_SIZE,normal_text,false);
   UpsertLabel("MARKET2",14,479,StringFormat("Spread/ATR: %.1f%%   |   Band: %s",spread_frac*100.0,spread_band),DASH_FONT_SIZE,gate_color,true);
   UpsertLabel("MARKET3",14,498,StringFormat("Normal Max: %.1f%%   |   Emergency Max: %.1f%%",CFG_MAX_SPREAD_ATR_FRAC*100.0,CFG_EMERGENCY_MAX_SPREAD_ATR_FRAC*100.0),DASH_FONT_SIZE,normal_text,false);

   string footer=StringFormat("Bal %.2f | Eq %.2f | Used Mgn %.2f",balance,equity,margin);
   if(g_last_action!="None")
      footer+=" | Last: "+g_last_action;
   UpsertLabel("FOOTER",14,526,footer,MathMax(8,DASH_FONT_SIZE-1),muted,false);

   ChartRedraw(0);
  }

bool ValidateInputs()
  {
   if(InpHedgeMagic<=0)
     {
      Print("[HedgeGuard] InpHedgeMagic must be > 0");
      return false;
     }
   if(InpCoreScope==CORE_SPECIFIC_MAGIC && InpCoreMagic==InpHedgeMagic)
     {
      Print("[HedgeGuard] Core magic and hedge magic must differ");
      return false;
     }
   if(InpMaxHedgeLots<0.0)
     {
      Print("[HedgeGuard] InpMaxHedgeLots must be >= 0.00");
      return false;
     }
   if(InpHedgeMode==HEDGE_MODE_LEANING && InpInvalidationTimeframe==PERIOD_CURRENT)
     {
      Print("[HedgeGuard] LEANING mode requires an explicit InpInvalidationTimeframe; PERIOD_CURRENT is not allowed");
      return false;
     }
   if(CFG_HEDGE_START_CORE_LOSS_PCT<0.0 || CFG_HEDGE_FULL_CORE_LOSS_PCT<CFG_HEDGE_START_CORE_LOSS_PCT)
     {
      Print("[HedgeGuard] Invalid hedge loss thresholds");
      return false;
     }
   if(CFG_RECOVERY_CORE_LOSS_PCT<0.0 || CFG_RECOVERY_CORE_LOSS_PCT>CFG_HEDGE_START_CORE_LOSS_PCT)
     {
      Print("[HedgeGuard] Recovery threshold must be between 0 and hedge-start loss");
      return false;
     }
   if(CFG_BASE_HEDGE_RATIO<0.0 || CFG_BASE_HEDGE_RATIO>1.0 || CFG_MAX_HEDGE_RATIO<CFG_BASE_HEDGE_RATIO || CFG_MAX_HEDGE_RATIO>1.0)
     {
      Print("[HedgeGuard] Hedge ratios must satisfy 0 <= base <= max <= 1");
      return false;
     }
   if(CFG_TIMER_SECONDS<1)
     {
      Print("[HedgeGuard] Timer must be >= 1 second");
      return false;
     }
   return true;
  }

//--------------------------- Events ---------------------------------
int OnInit()
  {
   if(InpHedgeMode==HEDGE_MODE_LEANING && InpCoreScope!=CORE_SPECIFIC_MAGIC)
     {
      Print("[HedgeGuard] LEANING mode requires InpCoreScope=CORE_SPECIFIC_MAGIC; blended symbol cores are invalid");
      return INIT_FAILED;
     }
   if(InpHedgeMode==HEDGE_MODE_LEANING && InpRequireTDIConfirm)
     {
      Print("[HedgeGuard] InpRequireTDIConfirm=true but TDI is not wired in this build; refusing to start (fail-closed). Set false or wire TDI.");
      return INIT_PARAMETERS_INCORRECT;
     }
   if(!ValidateInputs())
      return INIT_PARAMETERS_INCORRECT;

   g_symbol=(InpManagedSymbol=="" ? _Symbol : InpManagedSymbol);
   if(!SymbolSelect(g_symbol,true))
     {
      Print("[HedgeGuard] Unable to select symbol ",g_symbol);
      return INIT_FAILED;
     }

   if(!IsHedgingAccount())
      Print("[HedgeGuard] WARNING: Account is not ACCOUNT_MARGIN_MODE_RETAIL_HEDGING. Execution is disabled by logic.");

   g_atr_handle=iATR(g_symbol,CFG_ATR_TIMEFRAME,CFG_ATR_PERIOD);
   if(g_atr_handle==INVALID_HANDLE)
     {
      Print("[HedgeGuard] Failed to create ATR handle. Error ",GetLastError());
      return INIT_FAILED;
     }

   ResetInvalidationState(false);
   if(InpHedgeMode==HEDGE_MODE_LEANING)
      RestoreStage2Latch();
   if(InpHedgeMode==HEDGE_MODE_LEANING)
     {
      g_invalidation_ema_handle=iMA(g_symbol,InpInvalidationTimeframe,CFG_INVALIDATION_EMA_PERIOD,0,MODE_EMA,PRICE_CLOSE);
      g_invalidation_atr_handle=iATR(g_symbol,InpInvalidationTimeframe,CFG_ATR_PERIOD);
      if(g_invalidation_ema_handle==INVALID_HANDLE || g_invalidation_atr_handle==INVALID_HANDLE)
        {
         Print("[HedgeGuard] Failed to create leaning EMA/ATR handles. Error ",GetLastError());
         if(g_invalidation_ema_handle!=INVALID_HANDLE) IndicatorRelease(g_invalidation_ema_handle);
         if(g_invalidation_atr_handle!=INVALID_HANDLE) IndicatorRelease(g_invalidation_atr_handle);
         IndicatorRelease(g_atr_handle);
         return INIT_FAILED;
        }
      if(InpRequireTDIConfirm)
         Print("[HedgeGuard] WARNING: InpRequireTDIConfirm=true but TDI is not wired; TODO requires custom indicator file and buffer index. Stage 2 currently has no additional TDI gate.");
     }

   trade.SetExpertMagicNumber((ulong)InpHedgeMagic);
   trade.SetDeviationInPoints((ulong)MathMax(0,CFG_DEVIATION_POINTS));
   trade.SetTypeFillingBySymbol(g_symbol);

   EventSetTimer(CFG_TIMER_SECONDS);

   PrintFormat("[HedgeGuard] Initialized on %s | Mode=%s | Auto=%s | AccountMode=%s | Broker SO=%.2f %s",
               g_symbol,HedgeModeText(),(InpEnableAutoTrading?"ON":"OFF"),
               EnumToString((ENUM_ACCOUNT_MARGIN_MODE)AccountInfoInteger(ACCOUNT_MARGIN_MODE)),
               AccountInfoDouble(ACCOUNT_MARGIN_SO_SO),StopOutModeText());

   UpdateDashboard();
   return INIT_SUCCEEDED;
  }

void OnDeinit(const int reason)
  {
   EventKillTimer();
   if(g_atr_handle!=INVALID_HANDLE)
      IndicatorRelease(g_atr_handle);
   if(g_invalidation_ema_handle!=INVALID_HANDLE)
      IndicatorRelease(g_invalidation_ema_handle);
   if(g_invalidation_atr_handle!=INVALID_HANDLE)
      IndicatorRelease(g_invalidation_atr_handle);
   DeleteDashboardObjects();
   Comment("");
  }

void OnTick()
  {
   // Decisions and dashboard refresh are timer-driven to avoid burst-tick duplication
   // and unnecessary chart-object churn during high-volatility events.
  }

void OnTimer()
  {
   if(!InpEnableAutoTrading)
     {
      UpdateDashboard();
      return;
     }
   if(!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) || !MQLInfoInteger(MQL_TRADE_ALLOWED))
     {
      g_last_block_reason="Terminal/EA trading permission is disabled";
      UpdateDashboard();
      return;
     }
   if(!IsHedgingAccount())
     {
      g_last_block_reason="Execution requires MT5 retail hedging account";
      UpdateDashboard();
      return;
     }

   ManageHedge();
   UpdateDashboard();
  }
//+------------------------------------------------------------------+
