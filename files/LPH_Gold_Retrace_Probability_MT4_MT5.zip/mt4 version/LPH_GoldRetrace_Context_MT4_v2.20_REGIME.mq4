//+------------------------------------------------------------------+
//|             GoldRetrace_HistoricalContext_MT4_v2.mq4            |
//| MT4 comparison build for the GoldRetrace empirical framework.    |
//|                                                                  |
//| Purpose                                                          |
//| - Scans available XAUUSD D1 history on INIT and once per new D1. |
//| - Rebuilds the same broad 20-year-style event statistics locally.|
//| - Classifies the most recent qualifying bearish D1 event.        |
//| - Adds broker-relative D1 volume conditioning (20D baseline).    |
//| - Adds conditional ATR continuation decay from the same events.  |
//| - Adds full/modern/recent/current-regime probability segmentation.|
//| - Projects a context-sensitive median continuation target.       |
//| - Modern panel: full framework + prominent actionable state.     |
//| - Places NO orders. Analysis / comparison only.                  |
//|                                                                  |
//| Event definition (defaults):                                     |
//|   bearish D1 body >= 0.40 * ATR(14)                              |
//|   prior run-up >= 5% over prior 20 D1 sessions                   |
//| Outcomes: deeper low <=3D / <=5D, recovery above trigger high    |
//|           <=5D, median additional depth in ATR units.            |
//+------------------------------------------------------------------+
#property strict
#property version   "2.20"

//------------------------------ Inputs ------------------------------
input string InpSymbol                 = "";       // blank = chart symbol
input int    InpATRPeriod              = 14;
input int    InpPriorRunBars           = 20;
input double InpMinRunUpPct            = 5.0;
input double InpMinBodyATR             = 0.40;
input double InpModerateMaxATR         = 1.00;
input double InpMediumMaxATR           = 2.00;
input int    InpForward3Days           = 3;
input int    InpForward5Days           = 5;
input int    InpMaxHistoryBars         = 20000;    // scan cap; 0 = all available
input int    InpMinBucketEvents        = 30;       // fallback to ALL below this N
input bool   InpRecoveryUsesClose      = true;     // closed reclaim, not intraday high

// Volume context: broker-relative tick volume, event day vs PREVIOUS N D1 bars.
// It conditions the existing retracement population; it does not redefine events.
input bool   InpUseVolumeContext       = true;
input int    InpVolMAPeriod            = 20;
input double InpHighVolRatio           = 1.25;     // initial estimate from canonical suite
input int    InpMinVolumeEvents        = 30;       // fallback to body bucket below this N

// Regime lens: same event definition, but gives more relevance to modern/current Gold behavior.
// These filters DO NOT redefine the qualifying event; they segment the already-qualified history.
input int    InpModernStartYear         = 2020;
input int    InpRecentStartYear         = 2022;
input int    InpRegimeEMAPeriod         = 50;       // structural trend classifier
input int    InpRegimeSlopeBars         = 20;       // EMA slope lookback in D1 bars
input double InpRegimeHalfLifeYears     = 4.0;      // event-level recency weighting
input double InpSameRegimeBoost         = 1.50;     // extra weight for same structural regime
input double InpMinWeightedEffectiveN   = 20.0;     // below this, action falls back to matched-context P5
input bool   InpUseRegimeWeightedAction = true;     // use weighted P5 for action headline when reliable

// Conditional continuation decay from trigger low.
input bool   InpUseDecay               = true;
input double InpDecayStepATR           = 0.25;     // P(next +0.25 ATR | already reached X)
input double InpDecayMaxATR            = 2.00;
input double InpDecayStrongPct         = 60.0;     // display/action classification only
input double InpDecayWeakPct           = 45.0;

// Active-event interpretation
input int    InpActiveWindowDays       = 5;
input double InpDeepRunnerATR          = 1.00;     // below trigger low
input bool   InpInvalidateOnH4Close    = true;
input bool   InpInvalidateOnD1Close    = true;

// Optional internal wall references (do not affect the historical scan)
input bool   InpUseWallReferences      = true;
input double InpPutWall                = 4250.0;
input double InpPinStrike              = 4400.0;
input double InpCallWall               = 5200.0;

// Display / export
input bool   InpDrawLevels             = true;
input bool   InpShowPanel              = true;
input bool   InpExportCSV              = true;
input bool   InpAlerts                 = false;
input int    InpPanelCorner            = CORNER_LEFT_UPPER;
input int    InpPanelX                 = 12;
input int    InpPanelY                 = 28;
input bool   InpPanelStartMinimized    = false;    // start with compact panel

//-------------------------- Benchmark scan --------------------------
// Supplied 2006-05-08 -> 2026-08-26 benchmark (5,600 D1 bars)
#define BENCH_ALL_N       860
#define BENCH_ALL_P3      78.5
#define BENCH_ALL_P5      83.0
#define BENCH_ALL_REC     36.4
#define BENCH_ALL_MED     0.59

#define BENCH_MOD_N       638
#define BENCH_MOD_P3      77.3
#define BENCH_MOD_P5      82.6
#define BENCH_MOD_REC     43.7
#define BENCH_MOD_MED     0.55

#define BENCH_MED_N       198
#define BENCH_MED_P3      82.8
#define BENCH_MED_P5      85.4
#define BENCH_MED_REC     16.2
#define BENCH_MED_MED     0.83

#define BENCH_BIG_N       24
#define BENCH_BIG_P3      75.0
#define BENCH_BIG_P5      75.0
#define BENCH_BIG_REC     8.3
#define BENCH_BIG_MED     0.79

//----------------------------- Types --------------------------------
enum EventBucket
  {
   BUCKET_NONE     = 0,
   BUCKET_MODERATE = 1,
   BUCKET_MEDIUM   = 2,
   BUCKET_BIG      = 3
  };

struct HistStats
  {
   int    n;
   int    deeper3;
   int    deeper5;
   int    recovered5;
   double medianDepthATR;
  };

#define MAX_DECAY_STEPS 16

struct EventSample
  {
   datetime t;
   int      bucket;
   int      regime;      // +1 bull, 0 mixed, -1 bear
   double   volRatio;
   bool     d3;
   bool     d5;
   bool     rec;
   double   depthATR;
  };

//----------------------------- Globals ------------------------------
string    gSym="";
string    gPrefix="GRHC4_";
datetime  gLastD1Open=0;
datetime  gLastH4Open=0;

HistStats gAll, gMod, gMed, gBig;
double    gDepthAll[];
double    gDepthMod[];
double    gDepthMed[];
double    gDepthBig[];
EventSample gEvents[];
int       gBarsScanned=0;
datetime  gOldestScanned=0;
datetime  gNewestMatured=0;

bool      gHasActive=false;
bool      gInvalidated=false;
bool      gMedianTargetHit=false;
datetime  gTriggerTime=0;
int       gTriggerShift=-1;
double    gTriggerOpen=0.0;
double    gTriggerHigh=0.0;
double    gTriggerLow=0.0;
double    gTriggerClose=0.0;
double    gTriggerATR=0.0;
double    gTriggerBodyATR=0.0;
double    gTriggerRunUpPct=0.0;
double    gTriggerVolRatio=0.0;
int       gTriggerRegime=0;
EventBucket gTriggerBucket=BUCKET_NONE;
double    gMedianTarget=0.0;
double    gDeepRunnerTarget=0.0;
string    gInvalidReason="";
bool      gAlertedTarget=false;
bool      gAlertedInvalid=false;
bool      gPanelMinimized=false;

// Cached context chosen for the active event.
HistStats gBaseSelected;
HistStats gContextSelected;
bool      gContextUsesVolume=false;
string    gContextSource="BASE";
int       gDecayReached[MAX_DECAY_STEPS];
int       gDecayNext[MAX_DECAY_STEPS];
int       gDecayStepCount=0;

// Regime-segmented statistics for the active event.
HistStats gRegFull, gRegModern, gRegRecent, gRegCurrent;
double    gRegimeWeightedP5=-1.0;
double    gRegimeWeightedEffN=0.0;
bool      gRegimeWeightedUsedForAction=false;

//+------------------------------------------------------------------+
//| Initialization                                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
   gSym=(StringLen(InpSymbol)>0 ? InpSymbol : Symbol());
   if(!SymbolSelect(gSym,true))
     {
      Print("GoldRetrace MT4: cannot select symbol ",gSym);
      return(INIT_FAILED);
     }

   gPanelMinimized=InpPanelStartMinimized;

   RebuildHistoricalContext();
   RefreshActiveEvent(true);

   gLastD1Open=iTime(gSym,PERIOD_D1,0);
   gLastH4Open=iTime(gSym,PERIOD_H4,0);

   if(InpDrawLevels) DrawLevels();
   if(InpShowPanel)  UpdatePanel();
   if(InpExportCSV)  ExportStatsCSV();

   Print("GoldRetrace MT4 loaded | symbol=",gSym,
         " | scanned=",gBarsScanned,
         " | ALL N=",gAll.n,
         " | MOD N=",gMod.n);
   return(INIT_SUCCEEDED);
  }

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   DeleteObjects();
   Comment("");
  }

//+------------------------------------------------------------------+
void OnTick()
  {
   datetime d1Open=iTime(gSym,PERIOD_D1,0);
   if(d1Open!=0 && d1Open!=gLastD1Open)
     {
      gLastD1Open=d1Open;
      // 5-6k D1 bars is tiny. Rebuild once per day, never per tick.
      // This also automatically incorporates newly matured forward outcomes.
      RebuildHistoricalContext();
      RefreshActiveEvent(false);
      if(InpExportCSV) ExportStatsCSV();
     }

   datetime h4Open=iTime(gSym,PERIOD_H4,0);
   if(h4Open!=0 && h4Open!=gLastH4Open)
     {
      gLastH4Open=h4Open;
      if(gHasActive && !gInvalidated)
         CheckH4Invalidation();
     }

   if(gHasActive && !gInvalidated)
     {
      double bid=MarketInfo(gSym,MODE_BID);
      if(bid>0 && gMedianTarget>0 && bid<=gMedianTarget)
        {
         gMedianTargetHit=true;
         if(InpAlerts && !gAlertedTarget)
           {
            Alert(gSym," GoldRetrace: median continuation target reached ~",
                  DoubleToString(gMedianTarget,DigitsForSymbol()));
            gAlertedTarget=true;
           }
        }
     }

   if(InpDrawLevels) DrawLevels();
   if(InpShowPanel)  UpdatePanel();
  }

//+------------------------------------------------------------------+
//| Panel minimize / expand toggle                                   |
//+------------------------------------------------------------------+
void OnChartEvent(const int id,const long &lparam,const double &dparam,const string &sparam)
  {
   if(id!=CHARTEVENT_OBJECT_CLICK) return;
   if(sparam!=gPrefix+"PanelToggle") return;

   gPanelMinimized=!gPanelMinimized;
   ObjectSetInteger(0,gPrefix+"PanelToggle",OBJPROP_STATE,false);
   DeletePanelDetailObjects();
   UpdatePanel();
   ChartRedraw();
  }

//========================== Historical scan =========================
void ResetStats(HistStats &s)
  {
   s.n=0;
   s.deeper3=0;
   s.deeper5=0;
   s.recovered5=0;
   s.medianDepthATR=0.0;
  }

void RebuildHistoricalContext()
  {
   ResetStats(gAll); ResetStats(gMod); ResetStats(gMed); ResetStats(gBig);
   ArrayResize(gDepthAll,0);
   ArrayResize(gDepthMod,0);
   ArrayResize(gDepthMed,0);
   ArrayResize(gDepthBig,0);
   ArrayResize(gEvents,0);
   gBarsScanned=0;
   gOldestScanned=0;
   gNewestMatured=0;

   int total=iBars(gSym,PERIOD_D1);
   int priorNeed=MathMax(InpPriorRunBars,MathMax(InpVolMAPeriod,InpATRPeriod));
   if(total<=priorNeed+InpForward5Days+10)
     {
      Print("GoldRetrace MT4: insufficient D1 history (",total," bars)");
      return;
     }

   int oldestShift=total-priorNeed-2;
   if(InpMaxHistoryBars>0)
      oldestShift=MathMin(oldestShift,InpMaxHistoryBars);

   int minShift=InpForward5Days+1; // guarantees a fully observed 5D outcome
   if(oldestShift<=minShift) return;

   gOldestScanned=iTime(gSym,PERIOD_D1,oldestShift);
   gNewestMatured=iTime(gSym,PERIOD_D1,minShift);

   for(int s=oldestShift; s>=minShift; s--)
     {
      gBarsScanned++;

      double o=iOpen(gSym,PERIOD_D1,s);
      double c=iClose(gSym,PERIOD_D1,s);
      double h=iHigh(gSym,PERIOD_D1,s);
      double l=iLow(gSym,PERIOD_D1,s);
      double atr=iATR(gSym,PERIOD_D1,InpATRPeriod,s);
      if(o<=0 || c<=0 || h<=0 || l<=0 || atr<=0) continue;
      if(c>=o) continue; // bearish body only

      double bodyATR=MathAbs(o-c)/atr;
      if(bodyATR<InpMinBodyATR) continue;

      double runUp=PriorRunUpPct(s);
      if(runUp<InpMinRunUpPct) continue;

      EventBucket bucket=ClassifyBucket(bodyATR);
      double volRatio=VolumeRatioAtShift(s);

      double min3=l;
      double min5=l;
      double maxRecovery=-1.0e308;

      for(int f=1; f<=InpForward5Days; f++)
        {
         int fs=s-f; // newer bar = smaller shift
         if(fs<1) break;

         double fl=iLow(gSym,PERIOD_D1,fs);
         if(fl>0 && fl<min5) min5=fl;
         if(f<=InpForward3Days && fl>0 && fl<min3) min3=fl;

         double rv=(InpRecoveryUsesClose
                    ? iClose(gSym,PERIOD_D1,fs)
                    : iHigh(gSym,PERIOD_D1,fs));
         if(rv>maxRecovery) maxRecovery=rv;
        }

      bool d3=(min3<l);
      bool d5=(min5<l);
      bool rec=(maxRecovery>h);
      double depth=MathMax(0.0,(l-min5)/atr);

      AddObservation(gAll,gDepthAll,d3,d5,rec,depth);
      if(bucket==BUCKET_MODERATE)
         AddObservation(gMod,gDepthMod,d3,d5,rec,depth);
      else if(bucket==BUCKET_MEDIUM)
         AddObservation(gMed,gDepthMed,d3,d5,rec,depth);
      else if(bucket==BUCKET_BIG)
         AddObservation(gBig,gDepthBig,d3,d5,rec,depth);

      AddEventSample(iTime(gSym,PERIOD_D1,s),bucket,TrendRegimeAtShift(s),volRatio,d3,d5,rec,depth);
     }

   gAll.medianDepthATR=Median(gDepthAll);
   gMod.medianDepthATR=Median(gDepthMod);
   gMed.medianDepthATR=Median(gDepthMed);
   gBig.medianDepthATR=Median(gDepthBig);
  }

void AddObservation(HistStats &s,double &depths[],bool d3,bool d5,bool rec,double depth)
  {
   s.n++;
   if(d3)  s.deeper3++;
   if(d5)  s.deeper5++;
   if(rec) s.recovered5++;

   int n=ArraySize(depths);
   ArrayResize(depths,n+1);
   depths[n]=depth;
  }

void AddEventSample(datetime t,EventBucket bucket,int regime,double volRatio,bool d3,bool d5,bool rec,double depth)
  {
   int n=ArraySize(gEvents);
   ArrayResize(gEvents,n+1);
   gEvents[n].t=t;
   gEvents[n].bucket=(int)bucket;
   gEvents[n].regime=regime;
   gEvents[n].volRatio=volRatio;
   gEvents[n].d3=d3;
   gEvents[n].d5=d5;
   gEvents[n].rec=rec;
   gEvents[n].depthATR=depth;
  }

double Median(double &a[])
  {
   int n=ArraySize(a);
   if(n<=0) return 0.0;

   double tmp[];
   ArrayResize(tmp,n);
   for(int i=0;i<n;i++) tmp[i]=a[i];
   ArraySort(tmp,WHOLE_ARRAY,0,MODE_ASCEND);

   if((n%2)==1) return tmp[n/2];
   return 0.5*(tmp[n/2-1]+tmp[n/2]);
  }

double VolumeRatioAtShift(int eventShift)
  {
   if(InpVolMAPeriod<1) return 0.0;
   double eventVol=(double)iVolume(gSym,PERIOD_D1,eventShift);
   if(eventVol<=0.0) return 0.0;

   double sum=0.0;
   int n=0;
   for(int k=1;k<=InpVolMAPeriod;k++)
     {
      double v=(double)iVolume(gSym,PERIOD_D1,eventShift+k);
      if(v>0.0)
        {
         sum+=v;
         n++;
        }
     }
   if(n<MathMax(5,InpVolMAPeriod/2) || sum<=0.0) return 0.0;
   return eventVol/(sum/(double)n);
  }

// Structural regime classifier used only for regime segmentation.
// BULL = trigger close above EMA and EMA rising over slope lookback.
// BEAR = trigger close below EMA and EMA falling. Everything else = MIXED.
int TrendRegimeAtShift(int shift)
  {
   int emaPeriod=MathMax(2,InpRegimeEMAPeriod);
   int slopeBars=MathMax(1,InpRegimeSlopeBars);
   double c=iClose(gSym,PERIOD_D1,shift);
   double emaNow=iMA(gSym,PERIOD_D1,emaPeriod,0,MODE_EMA,PRICE_CLOSE,shift);
   double emaPast=iMA(gSym,PERIOD_D1,emaPeriod,0,MODE_EMA,PRICE_CLOSE,shift+slopeBars);
   if(c<=0.0 || emaNow<=0.0 || emaPast<=0.0) return 0;
   if(c>emaNow && emaNow>emaPast) return 1;
   if(c<emaNow && emaNow<emaPast) return -1;
   return 0;
  }

string RegimeName(int r)
  {
   if(r>0) return "BULL";
   if(r<0) return "BEAR";
   return "MIXED";
  }

// Prior run-up = trigger-day high relative to the lowest low in the
// preceding N completed D1 sessions. Input is exposed so the exact
// population definition can be changed without rewriting the EA.
double PriorRunUpPct(int eventShift)
  {
   double floor=1.0e308;
   for(int k=1;k<=InpPriorRunBars;k++)
     {
      double x=iLow(gSym,PERIOD_D1,eventShift+k);
      if(x>0 && x<floor) floor=x;
     }
   double h=iHigh(gSym,PERIOD_D1,eventShift);
   if(floor>1.0e307 || floor<=0 || h<=0) return 0.0;
   return (h-floor)/floor*100.0;
  }

EventBucket ClassifyBucket(double bodyATR)
  {
   if(bodyATR<InpMinBodyATR) return BUCKET_NONE;
   if(bodyATR<InpModerateMaxATR) return BUCKET_MODERATE;
   if(bodyATR<InpMediumMaxATR)   return BUCKET_MEDIUM;
   return BUCKET_BIG;
  }

//========================== Active event ============================
bool IsQualifyingEvent(int s,double &bodyATR,double &runUp)
  {
   double o=iOpen(gSym,PERIOD_D1,s);
   double c=iClose(gSym,PERIOD_D1,s);
   double atr=iATR(gSym,PERIOD_D1,InpATRPeriod,s);
   if(o<=0 || c<=0 || atr<=0 || c>=o) return false;

   bodyATR=MathAbs(o-c)/atr;
   if(bodyATR<InpMinBodyATR) return false;

   runUp=PriorRunUpPct(s);
   if(runUp<InpMinRunUpPct) return false;
   return true;
  }

void RefreshActiveEvent(bool initializing)
  {
   datetime oldTrigger=gTriggerTime;

   gHasActive=false;
   gTriggerShift=-1;

   int maxS=InpActiveWindowDays+1;
   int bars=iBars(gSym,PERIOD_D1);
   int priorNeed=MathMax(InpPriorRunBars,InpVolMAPeriod);
   maxS=MathMin(maxS,bars-priorNeed-2);

   for(int s=1;s<=maxS;s++)
     {
      double ratio=0.0,runUp=0.0;
      if(IsQualifyingEvent(s,ratio,runUp))
        {
         gHasActive=true;
         gTriggerShift=s;
         gTriggerTime=iTime(gSym,PERIOD_D1,s);
         gTriggerOpen=iOpen(gSym,PERIOD_D1,s);
         gTriggerHigh=iHigh(gSym,PERIOD_D1,s);
         gTriggerLow=iLow(gSym,PERIOD_D1,s);
         gTriggerClose=iClose(gSym,PERIOD_D1,s);
         gTriggerATR=iATR(gSym,PERIOD_D1,InpATRPeriod,s);
         gTriggerBodyATR=ratio;
         gTriggerRunUpPct=runUp;
         gTriggerVolRatio=VolumeRatioAtShift(s);
         gTriggerRegime=TrendRegimeAtShift(s);
         gTriggerBucket=ClassifyBucket(ratio);
         break; // most recent qualifying trigger
        }
     }

   if(!gHasActive)
     {
      gTriggerTime=0;
      gTriggerVolRatio=0.0;
      gTriggerRegime=0;
      gInvalidated=false;
      gMedianTargetHit=false;
      gMedianTarget=0;
      gDeepRunnerTarget=0;
      gInvalidReason="";
      gAlertedTarget=false;
      gAlertedInvalid=false;
      ResetStats(gBaseSelected);
      ResetStats(gContextSelected);
      ResetStats(gRegFull); ResetStats(gRegModern); ResetStats(gRegRecent); ResetStats(gRegCurrent);
      gRegimeWeightedP5=-1.0;
      gRegimeWeightedEffN=0.0;
      gRegimeWeightedUsedForAction=false;
      ClearDecayCache();
      return;
     }

   BuildActiveContext();

   double med=gContextSelected.medianDepthATR;
   if(med<=0) med=BenchmarkMedian(gTriggerBucket);
   gMedianTarget=gTriggerLow-med*gTriggerATR;
   gDeepRunnerTarget=gTriggerLow-InpDeepRunnerATR*gTriggerATR;

   // New trigger -> reset state. Same trigger -> preserve live invalidation.
   if(oldTrigger!=gTriggerTime)
     {
      gInvalidated=false;
      gMedianTargetHit=false;
      gInvalidReason="";
      gAlertedTarget=false;
      gAlertedInvalid=false;

      ReconstructPostTriggerState();

      if(InpAlerts && !initializing)
         Alert(gSym," GoldRetrace: new qualifying D1 event | ",
               BucketName(gTriggerBucket)," body/ATR=",
               DoubleToString(gTriggerBodyATR,2));
     }
   else
     {
      ReconstructPostTriggerState();
     }
  }

void BuildActiveContext()
  {
   SelectedStats(gTriggerBucket,gBaseSelected);
   CopyStats(gBaseSelected,gContextSelected);
   gContextUsesVolume=false;
   gContextSource="BASE "+BucketShort(gTriggerBucket);

   if(InpUseVolumeContext && gTriggerVolRatio>0.0)
     {
      bool wantHigh=(gTriggerVolRatio>=InpHighVolRatio);
      HistStats v;
      BuildFilteredStats(gTriggerBucket,true,wantHigh,v);
      if(v.n>=InpMinVolumeEvents)
        {
         CopyStats(v,gContextSelected);
         gContextUsesVolume=true;
         gContextSource=(wantHigh ? "HIGH VOL" : "NORMAL VOL");
        }
     }

   BuildDecayCache();
   BuildRegimeLens();
  }

// The regime lens keeps the SAME event definition/body bucket while changing
// only the time/regime lens. Volume remains a separate conditioning overlay.
// This makes 2006-2026 vs 2020+ vs 2022+ comparisons apples-to-apples.
bool EventMatchesRegimeBase(int i)
  {
   if(i<0 || i>=ArraySize(gEvents)) return false;
   // Keep regime analysis independent from the volume overlay so time/regime
   // effects can be compared cleanly against the 2006-2026 body-bucket benchmark.
   if(gTriggerBucket!=BUCKET_NONE && gEvents[i].bucket!=(int)gTriggerBucket) return false;
   return true;
  }

void BuildRegimeStats(int startYear,bool requireSameRegime,HistStats &out)
  {
   ResetStats(out);
   double depths[];
   ArrayResize(depths,0);
   int n=ArraySize(gEvents);
   for(int i=0;i<n;i++)
     {
      if(!EventMatchesRegimeBase(i)) continue;
      if(startYear>0 && TimeYear(gEvents[i].t)<startYear) continue;
      if(requireSameRegime && gEvents[i].regime!=gTriggerRegime) continue;
      AddObservation(out,depths,gEvents[i].d3,gEvents[i].d5,gEvents[i].rec,gEvents[i].depthATR);
     }
   out.medianDepthATR=Median(depths);
  }

void BuildRegimeWeightedRead()
  {
   gRegimeWeightedP5=-1.0;
   gRegimeWeightedEffN=0.0;
   gRegimeWeightedUsedForAction=false;
   if(!gHasActive || InpRegimeHalfLifeYears<=0.0) return;

   double sw=0.0, sw2=0.0, hit=0.0;
   int n=ArraySize(gEvents);
   for(int i=0;i<n;i++)
     {
      if(!EventMatchesRegimeBase(i)) continue;
      if(gEvents[i].t<=0 || gEvents[i].t>=gTriggerTime) continue;
      double ageYears=(double)(gTriggerTime-gEvents[i].t)/(365.25*86400.0);
      if(ageYears<0.0) ageYears=0.0;
      double w=MathPow(0.5,ageYears/InpRegimeHalfLifeYears);
      if(gEvents[i].regime==gTriggerRegime) w*=MathMax(0.0,InpSameRegimeBoost);
      if(w<=0.0) continue;
      sw+=w;
      sw2+=w*w;
      if(gEvents[i].d5) hit+=w;
     }
   if(sw<=0.0) return;
   gRegimeWeightedP5=100.0*hit/sw;
   if(sw2>0.0) gRegimeWeightedEffN=(sw*sw)/sw2;
   if(InpUseRegimeWeightedAction && gRegimeWeightedEffN>=InpMinWeightedEffectiveN)
      gRegimeWeightedUsedForAction=true;
  }

void BuildRegimeLens()
  {
   BuildRegimeStats(0,false,gRegFull);
   BuildRegimeStats(InpModernStartYear,false,gRegModern);
   BuildRegimeStats(InpRecentStartYear,false,gRegRecent);
   BuildRegimeStats(InpModernStartYear,true,gRegCurrent);
   BuildRegimeWeightedRead();
  }

void BuildFilteredStats(EventBucket bucket,bool filterVolume,bool wantHigh,HistStats &out)
  {
   ResetStats(out);
   double depths[];
   ArrayResize(depths,0);

   int n=ArraySize(gEvents);
   for(int i=0;i<n;i++)
     {
      if(bucket!=BUCKET_NONE && gEvents[i].bucket!=(int)bucket) continue;
      if(filterVolume)
        {
         if(gEvents[i].volRatio<=0.0) continue;
         bool isHigh=(gEvents[i].volRatio>=InpHighVolRatio);
         if(isHigh!=wantHigh) continue;
        }
      AddObservation(out,depths,gEvents[i].d3,gEvents[i].d5,gEvents[i].rec,gEvents[i].depthATR);
     }
   out.medianDepthATR=Median(depths);
  }

void ClearDecayCache()
  {
   for(int i=0;i<MAX_DECAY_STEPS;i++)
     {
      gDecayReached[i]=0;
      gDecayNext[i]=0;
     }
   gDecayStepCount=0;
  }

void BuildDecayCache()
  {
   ClearDecayCache();
   if(!InpUseDecay || InpDecayStepATR<=0.0) return;

   gDecayStepCount=(int)MathFloor(InpDecayMaxATR/InpDecayStepATR)+1;
   gDecayStepCount=MathMax(1,MathMin(MAX_DECAY_STEPS,gDecayStepCount));

   int n=ArraySize(gEvents);
   for(int i=0;i<n;i++)
     {
      bool include=true;
      if(gTriggerBucket!=BUCKET_NONE && gEvents[i].bucket!=(int)gTriggerBucket)
         include=false;

      if(include && gContextUsesVolume)
        {
         if(gEvents[i].volRatio<=0.0) include=false;
         else
           {
            bool eventHigh=(gEvents[i].volRatio>=InpHighVolRatio);
            bool triggerHigh=(gTriggerVolRatio>=InpHighVolRatio);
            if(eventHigh!=triggerHigh) include=false;
           }
        }

      if(!include) continue;

      for(int k=0;k<gDecayStepCount;k++)
        {
         double reached=(double)k*InpDecayStepATR;
         double next=reached+InpDecayStepATR;
         if(gEvents[i].depthATR+1e-10>=reached)
           {
            gDecayReached[k]++;
            if(gEvents[i].depthATR+1e-10>=next)
               gDecayNext[k]++;
           }
        }
     }
  }

void ReconstructPostTriggerState()
  {
   if(!gHasActive) return;

   for(int s=gTriggerShift-1; s>=0; s--)
     {
      double l=iLow(gSym,PERIOD_D1,s);
      if(l>0 && l<=gMedianTarget)
         gMedianTargetHit=true;
     }

   if(InpInvalidateOnD1Close)
     {
      for(int s=gTriggerShift-1; s>=1; s--)
        {
         double c=iClose(gSym,PERIOD_D1,s);
         if(c>gTriggerHigh)
           {
            gInvalidated=true;
            gInvalidReason="D1 closed above trigger high";
            break;
           }
        }
     }

   if(!gInvalidated && InpInvalidateOnH4Close)
     {
      int h4Bars=iBars(gSym,PERIOD_H4);
      int maxCheck=MathMin(h4Bars-1,(InpActiveWindowDays+3)*6);
      datetime afterTrigger=iTime(gSym,PERIOD_D1,gTriggerShift-1);
      if(afterTrigger<=0) afterTrigger=gTriggerTime;
      for(int s=1;s<=maxCheck;s++)
        {
         datetime t=iTime(gSym,PERIOD_H4,s);
         if(t<afterTrigger) break;
         double c=iClose(gSym,PERIOD_H4,s);
         if(c>gTriggerHigh)
           {
            gInvalidated=true;
            gInvalidReason="H4 closed above trigger high";
            break;
           }
        }
     }
  }

void CheckH4Invalidation()
  {
   if(!InpInvalidateOnH4Close || !gHasActive || gInvalidated) return;
   double c=iClose(gSym,PERIOD_H4,1);
   if(c>gTriggerHigh)
     {
      gInvalidated=true;
      gInvalidReason="H4 closed above trigger high";
      if(InpAlerts && !gAlertedInvalid)
        {
         Alert(gSym," GoldRetrace invalidated: H4 closed above ",
               DoubleToString(gTriggerHigh,DigitsForSymbol()));
         gAlertedInvalid=true;
        }
     }
  }

//=========================== Statistics =============================
void CopyStats(HistStats &src,HistStats &dst)
  {
   dst.n=src.n;
   dst.deeper3=src.deeper3;
   dst.deeper5=src.deeper5;
   dst.recovered5=src.recovered5;
   dst.medianDepthATR=src.medianDepthATR;
  }

void SelectedStats(EventBucket bucket,HistStats &out)
  {
   if(bucket==BUCKET_MODERATE && gMod.n>=InpMinBucketEvents)
      CopyStats(gMod,out);
   else if(bucket==BUCKET_MEDIUM && gMed.n>=InpMinBucketEvents)
      CopyStats(gMed,out);
   else if(bucket==BUCKET_BIG && gBig.n>=InpMinBucketEvents)
      CopyStats(gBig,out);
   else
      CopyStats(gAll,out);
  }

double Pct(int x,int n)
  {
   if(n<=0) return 0.0;
   return 100.0*x/n;
  }

string BucketName(EventBucket b)
  {
   if(b==BUCKET_MODERATE) return "MODERATE 0.4-1.0x";
   if(b==BUCKET_MEDIUM)   return "MEDIUM 1.0-2.0x";
   if(b==BUCKET_BIG)      return "BIG >=2.0x";
   return "NONE";
  }

int BenchmarkN(EventBucket b)
  {
   if(b==BUCKET_MODERATE) return BENCH_MOD_N;
   if(b==BUCKET_MEDIUM)   return BENCH_MED_N;
   if(b==BUCKET_BIG)      return BENCH_BIG_N;
   return BENCH_ALL_N;
  }

double BenchmarkP3(EventBucket b)
  {
   if(b==BUCKET_MODERATE) return BENCH_MOD_P3;
   if(b==BUCKET_MEDIUM)   return BENCH_MED_P3;
   if(b==BUCKET_BIG)      return BENCH_BIG_P3;
   return BENCH_ALL_P3;
  }

double BenchmarkP5(EventBucket b)
  {
   if(b==BUCKET_MODERATE) return BENCH_MOD_P5;
   if(b==BUCKET_MEDIUM)   return BENCH_MED_P5;
   if(b==BUCKET_BIG)      return BENCH_BIG_P5;
   return BENCH_ALL_P5;
  }

double BenchmarkRecovery(EventBucket b)
  {
   if(b==BUCKET_MODERATE) return BENCH_MOD_REC;
   if(b==BUCKET_MEDIUM)   return BENCH_MED_REC;
   if(b==BUCKET_BIG)      return BENCH_BIG_REC;
   return BENCH_ALL_REC;
  }

double BenchmarkMedian(EventBucket b)
  {
   if(b==BUCKET_MODERATE) return BENCH_MOD_MED;
   if(b==BUCKET_MEDIUM)   return BENCH_MED_MED;
   if(b==BUCKET_BIG)      return BENCH_BIG_MED;
   return BENCH_ALL_MED;
  }


string BucketShort(EventBucket b)
  {
   if(b==BUCKET_MODERATE) return "MOD";
   if(b==BUCKET_MEDIUM) return "MED";
   if(b==BUCKET_BIG) return "BIG";
   return "ALL";
  }

string VolumeTag(double ratio)
  {
   if(ratio<=0.0) return "NO DATA";
   if(ratio>=1.50) return "SURGE";
   if(ratio>=InpHighVolRatio) return "HIGH";
   if(ratio>=0.80) return "NORMAL";
   return "LOW";
  }

double CurrentDepthATR()
  {
   if(!gHasActive || gTriggerATR<=0.0) return 0.0;
   double bid=MarketInfo(gSym,MODE_BID);
   if(bid<=0.0) bid=iClose(gSym,PERIOD_D1,0);
   return MathMax(0.0,(gTriggerLow-bid)/gTriggerATR);
  }

int CurrentDecayIndex(double depth)
  {
   if(gDecayStepCount<=0 || InpDecayStepATR<=0.0) return -1;
   int k=(int)MathFloor(MathMax(0.0,depth)/InpDecayStepATR);
   if(k>=gDecayStepCount) k=gDecayStepCount-1;
   if(k<0) k=0;
   return k;
  }

double CurrentDecayProbability(int &nReached,double &fromATR,double &toATR)
  {
   nReached=0; fromATR=0.0; toATR=0.0;
   if(!InpUseDecay || gDecayStepCount<=0) return -1.0;
   int k=CurrentDecayIndex(CurrentDepthATR());
   if(k<0) return -1.0;
   nReached=gDecayReached[k];
   fromATR=(double)k*InpDecayStepATR;
   toATR=fromATR+InpDecayStepATR;
   if(nReached<=0) return -1.0;
   return 100.0*(double)gDecayNext[k]/(double)nReached;
  }

double NextDecayTarget()
  {
   if(!gHasActive || gTriggerATR<=0.0 || gDecayStepCount<=0) return 0.0;
   int k=CurrentDecayIndex(CurrentDepthATR());
   if(k<0) return 0.0;
   double toATR=((double)k+1.0)*InpDecayStepATR;
   return gTriggerLow-toATR*gTriggerATR;
  }

string ConfidenceTag(int n)
  {
   if(n>=100) return "HIGH";
   if(n>=50) return "GOOD";
   if(n>=30) return "FAIR";
   return "LOW";
  }

void GetActionState(string &headline,string &detail,color &accent,color &boxBg)
  {
   headline="WAIT FOR SETUP";
   detail="No active qualifying D1 retracement event.";
   accent=C'170,185,205';
   boxBg=C'28,36,50';
   if(!gHasActive) return;

   int elapsed=(gTriggerShift>0 ? gTriggerShift-1 : 0);
   int dn=0; double fromA=0.0,toA=0.0;
   double decay=CurrentDecayProbability(dn,fromA,toA);
   double p5=Pct(gContextSelected.deeper5,gContextSelected.n);
   if(gRegimeWeightedUsedForAction && gRegimeWeightedP5>=0.0)
      p5=gRegimeWeightedP5;

   if(gInvalidated)
     {
      headline="PULLBACK READ INVALIDATED";
      detail="A closed H4/D1 bar reclaimed the trigger high. Bearish retracement context is OFF until a new qualifying setup.";
      accent=C'95,220,205'; boxBg=C'20,48,50';
      return;
     }
   if(elapsed>InpActiveWindowDays)
     {
      headline="WINDOW EXPIRED";
      detail="5-session continuation window is over. Wait for a fresh trigger.";
      accent=C'185,195,210'; boxBg=C'37,43,55';
      return;
     }
   if(gMedianTargetHit)
     {
      if(decay>=InpDecayStrongPct)
        {
         headline="MEDIAN HIT - RUNNER STILL VIABLE";
         detail="Median objective reached. Next-step decay remains strong; manage only the runner.";
         accent=C'255,210,90'; boxBg=C'58,45,18';
        }
      else
        {
         headline="MEDIAN HIT - PROTECT / DO NOT CHASE";
         detail="Core objective is spent. Continuation edge has decayed; wait for fresh confirmation.";
         accent=C'255,190,85'; boxBg=C'60,39,20';
        }
      return;
     }

   if(p5>=70.0 && (decay<0.0 || decay>=InpDecayStrongPct))
     {
      headline="DOWNSIDE CONTINUATION FAVORED";
      detail="Use the next extension checkpoint first; the median is an objective, not a certainty.";
      accent=C'255,105,115'; boxBg=C'58,22,28';
      return;
     }
   if(p5>=60.0 && (decay<0.0 || decay>=InpDecayWeakPct))
     {
      headline="DOWNSIDE CONTINUATION LEAN - NO CHASE";
      detail="Edge remains positive but weaker. Let price come to the level; do not extrapolate the tail.";
      accent=C'255,155,105'; boxBg=C'58,32,25';
      return;
     }

   headline="EXHAUSTION RISK - WAIT";
   detail="Conditional continuation is weak. Protect the pullback thesis until a fresh closed-bar signal.";
   accent=C'255,140,105'; boxBg=C'62,33,26';
  }

//============================= Panel ================================
void UpdatePanel()
  {
   if(!InpShowPanel) return;
   EnsurePanelBase();

   if(gPanelMinimized)
     {
      string miniAction,miniDetail; color miniAccent,miniBg;
      GetActionState(miniAction,miniDetail,miniAccent,miniBg);
      SetPanelText("Title","LPH RETRACE  |  "+gSym+"  |  "+miniAction,miniAccent,10,true);
      SetToggleButtonText("EXPAND");
      return;
     }

   string histRange="n/a";
   if(gOldestScanned>0 && gNewestMatured>0)
      histRange=TimeToString(gOldestScanned,TIME_DATE)+" -> "+TimeToString(gNewestMatured,TIME_DATE);

   datetime latestClosed=iTime(gSym,PERIOD_D1,1);
   datetime liveD1=iTime(gSym,PERIOD_D1,0);
   string latestClosedText=(latestClosed>0 ? TimeToString(latestClosed,TIME_DATE) : "n/a");
   string liveD1Text=(liveD1>0 ? TimeToString(liveD1,TIME_DATE) : "n/a");

   SetPanelText("Title","LPH RETRACE CONTEXT  |  "+gSym,C'242,247,255',12,true);
   SetPanelText("Meta","HISTORICAL SAMPLE  "+IntegerToString(gBarsScanned)+" D1 bars  |  Fully observed: "+histRange,C'125,145,170',8,false);
   SetPanelText("Meta2","LATEST CLOSED D1  "+latestClosedText+"  |  LIVE D1  "+liveD1Text,C'105,125,150',8,false);
   SetPanelText("Framework","EVENT DEFINITION  Bear body >= "+DoubleToString(InpMinBodyATR,2)+" ATR  |  Prior "+IntegerToString(InpPriorRunBars)+"D run-up >= "+DoubleToString(InpMinRunUpPct,1)+"%",C'145,165,190',8,false);
   SetPanelText("Framework2","OUTCOMES  Deeper low <=3D / <=5D  |  Recovery above trigger high <=5D  |  Median extra depth in ATR",C'120,140,165',8,false);

   string baseLine="BASE ALL  N="+IntegerToString(gAll.n)+"  |  P3 "+DoubleToString(Pct(gAll.deeper3,gAll.n),1)+"%  |  P5 "+DoubleToString(Pct(gAll.deeper5,gAll.n),1)+"%  |  Rec5 "+DoubleToString(Pct(gAll.recovered5,gAll.n),1)+"%  |  Median "+DoubleToString(gAll.medianDepthATR,2)+" ATR";
   SetPanelText("BaseAll",baseLine,C'155,175,200',8,false);

   string modLine="BASE MODERATE  N="+IntegerToString(gMod.n)+"  |  P3 "+DoubleToString(Pct(gMod.deeper3,gMod.n),1)+"%  |  P5 "+DoubleToString(Pct(gMod.deeper5,gMod.n),1)+"%  |  Rec5 "+DoubleToString(Pct(gMod.recovered5,gMod.n),1)+"%  |  Median "+DoubleToString(gMod.medianDepthATR,2)+" ATR";
   SetPanelText("BaseMod",modLine,C'155,175,200',8,false);

   string bench="GOLD BENCHMARK MODERATE  N="+IntegerToString(BENCH_MOD_N)+"  |  P3 "+DoubleToString(BENCH_MOD_P3,1)+"%  |  P5 "+DoubleToString(BENCH_MOD_P5,1)+"%  |  Rec5 "+DoubleToString(BENCH_MOD_REC,1)+"%  |  Median "+DoubleToString(BENCH_MOD_MED,2)+" ATR";
   SetPanelText("Benchmark",bench,C'100,120,145',8,false);

   string action,detail; color accent,bg;
   GetActionState(action,detail,accent,bg);
   SetToggleButtonText("MINIMIZE");
   string actionExtra="";

   if(!gHasActive)
     {
      SetPanelText("Current","CURRENT EVENT  No qualifying bearish event in the last "+IntegerToString(InpActiveWindowDays)+" sessions.",C'190,205,225',9,true);
      SetPanelText("Volume","VOLUME  Waiting for trigger.",C'125,145,170',8,false);
      SetPanelText("Context","MATCHED CONTEXT  Waiting for trigger.",C'125,145,170',8,false);
      SetPanelText("Context2","",C'125,145,170',8,false);
      SetPanelText("RegFull","REGIME LENS  Waiting for trigger.",C'125,145,170',8,false);
      SetPanelText("RegModern","",C'125,145,170',8,false);
      SetPanelText("RegRecent","",C'125,145,170',8,false);
      SetPanelText("RegCurrent","",C'125,145,170',8,false);
      SetPanelText("RegWeighted","",C'125,145,170',8,false);
      SetPanelText("Decay","LIVE DECAY  Waiting for trigger.",C'125,145,170',8,false);
      SetPanelText("Levels","LEVELS  Waiting for trigger.",C'125,145,170',8,false);
      SetPanelText("Levels2","",C'125,145,170',8,false);
      SetPanelText("State","",C'125,145,170',8,false);
      actionExtra="Monitoring market for the next completed qualifying D1 event.";
     }
   else
     {
      int elapsed=(gTriggerShift>0 ? gTriggerShift-1 : 0);
      string current="CURRENT EVENT  "+TimeToString(gTriggerTime,TIME_DATE)+"  |  "+BucketName(gTriggerBucket)+"  |  Body "+DoubleToString(gTriggerBodyATR,2)+"A  |  Run-up "+DoubleToString(gTriggerRunUpPct,1)+"%";
      SetPanelText("Current",current,C'230,238,250',9,true);

      string vol="VOLUME  "+DoubleToString(gTriggerVolRatio,2)+"x vs prior "+IntegerToString(InpVolMAPeriod)+"D avg  |  "+VolumeTag(gTriggerVolRatio);
      if(gTriggerVolRatio<=0.0) vol="VOLUME  unavailable on this broker history";
      SetPanelText("Volume",vol,(gTriggerVolRatio>=InpHighVolRatio ? C'80,220,160' : C'165,185,210'),8,true);

      double baseP5=Pct(gBaseSelected.deeper5,gBaseSelected.n);
      double ctxP5=Pct(gContextSelected.deeper5,gContextSelected.n);
      string context="MATCHED "+gContextSource+"  |  N="+IntegerToString(gContextSelected.n)+"  |  CONFIDENCE "+ConfidenceTag(gContextSelected.n);
      SetPanelText("Context",context,C'175,200,230',8,true);
      string context2="P5 "+DoubleToString(ctxP5,1)+"%  |  Lift "+Signed(ctxP5-baseP5,1)+"pp  |  Median "+DoubleToString(gContextSelected.medianDepthATR,2)+"A  |  Median lift "+Signed(gContextSelected.medianDepthATR-gBaseSelected.medianDepthATR,2)+"A";
      SetPanelText("Context2",context2,C'145,175,205',8,false);

      string rFull="FULL HISTORY  2006-2026  |  N="+IntegerToString(BenchmarkN(gTriggerBucket))+"  |  P5="+DoubleToString(BenchmarkP5(gTriggerBucket),1)+"%";
      string rModern="MODERN GOLD  "+IntegerToString(InpModernStartYear)+"-"+IntegerToString(TimeYear(gTriggerTime))+"  |  N="+IntegerToString(gRegModern.n)+"  |  P5="+DoubleToString(Pct(gRegModern.deeper5,gRegModern.n),1)+"%";
      string rRecent="RECENT REGIME  "+IntegerToString(InpRecentStartYear)+"-"+IntegerToString(TimeYear(gTriggerTime))+"  |  N="+IntegerToString(gRegRecent.n)+"  |  P5="+DoubleToString(Pct(gRegRecent.deeper5,gRegRecent.n),1)+"%";
      string rCurrent="CURRENT-REGIME MATCH  "+RegimeName(gTriggerRegime)+" (EMA50 state) / "+IntegerToString(InpModernStartYear)+"+  |  N="+IntegerToString(gRegCurrent.n)+"  |  P5="+DoubleToString(Pct(gRegCurrent.deeper5,gRegCurrent.n),1)+"%";
      string rw=(gRegimeWeightedP5>=0.0 ? DoubleToString(gRegimeWeightedP5,1)+"%" : "--");
      string rWeighted="REGIME-WEIGHTED READ  P5="+rw+"  |  Effective N="+DoubleToString(gRegimeWeightedEffN,1)+(gRegimeWeightedUsedForAction ? "  |  USED FOR ACTION" : "  |  DISPLAY ONLY / LOW N");
      SetPanelText("RegFull",rFull,C'145,165,190',8,false);
      SetPanelText("RegModern",rModern,C'160,185,215',8,false);
      SetPanelText("RegRecent",rRecent,C'175,200,230',8,false);
      SetPanelText("RegCurrent",rCurrent,C'195,215,240',8,true);
      SetPanelText("RegWeighted",rWeighted,(gRegimeWeightedUsedForAction ? C'255,185,115' : C'155,175,200'),8,true);

      int dn=0; double fromA=0.0,toA=0.0;
      double decay=CurrentDecayProbability(dn,fromA,toA);
      string decayText="LIVE DECAY  Post-trigger extension "+DoubleToString(CurrentDepthATR(),2)+" ATR  |  P(next +"+DoubleToString(InpDecayStepATR,2)+" ATR) "+(decay>=0.0 ? DoubleToString(decay,1)+"%" : "--")+"  |  Matched N="+IntegerToString(dn);
      color decayClr=(decay>=InpDecayStrongPct ? C'80,220,160' : (decay>=InpDecayWeakPct ? C'245,205,90' : C'245,135,110'));
      SetPanelText("Decay",decayText,decayClr,8,true);

      string levels="LEVELS  Trigger low "+DoubleToString(gTriggerLow,DigitsForSymbol())+"  |  Next checkpoint "+DoubleToString(NextDecayTarget(),DigitsForSymbol())+"  |  Median objective "+DoubleToString(gMedianTarget,DigitsForSymbol());
      SetPanelText("Levels",levels,C'210,220,235',8,false);

      string levels2="RUNNER "+DoubleToString(gDeepRunnerTarget,DigitsForSymbol())+"  |  Session "+IntegerToString(elapsed)+" / "+IntegerToString(InpActiveWindowDays);
      SetPanelText("Levels2",levels2,C'150,170,195',8,false);

      string state;
      color stateClr;
      if(gInvalidated)
        {
         state="INVALIDATION  CONFIRMED: closed H4/D1 above "+DoubleToString(gTriggerHigh,DigitsForSymbol())+"  |  Bearish pullback read OFF";
         stateClr=C'95,220,205';
        }
      else
        {
         state="INVALIDATION  Pullback read remains valid unless a CLOSED H4/D1 bar > "+DoubleToString(gTriggerHigh,DigitsForSymbol());
         stateClr=C'245,170,115';
        }
      SetPanelText("State",state,stateClr,8,true);

      string decayForAction=(decay>=0.0 ? DoubleToString(decay,1)+"%" : "--");
      string finalP5=(gRegimeWeightedUsedForAction && gRegimeWeightedP5>=0.0 ? DoubleToString(gRegimeWeightedP5,1)+"% regime P5" : DoubleToString(ctxP5,1)+"% matched P5");
      if(gInvalidated)
         actionExtra="Bearish retracement thesis is OFF  |  Invalidation level was "+DoubleToString(gTriggerHigh,DigitsForSymbol())+"  |  Wait for a new completed D1 trigger.";
      else if(elapsed>InpActiveWindowDays)
         actionExtra="Continuation window completed  |  Wait for a new completed D1 trigger.";
      else if(gMedianTargetHit)
         actionExtra="Runner "+DoubleToString(gDeepRunnerTarget,DigitsForSymbol())+"  |  P(next +"+DoubleToString(InpDecayStepATR,2)+"A) "+decayForAction+"  |  Do not treat the runner as the median case.";
      else
         actionExtra="Next "+DoubleToString(NextDecayTarget(),DigitsForSymbol())+"  |  Median "+DoubleToString(gMedianTarget,DigitsForSymbol())+"  |  "+finalP5+"  |  Next-step "+decayForAction+"  |  Invalid > "+DoubleToString(gTriggerHigh,DigitsForSymbol());
     }

   SetPanelBoxColor("ActionBox",bg,accent);
   SetPanelText("Action","ACTION  "+action,accent,11,true);
   SetPanelText("ActionDetail",detail,C'235,240,248',8,true);
   SetPanelText("ActionDetail2",actionExtra,C'215,226,238',8,true);
  }

void EnsurePanelBase()
  {
   if(gPanelMinimized)
     {
      CreatePanelBox("MainBox",InpPanelX,InpPanelY,520,46,C'12,17,27',C'43,55,72');
      CreatePanelLabel("Title",InpPanelX+14,InpPanelY+14);
      CreatePanelToggleButton(InpPanelX+424,InpPanelY+9,86,27);
      DeletePanelDetailObjects();
      return;
     }

   // Wider/taller layout: adds a dedicated regime lens without crowding the action box.
   CreatePanelBox("MainBox",InpPanelX,InpPanelY,920,575,C'12,17,27',C'43,55,72');
   CreatePanelBox("ActionBox",InpPanelX+10,InpPanelY+463,900,98,C'28,36,50',C'90,110,135');
   CreatePanelToggleButton(InpPanelX+820,InpPanelY+9,88,27);

   CreatePanelLabel("Title",InpPanelX+16,InpPanelY+12);
   CreatePanelLabel("Meta",InpPanelX+16,InpPanelY+35);
   CreatePanelLabel("Meta2",InpPanelX+16,InpPanelY+52);
   CreatePanelLabel("Framework",InpPanelX+16,InpPanelY+74);
   CreatePanelLabel("Framework2",InpPanelX+16,InpPanelY+92);
   CreatePanelLabel("BaseAll",InpPanelX+16,InpPanelY+116);
   CreatePanelLabel("BaseMod",InpPanelX+16,InpPanelY+135);
   CreatePanelLabel("Benchmark",InpPanelX+16,InpPanelY+154);
   CreatePanelLabel("Current",InpPanelX+16,InpPanelY+183);
   CreatePanelLabel("Volume",InpPanelX+16,InpPanelY+204);
   CreatePanelLabel("Context",InpPanelX+16,InpPanelY+225);
   CreatePanelLabel("Context2",InpPanelX+16,InpPanelY+244);
   CreatePanelLabel("RegFull",InpPanelX+16,InpPanelY+270);
   CreatePanelLabel("RegModern",InpPanelX+16,InpPanelY+289);
   CreatePanelLabel("RegRecent",InpPanelX+16,InpPanelY+308);
   CreatePanelLabel("RegCurrent",InpPanelX+16,InpPanelY+327);
   CreatePanelLabel("RegWeighted",InpPanelX+16,InpPanelY+346);
   CreatePanelLabel("Decay",InpPanelX+16,InpPanelY+374);
   CreatePanelLabel("Levels",InpPanelX+16,InpPanelY+397);
   CreatePanelLabel("Levels2",InpPanelX+16,InpPanelY+416);
   CreatePanelLabel("State",InpPanelX+16,InpPanelY+435);
   CreatePanelLabel("Action",InpPanelX+22,InpPanelY+473);
   CreatePanelLabel("ActionDetail",InpPanelX+22,InpPanelY+501);
   CreatePanelLabel("ActionDetail2",InpPanelX+22,InpPanelY+523);
  }

void CreatePanelToggleButton(int x,int y,int w,int h)
  {
   string name=gPrefix+"PanelToggle";
   if(ObjectFind(0,name)<0)
      ObjectCreate(0,name,OBJ_BUTTON,0,0,0);
   ObjectSetInteger(0,name,OBJPROP_CORNER,InpPanelCorner);
   ObjectSetInteger(0,name,OBJPROP_XDISTANCE,x);
   ObjectSetInteger(0,name,OBJPROP_YDISTANCE,y);
   ObjectSetInteger(0,name,OBJPROP_XSIZE,w);
   ObjectSetInteger(0,name,OBJPROP_YSIZE,h);
   ObjectSetInteger(0,name,OBJPROP_BGCOLOR,C'24,32,46');
   ObjectSetInteger(0,name,OBJPROP_COLOR,C'105,130,160');
   ObjectSetInteger(0,name,OBJPROP_BORDER_COLOR,C'70,88,112');
   ObjectSetInteger(0,name,OBJPROP_FONTSIZE,8);
   ObjectSetString(0,name,OBJPROP_FONT,"Segoe UI Semibold");
   ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
   ObjectSetInteger(0,name,OBJPROP_HIDDEN,true);
   ObjectSetInteger(0,name,OBJPROP_STATE,false);
   SetToggleButtonText(gPanelMinimized ? "EXPAND" : "MINIMIZE");
  }

void SetToggleButtonText(string txt)
  {
   string name=gPrefix+"PanelToggle";
   if(ObjectFind(0,name)<0) return;
   ObjectSetString(0,name,OBJPROP_TEXT,txt);
  }

void DeletePanelDetailObjects()
  {
   string tags[] = {"ActionBox","Meta","Meta2","Framework","Framework2","BaseAll","BaseMod","Benchmark",
                    "Current","Volume","Context","Context2","RegFull","RegModern","RegRecent","RegCurrent","RegWeighted",
                    "Decay","Levels","Levels2","State","Action","ActionDetail","ActionDetail2"};
   for(int i=0;i<ArraySize(tags);i++)
      ObjectDelete(0,gPrefix+tags[i]);
  }

void CreatePanelBox(string tag,int x,int y,int w,int h,color bg,color border)
  {
   string name=gPrefix+tag;
   if(ObjectFind(0,name)<0)
      ObjectCreate(0,name,OBJ_RECTANGLE_LABEL,0,0,0);
   ObjectSetInteger(0,name,OBJPROP_CORNER,InpPanelCorner);
   ObjectSetInteger(0,name,OBJPROP_XDISTANCE,x);
   ObjectSetInteger(0,name,OBJPROP_YDISTANCE,y);
   ObjectSetInteger(0,name,OBJPROP_XSIZE,w);
   ObjectSetInteger(0,name,OBJPROP_YSIZE,h);
   ObjectSetInteger(0,name,OBJPROP_BGCOLOR,bg);
   ObjectSetInteger(0,name,OBJPROP_COLOR,border);
   ObjectSetInteger(0,name,OBJPROP_BORDER_TYPE,BORDER_FLAT);
   ObjectSetInteger(0,name,OBJPROP_BACK,false);
   ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
   ObjectSetInteger(0,name,OBJPROP_HIDDEN,true);
  }

void CreatePanelLabel(string tag,int x,int y)
  {
   string name=gPrefix+tag;
   if(ObjectFind(0,name)<0)
      ObjectCreate(0,name,OBJ_LABEL,0,0,0);
   ObjectSetInteger(0,name,OBJPROP_CORNER,InpPanelCorner);
   ObjectSetInteger(0,name,OBJPROP_XDISTANCE,x);
   ObjectSetInteger(0,name,OBJPROP_YDISTANCE,y);
   ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
   ObjectSetInteger(0,name,OBJPROP_HIDDEN,true);
   ObjectSetInteger(0,name,OBJPROP_BACK,false);
  }

void SetPanelText(string tag,string txt,color col,int size,bool bold)
  {
   string name=gPrefix+tag;
   if(ObjectFind(0,name)<0) CreatePanelLabel(tag,InpPanelX+16,InpPanelY+16);
   ObjectSetText(name,txt,size,(bold ? "Segoe UI Semibold" : "Segoe UI"),col);
  }

void SetPanelBoxColor(string tag,color bg,color border)
  {
   string name=gPrefix+tag;
   if(ObjectFind(0,name)<0) return;
   ObjectSetInteger(0,name,OBJPROP_BGCOLOR,bg);
   ObjectSetInteger(0,name,OBJPROP_COLOR,border);
  }

string Signed(double x,int digits)
  {
   if(x>=0) return "+"+DoubleToString(x,digits);
   return DoubleToString(x,digits);
  }

//============================= Visuals ===============================
void DrawLevels()
  {
   if(InpUseWallReferences)
     {
      AddHLine("PutWall",InpPutWall,clrLimeGreen,STYLE_DOT,1);
      AddHLine("Pin",InpPinStrike,clrGold,STYLE_DOT,1);
      AddHLine("CallWall",InpCallWall,clrLimeGreen,STYLE_DOT,1);
     }

   if(!gHasActive)
     {
      DeleteEventObjects();
      return;
     }

   AddHLine("TriggerHigh",gTriggerHigh,clrDodgerBlue,STYLE_DASH,2);
   AddHLine("TriggerLow",gTriggerLow,clrSilver,STYLE_DASH,1);
   AddHLine("NextStep",NextDecayTarget(),clrGold,STYLE_DOT,1);
   AddHLine("MedianTarget",gMedianTarget,clrOrangeRed,STYLE_SOLID,2);
   AddHLine("DeepRunner",gDeepRunnerTarget,clrTomato,STYLE_DASHDOT,1);
  }

void AddHLine(string tag,double price,color col,int style,int width)
  {
   if(price<=0) return;
   string name=gPrefix+tag;
   if(ObjectFind(0,name)<0)
      ObjectCreate(0,name,OBJ_HLINE,0,0,price);
   ObjectSetDouble(0,name,OBJPROP_PRICE1,price);
   ObjectSetInteger(0,name,OBJPROP_COLOR,col);
   ObjectSetInteger(0,name,OBJPROP_STYLE,style);
   ObjectSetInteger(0,name,OBJPROP_WIDTH,width);
   ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
   ObjectSetInteger(0,name,OBJPROP_HIDDEN,true);
  }

void DeleteEventObjects()
  {
   ObjectDelete(0,gPrefix+"TriggerHigh");
   ObjectDelete(0,gPrefix+"TriggerLow");
   ObjectDelete(0,gPrefix+"NextStep");
   ObjectDelete(0,gPrefix+"MedianTarget");
   ObjectDelete(0,gPrefix+"DeepRunner");
  }

void DeleteObjects()
  {
   int total=ObjectsTotal(0,0,-1);
   for(int i=total-1;i>=0;i--)
     {
      string n=ObjectName(0,i,0,-1);
      if(StringFind(n,gPrefix,0)==0)
         ObjectDelete(0,n);
     }
  }

//============================== CSV =================================
void ExportStatsCSV()
  {
   string fn="GoldRetrace_MT4_HistoricalStats_"+SafeFileToken(gSym)+".csv";
   int h=FileOpen(fn,FILE_CSV|FILE_WRITE,';');
   if(h==INVALID_HANDLE)
     {
      Print("GoldRetrace MT4: CSV export failed, err=",GetLastError());
      return;
     }

   FileWrite(h,"Generated",TimeToString(TimeCurrent(),TIME_DATE|TIME_SECONDS));
   FileWrite(h,"Symbol",gSym);
   FileWrite(h,"HistoryRange",TimeToString(gOldestScanned,TIME_DATE),TimeToString(gNewestMatured,TIME_DATE));
   FileWrite(h,"EventDefinition","Bear body >=",InpMinBodyATR,"ATR","RunUp >=",InpMinRunUpPct,"%","PriorBars",InpPriorRunBars);
   FileWrite(h,"VolumeDefinition","Event D1 tick volume / prior",InpVolMAPeriod,"D mean","HighVol >=",InpHighVolRatio,"x");
   FileWrite(h,"DecayDefinition","StepATR",InpDecayStepATR,"MaxATR",InpDecayMaxATR);
   FileWrite(h,"Bucket","MT4_N","MT4_P3","MT4_P5","MT4_Recovery5","MT4_MedianDepthATR",
               "Benchmark_N","Benchmark_P3","Benchmark_P5","Benchmark_Recovery5","Benchmark_MedianDepthATR");

   WriteStatsRow(h,"ALL",gAll,BUCKET_NONE);
   WriteStatsRow(h,"MODERATE",gMod,BUCKET_MODERATE);
   WriteStatsRow(h,"MEDIUM",gMed,BUCKET_MEDIUM);
   WriteStatsRow(h,"BIG",gBig,BUCKET_BIG);

   if(gHasActive)
     {
      int dn=0; double fromA=0.0,toA=0.0;
      double decay=CurrentDecayProbability(dn,fromA,toA);
      FileWrite(h,"");
      FileWrite(h,"CURRENT_EVENT",
                TimeToString(gTriggerTime,TIME_DATE),
                BucketName(gTriggerBucket),
                "BodyATR",DoubleToString(gTriggerBodyATR,4),
                "RunUpPct",DoubleToString(gTriggerRunUpPct,4),
                "ATR",DoubleToString(gTriggerATR,4),
                "VolumeRatio",DoubleToString(gTriggerVolRatio,4),
                "Context",gContextSource,
                "ContextN",gContextSelected.n,
                "ContextP5",DoubleToString(Pct(gContextSelected.deeper5,gContextSelected.n),2),
                "ContextMedian",DoubleToString(gContextSelected.medianDepthATR,4),
                "CurrentDepthATR",DoubleToString(CurrentDepthATR(),4),
                "DecayFromATR",DoubleToString(fromA,4),
                "DecayToATR",DoubleToString(toA,4),
                "DecayProb",DoubleToString(decay,2),
                "DecayN",dn,
                "TriggerHigh",DoubleToString(gTriggerHigh,DigitsForSymbol()),
                "TriggerLow",DoubleToString(gTriggerLow,DigitsForSymbol()),
                "NextStep",DoubleToString(NextDecayTarget(),DigitsForSymbol()),
                "MedianTarget",DoubleToString(gMedianTarget,DigitsForSymbol()),
                "DeepRunner",DoubleToString(gDeepRunnerTarget,DigitsForSymbol()));

      FileWrite(h,"");
      FileWrite(h,"REGIME_LENS","FULL_BENCH_N",BenchmarkN(gTriggerBucket),"FULL_BENCH_P5",DoubleToString(BenchmarkP5(gTriggerBucket),2),
                "LOCAL_FULL_N",gRegFull.n,"LOCAL_FULL_P5",DoubleToString(Pct(gRegFull.deeper5,gRegFull.n),2),
                "MODERN_N",gRegModern.n,"MODERN_P5",DoubleToString(Pct(gRegModern.deeper5,gRegModern.n),2),
                "RECENT_N",gRegRecent.n,"RECENT_P5",DoubleToString(Pct(gRegRecent.deeper5,gRegRecent.n),2),
                "CURRENT_REGIME",RegimeName(gTriggerRegime),"CURRENT_N",gRegCurrent.n,"CURRENT_P5",DoubleToString(Pct(gRegCurrent.deeper5,gRegCurrent.n),2),
                "WEIGHTED_P5",DoubleToString(gRegimeWeightedP5,2),"EFFECTIVE_N",DoubleToString(gRegimeWeightedEffN,2),
                "USED_FOR_ACTION",(gRegimeWeightedUsedForAction ? "true" : "false"));

      FileWrite(h,"");
      FileWrite(h,"DECAY_TABLE","ReachedATR","NextATR","ReachedN","NextN","ConditionalPct");
      for(int k=0;k<gDecayStepCount;k++)
        {
         double a=(double)k*InpDecayStepATR;
         double b=a+InpDecayStepATR;
         double p=(gDecayReached[k]>0 ? 100.0*(double)gDecayNext[k]/(double)gDecayReached[k] : 0.0);
         FileWrite(h,"DECAY",DoubleToString(a,2),DoubleToString(b,2),gDecayReached[k],gDecayNext[k],DoubleToString(p,2));
        }
     }

   FileClose(h);
  }

void WriteStatsRow(int h,string label,HistStats &s,EventBucket b)
  {
   FileWrite(h,label,
             s.n,
             DoubleToString(Pct(s.deeper3,s.n),2),
             DoubleToString(Pct(s.deeper5,s.n),2),
             DoubleToString(Pct(s.recovered5,s.n),2),
             DoubleToString(s.medianDepthATR,4),
             BenchmarkN(b),
             DoubleToString(BenchmarkP3(b),2),
             DoubleToString(BenchmarkP5(b),2),
             DoubleToString(BenchmarkRecovery(b),2),
             DoubleToString(BenchmarkMedian(b),4));
  }

string SafeFileToken(string s)
  {
   string r=s;
   StringReplace(r,"/","_");
   StringReplace(r,"\\","_");
   StringReplace(r,":","_");
   StringReplace(r,"*","_");
   StringReplace(r,"?","_");
   return r;
  }

int DigitsForSymbol()
  {
   return (int)MarketInfo(gSym,MODE_DIGITS);
  }
//+------------------------------------------------------------------+
