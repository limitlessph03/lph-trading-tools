#!/usr/bin/env python3
"""LPH manual tradability advisor OFFLINE LABELS (not a backtest).

Input CSV columns: time,open,high,low,close,spread_price
`spread_price` is the observed bid-ask difference in the same price units as close,
not spread points/pips; broker/server timestamps and sampling are required.
Each input row MUST be a fully CLOSED bar. Output state at time t uses only rows
<= t. Zero / absent spreads and malformed data are flagged, not silently assumed.
"""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd

REQUIRED = ('time', 'open', 'high', 'low', 'close', 'spread_price')


def component_score(er, crossings, atr_ratio, cost_ratio):
    efficiency = 40 if er >= .40 else 30 if er >= .27 else 20 if er >= .17 else 8
    crossing = 25 if crossings <= 2 else 16 if crossings <= 4 else 8 if crossings <= 6 else 0
    volatility = 20 if atr_ratio <= 1.50 else 14 if atr_ratio <= 2.00 else 7 if atr_ratio <= 2.60 else 2
    spread = 15 if cost_ratio <= .03 else 10 if cost_ratio <= .06 else 5 if cost_ratio <= .10 else 0
    return efficiency + crossing + volatility + spread


def raw_state(score, er, crossings, atr_ratio, cost_ratio):
    multiple_hazards = (
        (er < .17 and crossings >= 5) or
        (atr_ratio > 2.0 and er < .27) or
        (cost_ratio > .10 and crossings >= 5)
    )
    if score < 45 and multiple_hazards:
        return 'CHAOTIC'
    if score >= 65 and er >= .22 and cost_ratio <= .10:
        return 'ORDERLY'
    return 'CAUTION'


def classify_csv(df):
    """Closed-bar labels with 100-bar ATR baseline and 2-bar persistence."""
    df = df.copy()
    missing = [c for c in REQUIRED if c not in df]
    if missing:
        raise ValueError('Missing required columns: ' + ','.join(missing))
    df['time'] = pd.to_datetime(df['time'], errors='raise')
    if df['time'].isna().any() or not df['time'].is_monotonic_increasing or df['time'].duplicated().any():
        raise ValueError('Unsorted, duplicate or invalid bar timestamps; do not auto-sort or deduplicate')
    for k in REQUIRED[1:]:
        df[k] = pd.to_numeric(df[k], errors='raise')
    a = df[list(REQUIRED[1:])].to_numpy(dtype=float)
    if not np.isfinite(a).all():
        raise ValueError('Non-finite price/spread values')
    if (df['high'] < df[['open','close','low']].max(axis=1)).any() or (df['low'] > df[['open','close']].min(axis=1)).any():
        raise ValueError('Malformed bars (high or low inconsistent)')
    if (df['spread_price'] <= 0).any():
        raise ValueError('Missing/nonpositive spread; do not infer zero cost')
    if (df['close'] <= 0).any():
        raise ValueError('Nonpositive closing price')

    c = df['close'].to_numpy(dtype=float)
    h = df['high'].to_numpy(dtype=float)
    l = df['low'].to_numpy(dtype=float)
    spread = df['spread_price'].to_numpy(dtype=float)
    n = len(df)
    prev = np.r_[c[0],c[:-1]]
    tr = np.maximum(h-l, np.maximum(np.abs(h-prev),np.abs(l-prev)))
    # ATR14 simple TR average, explicitly not Wilder's ATR.
    atr = pd.Series(tr).rolling(14, min_periods=14).mean().to_numpy()
    ema = pd.Series(c).ewm(span=20, adjust=False).mean().to_numpy()

    rows = []
    previous_raw = None
    for t in range(n):
        if t < 119:
            rows.append(dict(time=df['time'].iloc[t],state='DATA NOT READY',reason='less than 120 closed H1 bars'))
            previous_raw = None
            continue
        step = np.abs(np.diff(c[t-20:t+1]))
        movement = step.sum()
        er = abs(c[t]-c[t-20])/movement if movement > 0 else 0.0
        crosses = 0
        for i in range(t-15,t+1):
            prev_delta = c[i-1]-ema[i-1]
            cur_delta = c[i]-ema[i]
            if (prev_delta > 0 and cur_delta < 0) or (prev_delta < 0 and cur_delta > 0):
                crosses += 1
        baseline = np.median(atr[t-99:t+1])
        atr_ratio = atr[t]/baseline if baseline>0 else np.nan
        cost_ratio = spread[t]/atr[t] if atr[t]>0 else np.nan
        if not np.isfinite(atr_ratio) or not np.isfinite(cost_ratio):
            rows.append(dict(time=df['time'].iloc[t],state='DATA NOT READY',reason='ATR/ratio invalid'))
            previous_raw = None
            continue
        score = component_score(er,crosses,atr_ratio,cost_ratio)
        current_raw = raw_state(score,er,crosses,atr_ratio,cost_ratio)
        state = current_raw if previous_raw==current_raw and current_raw!='CAUTION' else 'CAUTION'
        rows.append(dict(time=df['time'].iloc[t],state=state,raw_state=current_raw,
                         score=score,er20=round(er,5),ema_crosses16=crosses,
                         atr14=round(atr[t],8),atr_ratio=round(atr_ratio,5),
                         spread_price=round(spread[t],8),spread_atr=round(cost_ratio,5),reason=''))
        previous_raw = current_raw
    return pd.DataFrame(rows)


def main():
    ap=argparse.ArgumentParser(description='Closed-H1-bar tradability labeling; NOT EA backtest')
    ap.add_argument('ohlc_csv',help='CSV: time,open,high,low,close,spread_price (all bars closed)')
    ap.add_argument('--out',required=True,help='output CSV for labels; will not overwrite input')
    args=ap.parse_args()
    src=Path(args.ohlc_csv).resolve()
    dest=Path(args.out).resolve()
    if src==dest:
        raise SystemExit('Cannot overwrite input')
    data=pd.read_csv(src)
    result=classify_csv(data)
    dest.parent.mkdir(parents=True,exist_ok=True)
    result.to_csv(dest,index=False)
    print(json.dumps(dict(input=str(src),output=str(dest),
         bars=len(result),status_counts=result['state'].value_counts().to_dict(),
         note='LABELS ONLY - NO TRADING PERFORMANCE VALIDATION'),indent=2))

if __name__=='__main__':
    main()
