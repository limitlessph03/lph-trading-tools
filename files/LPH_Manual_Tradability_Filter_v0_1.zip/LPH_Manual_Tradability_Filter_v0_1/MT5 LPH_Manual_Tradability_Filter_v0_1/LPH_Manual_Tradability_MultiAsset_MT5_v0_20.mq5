//+------------------------------------------------------------------+
//| LPH_Manual_Tradability_MultiAsset_MT5_v0_20.mq5                  |
//| Independent, read-only MULTI-SYMBOL MT5 dashboard.              |
//| Calculation and thresholds preserved from v0.10 MT5 research.  |
//| Native MT5 compilation and broker-feed parity NOT yet tested.  |
//+------------------------------------------------------------------+
#property copyright "Limitless PH | Private Research"
#property version   "0.20"
#property strict
#property indicator_chart_window
#property indicator_buffers 0
#property indicator_plots 0

#define MAX_ASSETS 20
#define PANEL_LINES 27

// Supply exact broker names where possible, especially if your broker has
// multiple suffix variants (e.g., XAUUSDzero and XAUUSDbas).
input string          InpSymbolsCSV = "XAUUSD,EURUSD,EURCHF,USDCAD,USDCHF,BTCUSD";
input bool            InpScanMarketWatch = false;    // false = list above; true = first symbols in Market Watch
input int             InpMaxAssets = 12;            // hard-capped at MAX_ASSETS
input ENUM_TIMEFRAMES InpEvaluationTF = PERIOD_H1;
input int             InpHistoryBars = 240;
input int             InpRefreshSeconds = 20;
input int             InpStaleQuoteSeconds = 180;
input bool            InpRequireNewQuoteSinceAttach = true;
input bool            InpPriorSpreadFallback = true;
input ENUM_BASE_CORNER InpPanelCorner = CORNER_RIGHT_UPPER;
input int             InpPanelX = 15;
input int             InpPanelY = 30;
input int             InpFontSize = 9;
input bool            InpWriteResearchLog = false;

struct Metrics
  {
   double er;
   int    crosses;
   double atr;
   double vol_ratio;
   double spread_ratio;
   int    score;
   string raw_state;
  };

struct AssetRow
  {
   string requested;
   string symbol;
   string status;
   string explanation;
   Metrics metrics;
   bool   previous_spread_fallback;
   datetime last_seen_tick_time;
   datetime last_quote_change_local;
   bool   seen_quote_change;
   datetime last_logged_closed_bar;
   datetime last_closed_bar_time;
  };

AssetRow g_assets[];
int g_count=0;
string g_prefix="";

string Upper(const string value)
  {
   string copy=value;
   StringToUpper(copy);
   return(copy);
  }

string Clean(const string value)
  {
   string copy=value;
   StringTrimLeft(copy);
   StringTrimRight(copy);
   return(copy);
  }

string TFName(const ENUM_TIMEFRAMES tf)
  {
   if(tf==PERIOD_M1) return("M1");
   if(tf==PERIOD_M5) return("M5");
   if(tf==PERIOD_M15) return("M15");
   if(tf==PERIOD_M30) return("M30");
   if(tf==PERIOD_H1) return("H1");
   if(tf==PERIOD_H4) return("H4");
   if(tf==PERIOD_D1) return("D1");
   if(tf==PERIOD_W1) return("W1");
   if(tf==PERIOD_MN1) return("MN1");
   return(EnumToString(tf));
  }

// Exact match first. Only automatically resolve a suffix if exactly one
// broker-listed symbol begins with the requested base name. If there are
// several possible matches, display AMBIGUOUS rather than choose silently.
string ResolveSymbol(const string request, string &diagnostic)
  {
   diagnostic="";
   string key=Upper(Clean(request));
   if(StringLen(key)==0) { diagnostic="EMPTY"; return(""); }
   int total=SymbolsTotal(false);
   for(int i=0;i<total;i++)
     {
      string item=SymbolName(i,false);
      if(Upper(item)==key) return(item);
     }
   string found="";
   int matches=0;
   for(int j=0;j<total;j++)
     {
      string item=SymbolName(j,false);
      string candidate=Upper(item);
      if(StringLen(candidate)>StringLen(key) &&
         StringSubstr(candidate,0,StringLen(key))==key)
        {
         found=item;
         matches++;
        }
     }
   if(matches==1) return(found);
   if(matches>1) diagnostic="AMBIGUOUS: ENTER EXACT BROKER SYMBOL";
   else diagnostic="NOT FOUND IN BROKER SYMBOL LIST";
   return("");
  }

void AddRequested(const string name)
  {
   if(g_count>=MAX_ASSETS) return;
   string clean=Clean(name);
   if(StringLen(clean)==0) return;
   for(int i=0;i<g_count;i++)
      if(Upper(g_assets[i].requested)==Upper(clean)) return;

   int idx=g_count;
   ArrayResize(g_assets,idx+1);
   g_assets[idx].requested=clean;
   g_assets[idx].symbol="";
   g_assets[idx].status="LOADING";
   g_assets[idx].explanation="";
   g_assets[idx].last_seen_tick_time=0;
   g_assets[idx].last_quote_change_local=0;
   g_assets[idx].seen_quote_change=false;
   g_assets[idx].last_logged_closed_bar=0;
   g_assets[idx].last_closed_bar_time=0;
   g_assets[idx].previous_spread_fallback=false;

   string diagnostic="";
   string resolved=ResolveSymbol(clean,diagnostic);
   if(resolved=="")
     {
      g_assets[idx].status="NO SYMBOL";
      g_assets[idx].explanation=diagnostic;
     }
   else if(!SymbolSelect(resolved,true))
     {
      g_assets[idx].status="NO QUOTES";
      g_assets[idx].explanation="FAILED TO SELECT IN MARKET WATCH";
     }
   else g_assets[idx].symbol=resolved;
   g_count++;
  }

int OnInit()
  {
   if(InpRefreshSeconds<5 || InpHistoryBars<140 || InpMaxAssets<1 || InpFontSize<7)
     {
      Print("[LPH MTA Multi] Invalid inputs: refresh >=5; history >=140; MaxAssets >=1; font >=7.");
      return(INIT_PARAMETERS_INCORRECT);
     }
   g_prefix="LPH_MTA_MT5_MULTI_v020_"+IntegerToString(ChartID())+"_";
   IndicatorSetString(INDICATOR_SHORTNAME,"LPH Multi-Asset Manual Tradability v0.20 (Advisory)");
   ArrayResize(g_assets,0);
   g_count=0;
   int cap=InpMaxAssets;
   if(cap>MAX_ASSETS) cap=MAX_ASSETS;
   if(InpScanMarketWatch)
     {
      int selected=SymbolsTotal(true);
      for(int i=0;i<selected && g_count<cap;i++) AddRequested(SymbolName(i,true));
     }
   else
     {
      string names[];
      ushort comma=StringGetCharacter(",",0);
      int n=StringSplit(InpSymbolsCSV,comma,names);
      for(int j=0;j<n && g_count<cap;j++) AddRequested(names[j]);
     }
   if(g_count<=0)
     {
      Print("[LPH MTA Multi] No usable symbols in the list.");
      return(INIT_PARAMETERS_INCORRECT);
     }
   if(!EventSetTimer(InpRefreshSeconds))
     {
      Print("[LPH MTA Multi] Timer setup failed: ",GetLastError());
      return(INIT_FAILED);
     }
   UpdateDashboard();
   return(INIT_SUCCEEDED);
  }

void OnDeinit(const int reason)
  {
   EventKillTimer();
   for(int i=0;i<PANEL_LINES;i++) ObjectDelete(0,g_prefix+IntegerToString(i));
  }

int OnCalculate(const int rates_total,const int prev_calculated,
                const datetime &time[],const double &open[],
                const double &high[],const double &low[],
                const double &close[],const long &tick_volume[],
                const long &volume[],const int &spread[])
  {
   if(prev_calculated==0) UpdateDashboard();
   return(rates_total);
  }

void OnTimer() { UpdateDashboard(); }

void Line(const int n,const string msg,const color clr)
  {
   if(n<0 || n>=PANEL_LINES) return;
   string id=g_prefix+IntegerToString(n);
   if(ObjectFind(0,id)<0)
     {
      if(!ObjectCreate(0,id,OBJ_LABEL,0,0,0)) return;
      ObjectSetInteger(0,id,OBJPROP_CORNER,InpPanelCorner);
      if(InpPanelCorner==CORNER_RIGHT_UPPER || InpPanelCorner==CORNER_RIGHT_LOWER)
         ObjectSetInteger(0,id,OBJPROP_ANCHOR,ANCHOR_RIGHT_UPPER);
      else ObjectSetInteger(0,id,OBJPROP_ANCHOR,ANCHOR_LEFT_UPPER);
      ObjectSetInteger(0,id,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,id,OBJPROP_HIDDEN,true);
      ObjectSetString(0,id,OBJPROP_FONT,"Consolas");
      ObjectSetInteger(0,id,OBJPROP_FONTSIZE,InpFontSize);
     }
   ObjectSetInteger(0,id,OBJPROP_XDISTANCE,InpPanelX);
   ObjectSetInteger(0,id,OBJPROP_YDISTANCE,InpPanelY+n*(InpFontSize+8));
   ObjectSetInteger(0,id,OBJPROP_COLOR,clr);
   ObjectSetString(0,id,OBJPROP_TEXT,msg);
  }

// Identical closed-bar metric construction and thresholds to single-symbol
// v0.10. r[0] is oldest and r[end] is newest COMPLETED evaluation bar.
double TrueRange(const MqlRates &r[],const int i)
  {
   double a=r[i].high-r[i].low;
   double b=MathAbs(r[i].high-r[i-1].close);
   double c=MathAbs(r[i].low-r[i-1].close);
   return(MathMax(a,MathMax(b,c)));
  }

double ATR14(const MqlRates &r[],const int end)
  {
   if(end<14) return(0);
   double s=0;
   for(int i=end-13;i<=end;i++) s+=TrueRange(r,i);
   return(s/14.0);
  }

double MedianArray(double &v[])
  {
   int n=ArraySize(v);
   if(n<=0) return(0);
   ArraySort(v);
   if(n%2!=0) return(v[n/2]);
   return((v[n/2-1]+v[n/2])*0.5);
  }

bool ComputeMetrics(const MqlRates &r[],const int end,
                    const double spread_price,Metrics &m)
  {
   if(end<119 || spread_price<=0) return(false);
   double move=0;
   for(int i=end-19;i<=end;i++)
      move+=MathAbs(r[i].close-r[i-1].close);
   m.er=0;
   if(move>0) m.er=MathAbs(r[end].close-r[end-20].close)/move;

   double ema[];
   ArrayResize(ema,end+1);
   double alpha=2.0/21.0;
   ema[0]=r[0].close;
   for(int i=1;i<=end;i++)
      ema[i]=alpha*r[i].close+(1.0-alpha)*ema[i-1];
   m.crosses=0;
   for(int k=end-15;k<=end;k++)
     {
      double prev=r[k-1].close-ema[k-1];
      double curr=r[k].close-ema[k];
      if((prev>0 && curr<0)||(prev<0 && curr>0)) m.crosses++;
     }

   m.atr=ATR14(r,end);
   if(m.atr<=0 || !MathIsValidNumber(m.atr)) return(false);
   double values[];
   ArrayResize(values,100);
   for(int j=0;j<100;j++)
     {
      values[j]=ATR14(r,end-99+j);
      if(values[j]<=0) return(false);
     }
   double baseline=MedianArray(values);
   if(baseline<=0) return(false);
   m.vol_ratio=m.atr/baseline;
   m.spread_ratio=spread_price/m.atr;

   int efficiency_score=8;
   if(m.er>=.40) efficiency_score=40;
   else if(m.er>=.27) efficiency_score=30;
   else if(m.er>=.17) efficiency_score=20;
   int crossing_score=0;
   if(m.crosses<=2) crossing_score=25;
   else if(m.crosses<=4) crossing_score=16;
   else if(m.crosses<=6) crossing_score=8;
   int volatility_score=2;
   if(m.vol_ratio<=1.50) volatility_score=20;
   else if(m.vol_ratio<=2.00) volatility_score=14;
   else if(m.vol_ratio<=2.60) volatility_score=7;
   int cost_score=0;
   if(m.spread_ratio<=.03) cost_score=15;
   else if(m.spread_ratio<=.06) cost_score=10;
   else if(m.spread_ratio<=.10) cost_score=5;
   m.score=efficiency_score+crossing_score+volatility_score+cost_score;

   bool joint=(m.er<.17 && m.crosses>=5) ||
              (m.vol_ratio>2.0 && m.er<.27) ||
              (m.spread_ratio>.10 && m.crosses>=5);
   if(m.score<45 && joint) m.raw_state="CHAOTIC";
   else if(m.score>=65 && m.er>=.22 && m.spread_ratio<=.10)
      m.raw_state="ORDERLY";
   else m.raw_state="CAUTION";
   return(true);
  }

void SaveSnapshot(const int index,const datetime closed_bar)
  {
   if(!InpWriteResearchLog || closed_bar<=0 ||
      closed_bar==g_assets[index].last_logged_closed_bar) return;
   string fname="LPH_Manual_Tradability_MultiAsset_MT5_v020.csv";
   int handle=FileOpen(fname,FILE_CSV|FILE_READ|FILE_WRITE|FILE_SHARE_READ|FILE_ANSI,',');
   if(handle==INVALID_HANDLE)
     {
      Print("[LPH MTA Multi] Research CSV open failed: ",GetLastError());
      return;
     }
   if(FileSize(handle)==0)
      FileWrite(handle,"closed_bar_server","symbol","tf","state","raw_state",
                "score","er20","cross16","atr_ratio","spread_atr","prior_spread_fallback");
   FileSeek(handle,0,SEEK_END);
   Metrics m=g_assets[index].metrics;
   FileWrite(handle,TimeToString(closed_bar,TIME_DATE|TIME_MINUTES),
             g_assets[index].symbol,TFName(InpEvaluationTF),g_assets[index].status,
             m.raw_state,m.score,DoubleToString(m.er,5),m.crosses,
             DoubleToString(m.vol_ratio,5),DoubleToString(m.spread_ratio,5),
             (g_assets[index].previous_spread_fallback ? "YES":"NO"));
   FileClose(handle);
   g_assets[index].last_logged_closed_bar=closed_bar;
  }

void ScanAsset(const int index)
  {
   if(g_assets[index].symbol=="") return;
   string sym=g_assets[index].symbol;
   g_assets[index].status="LOADING";
   g_assets[index].explanation="";
   g_assets[index].previous_spread_fallback=false;
   if(!TerminalInfoInteger(TERMINAL_CONNECTED))
     {
      g_assets[index].status="STALE";
      g_assets[index].explanation="TERMINAL DISCONNECTED";
      return;
     }
   MqlTick tick;
   if(!SymbolInfoTick(sym,tick) || tick.ask<=0 || tick.bid<=0 || tick.ask<=tick.bid)
     {
      g_assets[index].status="NO QUOTES";
      g_assets[index].explanation="INVALID OR MISSING BID/ASK";
      return;
     }
   datetime now=TimeLocal();
   if(g_assets[index].last_seen_tick_time==0)
     {
      g_assets[index].last_seen_tick_time=tick.time;
      g_assets[index].last_quote_change_local=now;
     }
   else if(tick.time!=g_assets[index].last_seen_tick_time)
     {
      g_assets[index].last_seen_tick_time=tick.time;
      g_assets[index].last_quote_change_local=now;
      g_assets[index].seen_quote_change=true;
     }

   if(InpRequireNewQuoteSinceAttach && !g_assets[index].seen_quote_change)
     {
      g_assets[index].status="WAIT TICK";
      g_assets[index].explanation="NEED FRESH QUOTE SINCE ATTACH";
      return;
     }
   if(InpStaleQuoteSeconds>0 &&
      (now-g_assets[index].last_quote_change_local)>InpStaleQuoteSeconds)
     {
      g_assets[index].status="STALE";
      g_assets[index].explanation="QUOTE NOT UPDATED";
      return;
     }
   // TimeCurrent() is server time of the last Market Watch tick. It can
   // reveal a stagnant instrument when other instruments are still updating.
   datetime server_now=TimeTradeServer();
   if(server_now<=0) server_now=TimeCurrent();
   if(InpStaleQuoteSeconds>0 && server_now>tick.time &&
      (server_now-tick.time)>InpStaleQuoteSeconds)
     {
      g_assets[index].status="STALE";
      g_assets[index].explanation="QUOTE OLDER THAN MARKET WATCH";
      return;
     }

   MqlRates r[];
   ArraySetAsSeries(r,false);
   int requested=InpHistoryBars;
   if(requested<140) requested=140;
   // shift 1 excludes the forming H1 (or selected timeframe) candle.
   int count=CopyRates(sym,InpEvaluationTF,1,requested,r);
   if(count<140)
     {
      g_assets[index].status="NO HISTORY";
      g_assets[index].explanation="INSUFFICIENT CLOSED BARS";
      return;
     }
   int end=count-1;
   Metrics cur,prior;
   ZeroMemory(cur);
   ZeroMemory(prior);
   double point=SymbolInfoDouble(sym,SYMBOL_POINT);
   double previous_spread=point*(double)r[end-1].spread;
   bool fallback=false;
   if(previous_spread<=0 && InpPriorSpreadFallback)
     {
      previous_spread=tick.ask-tick.bid;
      fallback=true;
     }
   if(!ComputeMetrics(r,end,tick.ask-tick.bid,cur))
     {
      g_assets[index].status="NO DATA";
      g_assets[index].explanation="ATR / SPREAD / HISTORY INVALID";
      return;
     }
   bool previous_ok=ComputeMetrics(r,end-1,previous_spread,prior);
   string state="CAUTION";
   if(previous_ok && cur.raw_state==prior.raw_state && cur.raw_state!="CAUTION")
      state=cur.raw_state;
   g_assets[index].metrics=cur;
   g_assets[index].status=state;
   g_assets[index].previous_spread_fallback=fallback;
   g_assets[index].last_closed_bar_time=r[end].time;
   SaveSnapshot(index,r[end].time);
  }

color StatusColor(const string status)
  {
   if(status=="ORDERLY") return(clrLimeGreen);
   if(status=="CAUTION") return(clrOrange);
   if(status=="CHAOTIC") return(clrTomato);
   return(clrSilver);
  }

void UpdateDashboard()
  {
   int good=0,caution=0,chaotic=0,missing=0;
   for(int i=0;i<g_count;i++)
     {
      ScanAsset(i);
      if(g_assets[i].status=="ORDERLY") good++;
      else if(g_assets[i].status=="CAUTION") caution++;
      else if(g_assets[i].status=="CHAOTIC") chaotic++;
      else missing++;
     }
   Line(0,"LPH | MULTI-ASSET TRADABILITY  [MT5]",clrLightSkyBlue);
   Line(1,TFName(InpEvaluationTF)+" CLOSED BARS | 2-BAR CONFIRM | "+IntegerToString(g_count)+" ASSETS",clrWhite);
   Line(2,"SYMBOL         STATE       SCORE   ER20 X16  ATRx  COST",clrKhaki);
   for(int j=0;j<g_count;j++)
     {
      string sym=g_assets[j].symbol;
      if(sym=="") sym=g_assets[j].requested;
      if(StringLen(sym)>14) sym=StringSubstr(sym,0,14);
      string row="";
      string status=g_assets[j].status;
      if(status=="ORDERLY" || status=="CAUTION" || status=="CHAOTIC")
        {
         Metrics m=g_assets[j].metrics;
         string foot=(g_assets[j].previous_spread_fallback?" *":"");
         row=StringFormat("%-14s %-10s %3d    %4.2f %2d  %4.2f  %4.1f%%%s",
                          sym,status,m.score,m.er,m.crosses,m.vol_ratio,
                          m.spread_ratio*100.0,foot);
        }
      else row=StringFormat("%-14s %-10s %s",sym,status,g_assets[j].explanation);
      Line(3+j,row,StatusColor(status));
     }
   int next=3+g_count;
   Line(next,StringFormat("ORDERLY %d  CAUTION %d  CHAOTIC %d  UNAVAILABLE %d",
                          good,caution,chaotic,missing),clrWhite);
   Line(next+1,"* PRIOR SPREAD: LIVE-QUOTE FALLBACK",clrKhaki);
   Line(next+2,"NEWS / PROP FLOOR / MARGIN: MANUAL CHECK",clrKhaki);
   Line(next+3,"ADVISORY ONLY. NOT AN ENTRY OR DIRECTION SIGNAL.",clrSilver);
   for(int k=next+4;k<PANEL_LINES;k++) Line(k,"",clrSilver);
   ChartRedraw(0);
  }
//+------------------------------------------------------------------+
