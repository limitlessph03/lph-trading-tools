# LPH Manual Tradability Advisor v0.10 - MetaTrader 5

Source-only, read-only research indicator. See the package README for installation,
status, metrics, and limitations. Copy the MQ5 to `MQL5/Indicators/`, compile in
MT5 MetaEditor, and validate in a separate demo terminal before wider use.
No compiled binary or verified native runtime result is included.

Default inputs: H1 evaluation, 240 requested history bars, 20-second refresh,
180-second stale-quote threshold, optional research logging off. The indicator
requires at least 140 completed evaluation bars. Settings JSON is documentation,
not a preset loader. News and account risk checks remain manual.

MT5 uses the previous completed bar's recorded spread for the preceding-state
confirmation. Missing/nonpositive prior spread prevents an extreme confirmed
state and results in CAUTION. Unlike MT4, no current-spread fallback is applied.

If enabled, the CSV log is written to the terminal's `MQL5/Files/` directory as
`LPH_Manual_Tradability_Advisor_v010.csv`. Use one instance per chart; keep
logging disabled initially. Terminal/feed parity, stale-history handling, and
restart behavior still need demo verification. The offline Python labeler is a
separate engineering aid, not a native MT5 validation or execution backtest.
