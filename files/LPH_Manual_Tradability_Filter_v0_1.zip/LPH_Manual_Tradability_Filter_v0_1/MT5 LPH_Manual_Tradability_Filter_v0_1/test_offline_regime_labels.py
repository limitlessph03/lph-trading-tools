"""Engineering sanity tests on synthetic arrays; NO market performance inference."""
import unittest
import numpy as np
import pandas as pd
from offline_regime_labels import component_score, raw_state, classify_csv

class TestRegimeRules(unittest.TestCase):
    def test_volatility_alone_never_chaotic(self):
        self.assertEqual(raw_state(35, .65, 1, 3.0, .01), 'CAUTION')

    def test_joint_weakness_chaotic(self):
        self.assertEqual(raw_state(24, .08, 7, 2.4, .05), 'CHAOTIC')

    def test_score_bounds(self):
        for er in (0, .2, .4, 1.0):
            for crosses in (0, 5, 20):
                for atr in (0.5, 1.5, 3.0):
                    for cost in (.001, .04, .20):
                        score=component_score(er,crosses,atr,cost)
                        self.assertGreaterEqual(score,0)
                        self.assertLessEqual(score,100)

    def test_no_future_dependency(self):
        rng=np.random.default_rng(234)
        close=200+np.cumsum(rng.normal(0,.3,200))
        df=pd.DataFrame(dict(time=pd.date_range('2026-01-01',periods=200,freq='h'),
                 open=close,high=close+.5,low=close-.5,close=close,
                 spread_price=np.full(200,.05)))
        labels_full=classify_csv(df)
        labels_past=classify_csv(df.iloc[:150])
        self.assertEqual(labels_full.loc[149,'state'],labels_past.loc[149,'state'])
        self.assertEqual(labels_full.loc[149,'score'],labels_past.loc[149,'score'])

    def test_missing_spread_is_rejected(self):
        df=pd.DataFrame(dict(time=pd.date_range('2026-01-01',periods=4,freq='h'),
            open=[3,3,3,3],high=[4]*4,low=[2]*4,close=[3]*4,spread_price=[0]*4))
        with self.assertRaises(ValueError): classify_csv(df)

if __name__=='__main__': unittest.main()
