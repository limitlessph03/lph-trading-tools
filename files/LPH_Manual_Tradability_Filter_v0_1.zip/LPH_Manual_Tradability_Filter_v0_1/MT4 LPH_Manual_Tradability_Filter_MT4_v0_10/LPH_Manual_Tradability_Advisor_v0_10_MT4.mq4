//+------------------------------------------------------------------+
//| LPH_Manual_Tradability_Advisor_v0_10_MT4.mq4                     |
//| MT4 port of supplied MT5 indicator v0.10                         |
//| RESEARCH ONLY: No trading, order management or EA modifications. |
//| Native MT4 MetaEditor compilation / broker parity NOT yet tested.|
//+------------------------------------------------------------------+
#property copyright "Limitless PH | Private Research"
#property version   "0.10"
#property strict
#property indicator_chart_window
#property indicator_buffers 0

input ENUM_TIMEFRAMES InpEvaluationTF = PERIOD_H1;
input int             InpHistoryBars = 240;
input int             InpRefreshSeconds = 20;
input int             InpStaleQuoteSeconds = 180;
input ENUM_BASE_CORNER InpPanelCorner = CORNER_RIGHT_UPPER;
input int             InpPanelX = 20;
input int             InpPanelY = 35;
input bool            InpWriteResearchLog = false;
// MT4 broker histories can lack spread on a closed bar. In that case,
// estimate the prior-bar *cost gate* from the CURRENT spread, and flag it.
input bool            InpPriorSpreadFallback = true;

string g_prefix = "";
datetime g_lastLoggedClosedBar = 0;
datetime g_lastSeenQuoteTime = 0;
datetime g_lastQuoteChangeLocal = 0;
const int LINE_COUNT = 8;

struct Metrics
  {
   double er;
   int    crosses;
   double atr;
   double vol_ratio;
   double spread_ratio;
   int    score;
   string raw_state;
  };

int OnInit()
  {
   g_prefix = "LPH_MTA_MT4_v010_"+IntegerToString(ChartID())+"_";
   IndicatorShortName("LPH Manual Tradability v0.10 MT4 (Advisory)");
   int interval = InpRefreshSeconds;
   if(interval < 5) interval = 5;
   if(!EventSetTimer(interval))
     {
      Print("[LPH MTA MT4] Timer setup failed: ",GetLastError());
      return(INIT_FAILED);
     }
   UpdateAdvisor();
   return(INIT_SUCCEEDED);
  }

void OnDeinit(const int reason)
  {
   EventKillTimer();
   for(int i=0;i<LINE_COUNT;i++)
      ObjectDelete(0,g_prefix+IntegerToString(i));
  }

// The display is refreshed by OnTimer and optionally at initial calculation.
// All measurements use completed evaluation timeframe bars, not candle 0.
int OnCalculate(const int rates_total,const int prev_calculated,
                const datetime &time[],const double &open[],
                const double &high[],const double &low[],
                const double &close[],const long &tick_volume[],
                const long &volume[],const int &spread[])
  {
   if(prev_calculated==0) UpdateAdvisor();
   return(rates_total);
  }

void OnTimer() { UpdateAdvisor(); }

string TFName(const ENUM_TIMEFRAMES tf)
  {
   // Compact, consistent with familiar MT4 timeframe labels.
   if(tf==PERIOD_M1) return("PERIOD_M1");
   if(tf==PERIOD_M5) return("PERIOD_M5");
   if(tf==PERIOD_M15) return("PERIOD_M15");
   if(tf==PERIOD_M30) return("PERIOD_M30");
   if(tf==PERIOD_H1) return("PERIOD_H1");
   if(tf==PERIOD_H4) return("PERIOD_H4");
   if(tf==PERIOD_D1) return("PERIOD_D1");
   if(tf==PERIOD_W1) return("PERIOD_W1");
   if(tf==PERIOD_MN1) return("PERIOD_MN1");
   return(EnumToString(tf));
  }

void Line(const int n,const string msg,const color clr)
  {
   string key=g_prefix+IntegerToString(n);
   if(ObjectFind(0,key)<0)
     {
      if(!ObjectCreate(0,key,OBJ_LABEL,0,0,0)) return;
      ObjectSetInteger(0,key,OBJPROP_CORNER,InpPanelCorner);
      // Keep text inside the chart on any selected panel corner.
      if(InpPanelCorner==CORNER_RIGHT_UPPER || InpPanelCorner==CORNER_RIGHT_LOWER)
         ObjectSetInteger(0,key,OBJPROP_ANCHOR,ANCHOR_RIGHT_UPPER);
      else ObjectSetInteger(0,key,OBJPROP_ANCHOR,ANCHOR_LEFT_UPPER);
      ObjectSetInteger(0,key,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,key,OBJPROP_HIDDEN,true);
      ObjectSetString(0,key,OBJPROP_FONT,"Consolas");
      ObjectSetInteger(0,key,OBJPROP_FONTSIZE,9);
     }
   ObjectSetInteger(0,key,OBJPROP_XDISTANCE,InpPanelX);
   ObjectSetInteger(0,key,OBJPROP_YDISTANCE,InpPanelY+n*17);
   ObjectSetInteger(0,key,OBJPROP_COLOR,clr);
   ObjectSetString(0,key,OBJPROP_TEXT,msg);
  }

void Render(const string status,const string reason,const Metrics &m,
            const bool prior_spread_fallback)
  {
   color status_color=clrOrange;
   if(status=="ORDERLY") status_color=clrLimeGreen;
   if(status=="CHAOTIC") status_color=clrTomato;
   if(status=="DATA NOT READY" || status=="DATA STALE") status_color=clrSilver;

   Line(0,"LPH | MANUAL TRADABILITY [MT4]",clrLightSkyBlue);
   Line(1,TFName(InpEvaluationTF)+" MODEL: "+status,status_color);
   if(status=="DATA NOT READY" || status=="DATA STALE")
     {
      Line(2,reason,clrSilver);
      Line(3,"Closed bars / current quote required",clrSilver);
      Line(4,"",clrSilver);
      Line(5,"",clrSilver);
     }
   else
     {
      Line(2,StringFormat("Score %d/100  ER20 %.2f  Cross16 %d",m.score,m.er,m.crosses),clrWhite);
      Line(3,StringFormat("ATR ratio %.2fx  Spread/ATR %.1f%%",m.vol_ratio,m.spread_ratio*100.0),clrWhite);
      Line(4,"Rule: two completed evaluation bars",clrSilver);
      if(prior_spread_fallback)
         Line(5,"PRIOR SPREAD: current-quote fallback",clrKhaki);
      else Line(5,"",clrSilver);
     }
   Line(6,"NEWS / PROP FLOOR: MANUAL CHECK",clrKhaki);
   Line(7,"ADVISORY ONLY. NOT A TRADE SIGNAL.",clrSilver);
   ChartRedraw(0);
  }

// CopyRates() returns the oldest sampled bar first in physical memory.
// We request starting from shift=1, and force chronological indexing.
// No current/incomplete evaluation bar is ever used in a calculation.
double TrueRange(const MqlRates &r[],const int i)
  {
   double a=r[i].high-r[i].low;
   double b=MathAbs(r[i].high-r[i-1].close);
   double c=MathAbs(r[i].low-r[i-1].close);
   return(MathMax(a,MathMax(b,c)));
  }

double ATR14(const MqlRates &r[],const int end)
  {
   if(end<14) return(0);
   double s=0;
   for(int i=end-13;i<=end;i++) s+=TrueRange(r,i);
   return(s/14.0);
  }

double MedianArray(double &v[])
  {
   int n=ArraySize(v);
   if(n<=0) return(0);
   ArraySort(v);
   if(n%2!=0) return(v[n/2]);
   return((v[n/2-1]+v[n/2])*0.5);
  }

bool ComputeMetrics(const MqlRates &r[],const int end,
                    const double spread_price,Metrics &m)
  {
   if(end<119 || spread_price<=0) return(false);

   double move=0;
   for(int i=end-19;i<=end;i++)
      move+=MathAbs(r[i].close-r[i-1].close);
   m.er=0;
   if(move>0) m.er=MathAbs(r[end].close-r[end-20].close)/move;

   double ema[];
   ArrayResize(ema,end+1);
   double alpha=2.0/21.0;
   ema[0]=r[0].close;
   for(int i=1;i<=end;i++)
      ema[i]=alpha*r[i].close+(1.0-alpha)*ema[i-1];
   m.crosses=0;
   for(int i=end-15;i<=end;i++)
     {
      double prev=r[i-1].close-ema[i-1];
      double curr=r[i].close-ema[i];
      if((prev>0 && curr<0)||(prev<0 && curr>0)) m.crosses++;
     }

   m.atr=ATR14(r,end);
   if(m.atr<=0 || !MathIsValidNumber(m.atr)) return(false);
   double v[];
   ArrayResize(v,100);
   for(int j=0;j<100;j++)
     {
      v[j]=ATR14(r,end-99+j);
      if(v[j]<=0) return(false);
     }
   double base=MedianArray(v);
   if(base<=0) return(false);
   m.vol_ratio=m.atr/base;
   m.spread_ratio=spread_price/m.atr;

   int e=8;
   if(m.er>=.40) e=40;
   else if(m.er>=.27) e=30;
   else if(m.er>=.17) e=20;
   int c=0;
   if(m.crosses<=2) c=25;
   else if(m.crosses<=4) c=16;
   else if(m.crosses<=6) c=8;
   int vscore=2;
   if(m.vol_ratio<=1.50) vscore=20;
   else if(m.vol_ratio<=2.00) vscore=14;
   else if(m.vol_ratio<=2.60) vscore=7;
   int cost=0;
   if(m.spread_ratio<=.03) cost=15;
   else if(m.spread_ratio<=.06) cost=10;
   else if(m.spread_ratio<=.10) cost=5;
   m.score=e+c+vscore+cost;

   bool joint=(m.er<.17 && m.crosses>=5) ||
              (m.vol_ratio>2.0 && m.er<.27) ||
              (m.spread_ratio>.10 && m.crosses>=5);
   if(m.score<45 && joint) m.raw_state="CHAOTIC";
   else if(m.score>=65 && m.er>=.22 && m.spread_ratio<=.10)
      m.raw_state="ORDERLY";
   else m.raw_state="CAUTION";
   return(true);
  }

void SaveSnapshot(const datetime closed_bar,const Metrics &m,const string status)
  {
   if(!InpWriteResearchLog || closed_bar<=0 || closed_bar==g_lastLoggedClosedBar)
      return;
   string fname="LPH_Manual_Tradability_Advisor_MT4_v010.csv";
   int f=FileOpen(fname,FILE_CSV|FILE_READ|FILE_WRITE|FILE_SHARE_READ|FILE_ANSI,',');
   if(f==INVALID_HANDLE)
     {
      Print("[LPH MTA MT4] Research CSV open failed, error=",GetLastError());
      return;
     }
   if(FileSize(f)==0)
      FileWrite(f,"closed_bar_open_time_server","symbol","timeframe","status","raw_state",
                "score","er20","crosses16","atr_ratio","spread_atr");
   FileSeek(f,0,SEEK_END);
   FileWrite(f,TimeToString(closed_bar,TIME_DATE|TIME_MINUTES),Symbol(),
             TFName(InpEvaluationTF),status,m.raw_state,m.score,
             DoubleToString(m.er,5),m.crosses,DoubleToString(m.vol_ratio,5),
             DoubleToString(m.spread_ratio,5));
   FileClose(f);
   g_lastLoggedClosedBar=closed_bar;
  }

void UpdateAdvisor()
  {
   Metrics blank;
   ZeroMemory(blank);
   if(!IsConnected())
     {
      Render("DATA STALE","TERMINAL DISCONNECTED",blank,false);
      return;
     }

   MqlTick tick;
   if(!SymbolInfoTick(Symbol(),tick) || tick.ask<=0 || tick.bid<=0 || tick.ask<=tick.bid)
     {
      Render("DATA NOT READY","Missing valid Bid / Ask",blank,false);
      return;
     }

   // MT4 has no TimeTradeServer(): track the most recent quote update using
   // the PC's local clock. This prevents silent stale panels when all quotes
   // stop updating (e.g., on weekends), after the observation window.
   datetime local_now=TimeLocal();
   if(tick.time!=g_lastSeenQuoteTime)
     {
      g_lastSeenQuoteTime=tick.time;
      g_lastQuoteChangeLocal=local_now;
     }
   if(g_lastQuoteChangeLocal>0 && InpStaleQuoteSeconds>0 &&
      (local_now-g_lastQuoteChangeLocal)>InpStaleQuoteSeconds)
     {
      Render("DATA STALE","Quote not updated",blank,false);
      return;
     }

   MqlRates r[];
   ArraySetAsSeries(r,false);
   int need=InpHistoryBars;
   if(need<140) need=140;
   int count=CopyRates(Symbol(),InpEvaluationTF,1,need,r);
   if(count<140)
     {
      Render("DATA NOT READY","Insufficient closed evaluation bars",blank,false);
      return;
     }
   int end=count-1;
   Metrics cur,prior;
   ZeroMemory(cur);
   ZeroMemory(prior);

   double point=MarketInfo(Symbol(),MODE_POINT);
   double prior_spread=point*(double)r[end-1].spread;
   bool fallback_used=false;
   if(prior_spread<=0 && InpPriorSpreadFallback)
     {
      prior_spread=tick.ask-tick.bid;
      fallback_used=true;
     }
   if(!ComputeMetrics(r,end,tick.ask-tick.bid,cur))
     {
      Render("DATA NOT READY","ATR, cost or history invalid",blank,false);
      return;
     }
   bool prior_ok=ComputeMetrics(r,end-1,prior_spread,prior);
   string state="CAUTION";
   if(prior_ok && cur.raw_state==prior.raw_state && cur.raw_state!="CAUTION")
      state=cur.raw_state;
   Render(state,"",cur,fallback_used);
   SaveSnapshot(r[end].time,cur,state);
  }
//+------------------------------------------------------------------+
