# LPH Manual Tradability Advisor v0.10 - MetaTrader 4

**Research prototype, chart indicator only. No order execution, no EA configuration changes.**

This is a direct MT4 translation of the supplied `LPH_Manual_Tradability_Advisor_v0_10.mq5`, retaining the **same metric definitions, thresholds and two-completed-bar confirmation**:

- Evaluation timeframe: **H1** by default, regardless of displayed chart timeframe.
- ER20 (20-completed-bar directional efficiency); EMA20 close crossing count over 16 bars.
- ATR14 / median ATR14 across 100 completed bars; current bid/ask spread / ATR14.
- Score weights: efficiency 40, crossings 25, volatility 20, transaction cost 15.
- Advisory states: `ORDERLY`, `CAUTION`, `CHAOTIC`, `DATA STALE`, `DATA NOT READY`.
- No news or prop-account risk integration. The display explicitly requires manual checks.

## Installation (MT4 only)

1. In a **demo / research MT4 terminal**, select **File > Open Data Folder**.
2. Copy `LPH_Manual_Tradability_Advisor_v0_10_MT4.mq4` to `MQL4/Indicators/`.
3. Open **MetaEditor (F4)**, open the `.mq4` and press **F7** to compile.
4. Confirm **0 compiler errors**. If there are errors, save the compile report for diagnosis.
5. In MT4 Navigator, right click **Indicators > Refresh**, and drag the indicator to any chart.
6. Use `InpEvaluationTF = PERIOD_H1` by default; keep `InpWriteResearchLog = false` initially.

You do **not** need to enable AutoTrading. Do not replace or alter any production EA.

## Notes / difference from supplied MT5 prototype

- MT4 does not expose MT5's `TimeTradeServer()` calculation. This version tracks observed quote updates against the local PC clock and displays `DATA STALE` after the configured idle period. Just after attaching a chart while the market is closed, the indicator may briefly consider its cached quote fresh; confirm a new broker quote before trusting any score.
- Some MT4 historical bars have `spread=0`. To prevent a missing previous-bar spread from forcing **every extreme state into CAUTION**, `InpPriorSpreadFallback=true` uses the current spread for the previous bar's **cost test** only when the historical value is missing. The panel labels this explicitly. When historical spreads are available, the original MT5 two-bar logic is used. Disable fallback for strict source-like behavior (which may yield false CAUTION on low-quality MT4 history).
- `COPYRATES` is requested with `shift=1` so the currently forming candle is excluded; the oldest returned closed bar is index 0, matching the MT5 arithmetic.
- Optional CSV saved in MT4 data folder, `MQL4/Files/LPH_Manual_Tradability_Advisor_MT4_v010.csv`.

## Validation status

- MT4 source file **created**; mathematical logic reviewed against user-supplied MT5 source.
- Static safety checks passed: no trade-placement, order-modification or external-library calls.
- **Not yet compiled in actual MT4 MetaEditor**. Native MT4 runtime and tester behavior remain unverified for this release.
- **Not validated for score / state parity on matching MT4 vs MT5 broker data**. Compare one symbol and timeframe on synchronized broker bars, verify closed-bar order, spreads, computed metrics, state, and quote freshness before wider use.
- **No claim** that the indicator improves discretionary profitability.

### Quick side-by-side parity acceptance checklist

| Field | Match requirement |
|---|---|
| Symbol/timeframe | Same broker instrument, exact same evaluation TF (H1 default) |
| Closed-bar timestamp | Same latest completed H1 bar |
| ER20, Cross16 | Same within display rounding |
| ATR ratio | Same within display rounding |
| Spread/ATR | Similar if current spreads differ; document differences |
| Score & raw classification | Same with matched spread inputs |
| Confirmed state | Same if preceding-bar spread histories match |

For any mismatch, compare broker OHLC and spreads before changing scoring thresholds.
