# LPH Manual Tradability Advisor - Multi-Asset v0.20

Read-only research dashboard for manual setup review. Places no orders.
This update includes MT4 and MT5 multi-asset scanner source and the legacy
single-symbol v0.10 indicators. Supplied MT4 EX4 binaries are included;
no MT5 EX5 binary was supplied. Binary/source correspondence, native compilation,
terminal behavior, and broker parity have not been independently verified here.
No trading performance validation is claimed.

## Multi-asset scanner setup

Use the matching `LPH_Manual_Tradability_MultiAsset_MT4_v0_20` or
`LPH_Manual_Tradability_MultiAsset_MT5_v0_20` file in the platform folder.
In a separate demo terminal, open File > Open Data Folder and copy the
matching files to MQL4/Indicators or MQL5/Indicators. Compile the source
with F7 in the matching MetaEditor before validation, refresh Navigator,
and attach one scanner instance to a chart. AutoTrading is not required.

`InpSymbolsCSV` defaults to XAUUSD, EURUSD, EURCHF, USDCAD, USDCHF, BTCUSD.
Use exact broker symbol names, including suffixes. `InpScanMarketWatch=true`
instead scans the first Market Watch symbols, subject to `InpMaxAssets`
(default 12, hard cap 20). The default evaluation timeframe is H1, with
240 requested history bars, a 20-second refresh and 180-second stale threshold.
The scanner can select symbols in Market Watch to obtain data.

Keep `InpRequireNewQuoteSinceAttach=true` and research logging off initially.
Wait for fresh quotes and sufficient closed history for each asset. Both new
scanners expose `InpPriorSpreadFallback`; consult their panel notices when
historical spreads are missing. Legacy single-symbol indicators have different
startup/spread handling. Do not assume matching platform/feed states.

ORDERLY is setup-review context, not an entry signal. CAUTION and CHAOTIC
require manual assessment; DATA NOT READY or DATA STALE must not be treated
as favorable. News, account limits, portfolio risk, commissions and actual
slippage require separate checks. Do not replace live EAs or presets.

## Other files

The checklist, blank observation log, provisional settings JSON, and optional
Python offline labeler remain included. JSON is a reference, not a preset loader.
The Python labeler requires NumPy and pandas; its synthetic engineering tests
do not verify the new MQL scanners, binary parity, or trading performance.

Sources and supplied binaries are unchanged from the updated upload.
Private design rationale and research-register notes are excluded.
SHA256_MANIFEST.json covers this public package's files.
