# LPH Manual Trade Gate | 30-second checklist (v0.1 proposal)

**PURPOSE:** Advisory decision aid. A favorable indicator state does not authorize a trade.

Before placing a **new** manual trade:

1. **Account:** Is maximum plausible aggregate loss (open positions + pending orders + planned new SL, fees, gap/slippage reserve) within my *actual current* equity/daily/overall limits? Is a server stop-out, failed execution or frozen close request unresolved? If yes to an execution issue or no to risk headroom: **NO NEW ORDER**. Verify through the broker first.
2. **EA status:** Is a related EA deliberately regime-blocked? If yes, record *why* I think this **separate manual setup** is valid. Silence/zero trades is not an entry signal. Never adjust the EA to force a trade.
3. **News:** Is a high-impact scheduled event in my trade horizon or unfolding unscheduled? Check a trusted calendar/headlines; screen has **no** live calendar integration. Consider standing aside. Time windows are trade-specific, not a universal cutoff.
4. **Environment:** `ORDERLY` = may proceed to *setup review*. `CAUTION` = require exceptionally clear planned setup, smaller exposure and documented override. `CHAOTIC` = defer new discretionary direction until conditions stabilize. `DATA NOT READY` = cannot use indicator.
5. **Setup:** Clearly defined bias, actual trigger, entry, stop, target, costs and expected R **before entry**; no market order solely to recover losses or because the EAs were idle.
6. **Hedge:** Does the proposed hedge materially reduce **net worst-case account loss** after gross exposure, spread, fees and both stops? If not, it is another position, not proven protection.
7. **Log:** Record the planned trade **including skipped setups** in `manual_trade_observation_log.csv`, before results are known. An override without a pre-trade reason is noncompliant with the study, even if profitable.

### Default decision logic

`NO NEW ORDER` for confirmed risk/processing constraints; `CHAOTIC` = stand aside by default; `CAUTION` = document exception; `ORDERLY` = still requires valid trade setup and risk capacity.

Never close/open positions automatically based on this research indicator. Risk decision thresholds must reflect the specific prop/account rule, not a hard-coded global daily percentage.
