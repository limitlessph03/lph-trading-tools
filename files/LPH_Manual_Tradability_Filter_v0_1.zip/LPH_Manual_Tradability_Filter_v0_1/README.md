# LPH Manual Tradability Advisor v0.10

Source-only research prototype for MT4 and MT5. This read-only chart indicator
provides environment context for manual setup review. It places no orders and
does not generate entries, directional forecasts, or calibrated probabilities.

## Status

- The indicator sources are unchanged from the supplied prototype.
- No compiled EX4/EX5 binaries are included. Native MetaEditor compilation,
  terminal behavior, and matched MT4/MT5 broker-feed parity remain unverified.
- Five supplied deterministic Python engineering tests passed on October 30,
  2026. These tests do not validate the MQL indicators or trading performance.
- Thresholds are provisional. No backtest, forward test, or live profitability
  claim is made. Public website availability is distribution, not trading validation.

## Package layout

- `MT4 LPH_Manual_Tradability_Filter_MT4_v0_10/`: MQ4 source and MT4 notes.
- `MT5 LPH_Manual_Tradability_Filter_v0_1/`: MQ5 source, MT5 notes, and the
  optional offline Python labeler with its engineering tests.
- `MANUAL_PRETRADE_CHECKLIST.md`: manual review checklist.
- `manual_trade_observation_log.csv`: blank observation template.
- `settings_proposal.json`: reference settings only, not an importable preset.
- `SHA256_MANIFEST.json`: checksums for this public distribution.

## Installation and first use

1. Use a separate demo/research terminal. In MetaTrader, select File > Open Data Folder.
2. Copy the platform's source into `MQL4/Indicators/` or `MQL5/Indicators/`.
3. Open that source in the matching MetaEditor and compile with F7. Resolve
   errors and review warnings before attaching it. Compilation is not runtime validation.
4. Refresh Navigator and attach the indicator to a demo chart. Keep
   `InpEvaluationTF = PERIOD_H1` and `InpWriteResearchLog = false` initially.
   AutoTrading is not required. Use one advisor instance per chart.
5. Confirm fresh quotes, the evaluation timeframe, closed-bar history, spread,
   and restart/no-tick behavior. Compare matching broker bars before assuming
   MT4/MT5 agreement. Do not replace existing EAs, presets, or live indicators.

## Reading the panel

- `ORDERLY`: proceed to manual setup and risk review; it is not an entry signal.
- `CAUTION`: mixed conditions requiring manual assessment.
- `CHAOTIC`: persistent adverse conditions requiring additional caution.
- `DATA NOT READY` / `DATA STALE`: do not rely on the advisory state.

The H1 default uses ER20, EMA20 close crossings across 16 completed bars,
a simple 14-bar true-range average relative to its 100-bar median, and current
spread divided by that average. Extreme states require agreement with the
preceding completed-bar evaluation. This is not standard Wilder ATR. At least
140 completed evaluation bars are required; the requested history defaults to 240.

MT4 can use the current spread when the preceding historical spread is missing,
with an explicit panel notice. A cached MT4 quote may briefly look fresh on
startup; confirm an actual new broker quote. MT5 does not use that spread
fallback. See each platform's README before comparing results.

News, commissions, swaps, slippage, account limits, and portfolio risk are not
integrated. Check these separately. The indicator cannot enforce a trading prohibition.

## Optional offline labeler

Requires Python, NumPy, and pandas. From the MT5 folder, run:

```text
python -m unittest -v test_offline_regime_labels.py
python offline_regime_labels.py closed_h1_bars.csv --out labels.csv
```

CSV columns: `time,open,high,low,close,spread_price`. Use only fully closed H1
bars. Spread is a positive bid/ask difference in price units, not pips or points.
Outputs are labels, not a trading backtest. The offline expanding EMA/history,
readiness rules, and historical spreads can differ from the terminal indicator's
rolling history/current quote, so matching terminal parity is not established.

## Distribution

This public package contains the tool, installation notes, and blank templates.
Internal design rationale and research-register notes are excluded. The original
private archive remains unchanged. The manifest describes this distribution only.
