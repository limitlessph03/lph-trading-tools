//+------------------------------------------------------------------+
//| LPH_MultiPair_Scanner.mq5                                        |
//| Multi-Pair Quantitative Probability Scanner & Radar (MT5).       |
//| Monitors an entire basket of pairs simultaneously on ONE chart!  |
//+------------------------------------------------------------------+
#property copyright "MetaTrader Assistant"
#property version   "3.70"
#property indicator_chart_window
#property indicator_plots   0

//--- Inputs
input group "=== 1. Multi-Pair Watchlist ==="
input string               InpSymbolsList      = "XAUUSD,EURUSD,GBPUSD,USDJPY,AUDUSD,USDCAD,USDCHF,NZDUSD,BTCUSD,US30,NAS100"; // Comma-separated Symbol List
input ENUM_TIMEFRAMES      InpScanTF           = PERIOD_H4;        // Timeframe to Scan (H4, D1, H1)
input int                  InpTimerSeconds     = 5;                // Refresh Interval (Seconds)

input group "=== 2. Strategy & Filter Settings ==="
input int                  InpEMA8             = 8;
input int                  InpEMA20            = 20;
input int                  InpEMA50            = 50;
input int                  InpATR              = 14;
input double               InpDeepATR          = 0.50;             // Deep Trigger (x ATR below event)
input double               InpZone1ATR         = 1.50;             // Zone 1 (x ATR below event)
input double               InpZone2ATR         = 2.60;             // Zone 2 (x ATR below event)
input int                  InpSurvBars         = 12;               // Survival lookahead bars
input int                  InpMaxEventAgeBars  = 24;               // Max event age to display
input bool                 InpUseSlopeFilter   = true;             // Filter by EMA50 slope
input double               InpMinSlopeATR      = 0.05;

input group "=== 3. Smart Alerts ==="
input bool                 InpAlertPopup       = true;             // Desktop Popup Alert
input bool                 InpAlertPush        = false;            // Push Notification to Mobile App
input bool                 InpAlertSound       = true;             // Sound Audio Alert

input group "=== 4. Scanner Dashboard UI ==="
input ENUM_BASE_CORNER     InpPanelCorner      = CORNER_LEFT_UPPER;// Dashboard Corner
input int                  InpPanelX           = 20;               // Dashboard X Offset (pixels)
input int                  InpPanelY           = 35;               // Dashboard Y Offset (pixels)
input int                  InpRowHeight        = 22;               // Table Row Height
input color                InpTriggerColor     = C'255,75,75';     // Trigger Color
input color                InpZoneColor        = C'255,205,0';     // Zone Color

struct SSymbolScanResult
  {
   string      symbol;
   bool        valid;
   int         totalEvents;
   int         cleanEvents;
   int         deepEvents;
   double      pClean;
   double      pDeep;
   double      avgDeepATR;
   int         eventBarAge;
   datetime    eventTime;
   double      eventClose;
   double      triggerPrice;
   double      zone1Price;
   double      zone2Price;
   bool        hasActiveEvent;
   bool        deepTriggered;
   bool        inTargetZone;
   int         survivedBars;
   string      statusText;
   color       statusColor;
   datetime    lastAlertEvent;
  };

SSymbolScanResult g_results[];
string            g_symbols[];
int               g_symbolCount = 0;
string            g_prefix = "LPHSCAN_";
bool              g_firstRunDone = false;

void CalcEMA(const double &p[], const int period, double &e[], const int n)
  {
   for(int i = 0; i < n; i++) e[i] = EMPTY_VALUE;
   if(n < period || period <= 0) return;

   double sum = 0.0;
   for(int i = 0; i < period; i++) sum += p[i];
   e[period - 1] = sum / (double)period;
   double k = 2.0 / ((double)period + 1.0);

   for(int i = period; i < n; i++)
     {
      if(e[i - 1] == EMPTY_VALUE) e[i] = p[i];
      else e[i] = p[i] * k + e[i - 1] * (1.0 - k);
     }
  }

void SendMultiAlert(string sym, string title, string msg)
  {
   string fullMsg = "[LPH Scanner] " + sym + " (" + EnumToString(InpScanTF) + ") " + title + "\n" + msg;
   if(InpAlertPopup) Alert(fullMsg);
   if(InpAlertPush)  SendNotification(fullMsg);
   if(InpAlertSound) PlaySound("expert.wav");
  }

void ScanSingleSymbol(int idx)
  {
   string sym = g_symbols[idx];
   g_results[idx].symbol = sym;
   g_results[idx].valid = false;

   int nReq = 400;
   MqlRates r[];
   if(CopyRates(sym, InpScanTF, 0, nReq, r) < InpEMA50 + InpSurvBars + 10) return;

   int n = ArraySize(r);
   double close[], high[], low[], open[];
   ArrayResize(close, n); ArrayResize(high, n); ArrayResize(low, n); ArrayResize(open, n);
   for(int i = 0; i < n; i++)
     {
      close[i] = r[i].close; high[i] = r[i].high; low[i] = r[i].low; open[i] = r[i].open;
     }

   double e50[], e8[], e20[], atr[];
   ArrayResize(e50, n); ArrayResize(e8, n); ArrayResize(e20, n); ArrayResize(atr, n);
   CalcEMA(close, InpEMA50, e50, n);
   CalcEMA(close, InpEMA8,  e8,  n);
   CalcEMA(close, InpEMA20, e20, n);

   for(int i = 0; i < n; i++)
     {
      if(i >= InpATR)
        {
         double s = 0.0;
         for(int j = i - (InpATR - 1); j <= i; j++)
            s += MathMax(high[j] - low[j], MathMax(MathAbs(high[j] - close[j - 1]), MathAbs(low[j] - close[j - 1])));
         atr[i] = s / (double)InpATR;
        }
      else if(i > 0) atr[i] = MathMax(high[i] - low[i], MathMax(MathAbs(high[i] - close[i - 1]), MathAbs(low[i] - close[i - 1])));
      else atr[i] = high[i] - low[i];
     }

   int tot = 0, clean = 0, deep = 0;
   double sumDeepATR = 0.0;

   for(int i = InpEMA50 + 5; i < n - 1 - InpSurvBars; i++)
     {
      if(e50[i] == EMPTY_VALUE || e50[i-1] == EMPTY_VALUE || e8[i-1] == EMPTY_VALUE || e20[i-1] == EMPTY_VALUE) continue;
      if(close[i] >= e50[i]) continue;
      if(!(close[i - 1] > e50[i - 1])) continue;
      if(!(e8[i - 1] > e20[i - 1])) continue;

      if(InpUseSlopeFilter && e50[i - 5] != EMPTY_VALUE)
        {
         double slope = (e50[i - 1] - e50[i - 5]) / (atr[i - 1] > 0 ? atr[i - 1] : 1.0);
         if(slope < InpMinSlopeATR) continue;
        }

      tot++;
      bool reverted = false, isDeeper = false;
      double minClose = close[i];
      for(int j = i + 1; j <= i + InpSurvBars && j < n; j++)
        {
         if(close[j] < minClose) minClose = close[j];
         if(!reverted && close[j] > e50[j]) reverted = true;
         if(!isDeeper && close[j] <= close[i] - InpDeepATR * atr[i]) isDeeper = true;
        }
      double depthATR = (close[i] - minClose) / (atr[i] > 0 ? atr[i] : 1.0);
      if(reverted && !isDeeper) clean++;
      else { deep++; sumDeepATR += depthATR; }
     }

   g_results[idx].totalEvents = tot;
   g_results[idx].cleanEvents = clean;
   g_results[idx].deepEvents  = deep;
   g_results[idx].pClean      = (tot > 0) ? (100.0 * (double)clean / (double)tot) : 0.0;
   g_results[idx].pDeep       = (tot > 0) ? (100.0 * (double)deep  / (double)tot) : 0.0;
   g_results[idx].avgDeepATR  = (deep > 0) ? (sumDeepATR / (double)deep) : 2.6;

   int evAnchor = -1;
   for(int i = n - 2; i >= InpEMA50 + 5; i--)
     {
      if(e50[i] == EMPTY_VALUE || e50[i-1] == EMPTY_VALUE || e8[i-1] == EMPTY_VALUE || e20[i-1] == EMPTY_VALUE) continue;
      if(close[i] >= e50[i]) continue;
      if(!(close[i - 1] > e50[i - 1])) continue;
      if(!(e8[i - 1] > e20[i - 1])) continue;

      if(InpUseSlopeFilter && e50[i - 5] != EMPTY_VALUE)
        {
         double slope = (e50[i - 1] - e50[i - 5]) / (atr[i - 1] > 0 ? atr[i - 1] : 1.0);
         if(slope < InpMinSlopeATR) continue;
        }
      evAnchor = i;
      break;
     }

   if(evAnchor >= 0)
     {
      int age = (n - 1) - evAnchor;
      g_results[idx].eventBarAge   = age;
      g_results[idx].eventTime     = r[evAnchor].time;
      g_results[idx].eventClose    = close[evAnchor];
      g_results[idx].triggerPrice  = close[evAnchor] - InpDeepATR * atr[evAnchor];
      g_results[idx].zone1Price    = close[evAnchor] - InpZone1ATR * atr[evAnchor];
      double z2ATR = g_results[idx].avgDeepATR > 0 ? MathMax(g_results[idx].avgDeepATR, InpZone1ATR) : 2.6;
      g_results[idx].zone2Price    = close[evAnchor] - z2ATR * atr[evAnchor];
      g_results[idx].hasActiveEvent = (age <= InpMaxEventAgeBars);

      g_results[idx].deepTriggered = false;
      g_results[idx].survivedBars  = 0;
      for(int k = evAnchor + 1; k < n; k++)
        {
         if(close[k] <= g_results[idx].triggerPrice)
           {
            g_results[idx].deepTriggered = true;
            break;
           }
         g_results[idx].survivedBars++;
        }

      double currentPrice = close[n - 1];
      g_results[idx].inTargetZone = (currentPrice <= g_results[idx].zone1Price && currentPrice >= g_results[idx].zone2Price);

      if(g_results[idx].hasActiveEvent)
        {
         if(g_results[idx].inTargetZone)
           {
            g_results[idx].statusText  = "🎯 IN VALUE ZONE";
            g_results[idx].statusColor = C'255,215,0';
           }
         else if(g_results[idx].deepTriggered)
           {
            g_results[idx].statusText  = "🔴 DEEP PATH";
            g_results[idx].statusColor = C'255,85,85';
           }
         else
           {
            g_results[idx].statusText  = "🟢 SHALLOW BOUNCE (" + IntegerToString(g_results[idx].survivedBars) + "b)";
            g_results[idx].statusColor = C'0,230,130';
           }
        }
      else
        {
         g_results[idx].statusText  = "⚪ MONITORING";
         g_results[idx].statusColor = C'140,150,170';
        }

      if(g_firstRunDone && g_results[idx].hasActiveEvent)
        {
         if(g_results[idx].eventTime != g_results[idx].lastAlertEvent && age <= 1)
           {
            SendMultiAlert(sym, "New Pullback Event", "Closed below EMA50 at " + DoubleToString(g_results[idx].eventClose, (int)SymbolInfoInteger(sym, SYMBOL_DIGITS)));
            g_results[idx].lastAlertEvent = g_results[idx].eventTime;
           }
        }
     }
   else
     {
      g_results[idx].hasActiveEvent = false;
      g_results[idx].statusText     = "⚪ MONITORING";
      g_results[idx].statusColor    = C'140,150,170';
     }

   g_results[idx].valid = true;
  }

void CreateCell(string id, int x, int y, string text, color clr, int fontSize, bool isBold = false)
  {
   string fullId = g_prefix + id;
   if(ObjectFind(0, fullId) < 0) ObjectCreate(0, fullId, OBJ_LABEL, 0, 0, 0);
   ObjectSetInteger(0, fullId, OBJPROP_CORNER, InpPanelCorner);
   ObjectSetInteger(0, fullId, OBJPROP_XDISTANCE, InpPanelX + x);
   ObjectSetInteger(0, fullId, OBJPROP_YDISTANCE, InpPanelY + y);
   ObjectSetInteger(0, fullId, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, fullId, OBJPROP_FONTSIZE, fontSize);
   ObjectSetString(0, fullId, OBJPROP_FONT, isBold ? "Segoe UI Semibold" : "Segoe UI");
   ObjectSetString(0, fullId, OBJPROP_TEXT, text);
   ObjectSetInteger(0, fullId, OBJPROP_BACK, false);
   ObjectSetInteger(0, fullId, OBJPROP_SELECTABLE, false);
  }

void DrawScannerDashboard()
  {
   int tableW = 680;
   int headerH = 50;
   int tableH = headerH + (g_symbolCount * InpRowHeight) + 20;

   string bgId = g_prefix + "bg";
   if(ObjectFind(0, bgId) < 0) ObjectCreate(0, bgId, OBJ_RECTANGLE_LABEL, 0, 0, 0);
   ObjectSetInteger(0, bgId, OBJPROP_CORNER, InpPanelCorner);
   ObjectSetInteger(0, bgId, OBJPROP_XDISTANCE, InpPanelX);
   ObjectSetInteger(0, bgId, OBJPROP_YDISTANCE, InpPanelY);
   ObjectSetInteger(0, bgId, OBJPROP_XSIZE, tableW);
   ObjectSetInteger(0, bgId, OBJPROP_YSIZE, tableH);
   ObjectSetInteger(0, bgId, OBJPROP_BGCOLOR, C'14,18,26');
   ObjectSetInteger(0, bgId, OBJPROP_BORDER_COLOR, C'45,60,85');
   ObjectSetInteger(0, bgId, OBJPROP_BORDER_TYPE, BORDER_FLAT);

   string barId = g_prefix + "bar";
   if(ObjectFind(0, barId) < 0) ObjectCreate(0, barId, OBJ_RECTANGLE_LABEL, 0, 0, 0);
   ObjectSetInteger(0, barId, OBJPROP_CORNER, InpPanelCorner);
   ObjectSetInteger(0, barId, OBJPROP_XDISTANCE, InpPanelX);
   ObjectSetInteger(0, barId, OBJPROP_YDISTANCE, InpPanelY);
   ObjectSetInteger(0, barId, OBJPROP_XSIZE, tableW);
   ObjectSetInteger(0, barId, OBJPROP_YSIZE, 4);
   ObjectSetInteger(0, barId, OBJPROP_BGCOLOR, C'0,210,255');
   ObjectSetInteger(0, barId, OBJPROP_BORDER_COLOR, C'0,210,255');

   CreateCell("h_title", 15, 10, "⚡ LPH MULTI-PAIR QUANT RADAR", C'240,245,255', 10, true);
   CreateCell("h_sub", 15, 26, "Monitoring " + IntegerToString(g_symbolCount) + " pairs on " + EnumToString(InpScanTF) + " • Real-Time Statistical Radar", C'140,160,190', 8);

   int curY = headerH;
   CreateCell("th_sym",  15,  curY, "SYMBOL",     C'180,200,230', 8, true);
   CreateCell("th_stat", 95,  curY, "STATE / PHASE", C'180,200,230', 8, true);
   CreateCell("th_pcln", 260, curY, "P(CLEAN)",   C'180,200,230', 8, true);
   CreateCell("th_pdep", 335, curY, "P(DEEP)",    C'180,200,230', 8, true);
   CreateCell("th_trig", 405, curY, "TRIGGER",    C'180,200,230', 8, true);
   CreateCell("th_zone", 495, curY, "TARGET ZONE",C'180,200,230', 8, true);
   CreateCell("th_hist", 605, curY, "SAMPLE",     C'180,200,230', 8, true);

   CreateCell("th_div",  15,  curY + 12, "──────────────────────────────────────────────────────────────────────────", C'40,55,75', 8);

   curY += 24;
   for(int i = 0; i < g_symbolCount; i++)
     {
      string rowPrefix = "r_" + IntegerToString(i) + "_";
      string sym = g_results[i].symbol;
      int dg = (int)SymbolInfoInteger(sym, SYMBOL_DIGITS);
      if(dg <= 0) dg = 2;

      color symColor = (sym == _Symbol) ? C'0,230,255' : C'230,235,245';
      CreateCell(rowPrefix + "sym", 15, curY, sym + (sym == _Symbol ? " ◄" : ""), symColor, 8, true);
      CreateCell(rowPrefix + "stat", 95, curY, g_results[i].statusText, g_results[i].statusColor, 8, true);

      if(g_results[i].totalEvents > 0)
        {
         CreateCell(rowPrefix + "pcln", 260, curY, DoubleToString(g_results[i].pClean, 1) + "%", C'0,230,130', 8);
         CreateCell(rowPrefix + "pdep", 335, curY, DoubleToString(g_results[i].pDeep, 1) + "%",  C'255,160,50', 8);
        }
      else
        {
         CreateCell(rowPrefix + "pcln", 260, curY, "──", C'100,115,135', 8);
         CreateCell(rowPrefix + "pdep", 335, curY, "──", C'100,115,135', 8);
        }

      if(g_results[i].hasActiveEvent)
        {
         CreateCell(rowPrefix + "trig", 405, curY, DoubleToString(g_results[i].triggerPrice, dg), InpTriggerColor, 8);
         CreateCell(rowPrefix + "zone", 495, curY, DoubleToString(g_results[i].zone1Price, dg) + "-" + DoubleToString(g_results[i].zone2Price, dg), InpZoneColor, 8);
        }
      else
        {
         CreateCell(rowPrefix + "trig", 405, curY, "──", C'100,115,135', 8);
         CreateCell(rowPrefix + "zone", 495, curY, "──", C'100,115,135', 8);
        }

      CreateCell(rowPrefix + "hist", 605, curY, IntegerToString(g_results[i].totalEvents) + " ev", C'150,165,185', 8);
      curY += InpRowHeight;
     }
  }

void ParseSymbolList()
  {
   string parts[];
   int count = StringSplit(InpSymbolsList, ',', parts);
   g_symbolCount = 0;
   ArrayResize(g_symbols, 0);

   for(int i = 0; i < count; i++)
     {
      string s = parts[i];
      StringTrimLeft(s);
      StringTrimRight(s);
      if(StringLen(s) > 0)
        {
         SymbolSelect(s, true);
         int newSize = ArraySize(g_symbols) + 1;
         ArrayResize(g_symbols, newSize);
         g_symbols[newSize - 1] = s;
         g_symbolCount++;
        }
     }
   ArrayResize(g_results, g_symbolCount);
  }

int OnInit()
  {
   ParseSymbolList();
   EventSetTimer(InpTimerSeconds);
   return INIT_SUCCEEDED;
  }

void OnDeinit(const int reason)
  {
   EventKillTimer();
   ObjectsDeleteAll(0, g_prefix);
  }

void OnTimer()
  {
   for(int i = 0; i < g_symbolCount; i++)
     {
      ScanSingleSymbol(i);
     }
   DrawScannerDashboard();
   g_firstRunDone = true;
  }

int OnCalculate(const int rates_total, const int prev_calculated,
                const datetime &time[], const double &open[], const double &high[],
                const double &low[], const double &close[], const long &tick_volume[],
                const long &volume[], const int &spread[])
  {
   if(!g_firstRunDone)
     {
      OnTimer();
     }
   return rates_total;
  }
//+------------------------------------------------------------------+
