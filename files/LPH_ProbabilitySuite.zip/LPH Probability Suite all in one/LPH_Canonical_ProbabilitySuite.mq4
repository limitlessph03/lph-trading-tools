//+------------------------------------------------------------------+
//| LPH_Canonical_ProbabilitySuite.mq4                              |
//| CANONICAL MERGED SUITE (v4.00) - MT4 EXACT REPLICA               |
//|   Engine 1: Intraday Pullback Probability Map (24-bar baseline)  |
//|   Engine 2: D1 Extension & Volume Probability Engine             |
//|   Output : Unified HUD, combined scenario read, chart levels,    |
//|            alerts, optional D1 research report.                   |
//|                                                                  |
//|  ALL statistical parameters are HARDCODED (canonical baseline).  |
//|  Only UI, alerts and trade-plan presentation remain adjustable.  |
//|                                                                  |
//|  INSTALL: copy this .mq4 to  <MT4 Data>\MQL4\Indicators\Alpha    |
//|           LPH\  then compile in MetaEditor (MT4).                |
//+------------------------------------------------------------------+
#property copyright "Limitless PH Trading Academy / MetaTrader Assistant"
#property link      "https://limitlessphtraining.com"
#property version   "4.00"
#property description "Canonical combination: intraday pullback probability map + D1 extension probability engine."
#property strict
#property indicator_chart_window
#property indicator_buffers 3
#property indicator_color1 C'255,145,0'
#property indicator_color2 C'0,170,255'
#property indicator_color3 C'0,220,130'

enum ENUM_EVAL_BAR
  {
   EVAL_TODAY_FORMING = 0, // Today's Forming D1 Bar (Shift 0)
   EVAL_PREVIOUS_D1   = 1, // Yesterday's Completed D1 Bar (Shift 1)
   EVAL_AUTO_SWITCH   = 2  // Auto: Prior D1 early session -> Today when active
  };

//=========================================================================
//  CANONICAL BASELINE - ENGINE 1: INTRADAY PULLBACK PROBABILITY MAP
//  (hardcoded - DO NOT CHANGE)
//=========================================================================
#define InpEMA8            8
#define InpEMA20           20
#define InpEMA50           50
#define InpATR             14
#define InpDeepATR         0.50
#define InpSurvBars        24
#define InpZone1ATR        1.50
#define InpMaxEventAgeBars 24
#define InpUseSlopeFilter  true
#define InpMinSlopeATR     0.05
#define InpUseADXFilter    true
#define InpADXPeriod       14
#define InpMinADX          20.0
#define InpUseRSIFilter    false
#define InpRSIPeriod       14
#define InpMaxRSI          48.0

//=========================================================================
//  CANONICAL BASELINE - ENGINE 2: D1 EXTENSION & VOLUME PROBABILITY
//  (hardcoded - DO NOT CHANGE)
//=========================================================================
#define InpATRPeriod       14
#define InpMinMoveATR      1.00
#define InpMinRangeATR     1.50
#define InpMaxFwdDays      5
#define InpMinEvents       20
#define InpVolMA_Period    20
#define InpHighVolRatio    1.25
#define InpEvalBar         EVAL_AUTO_SWITCH

#define MAXW   5
#define MAXLVL 4
#define MAXSTEP 6
#define MAXBUCK 7
#define MAXTIER 2
#define MAXVOLIDX 28
#define MAXEVT 12000

//-------------------------------------------------------------------------
//  FREE / TRADER-SELECTABLE INPUTS (presentation only - never statistics)
//-------------------------------------------------------------------------
extern bool                 InpShowPanel        = true;
extern ENUM_BASE_CORNER     InpPanelCorner      = CORNER_LEFT_UPPER;
extern int                  InpPanelX           = 15;
extern int                  InpPanelY           = 30;
extern bool                 InpRayLevels        = true;
extern bool                 InpShowExtTargets   = false;
extern color                InpTriggerColor     = C'255,75,75';
extern color                InpZoneColor        = C'255,205,0';
extern color                InpBandColor        = C'15,50,90';
extern color                InpSLColor          = C'255,50,80';
extern color                InpTPColor          = C'0,230,130';

extern bool                 InpShowTradePlan    = true;
extern double               InpSL_BufferATR     = 0.25;
extern double               InpTP2_FibRatio     = 1.618;
extern int                  InpSwingLookback    = 30;

extern bool                 InpAlertPopup       = true;
extern bool                 InpAlertPush        = false;
extern bool                 InpAlertSound       = true;
extern bool                 InpAlertOnEvent     = true;
extern bool                 InpAlertOnDeep      = true;
extern bool                 InpAlertOnRebound   = true;

extern bool                 InpWriteReport      = false;
extern string               InpReportFolder     = "Research";

//===========================================================
//  Engine 1 globals - pullback probability map
//===========================================================
double  g_ema50[];
double  g_ema8[];
double  g_ema20[];

int      g_total = 0, g_clean = 0, g_deep = 0;
int      g_deepAtBar[];
double   g_avgDeepATR = 0.0, g_avgCleanATR = 0.0;
int      g_eventBar = -1;
datetime g_eventTime = 0;
double   g_eventClose = 0.0, g_evATR = 0.0, g_evEMA50 = 0.0;
int      g_survived = 0;
bool     g_deepTriggered = false;
bool     g_statsReady = false;
string   g_prefix = "LPHCAN_";

double   g_tradeSL = 0.0, g_tradeTP1 = 0.0, g_tradeTP2 = 0.0, g_tradeRR = 0.0;
int      g_handleADX = -1;

bool     g_firstCalculationDone = false;
datetime g_lastAlertEvent = 0;
datetime g_lastAlertDeep  = 0;
datetime g_lastAlertReb   = 0;

//===========================================================
//  Engine 2 globals - D1 extension & volume probability
//===========================================================
double   g_winDays[MAXW]  = {1.0, 3.0, 5.0};
double   g_levels[MAXLVL] = {0.5, 1.0, 1.5, 2.0};
double   g_bEdges[MAXBUCK]={1.0,1.5,2.0,2.5,3.0,4.0,1e9};

int      g_n[MAXBUCK][2];
int      g_hit[MAXBUCK][2][MAXW][MAXLVL];
int      g_clsUp[MAXBUCK][2][MAXW];
double   g_avgExt[MAXBUCK][2][MAXW];
double   g_maxExt[MAXBUCK][2][MAXW];
double   g_sumMoveATR[MAXBUCK][2];

int      g_volN[MAXBUCK][2][MAXTIER];
int      g_volHit[MAXVOLIDX][MAXW][MAXLVL];
int      g_volClsUp[MAXVOLIDX][MAXW];
double   g_volAvgExt[MAXVOLIDX][MAXW];
double   g_sumVolRatio[MAXBUCK][2];

int      g_reached[MAXBUCK][2][MAXSTEP];
int      g_nextStep[MAXBUCK][2][MAXSTEP];

struct SEvent
  {
   datetime t;
   int      dir;
   double   moveATR;
   double   rangeATR;
   double   volRatio;
   double   maxExt5;
   double   clsUp5;
   double   fwd5Ret;
  };
SEvent   g_ev[MAXEVT];
int      g_evN = 0;

bool     g_extComputed = false;
datetime g_lastReportDay = 0;

double   g_prevCls   = 0.0;
double   g_prevCls2  = 0.0;
double   g_curOpen   = 0.0;
double   g_curATR    = 0.0;
double   g_curVolMA  = 0.0;
int      g_nBars     = 0;

//===========================================================
//  Helpers
//===========================================================
int VolIdx(const int b, const int d, const int t)
  {
   return (b * 4 + d * 2 + t);
  }

void SendSmartAlert(string title, string msg)
  {
   string fullMsg = "[LPH Canonical " + Symbol() + " (" + EnumToString((ENUM_TIMEFRAMES)Period()) + ")] " + title + "\n" + msg;
   if(InpAlertPopup) Alert(fullMsg);
   if(InpAlertPush)  SendNotification(fullMsg);
   if(InpAlertSound) PlaySound("expert.wav");
  }

void CalcEMA(const double &p[], const int period, double &e[], const int n)
  {
   for(int i = 0; i < n; i++) e[i] = EMPTY_VALUE;
   if(n < period || period <= 0) return;

   double sum = 0.0;
   for(int i = 0; i < period; i++) sum += p[i];
   e[period - 1] = sum / (double)period;
   double k = 2.0 / ((double)period + 1.0);

   for(int i = period; i < n; i++)
     {
      if(e[i - 1] == EMPTY_VALUE) e[i] = p[i];
      else e[i] = p[i] * k + e[i - 1] * (1.0 - k);
     }
  }

//===========================================================
//  Engine 1 - pullback probability statistics
//  (arrays chronological: 0 = oldest, n-1 = newest)
//===========================================================
void ComputePullbackStats(const datetime &time[], const double &open[], const double &high[],
                          const double &low[], const double &close[], const int n)
  {
   if(n < InpEMA50 + InpSurvBars + 10) return;

   double e50[], e8[], e20[], atr[];
   ArrayResize(e50, n); ArrayResize(e8, n); ArrayResize(e20, n); ArrayResize(atr, n);
   CalcEMA(close, InpEMA50, e50, n);
   CalcEMA(close, InpEMA8,  e8,  n);
   CalcEMA(close, InpEMA20, e20, n);

   for(int i = 0; i < n; i++)
     {
      if(i >= InpATR)
        {
         double s = 0.0;
         for(int j = i - (InpATR - 1); j <= i; j++)
            s += MathMax(high[j] - low[j], MathMax(MathAbs(high[j] - close[j - 1]), MathAbs(low[j] - close[j - 1])));
         atr[i] = s / (double)InpATR;
        }
      else if(i > 0) atr[i] = MathMax(high[i] - low[i], MathMax(MathAbs(high[i] - close[i - 1]), MathAbs(low[i] - close[i - 1])));
      else atr[i] = high[i] - low[i];
     }

   double adxVal[];
   if(InpUseADXFilter)
     {
      ArrayResize(adxVal, n);
      for(int i = 0; i < n; i++)
         adxVal[i] = iADX(Symbol(), Period(), InpADXPeriod, PRICE_CLOSE, MODE_MAIN, n - 1 - i);
     }

   MqlRates d1[];
   int nd = 0;
   bool useD1 = (Period() < PERIOD_D1);
   double dc[], d1e50[];
   if(useD1)
     {
      nd = CopyRates(Symbol(), PERIOD_D1, time[0], time[n - 1], d1);
      if(nd >= InpEMA50)
        {
         ArrayResize(dc, nd); ArrayResize(d1e50, nd);
         for(int i = 0; i < nd; i++) dc[i] = d1[i].close;
         CalcEMA(dc, InpEMA50, d1e50, nd);
        }
      else useD1 = false;
     }

   g_total = 0; g_clean = 0; g_deep = 0; g_avgDeepATR = 0.0; g_avgCleanATR = 0.0;
   int survMax = MathMax(InpSurvBars, 1);
   ArrayResize(g_deepAtBar, survMax + 1);
   ArrayInitialize(g_deepAtBar, 0);
   double sumDeepATR = 0.0, sumCleanATR = 0.0;
   int d1ptr = 0;
   int evChrono = -1;

   for(int i = InpEMA50 + 5; i < n - 1 - InpSurvBars; i++)
     {
      if(e50[i] == EMPTY_VALUE || e50[i-1] == EMPTY_VALUE || e8[i-1] == EMPTY_VALUE || e20[i-1] == EMPTY_VALUE) continue;
      if(close[i] >= e50[i]) continue;
      if(!(close[i - 1] > e50[i - 1])) continue;
      if(!(e8[i - 1] > e20[i - 1])) continue;

      if(InpUseSlopeFilter)
        {
         if(e50[i - 5] == EMPTY_VALUE) continue;
         double slope = (e50[i - 1] - e50[i - 5]) / (atr[i - 1] > 0 ? atr[i - 1] : 1.0);
         if(slope < InpMinSlopeATR) continue;
        }

      if(InpUseADXFilter && ArraySize(adxVal) == n)
        {
         if(adxVal[i - 1] < InpMinADX) continue;
        }

      if(useD1)
        {
         datetime tPrev = time[i - 1];
         while(d1ptr + 1 < nd && d1[d1ptr + 1].time <= tPrev) d1ptr++;
         if(d1ptr >= nd) continue;
         if(d1e50[d1ptr] == EMPTY_VALUE || !(dc[d1ptr] > d1e50[d1ptr])) continue;
        }

      g_total++;
      bool reverted = false, deeper = false;
      int deepBar = -1;
      double minClose = close[i];
      for(int j = i + 1; j <= i + InpSurvBars && j < n; j++)
        {
         if(close[j] < minClose) minClose = close[j];
         if(!reverted && close[j] > e50[j]) reverted = true;
         if(!deeper && close[j] <= close[i] - InpDeepATR * atr[i]) { deeper = true; deepBar = j - i; }
        }
      double depthATR = (close[i] - minClose) / (atr[i] > 0 ? atr[i] : 1.0);
      if(reverted && !deeper) { g_clean++; sumCleanATR += depthATR; }
      else if(deeper)         { g_deep++; sumDeepATR += depthATR;
                                if(deepBar >= 1 && deepBar <= InpSurvBars) g_deepAtBar[deepBar]++; }
      else                    { g_deep++; sumDeepATR += depthATR; }

      evChrono = i;
     }

   g_avgDeepATR  = g_deep  > 0 ? sumDeepATR  / (double)g_deep  : 0.0;
   g_avgCleanATR = g_clean > 0 ? sumCleanATR / (double)g_clean : 0.0;

   int evAnchor = -1;
   int d1p2 = nd - 1;
   for(int i = n - 2; i >= InpEMA50 + 5; i--)
     {
      if(e50[i] == EMPTY_VALUE || e50[i-1] == EMPTY_VALUE || e8[i-1] == EMPTY_VALUE || e20[i-1] == EMPTY_VALUE) continue;
      if(close[i] >= e50[i]) continue;
      if(!(close[i - 1] > e50[i - 1])) continue;
      if(!(e8[i - 1] > e20[i - 1])) continue;

      if(InpUseSlopeFilter)
        {
         if(e50[i - 5] == EMPTY_VALUE) continue;
         double slope = (e50[i - 1] - e50[i - 5]) / (atr[i - 1] > 0 ? atr[i - 1] : 1.0);
         if(slope < InpMinSlopeATR) continue;
        }

      if(InpUseADXFilter && ArraySize(adxVal) == n)
        {
         if(adxVal[i - 1] < InpMinADX) continue;
        }

      if(useD1)
        {
         datetime tPrev = time[i - 1];
         while(d1p2 > 0 && d1[d1p2].time > tPrev) d1p2--;
         if(d1p2 < 0) break;
         if(d1e50[d1p2] == EMPTY_VALUE || !(dc[d1p2] > d1e50[d1p2])) continue;
        }
      evAnchor = i;
      break;
     }
   if(evAnchor < 0) evAnchor = evChrono;

   if(evAnchor >= 0)
     {
      g_eventBar   = evAnchor;
      g_eventTime  = time[evAnchor];
      g_eventClose = close[evAnchor];
      g_evATR      = atr[evAnchor];
      g_evEMA50    = e50[evAnchor];

      double z2ATR = g_avgDeepATR > 0 ? MathMax(g_avgDeepATR, InpZone1ATR) : 2.6;
      double z2 = g_eventClose - z2ATR * g_evATR;
      g_tradeSL = z2 - InpSL_BufferATR * g_evATR;

      double highestSwing = high[evAnchor];
      int lookStart = MathMax(0, evAnchor - InpSwingLookback);
      for(int s = lookStart; s <= evAnchor; s++)
        {
         if(high[s] > highestSwing) highestSwing = high[s];
        }
      g_tradeTP1 = highestSwing;
      double risk = MathMax(g_eventClose - g_tradeSL, Point * 10);
      g_tradeTP2 = g_eventClose + InpTP2_FibRatio * (highestSwing - g_eventClose + risk);
      g_tradeRR  = (g_tradeTP1 - g_eventClose) / risk;
     }
   else
     {
      g_eventBar   = -1;
      g_eventTime  = 0;
     }

   g_survived = 0; g_deepTriggered = false;
   if(g_eventBar >= 0)
     {
      double trig = g_eventClose - InpDeepATR * g_evATR;
      for(int k = g_eventBar + 1; k < n; k++)
        {
         if(close[k] <= trig) { g_deepTriggered = true; break; }
         g_survived++;
        }
     }

   g_statsReady = true;
  }

double RemainingDeepProb(const int survived)
  {
   if(g_total == 0) return 0.0;
   int cum = 0;
   int maxK = MathMin(InpSurvBars, ArraySize(g_deepAtBar) - 1);
   for(int k = 1; k <= survived && k <= maxK; k++) cum += g_deepAtBar[k];
   return 100.0 * (double)(g_deep - cum) / (double)g_total;
  }

//===========================================================
//  Engine 2 - D1 extension statistics
//  (arrays chronological: 0 = oldest, n-1 = newest)
//===========================================================
void CalcATR_D1(const double &h[], const double &l[], const double &c[], const int n,
                const int period, double &atr[], const int start)
  {
   for(int i = 0; i < start; i++) atr[i] = 0.0;
   for(int i = start; i < n; i++)
     {
      double s = 0.0;
      for(int j = i - period + 1; j <= i; j++)
        {
         double tr = h[j] - l[j];
         double hc = MathAbs(h[j] - c[j - 1]);
         double lc = MathAbs(l[j] - c[j - 1]);
         if(hc > tr) tr = hc;
         if(lc > tr) tr = lc;
         s += tr;
        }
      atr[i] = s / (double)period;
     }
  }

void CalcVolMA_D1(const double &v[], const int n, const int period, double &vma[], const int start)
  {
   for(int i = 0; i < start; i++) vma[i] = 0.0;
   for(int i = start; i < n; i++)
     {
      double s = 0.0;
      for(int j = i - period; j < i; j++) s += v[j];
      vma[i] = s / (double)period;
     }
  }

void ComputeExtensionStats(const datetime &dtime[], const double &dopen[], const double &dhigh[],
                           const double &dlow[], const double &dclose[], const double &dvol[], const int n)
  {
   for(int b = 0; b < MAXBUCK; b++)
     {
      g_n[b][0] = g_n[b][1] = 0;
      g_sumMoveATR[b][0] = g_sumMoveATR[b][1] = 0.0;
      g_sumVolRatio[b][0] = g_sumVolRatio[b][1] = 0.0;
      for(int d = 0; d < 2; d++)
        {
         for(int t = 0; t < MAXTIER; t++)
           {
            g_volN[b][d][t] = 0;
            int vi = VolIdx(b, d, t);
            for(int w = 0; w < MAXW; w++)
              {
               g_volClsUp[vi][w] = 0;
               g_volAvgExt[vi][w] = 0.0;
               for(int l = 0; l < MAXLVL; l++) g_volHit[vi][w][l] = 0;
              }
           }
         for(int w = 0; w < MAXW; w++)
           {
            g_clsUp[b][d][w] = 0;
            g_avgExt[b][d][w] = 0.0;
            g_maxExt[b][d][w] = 0.0;
            for(int l = 0; l < MAXLVL; l++) g_hit[b][d][w][l] = 0;
           }
         for(int s = 0; s < MAXSTEP; s++) { g_reached[b][d][s] = 0; g_nextStep[b][d][s] = 0; }
        }
     }
   g_evN = 0;

   int period = MathMax(InpATRPeriod, 2);
   int volPeriod = MathMax(InpVolMA_Period, 5);
   int startIdx = MathMax(period, volPeriod);
   if(n < startIdx + InpMaxFwdDays + 5) return;

   double atr[], volMA[];
   ArrayResize(atr, n);
   ArrayResize(volMA, n);
   CalcATR_D1(dhigh, dlow, dclose, n, period, atr, period);
   CalcVolMA_D1(dvol, n, volPeriod, volMA, volPeriod);

   int maxFwd = MathMin(InpMaxFwdDays, 5);
   if(maxFwd < 1) maxFwd = 1;

   int wd[MAXW] = {0,0,0};
   int wn = 0;
   for(int w = 0; w < MAXW; w++)
      if((int)g_winDays[w] <= maxFwd) wd[wn++] = (int)g_winDays[w];

   for(int i = startIdx; i < n - maxFwd - 1; i++)
     {
      if(atr[i] <= 0.0) continue;
      double move  = dclose[i] - dclose[i - 1];
      double range = dhigh[i] - dlow[i];
      double moveATR  = MathAbs(move) / atr[i];
      double rangeATR = range / atr[i];
      if(moveATR < InpMinMoveATR)  continue;
      if(rangeATR < InpMinRangeATR) continue;

      double vRatio = (volMA[i] > 0.0) ? (dvol[i] / volMA[i]) : 1.0;
      int vTier = (vRatio >= InpHighVolRatio) ? 1 : 0;

      int dir = (move > 0) ? 0 : 1;
      double base = dclose[i];

      int b = 0;
      while(b < MAXBUCK - 1 && moveATR >= g_bEdges[b]) b++;

      g_n[b][dir]++;
      g_sumMoveATR[b][dir] += moveATR;
      g_sumVolRatio[b][dir] += vRatio;

      g_volN[b][dir][vTier]++;
      int vi = VolIdx(b, dir, vTier);

      double maxExt5 = 0.0;
      for(int k = 1; k <= maxFwd; k++)
        {
         double ext = (dir == 0) ? (dhigh[i + k] - base) : (base - dlow[i + k]);
         if(ext > maxExt5) maxExt5 = ext;
        }
      double maxExt5ATR = maxExt5 / atr[i];
      if(maxExt5ATR > g_maxExt[b][dir][2]) g_maxExt[b][dir][2] = maxExt5ATR;

      for(int w = 0; w < wn; w++)
        {
         int k = wd[w];
         double ext = 0.0;
         for(int j = 1; j <= k; j++)
           {
            double e = (dir == 0) ? (dhigh[i + j] - base) : (base - dlow[i + j]);
            if(e > ext) ext = e;
           }
         double extATR = ext / atr[i];
         int wi = (k == 1) ? 0 : (k == 3 ? 1 : 2);
         g_avgExt[b][dir][wi] += extATR;
         g_volAvgExt[vi][wi] += extATR;

         if(extATR > g_maxExt[b][dir][wi]) g_maxExt[b][dir][wi] = extATR;
         for(int l = 0; l < MAXLVL; l++)
           {
            if(extATR >= g_levels[l])
              {
               g_hit[b][dir][wi][l]++;
               g_volHit[vi][wi][l]++;
              }
           }

         double fut = (dir == 0) ? (dclose[i + k] - base) : (base - dclose[i + k]);
         if(fut > 0)
           {
            g_clsUp[b][dir][wi]++;
            g_volClsUp[vi][wi]++;
           }
        }

      for(int s = 0; s < MAXSTEP; s++)
        {
         double L = 0.5 * (double)s;
         if(maxExt5ATR >= L)
           {
            g_reached[b][dir][s]++;
            if(maxExt5ATR >= L + 0.5) g_nextStep[b][dir][s]++;
           }
        }

      if(g_evN < MAXEVT)
        {
         SEvent e;
         e.t        = dtime[i];
         e.dir      = (dir == 0) ? 1 : -1;
         e.moveATR  = moveATR;
         e.rangeATR = rangeATR;
         e.volRatio = vRatio;
         e.maxExt5  = maxExt5ATR;
         double fut5 = (dir == 0) ? (dclose[i + 5] - base) : (base - dclose[i + 5]);
         e.clsUp5   = (fut5 > 0) ? 1.0 : 0.0;
         e.fwd5Ret  = 100.0 * fut5 / base;
         g_ev[g_evN++] = e;
        }
     }

   for(int b = 0; b < MAXBUCK; b++)
     {
      for(int d = 0; d < 2; d++)
        {
         for(int w = 0; w < MAXW; w++)
           {
            if(g_n[b][d] > 0) g_avgExt[b][d][w] /= (double)g_n[b][d];
            for(int t = 0; t < MAXTIER; t++)
              {
               int vi = VolIdx(b, d, t);
               if(g_volN[b][d][t] > 0) g_volAvgExt[vi][w] /= (double)g_volN[b][d][t];
              }
           }
        }
     }

   g_extComputed = true;
  }

string Pct100(const int num, const int den)
  {
   if(den <= 0) return "--";
   return DoubleToString(100.0 * (double)num / (double)den, 1);
  }

string Pct100d(const double num, const double den)
  {
   if(den <= 0.0) return "--";
   return DoubleToString(100.0 * num / den, 1);
  }

int BucketOfMove(const double moveATR)
  {
   int b = 0;
   while(b < MAXBUCK - 1 && moveATR >= g_bEdges[b]) b++;
   return b;
  }

// Verdict level: 0 = no signal, 1 = fade/weak (red), 2 = moderate (amber), 3 = strong (green)
void TraderVerdictLevel(const int b, const int dir, const bool isBig, const int step,
                        const double volRatio, int &lvl, string &vText, color &vClr)
  {
   int nS = g_n[b][dir];
   lvl = 0; vText = "NO SIGNAL"; vClr = C'120,130,150';
   if(!isBig) { vText = "NO BIG RUN - NORMAL DAY"; vClr = C'120,130,150'; return; }
   if(nS < InpMinEvents) { vText = "NO SIGNAL (n=" + IntegerToString(nS) + " < " + IntegerToString(InpMinEvents) + ")"; vClr = C'120,130,150'; return; }

   double p3  = 100.0 * (double)g_hit[b][dir][1][1] / (double)nS;
   bool strong = false, mod = false;
   if(dir == 0) { strong = (p3 >= 65.0); mod = (p3 >= 45.0); }
   else         { strong = (p3 >= 60.0); mod = (p3 >= 40.0); }

   if(strong)
     {
      lvl = 3;
      if(volRatio >= InpHighVolRatio)
        { vText = (dir == 0 ? "FOLLOW UP - STRONG (HIGH VOL)" : "FOLLOW DN - STRONG (HIGH VOL)"); vClr = C'0,230,130'; }
      else
        { vText = (dir == 0 ? "FOLLOW UP - STRONG" : "FOLLOW DN - STRONG"); vClr = C'0,230,130'; }
     }
   else if(mod)
     {
      lvl = 2;
      vText = (dir == 0 ? "FOLLOW UP - MODERATE" : "FOLLOW DN - MODERATE"); vClr = C'255,215,0';
     }
   else
     {
      lvl = 1;
      if(volRatio < 0.85)
        { vText = (dir == 0 ? "WEAK UP - LOW VOL FADE" : "DN FADES - LOW VOL RETRACE"); vClr = C'255,95,95'; }
      else
        { vText = (dir == 0 ? "WEAK UP - EXPECT FADE" : "DN FADES - EXPECT RETRACE"); vClr = C'255,95,95'; }
     }

   if(step >= 3)
     { vText += " | EXTENDED"; vClr = C'255,160,60'; }
  }

//===========================================================
//  Combined canonical scenario read
//===========================================================
void GetCombinedScenario(const int b, const int dir, const bool isBig, const int step,
                         const double volRatio, string &scText, color &scClr)
  {
   int lvl = 0; string vTxt = ""; color vClr = 0;
   TraderVerdictLevel(b, dir, isBig, step, volRatio, lvl, vTxt, vClr);

   bool extDeep   = (lvl == 1);
   bool extStrong = (lvl == 3);
   bool extMod    = (lvl == 2);

   bool mapActive = (g_statsReady && g_eventBar >= 0);
   bool deepNow   = g_deepTriggered;
   double liveRisk = 100.0;
   if(mapActive && !deepNow) liveRisk = RemainingDeepProb(g_survived);
   bool windowClosed = (g_survived >= InpSurvBars);
   bool liveLow = (liveRisk <= 10.0);

   if(!mapActive)
     { scText = "NO ACTIVE PULLBACK MAP - MONITOR"; scClr = C'120,130,150'; }
   else if(deepNow)
     { scText = "MAP: DEEP PATH ACTIVE - RESPECT DEEP ZONES"; scClr = C'255,85,85'; }
   else if(extDeep)
     {
      if(liveLow && windowClosed) { scText = "DEEP BIAS x WINDOW CLOSED - SAFE SHALLOW HOLD"; scClr = C'0,230,130'; }
      else if(liveLow)            { scText = "DEEP BIAS x LOW LIVE RISK - HOLD W/ TIGHT GUARD"; scClr = C'220,230,120'; }
      else                        { scText = "DEEP BIAS x HIGH LIVE RISK - STAND ASIDE"; scClr = C'255,95,95'; }
     }
   else if(extStrong || extMod)
     {
      if(liveLow && windowClosed) { scText = "CONTINUATION x WINDOW CLOSED - RUN SHALLOW/TP"; scClr = C'0,230,130'; }
      else if(liveLow)            { scText = "CONTINUATION BIAS x LOW LIVE RISK - LEAN SHALLOW"; scClr = C'0,230,130'; }
      else                        { scText = "CONTINUATION BIAS x RISK OPEN - WAIT FOR HOLD"; scClr = C'255,215,0'; }
     }
   else
     { scText = "NEUTRAL EXT - FOLLOW LIVE RISK"; scClr = C'200,215,235'; }
  }

//===========================================================
//  Object helpers (MQL4)
//===========================================================
void ObjDelAll()
  {
   for(int i = ObjectsTotal(-1) - 1; i >= 0; i--)
     {
      string nm = ObjectName(i, -1, -1);
      if(StringFind(nm, g_prefix) == 0) ObjectDelete(nm);
     }
  }

void HLabel(string name, int x, int y, string text, color clr, int fs, bool bold = false)
  {
   string id = g_prefix + name;
   if(ObjectFind(id) < 0) ObjectCreate(id, OBJ_LABEL, 0, 0, 0);
   ObjectSetInteger(0, id, OBJPROP_CORNER, InpPanelCorner);
   ObjectSetInteger(0, id, OBJPROP_XDISTANCE, InpPanelX + x);
   ObjectSetInteger(0, id, OBJPROP_YDISTANCE, InpPanelY + y);
   ObjectSetInteger(0, id, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, id, OBJPROP_FONTSIZE, fs);
   ObjectSetString(0, id, OBJPROP_FONT, bold ? "Segoe UI Semibold" : "Segoe UI");
   ObjectSetString(0, id, OBJPROP_TEXT, text);
   ObjectSetInteger(0, id, OBJPROP_BACK, false);
   ObjectSetInteger(0, id, OBJPROP_SELECTABLE, false);
  }

void BgRect(string name, int x, int y, int w, int h, color bg, color border)
  {
   string id = g_prefix + name;
   if(ObjectFind(id) < 0) ObjectCreate(id, OBJ_RECTANGLE_LABEL, 0, 0, 0);
   ObjectSetInteger(0, id, OBJPROP_CORNER, InpPanelCorner);
   ObjectSetInteger(0, id, OBJPROP_XDISTANCE, InpPanelX + x);
   ObjectSetInteger(0, id, OBJPROP_YDISTANCE, InpPanelY + y);
   ObjectSetInteger(0, id, OBJPROP_XSIZE, w);
   ObjectSetInteger(0, id, OBJPROP_YSIZE, h);
   ObjectSetInteger(0, id, OBJPROP_BGCOLOR, bg);
   ObjectSetInteger(0, id, OBJPROP_BORDER_COLOR, border);
   ObjectSetInteger(0, id, OBJPROP_BORDER_TYPE, BORDER_FLAT);
   ObjectSetInteger(0, id, OBJPROP_BACK, true);
   ObjectSetInteger(0, id, OBJPROP_SELECTABLE, false);
  }

void CreateLevelRay(string name, datetime tStart, datetime tEnd, double price, color clr,
                    ENUM_LINE_STYLE style, int width, string tagText)
  {
   string lineId = g_prefix + "ray_" + name;
   string tagId  = g_prefix + "tag_" + name;

   if(InpRayLevels)
     {
      if(ObjectFind(lineId) < 0) ObjectCreate(lineId, OBJ_TREND, 0, tStart, price, tEnd, price);
      else
        {
         ObjectSetInteger(0, lineId, OBJPROP_TIME, 0, tStart);
         ObjectSetDouble(0, lineId, OBJPROP_PRICE, 0, price);
         ObjectSetInteger(0, lineId, OBJPROP_TIME, 1, tEnd);
         ObjectSetDouble(0, lineId, OBJPROP_PRICE, 1, price);
        }
      ObjectSetInteger(0, lineId, OBJPROP_RAY_RIGHT, true);
     }
   else
     {
      if(ObjectFind(lineId) < 0) ObjectCreate(lineId, OBJ_HLINE, 0, 0, price);
      else ObjectSetDouble(0, lineId, OBJPROP_PRICE, 0, price);
     }

   ObjectSetInteger(0, lineId, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, lineId, OBJPROP_STYLE, style);
   ObjectSetInteger(0, lineId, OBJPROP_WIDTH, width);
   ObjectSetInteger(0, lineId, OBJPROP_BACK, true);

   if(ObjectFind(tagId) < 0) ObjectCreate(tagId, OBJ_TEXT, 0, tEnd, price);
   else
     {
      ObjectSetInteger(0, tagId, OBJPROP_TIME, 0, tEnd);
      ObjectSetDouble(0, tagId, OBJPROP_PRICE, 0, price);
     }
   ObjectSetString(0, tagId, OBJPROP_TEXT, "  " + tagText);
   ObjectSetInteger(0, tagId, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, tagId, OBJPROP_FONTSIZE, 8);
   ObjectSetString(0, tagId, OBJPROP_FONT, "Arial Bold");
   ObjectSetInteger(0, tagId, OBJPROP_ANCHOR, ANCHOR_LEFT);
   ObjectSetInteger(0, tagId, OBJPROP_BACK, false);
  }

//===========================================================
//  Engine 1 - chart map objects
//===========================================================
void UpdateMapObjects(const datetime &time[], const double &low[], const double &close[], const int n)
  {
   if(!g_statsReady) return;

   int eventAgeBars = (g_eventBar >= 0) ? (n - 1 - g_eventBar) : 999999;
   bool drawMap = (g_eventBar >= 0 && eventAgeBars <= InpMaxEventAgeBars);
   double trig = g_eventClose - InpDeepATR   * g_evATR;
   double z1   = g_eventClose - InpZone1ATR  * g_evATR;
   double z2   = g_eventClose - (g_avgDeepATR > 0 ? MathMax(g_avgDeepATR, InpZone1ATR) : 2.6) * g_evATR;
   int dg = (int)Digits;
   string nm;

   datetime nowTime = time[n - 1];
   datetime futureTime = nowTime + Period() * 60 * 8;

   if(drawMap)
     {
      CreateLevelRay("trig", g_eventTime, futureTime, trig, InpTriggerColor, STYLE_DASH, 1,
                     "TRIGGER (0.5x ATR): " + DoubleToString(trig, dg));
      CreateLevelRay("z1",   g_eventTime, futureTime, z1,   InpZoneColor,    STYLE_DASH, 1,
                     "ZONE 1 (1.5x ATR): " + DoubleToString(z1, dg));
      CreateLevelRay("z2",   g_eventTime, futureTime, z2,   InpZoneColor,    STYLE_SOLID, 2,
                     "ZONE 2 (Avg Deep): " + DoubleToString(z2, dg));

      if(InpShowTradePlan)
        {
         CreateLevelRay("sl",  g_eventTime, futureTime, g_tradeSL,  InpSLColor, STYLE_SOLID, 2, "STOP LOSS: " + DoubleToString(g_tradeSL, dg));
         CreateLevelRay("tp1", g_eventTime, futureTime, g_tradeTP1, InpTPColor, STYLE_SOLID, 2, "TP1 (Swing High): " + DoubleToString(g_tradeTP1, dg));
         CreateLevelRay("tp2", g_eventTime, futureTime, g_tradeTP2, InpTPColor, STYLE_DASH,  1, "TP2 (1.618 Fib): " + DoubleToString(g_tradeTP2, dg));
        }

      nm = g_prefix + "band";
      if(ObjectFind(nm) < 0) ObjectCreate(nm, OBJ_RECTANGLE, 0, g_eventTime, z1, futureTime, z2);
      ObjectSetInteger(0, nm, OBJPROP_COLOR, InpBandColor);
      ObjectSetInteger(0, nm, OBJPROP_FILL, true);
      ObjectSetInteger(0, nm, OBJPROP_BACK, true);

      nm = g_prefix + "evArrow";
      if(ObjectFind(nm) < 0) ObjectCreate(nm, OBJ_ARROW, 0, g_eventTime, low[g_eventBar]);
      ObjectSetInteger(0, nm, OBJPROP_ARROWCODE, 234);
      ObjectSetInteger(0, nm, OBJPROP_COLOR, InpTriggerColor);
      ObjectSetInteger(0, nm, OBJPROP_WIDTH, 2);
      ObjectSetInteger(0, nm, OBJPROP_ANCHOR, ANCHOR_TOP);

      nm = g_prefix + "evTxt";
      if(ObjectFind(nm) < 0) ObjectCreate(nm, OBJ_TEXT, 0, g_eventTime, low[g_eventBar]);
      ObjectSetString(0, nm, OBJPROP_TEXT, "  PRO PULLBACK SETUP\n  " + TimeToString(g_eventTime, TIME_DATE|TIME_MINUTES) +
                                           "\n  Entry: " + DoubleToString(g_eventClose, dg));
      ObjectSetInteger(0, nm, OBJPROP_COLOR, InpTriggerColor);
      ObjectSetInteger(0, nm, OBJPROP_FONTSIZE, 8);
      ObjectSetString(0, nm, OBJPROP_FONT, "Arial");
      ObjectSetInteger(0, nm, OBJPROP_ANCHOR, ANCHOR_TOP);
     }
  }

//===========================================================
//  Engine 2 - D1 extension context + optional chart targets
//===========================================================
void LoadExtensionD1(const int n)
  {
   MqlRates rates[];
   ArraySetAsSeries(rates, false);
   int copied = CopyRates(Symbol(), PERIOD_D1, 0, n, rates);
   if(copied < InpATRPeriod + InpMaxFwdDays + 5) return;

   datetime dtime[];
   double   dopen[], dhigh[], dlow[], dclose[], dvol[];
   ArrayResize(dtime, copied);  ArrayResize(dopen, copied);
   ArrayResize(dhigh, copied);  ArrayResize(dlow, copied);
   ArrayResize(dclose, copied); ArrayResize(dvol, copied);

   for(int i = 0; i < copied; i++)
     {
      dtime[i]  = rates[i].time;
      dopen[i]  = rates[i].open;
      dhigh[i]  = rates[i].high;
      dlow[i]   = rates[i].low;
      dclose[i] = rates[i].close;
      dvol[i]   = (double)(rates[i].tick_volume > 0 ? rates[i].tick_volume : rates[i].real_volume);
     }
   ComputeExtensionStats(dtime, dopen, dhigh, dlow, dclose, dvol, copied);
  }

void StoreExtensionContext(const int n)
  {
   g_nBars = n;
   if(n < 4) return;
   MqlRates rates[];
   ArraySetAsSeries(rates, true);
   int need = MathMax(InpATRPeriod + 5, InpVolMA_Period + 5);
   int copied = CopyRates(Symbol(), PERIOD_D1, 0, need, rates);
   if(copied < 4) return;

   g_prevCls  = rates[1].close;
   g_prevCls2 = rates[2].close;
   g_curOpen  = rates[0].open;

   int period = MathMax(InpATRPeriod, 2);
   double s = 0.0;
   for(int j = 1; j <= period && j < copied - 1; j++)
     {
      double tr = rates[j].high - rates[j].low;
      double hc = MathAbs(rates[j].high - rates[j + 1].close);
      double lc = MathAbs(rates[j].low - rates[j + 1].close);
      if(hc > tr) tr = hc;
      if(lc > tr) tr = lc;
      s += tr;
     }
   g_curATR = s / (double)period;
   if(g_curATR <= 0.0) g_curATR = rates[1].high - rates[1].low;

   int volPeriod = MathMax(InpVolMA_Period, 5);
   double vs = 0.0;
   for(int k = 1; k <= volPeriod && k < copied; k++)
     {
      double v = (double)(rates[k].tick_volume > 0 ? rates[k].tick_volume : rates[k].real_volume);
      vs += v;
     }
   g_curVolMA = vs / (double)volPeriod;
   if(g_curVolMA <= 0.0) g_curVolMA = 1.0;
  }

void UpdateExtTargets()
  {
   if(!InpShowExtTargets || !g_extComputed || g_nBars < 3) return;

   MqlRates r[];
   ArraySetAsSeries(r, true);
   if(CopyRates(Symbol(), PERIOD_D1, 0, 3, r) < 3) return;

   double base = r[1].close;
   double atr  = g_curATR;
   if(atr <= 0.0) return;
   datetime t0 = r[1].time;
   datetime t1 = TimeCurrent() + Period() * 60 * 8;

   double move = r[1].close - g_prevCls2;
   int dir = (move > 0) ? 0 : 1;
   int dg = (int)Digits;
   double sign = (dir == 0) ? 1.0 : -1.0;
   string tag = (dir == 0) ? "EXT+" : "EXT-";

   for(int l = 0; l < MAXLVL; l++)
     {
      double lvl = g_levels[l];
      double price = base + sign * lvl * atr;
      string nm = "ext" + IntegerToString(l);
      CreateLevelRay(nm, t0, t1, price, C'200,120,255', STYLE_DOT, 1,
                     tag + DoubleToString(lvl, 1) + "A: " + DoubleToString(price, dg));
     }
  }

//===========================================================
//  Research report (compact canonical)
//===========================================================
void BuildCanonicalReport(const string fname)
  {
   string r = "";
   r += "# LPH Canonical Probability Suite - " + Symbol() + "\n\n";
   r += "Generated: " + TimeToString(TimeCurrent(), TIME_DATE|TIME_MINUTES) + "\n\n";
   r += "**Canonical baseline:** intraday map = 24b survival, 0.50 ATR deep, Slope+ADX ON. ";
   r += "D1 ext event = |move|>= " + DoubleToString(InpMinMoveATR, 2) + "A & range>= " +
                 DoubleToString(InpMinRangeATR, 2) + "A; HighVol >= " + DoubleToString(InpHighVolRatio, 2) + "x; fwd " +
                 IntegerToString(InpMaxFwdDays) + "d.\n\n";

   int upN = 0, dnN = 0;
   for(int b = 0; b < MAXBUCK; b++) { upN += g_n[b][0]; dnN += g_n[b][1]; }
   r += "**D1 events:** UP " + IntegerToString(upN) + " | DOWN " + IntegerToString(dnN) + "\n\n";

   for(int d = 0; d < 2; d++)
     {
      string ds = (d == 0) ? "UP" : "DOWN";
      string sgn = (d == 0) ? "+" : "-";
      r += "## " + ds + " big candles - P(extension beyond close)\n\n";
      r += "| Bucket | n | " + sgn + "0.5A/1d | " + sgn + "1.0A/1d | " + sgn + "1.0A/3d | " + sgn + "1.5A/3d | " + sgn + "2.0A/3d | close 1d | close 3d | close 5d | avgExt5d |\n";
      r += "|---|---|---|---|---|---|---|---|---|---|---|\n";
      for(int b = 0; b < MAXBUCK; b++)
        {
         if(g_n[b][d] == 0) continue;
         string lab = (b >= MAXBUCK - 2) ? "4.0+" : DoubleToString(g_bEdges[b], 1) + "-" + DoubleToString(g_bEdges[b + 1], 1);
         r += "| " + lab + " | " + IntegerToString(g_n[b][d]) +
                   " | " + Pct100(g_hit[b][d][0][0], g_n[b][d]) +
                   " | " + Pct100(g_hit[b][d][0][1], g_n[b][d]) +
                   " | " + Pct100(g_hit[b][d][1][1], g_n[b][d]) +
                   " | " + Pct100(g_hit[b][d][1][2], g_n[b][d]) +
                   " | " + Pct100(g_hit[b][d][1][3], g_n[b][d]) +
                   " | " + Pct100(g_clsUp[b][d][0], g_n[b][d]) +
                   " | " + Pct100(g_clsUp[b][d][1], g_n[b][d]) +
                   " | " + Pct100(g_clsUp[b][d][2], g_n[b][d]) +
                   " | " + DoubleToString(g_avgExt[b][d][2], 2) + " |\n";
        }
      r += "\n";
     }

   r += "## Volume expansion edge - P(+-1.0A / 3d), high vs normal vol\n\n";
   r += "| Dir & Bucket | HighVol n | HighVol % | NormVol n | NormVol % | Delta |\n|---|---|---|---|---|---|\n";
   for(int d = 0; d < 2; d++)
     {
      string ds = (d == 0) ? "UP" : "DOWN";
      for(int b = 0; b < MAXBUCK; b++)
        {
         if(g_n[b][d] == 0) continue;
         int nHigh = g_volN[b][d][1];
         int nNorm = g_volN[b][d][0];
         int viHigh = VolIdx(b, d, 1);
         int viNorm = VolIdx(b, d, 0);
         string pHigh = Pct100(g_volHit[viHigh][1][1], nHigh);
         string pNorm = Pct100(g_volHit[viNorm][1][1], nNorm);
         string dStr = "--";
         if(nHigh > 0 && nNorm > 0)
           {
            double delta = (100.0 * g_volHit[viHigh][1][1] / nHigh) - (100.0 * g_volHit[viNorm][1][1] / nNorm);
            dStr = (delta >= 0 ? "+" : "") + DoubleToString(delta, 1) + "%";
           }
         string lab = (b >= MAXBUCK - 2) ? "4.0+" : DoubleToString(g_bEdges[b], 1) + "-" + DoubleToString(g_bEdges[b + 1], 1);
         r += "| " + ds + " " + lab + " | " + IntegerToString(nHigh) + " | " + pHigh + "% | " +
                   IntegerToString(nNorm) + " | " + pNorm + "% | " + dStr + " |\n";
        }
     }
   r += "\n";

   if(g_total > 0)
     {
      r += "## Intraday pullback map (canonical 24b)\n\n";
      r += "| Metric | Value |\n|---|---|\n";
      r += "| Verified setups | " + IntegerToString(g_total) + " |\n";
      r += "| Clean revert rate | " + DoubleToString(100.0 * g_clean / g_total, 1) + "% |\n";
      r += "| Base deep rate (24b) | " + DoubleToString(100.0 * g_deep / g_total, 1) + "% |\n";
      r += "| Avg deep drawdown | " + DoubleToString(g_avgDeepATR, 2) + " ATR |\n";
      r += "| Avg clean depth | " + DoubleToString(g_avgCleanATR, 2) + " ATR |\n\n";
     }

   FolderCreate(InpReportFolder);
   int fh = FileOpen(fname, FILE_TXT | FILE_WRITE | FILE_ANSI);
   if(fh == -1)
     {
      Print("LPHCAN: cannot write report ", fname, " err=", GetLastError());
      return;
     }
   FileWriteString(fh, r);
   FileClose(fh);
   Print("LPHCAN: report written -> ", fname, " (", g_evN, " ext events)");
  }

string ReportFileName()
  {
   return InpReportFolder + "\\LPH_Canonical_" + Symbol() + ".md";
  }

//===========================================================
//  Unified HUD panel
//===========================================================
void DrawCanonicalPanel(const int b, const int dir, const bool isBig, const double moveATR,
                        const double rangeATR, const double intradayAbs, const int step,
                        const string ctxTag, const double volRatio)
  {
   int W = 420, H = 382;
   BgRect("bg", 0, 0, W, H, C'14,18,26', C'45,60,85');

   HLabel("title", 12, 10, "LPH CANONICAL PROBABILITY SUITE", C'240,245,255', 10, true);

   int upN = 0, dnN = 0;
   for(int bb = 0; bb < MAXBUCK; bb++) { upN += g_n[bb][0]; dnN += g_n[bb][1]; }

   string mapCnt = (g_statsReady && g_total > 0) ? ("map n=" + IntegerToString(g_total)) : "map --";
   string extCnt = (g_extComputed) ? ("ext n=" + IntegerToString(upN + dnN)) : "ext --";
   HLabel("sub", 12, 27, Symbol() + " " + EnumToString((ENUM_TIMEFRAMES)Period()) + " | " + ctxTag + " | " + mapCnt + " | " + extCnt, C'140,160,190', 8);

   string dirmove = (dir == 0 ? "UP +" : "DN -") + DoubleToString(moveATR, 2) + " ATR";
   color dc = (dir == 0) ? C'0,230,130' : C'255,95,95';
   HLabel("cur", 12, 45, "D1: " + dirmove + (isBig ? "   [BIG RUN]" : ""), dc, 10, true);
   HLabel("rng", 12, 61, "Range " + DoubleToString(rangeATR, 2) + " ATR | intraday ext " +
          DoubleToString(intradayAbs, 2) + " ATR", C'170,185,210', 8);

   string vText = ""; color vClr = C'120,130,150'; int lvl = 0;
   TraderVerdictLevel(b, dir, isBig, step, volRatio, lvl, vText, vClr);
   string bLabel = (b >= MAXBUCK - 2) ? "4.0+" : DoubleToString(g_bEdges[b], 1) + "-" + DoubleToString(g_bEdges[b + 1], 1);
   HLabel("vbox", 12, 78, "EXT VERDICT  " + vText + "   (" + bLabel + "A)", vClr, 12, true);

   string volTag = (volRatio >= 1.5) ? "SURGE" : (volRatio >= InpHighVolRatio ? "EXPANSION" : (volRatio >= 0.8 ? "NORMAL" : "LOW (FADE RISK)"));
   color volClr = (volRatio >= InpHighVolRatio) ? C'0,230,130' : (volRatio >= 0.8 ? C'200,215,235' : C'255,140,140');
   HLabel("volh", 12, 100, "Volume Pace: " + DoubleToString(volRatio, 2) + "x 20d-Avg [" + volTag + "]", volClr, 8, true);

   int nHigh = g_volN[b][dir][1];
   int nNorm = g_volN[b][dir][0];
   int viHigh = VolIdx(b, dir, 1);
   int viNorm = VolIdx(b, dir, 0);
   string pHigh = (nHigh > 0) ? Pct100(g_volHit[viHigh][1][1], nHigh) + "%" : "--";
   string pNorm = (nNorm > 0) ? Pct100(g_volHit[viNorm][1][1], nNorm) + "%" : "--";
   HLabel("vole", 12, 116, "Vol Edge P(+1.0A/3d): HV=" + pHigh + " (n=" + IntegerToString(nHigh) + ") | NV=" + pNorm + " (n=" + IntegerToString(nNorm) + ")", C'170,200,240', 8);

   if(isBig && g_n[b][dir] >= InpMinEvents)
     {
      HLabel("ph", 12, 136, "P(extend beyond D1 candle close):", C'120,135,160', 8);
      HLabel("pv", 12, 151,
             "+0.5A/1d  " + Pct100(g_hit[b][dir][0][0], g_n[b][dir]) + "%     " +
             "+1.0A/3d  " + Pct100(g_hit[b][dir][1][1], g_n[b][dir]) + "%     " +
             "+1.5A/3d  " + Pct100(g_hit[b][dir][1][2], g_n[b][dir]) + "%",
             C'220,235,255', 9, true);
      HLabel("ch", 12, 169, "Close beyond candle: 1d " + Pct100(g_clsUp[b][dir][0], g_n[b][dir]) +
             "% | 3d " + Pct100(g_clsUp[b][dir][1], g_n[b][dir]) +
             "% | 5d " + Pct100(g_clsUp[b][dir][2], g_n[b][dir]) + "%", C'170,200,240', 8);
     }
   else
     {
      HLabel("ph", 12, 136, "No valid sample in bucket " + bLabel + " ATR (n=" +
             IntegerToString(g_n[b][dir]) + ")", C'140,150,170', 8);
      HLabel("pv", 12, 151, "", C'220,235,255', 9);
      HLabel("ch", 12, 169, "", C'170,200,240', 8);
     }

   string pNext = Pct100d(g_nextStep[b][dir][step], g_reached[b][dir][step]);
   if(step > 0)
      HLabel("decay", 12, 187, "DECAY: extended " + DoubleToString(intradayAbs, 2) +
             " ATR -> P(next +0.5 ATR) = " + pNext + "%", C'255,215,0', 8, true);
   else
      HLabel("decay", 12, 187, "DECAY: P(+0.5 ATR from close) = " + pNext + "%", C'255,215,0', 8, true);

   HLabel("div1", 12, 205, "----------------------------------------------------------------", C'35,45,65', 8);

   double pClean = g_total > 0 ? (100.0 * (double)g_clean / (double)g_total) : 0.0;
   double pDeep  = g_total > 0 ? (100.0 * (double)g_deep  / (double)g_total) : 0.0;
   double remDeep = (g_statsReady && g_eventBar >= 0 && !g_deepTriggered) ? RemainingDeepProb(g_survived) : 100.0;

   HLabel("pbm_h", 12, 212, "PULLBACK MAP  (CANONICAL " + IntegerToString(InpSurvBars) + "b - 0.5A deep)", C'255,215,0', 8, true);
   HLabel("pbm1", 12, 228, "Clean Revert " + DoubleToString(pClean, 1) + "%   |   Base Deep (" + IntegerToString(InpSurvBars) + "b) " +
          DoubleToString(pDeep, 1) + "%", C'220,235,255', 9, true);
   HLabel("pbm2", 12, 244, "Live Drawdown Risk " + DoubleToString(remDeep, 1) + "%   |   Survived " +
          IntegerToString(g_survived) + "/" + IntegerToString(InpSurvBars), C'0,230,130', 9, true);

   string badgeText = "MONITORING MARKET";
   color badgeColor = C'140,150,170';
   if(g_eventBar >= 0)
     {
      if(g_deepTriggered)
        {
         badgeText = "DEEP PATH ACTIVE";
         badgeColor = C'255,85,85';
        }
      else
        {
         badgeText = "SHALLOW BOUNCE (" + IntegerToString(g_survived) + "/" + IntegerToString(InpSurvBars) + " bars safe)";
         badgeColor = C'0,230,130';
        }
     }
   HLabel("badge", 12, 262, badgeText, badgeColor, 8, true);

   string scText = ""; color scClr = C'120,130,150';
   GetCombinedScenario(b, dir, isBig, step, volRatio, scText, scClr);

   string scBox = g_prefix + "sc_box";
   if(ObjectFind(scBox) < 0) ObjectCreate(scBox, OBJ_RECTANGLE_LABEL, 0, 0, 0);
   ObjectSetInteger(0, scBox, OBJPROP_CORNER, InpPanelCorner);
   ObjectSetInteger(0, scBox, OBJPROP_XDISTANCE, InpPanelX + 10);
   ObjectSetInteger(0, scBox, OBJPROP_YDISTANCE, InpPanelY + 280);
   ObjectSetInteger(0, scBox, OBJPROP_XSIZE, W - 20);
   ObjectSetInteger(0, scBox, OBJPROP_YSIZE, 34);
   ObjectSetInteger(0, scBox, OBJPROP_BGCOLOR, C'22,30,44');
   ObjectSetInteger(0, scBox, OBJPROP_BORDER_COLOR, scClr);
   ObjectSetInteger(0, scBox, OBJPROP_BORDER_TYPE, BORDER_FLAT);
   ObjectSetInteger(0, scBox, OBJPROP_BACK, true);

   HLabel("sc", 22, 291, "SCENARIO:  " + scText, scClr, 10, true);

   HLabel("foot", 12, 330, "CANONICAL - 24b surv - 0.5A deep - D1 ext>=1.0/1.5A - Vol 1.25x | Filters Locked", C'120,140,165', 7);

   if(InpShowTradePlan && g_statsReady && g_eventBar >= 0)
     {
      HLabel("plan", 12, 346, "SL " + DoubleToString(g_tradeSL, (int)Digits) + "  TP1 " +
             DoubleToString(g_tradeTP1, (int)Digits) + "  TP2 " + DoubleToString(g_tradeTP2, (int)Digits) +
             "  R:R 1:" + DoubleToString(g_tradeRR, 2), C'0,230,130', 8, true);
     }
  }

//===========================================================
//  init / deinit / start
//===========================================================
int init()
  {
   SetIndexBuffer(0, g_ema50);
   SetIndexBuffer(1, g_ema8);
   SetIndexBuffer(2, g_ema20);

   SetIndexStyle(0, DRAW_LINE, STYLE_SOLID, 2);
   SetIndexStyle(1, DRAW_LINE, STYLE_SOLID, 1);
   SetIndexStyle(2, DRAW_LINE, STYLE_SOLID, 1);

   SetIndexEmptyValue(0, EMPTY_VALUE);
   SetIndexEmptyValue(1, EMPTY_VALUE);
   SetIndexEmptyValue(2, EMPTY_VALUE);

   SetIndexDrawBegin(0, InpEMA50);
   SetIndexDrawBegin(1, InpEMA8);
   SetIndexDrawBegin(2, InpEMA20);

   g_handleADX = InpUseADXFilter ? 0 : -1;

   g_firstCalculationDone = false;
   return (0);
  }

int deinit()
  {
   ObjDelAll();
   return (0);
  }

int start()
  {
   int rates_total = Bars;
   int prev_calculated = 0;

   if(rates_total < InpEMA50 + InpSurvBars + 10) return (0);

   datetime time[];
   double open[], high[], low[], close[], tvol[], vol[];
   int spread[];
   ArrayResize(time, rates_total);
   ArrayResize(open, rates_total);
   ArrayResize(high, rates_total);
   ArrayResize(low, rates_total);
   ArrayResize(close, rates_total);
   ArrayResize(tvol, rates_total);
   ArrayResize(vol, rates_total);
   ArrayResize(spread, rates_total);

   // NOTE: MT4 price arrays from built-ins are as-series (0 = current).
   for(int i = 0; i < rates_total; i++)
     {
      time[i]  = iTime(Symbol(), Period(), i);
      open[i]  = iOpen(Symbol(), Period(), i);
      high[i]  = iHigh(Symbol(), Period(), i);
      low[i]   = iLow(Symbol(), Period(), i);
      close[i] = iClose(Symbol(), Period(), i);
      tvol[i]  = (double)iVolume(Symbol(), Period(), i);
      vol[i]   = tvol[i];
      spread[i]= 0;
     }

   // Normalize to strict chronological (0 = oldest, n-1 = newest)
   datetime wTime[];
   double   wOpen[], wHigh[], wLow[], wClose[];
   ArrayResize(wTime,  rates_total);
   ArrayResize(wOpen,  rates_total);
   ArrayResize(wHigh,  rates_total);
   ArrayResize(wLow,   rates_total);
   ArrayResize(wClose, rates_total);

   for(int i = 0; i < rates_total; i++)
     {
      int src = rates_total - 1 - i;
      wTime[i]  = time[src];
      wOpen[i]  = open[src];
      wHigh[i]  = high[src];
      wLow[i]   = low[src];
      wClose[i] = close[src];
     }

   double e50c[], e8c[], e20c[];
   ArrayResize(e50c, rates_total); ArrayResize(e8c, rates_total); ArrayResize(e20c, rates_total);
   CalcEMA(wClose, InpEMA50, e50c, rates_total);
   CalcEMA(wClose, InpEMA8,  e8c,  rates_total);
   CalcEMA(wClose, InpEMA20, e20c, rates_total);

   for(int i = 0; i < rates_total; i++)
     {
      int dst = rates_total - 1 - i;
      g_ema50[dst] = e50c[i];
      g_ema8[dst]  = e8c[i];
      g_ema20[dst] = e20c[i];
     }

   if(!g_statsReady || prev_calculated == 0)
     {
      ComputePullbackStats(wTime, wOpen, wHigh, wLow, wClose, rates_total);
     }
   else
     {
      if(g_eventBar >= 0)
        {
         double trig = g_eventClose - InpDeepATR * g_evATR;
         g_survived = 0; g_deepTriggered = false;
         for(int k = g_eventBar + 1; k < rates_total; k++)
           {
            if(wClose[k] <= trig) { g_deepTriggered = true; break; }
            g_survived++;
           }
        }
     }

   static datetime lastExtDay = 0;
   datetime curDay = iTime(Symbol(), PERIOD_D1, 0);
   int d1bars = iBars(Symbol(), PERIOD_D1);
   if(!g_extComputed || curDay != lastExtDay || g_nBars != d1bars)
     {
      LoadExtensionD1(d1bars);
      StoreExtensionContext(d1bars);
      lastExtDay = curDay;
      if(InpWriteReport && (g_lastReportDay == 0 || curDay != g_lastReportDay))
        {
         BuildCanonicalReport(ReportFileName());
         g_lastReportDay = curDay;
        }
     }

   static datetime s_objTime = 0;
   static bool     s_objDeep = false;
   static int      s_objSurv = -1;
   if(s_objTime != wTime[rates_total - 1] || s_objDeep != g_deepTriggered || s_objSurv != g_survived)
     {
      ObjDelAll();
      UpdateMapObjects(wTime, wLow, wClose, rates_total);
      UpdateExtTargets();
      s_objTime = wTime[rates_total - 1];
      s_objDeep = g_deepTriggered;
      s_objSurv = g_survived;
     }

   if(InpShowPanel && g_extComputed && g_nBars >= 3)
     {
      MqlRates rCurrent[];
      ArraySetAsSeries(rCurrent, true);
      if(CopyRates(Symbol(), PERIOD_D1, 0, 3, rCurrent) >= 3)
        {
         int activeEvalBar = 0;
         int evalMode = (int)InpEvalBar;
         if(evalMode == EVAL_PREVIOUS_D1)
            activeEvalBar = 1;
         else if(evalMode == EVAL_AUTO_SWITCH)
           {
            double todayMoveATR = MathAbs(rCurrent[0].close - g_prevCls) / g_curATR;
            double yestMoveATR  = MathAbs(g_prevCls - g_prevCls2) / g_curATR;
            double yestRangeATR = (rCurrent[1].high - rCurrent[1].low) / g_curATR;
            bool yestIsBig = (yestMoveATR >= InpMinMoveATR && yestRangeATR >= InpMinRangeATR);
            if(todayMoveATR < 0.60 && yestIsBig)
               activeEvalBar = 1;
            else
               activeEvalBar = 0;
           }

         double evalCls = 0.0, evalPrevCls = 0.0, evalHigh = 0.0, evalLow = 0.0, evalVol = 0.0;
         string ctxTag = "";
         if(activeEvalBar == 1)
           {
            evalCls     = rCurrent[1].close;
            evalPrevCls = g_prevCls2;
            evalHigh    = rCurrent[1].high;
            evalLow     = rCurrent[1].low;
            evalVol     = (double)(rCurrent[1].tick_volume > 0 ? rCurrent[1].tick_volume : rCurrent[1].real_volume);
            ctxTag      = "Prior D1";
           }
         else
           {
            evalCls     = rCurrent[0].close;
            evalPrevCls = g_prevCls;
            evalHigh    = rCurrent[0].high;
            evalLow     = rCurrent[0].low;
            evalVol     = (double)(rCurrent[0].tick_volume > 0 ? rCurrent[0].tick_volume : rCurrent[0].real_volume);
            ctxTag      = "Today D1";
           }

         MqlTick lastTick;
         double bid = 0.0;
         if(SymbolInfoTick(Symbol(), lastTick)) bid = lastTick.bid;
         else bid = evalCls;

         double move = evalCls - evalPrevCls;
         double moveATR  = (g_curATR > 0.0) ? MathAbs(move) / g_curATR : 0.0;
         double rangeATR = (g_curATR > 0.0) ? (evalHigh - evalLow) / g_curATR : 0.0;
         int dir = (move > 0) ? 0 : 1;
         int b = BucketOfMove(moveATR);

         double volRatio = 1.0;
         if(activeEvalBar == 0)
           {
            datetime now = TimeCurrent();
            int secIntoDay = (int)(now % 86400);
            double dayFrac = MathMax((double)secIntoDay / 86400.0, 0.04);
            volRatio = (g_curVolMA > 0.0) ? ((evalVol / dayFrac) / g_curVolMA) : 1.0;
           }
         else
            volRatio = (g_curVolMA > 0.0) ? (evalVol / g_curVolMA) : 1.0;

         double intradayExt = (bid - (activeEvalBar == 1 ? evalCls : g_curOpen)) / (g_curATR > 0.0 ? g_curATR : 1.0);
         double intradayAbs = MathAbs(intradayExt);
         int step = (int)MathFloor(intradayAbs / 0.5);
         if(step > MAXSTEP - 1) step = MAXSTEP - 1;

         bool isBig = (moveATR >= InpMinMoveATR && rangeATR >= InpMinRangeATR);

         static double   s_lastBid = 0.0;
         static int      s_lastStep = -1;
         if(s_lastBid != bid || s_objSurv != g_survived || s_objDeep != g_deepTriggered || s_lastStep != step)
           {
            DrawCanonicalPanel(b, dir, isBig, moveATR, rangeATR, intradayAbs, step, ctxTag, volRatio);
            ChartRedraw();
            s_lastBid = bid;
            s_lastStep = step;
           }
        }
     }

   if(!g_firstCalculationDone)
     {
      g_firstCalculationDone = true;
      g_lastAlertEvent = g_eventTime;
      g_lastAlertDeep  = g_deepTriggered ? g_eventTime : 0;
      g_lastAlertReb   = g_eventTime;
     }
   else
     {
      if(g_eventBar >= 0 && g_eventTime != g_lastAlertEvent)
        {
         if(InpAlertOnEvent && (rates_total - 1 - g_eventBar) <= 1)
           {
            SendSmartAlert("New Valid Pullback Event", "Price closed below EMA50 at " + DoubleToString(g_eventClose, Digits) + ". Trend filters verified.");
            g_lastAlertEvent = g_eventTime;
           }
        }

      if(g_deepTriggered && g_eventTime != g_lastAlertDeep)
        {
         if(InpAlertOnDeep)
           {
            SendSmartAlert("Deep Path Triggered", "Price broke below trigger line (" + DoubleToString(g_eventClose - InpDeepATR * g_evATR, Digits) + "). Target Zone below.");
            g_lastAlertDeep = g_eventTime;
           }
        }

      if(!g_deepTriggered && g_survived >= 1 && wClose[rates_total - 1] > e8c[rates_total - 1] && g_eventTime != g_lastAlertReb)
        {
         if(InpAlertOnRebound)
           {
            SendSmartAlert("Clean Rebound Confirmed", "Price closed back above EMA8. Shallow bounce active!");
            g_lastAlertReb = g_eventTime;
           }
        }
     }

   return (rates_total);
  }
//+------------------------------------------------------------------+
