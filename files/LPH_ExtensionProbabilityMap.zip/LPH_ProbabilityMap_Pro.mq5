//+------------------------------------------------------------------+
//| LPH_ProbabilityMap_Pro.mq5                                      |
//| Complete Quant & Trade Execution Suite (MT5).                    |
//| Features:                                                        |
//|  1) Quality Filters (EMA50 Slope, ADX Momentum, RSI Exhaustion)  |
//|  2) Dynamic Trade Setup Engine (Auto SL, TP1, TP2, Live R:R)     |
//|  3) Visual SL/TP Price Rays & Chart Tags                         |
//|  4) Real-Time Alerts (No False Alerts on TF Change)              |
//|  5) Pro Quant HUD Dashboard with Trade Calculator & Status Badges|
//+------------------------------------------------------------------+
#property copyright "MetaTrader Assistant"
#property version   "3.70"
#property indicator_chart_window
#property indicator_buffers 3
#property indicator_plots   3

#property indicator_label1  "EMA50"
#property indicator_type1   DRAW_LINE
#property indicator_color1  C'255,145,0'
#property indicator_style1  STYLE_SOLID
#property indicator_width1  2

#property indicator_label2  "EMA8"
#property indicator_type2   DRAW_LINE
#property indicator_color2  C'0,170,255'
#property indicator_style2  STYLE_SOLID
#property indicator_width2  1

#property indicator_label3  "EMA20"
#property indicator_type3   DRAW_LINE
#property indicator_color3  C'0,220,130'
#property indicator_style3  STYLE_SOLID
#property indicator_width3  1

//--- Inputs
input group "=== 1. Core Parameters ==="
input int                  InpEMA8             = 8;
input int                  InpEMA20            = 20;
input int                  InpEMA50            = 50;
input int                  InpATR              = 14;
input double               InpDeepATR          = 0.50;    // Deep trigger: close <= eventClose - X*ATR
input int                  InpSurvBars         = 12;      // Survival lookahead bars
input double               InpZone1ATR         = 1.50;    // Zone 1 line (x ATR below event)
input int                  InpMaxEventAgeBars  = 24;      // Hide stale event map if last event older than N bars

input group "=== 2. Quality & Trend Filters ==="
input bool                 InpUseSlopeFilter   = true;    // Require EMA50 to be rising (slope > 0)
input double               InpMinSlopeATR      = 0.05;    // Min EMA50 rise over 5 bars (in ATR units)
input bool                 InpUseADXFilter     = true;    // Require ADX Trend Strength
input int                  InpADXPeriod        = 14;      // ADX Period
input double               InpMinADX           = 20.0;    // Minimum ADX Threshold
input bool                 InpUseRSIFilter     = false;   // Require RSI Pullback Condition
input int                  InpRSIPeriod        = 14;      // RSI Period
input double               InpMaxRSI           = 48.0;    // Max RSI at pullback

input group "=== 3. Trade Plan & Target Engine ==="
input bool                 InpShowTradePlan    = true;    // Calculate and plot SL, TP1, TP2 & R:R
input double               InpSL_BufferATR     = 0.25;    // Stop Loss buffer below Zone 2 (in ATR)
input double               InpTP2_FibRatio     = 1.618;   // TP2 Fibonacci Extension Ratio
input int                  InpSwingLookback    = 30;      // Swing High lookback for TP1

input group "=== 4. Smart Alerts ==="
input bool                 InpAlertPopup       = true;    // Desktop Popup Alert
input bool                 InpAlertPush        = false;   // Push Notification to Mobile App
input bool                 InpAlertSound       = true;    // Sound Audio Alert
input bool                 InpAlertOnEvent     = true;    // Alert on New Valid Pullback Event
input bool                 InpAlertOnDeep      = true;    // Alert when Deep Path Triggers
input bool                 InpAlertOnRebound   = true;    // Alert when Rebound Confirms (Close > EMA8)

input group "=== 5. UI / Dashboard Settings ==="
input bool                 InpShowPanel        = true;    // Show Modern Floating HUD Dashboard
input ENUM_BASE_CORNER     InpPanelCorner      = CORNER_LEFT_UPPER; // Dashboard Corner
input int                  InpPanelX           = 15;      // Dashboard X Offset (pixels)
input int                  InpPanelY           = 30;      // Dashboard Y Offset (pixels)
input bool                 InpRayLevels        = true;    // Clean bounded rays (true) vs full HLines (false)
input color                InpTriggerColor     = C'255,75,75';    // Deep Trigger Color
input color                InpZoneColor        = C'255,205,0';    // Target Zone Lines Color
input color                InpBandColor        = C'15,50,90';     // Target Zone Area Fill Color
input color                InpSLColor          = C'255,50,80';    // Stop Loss Color
input color                InpTPColor          = C'0,230,130';    // Take Profit Color

double  g_ema50[], g_ema8[], g_ema20[];

int      g_total = 0, g_clean = 0, g_deep = 0;
int      g_deepAtBar[];
double   g_avgDeepATR = 0.0, g_avgCleanATR = 0.0;
int      g_eventBar = -1;
datetime g_eventTime = 0;
double   g_eventClose = 0.0, g_evATR = 0.0, g_evEMA50 = 0.0;
int      g_survived = 0;
bool     g_deepTriggered = false;
bool     g_statsReady = false;
string   g_prefix = "LPHPRO_";

// Trade Plan targets
double   g_tradeSL = 0.0, g_tradeTP1 = 0.0, g_tradeTP2 = 0.0, g_tradeRR = 0.0;

int      g_handleADX = INVALID_HANDLE;
int      g_handleRSI = INVALID_HANDLE;

// Alert state tracking
bool     g_firstCalculationDone = false;
datetime g_lastAlertEvent = 0;
datetime g_lastAlertDeep  = 0;
datetime g_lastAlertReb   = 0;

void SendSmartAlert(string title, string msg)
  {
   string fullMsg = "[LPH Pro " + _Symbol + " (" + EnumToString(_Period) + ")] " + title + "\n" + msg;
   if(InpAlertPopup) Alert(fullMsg);
   if(InpAlertPush)  SendNotification(fullMsg);
   if(InpAlertSound) PlaySound("expert.wav");
  }

void CalcEMA(const double &p[], const int period, double &e[], const int n)
  {
   for(int i = 0; i < n; i++) e[i] = EMPTY_VALUE;
   if(n < period || period <= 0) return;

   double sum = 0.0;
   for(int i = 0; i < period; i++) sum += p[i];
   e[period - 1] = sum / (double)period;
   double k = 2.0 / ((double)period + 1.0);

   for(int i = period; i < n; i++)
     {
      if(e[i - 1] == EMPTY_VALUE) e[i] = p[i];
      else e[i] = p[i] * k + e[i - 1] * (1.0 - k);
     }
  }

// All input arrays here are guaranteed to be chronological (0 = oldest, n-1 = newest)
void ComputeStats(const datetime &time[], const double &open[], const double &high[],
                  const double &low[], const double &close[], const int n)
  {
   if(n < InpEMA50 + InpSurvBars + 10) return;

   double e50[], e8[], e20[], atr[];
   ArrayResize(e50, n); ArrayResize(e8, n); ArrayResize(e20, n); ArrayResize(atr, n);
   CalcEMA(close, InpEMA50, e50, n);
   CalcEMA(close, InpEMA8,  e8,  n);
   CalcEMA(close, InpEMA20, e20, n);

   for(int i = 0; i < n; i++)
     {
      if(i >= InpATR)
        {
         double s = 0.0;
         for(int j = i - (InpATR - 1); j <= i; j++)
            s += MathMax(high[j] - low[j], MathMax(MathAbs(high[j] - close[j - 1]), MathAbs(low[j] - close[j - 1])));
         atr[i] = s / (double)InpATR;
        }
      else if(i > 0) atr[i] = MathMax(high[i] - low[i], MathMax(MathAbs(high[i] - close[i - 1]), MathAbs(low[i] - close[i - 1])));
      else atr[i] = high[i] - low[i];
     }

   double adxVal[], rsiVal[];
   if(InpUseADXFilter && g_handleADX != INVALID_HANDLE)
     {
      double adxRaw[];
      int copied = CopyBuffer(g_handleADX, 0, 0, n, adxRaw);
      if(copied == n)
        {
         ArrayResize(adxVal, n);
         // CopyBuffer index 0 is oldest if as_series is false (default in MT5)
         bool isAdxSeries = ArrayGetAsSeries(adxRaw);
         for(int i = 0; i < n; i++)
            adxVal[i] = isAdxSeries ? adxRaw[n - 1 - i] : adxRaw[i];
        }
     }
   if(InpUseRSIFilter && g_handleRSI != INVALID_HANDLE)
     {
      double rsiRaw[];
      int copied = CopyBuffer(g_handleRSI, 0, 0, n, rsiRaw);
      if(copied == n)
        {
         ArrayResize(rsiVal, n);
         bool isRsiSeries = ArrayGetAsSeries(rsiRaw);
         for(int i = 0; i < n; i++)
            rsiVal[i] = isRsiSeries ? rsiRaw[n - 1 - i] : rsiRaw[i];
        }
     }

   MqlRates d1[];
   int nd = 0;
   bool useD1 = (_Period < PERIOD_D1);
   double dc[], d1e50[];
   if(useD1)
     {
      nd = CopyRates(_Symbol, PERIOD_D1, time[0], time[n - 1], d1);
      if(nd >= InpEMA50)
        {
         ArrayResize(dc, nd); ArrayResize(d1e50, nd);
         for(int i = 0; i < nd; i++) dc[i] = d1[i].close;
         CalcEMA(dc, InpEMA50, d1e50, nd);
        }
      else useD1 = false;
     }

   g_total = 0; g_clean = 0; g_deep = 0; g_avgDeepATR = 0.0; g_avgCleanATR = 0.0;
   int survMax = MathMax(InpSurvBars, 1);
   ArrayResize(g_deepAtBar, survMax + 1);
   ArrayInitialize(g_deepAtBar, 0);
   double sumDeepATR = 0.0, sumCleanATR = 0.0;
   int d1ptr = 0;
   int evChrono = -1;

   for(int i = InpEMA50 + 5; i < n - 1 - InpSurvBars; i++)
     {
      if(e50[i] == EMPTY_VALUE || e50[i-1] == EMPTY_VALUE || e8[i-1] == EMPTY_VALUE || e20[i-1] == EMPTY_VALUE) continue;
      if(close[i] >= e50[i]) continue;
      if(!(close[i - 1] > e50[i - 1])) continue;
      if(!(e8[i - 1] > e20[i - 1])) continue;

      if(InpUseSlopeFilter)
        {
         if(e50[i - 5] == EMPTY_VALUE) continue;
         double slope = (e50[i - 1] - e50[i - 5]) / (atr[i - 1] > 0 ? atr[i - 1] : 1.0);
         if(slope < InpMinSlopeATR) continue;
        }

      if(InpUseADXFilter && ArraySize(adxVal) == n)
        {
         if(adxVal[i - 1] < InpMinADX) continue;
        }

      if(InpUseRSIFilter && ArraySize(rsiVal) == n)
        {
         if(rsiVal[i] > InpMaxRSI) continue;
        }

      if(useD1)
        {
         datetime tPrev = time[i - 1];
         while(d1ptr + 1 < nd && d1[d1ptr + 1].time <= tPrev) d1ptr++;
         if(d1ptr >= nd) continue;
         if(d1e50[d1ptr] == EMPTY_VALUE || !(dc[d1ptr] > d1e50[d1ptr])) continue;
        }

      g_total++;
      bool reverted = false, deeper = false;
      int deepBar = -1;
      double minClose = close[i];
      for(int j = i + 1; j <= i + InpSurvBars && j < n; j++)
        {
         if(close[j] < minClose) minClose = close[j];
         if(!reverted && close[j] > e50[j]) reverted = true;
         if(!deeper && close[j] <= close[i] - InpDeepATR * atr[i]) { deeper = true; deepBar = j - i; }
        }
      double depthATR = (close[i] - minClose) / (atr[i] > 0 ? atr[i] : 1.0);
      if(reverted && !deeper) { g_clean++; sumCleanATR += depthATR; }
      else if(deeper)         { g_deep++; sumDeepATR += depthATR;
                                if(deepBar >= 1 && deepBar <= InpSurvBars) g_deepAtBar[deepBar]++; }
      else                    { g_deep++; sumDeepATR += depthATR; }

      evChrono = i;
     }

   g_avgDeepATR  = g_deep  > 0 ? sumDeepATR  / (double)g_deep  : 0.0;
   g_avgCleanATR = g_clean > 0 ? sumCleanATR / (double)g_clean : 0.0;

   // Find live event anchor scanning backward from the newest completed bar (n - 2)
   int evAnchor = -1;
   int d1p2 = nd - 1;
   for(int i = n - 2; i >= InpEMA50 + 5; i--)
     {
      if(e50[i] == EMPTY_VALUE || e50[i-1] == EMPTY_VALUE || e8[i-1] == EMPTY_VALUE || e20[i-1] == EMPTY_VALUE) continue;
      if(close[i] >= e50[i]) continue;
      if(!(close[i - 1] > e50[i - 1])) continue;
      if(!(e8[i - 1] > e20[i - 1])) continue;

      if(InpUseSlopeFilter)
        {
         if(e50[i - 5] == EMPTY_VALUE) continue;
         double slope = (e50[i - 1] - e50[i - 5]) / (atr[i - 1] > 0 ? atr[i - 1] : 1.0);
         if(slope < InpMinSlopeATR) continue;
        }

      if(InpUseADXFilter && ArraySize(adxVal) == n)
        {
         if(adxVal[i - 1] < InpMinADX) continue;
        }

      if(InpUseRSIFilter && ArraySize(rsiVal) == n)
        {
         if(rsiVal[i] > InpMaxRSI) continue;
        }

      if(useD1)
        {
         datetime tPrev = time[i - 1];
         while(d1p2 > 0 && d1[d1p2].time > tPrev) d1p2--;
         if(d1p2 < 0) break;
         if(d1e50[d1p2] == EMPTY_VALUE || !(dc[d1p2] > d1e50[d1p2])) continue;
        }
      evAnchor = i;
      break;
     }
   if(evAnchor < 0) evAnchor = evChrono;

   if(evAnchor >= 0)
     {
      g_eventBar   = evAnchor;
      g_eventTime  = time[evAnchor];
      g_eventClose = close[evAnchor];
      g_evATR      = atr[evAnchor];
      g_evEMA50    = e50[evAnchor];

      double z2ATR = g_avgDeepATR > 0 ? MathMax(g_avgDeepATR, InpZone1ATR) : 2.6;
      double z2 = g_eventClose - z2ATR * g_evATR;
      g_tradeSL = z2 - InpSL_BufferATR * g_evATR;

      double highestSwing = high[evAnchor];
      int lookStart = MathMax(0, evAnchor - InpSwingLookback);
      for(int s = lookStart; s <= evAnchor; s++)
        {
         if(high[s] > highestSwing) highestSwing = high[s];
        }
      g_tradeTP1 = highestSwing;
      double risk = MathMax(g_eventClose - g_tradeSL, _Point * 10);
      g_tradeTP2 = g_eventClose + InpTP2_FibRatio * (highestSwing - g_eventClose + risk);
      g_tradeRR  = (g_tradeTP1 - g_eventClose) / risk;
     }
   else
     {
      g_eventBar   = -1;
      g_eventTime  = 0;
     }

   g_survived = 0; g_deepTriggered = false;
   if(g_eventBar >= 0)
     {
      double trig = g_eventClose - InpDeepATR * g_evATR;
      for(int k = g_eventBar + 1; k < n; k++)
        {
         if(close[k] <= trig) { g_deepTriggered = true; break; }
         g_survived++;
        }
     }

   g_statsReady = true;
  }

double RemainingDeepProb(const int survived)
  {
   if(g_total == 0) return 0.0;
   int cum = 0;
   int maxK = MathMin(InpSurvBars, ArraySize(g_deepAtBar) - 1);
   for(int k = 1; k <= survived && k <= maxK; k++) cum += g_deepAtBar[k];
   return 100.0 * (double)(g_deep - cum) / (double)g_total;
  }

void ObjDelAll() { ObjectsDeleteAll(0, g_prefix); }

void OnDeinit(const int reason)
  {
   ObjDelAll();
   if(g_handleADX != INVALID_HANDLE) IndicatorRelease(g_handleADX);
   if(g_handleRSI != INVALID_HANDLE) IndicatorRelease(g_handleRSI);
  }

void CreateHudLabel(string name, int x, int y, string text, color clr, int fontSize, bool isBold = false)
  {
   string fullId = g_prefix + name;
   if(ObjectFind(0, fullId) < 0) ObjectCreate(0, fullId, OBJ_LABEL, 0, 0, 0);
   ObjectSetInteger(0, fullId, OBJPROP_CORNER, InpPanelCorner);
   ObjectSetInteger(0, fullId, OBJPROP_XDISTANCE, InpPanelX + x);
   ObjectSetInteger(0, fullId, OBJPROP_YDISTANCE, InpPanelY + y);
   ObjectSetInteger(0, fullId, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, fullId, OBJPROP_FONTSIZE, fontSize);
   ObjectSetString(0, fullId, OBJPROP_FONT, isBold ? "Segoe UI Semibold" : "Segoe UI");
   ObjectSetString(0, fullId, OBJPROP_TEXT, text);
   ObjectSetInteger(0, fullId, OBJPROP_BACK, false);
   ObjectSetInteger(0, fullId, OBJPROP_SELECTABLE, false);
  }

void CreateLevelRay(string name, datetime tStart, datetime tEnd, double price, color clr, ENUM_LINE_STYLE style, int width, string tagText)
  {
   string lineId = g_prefix + "ray_" + name;
   string tagId  = g_prefix + "tag_" + name;

   if(InpRayLevels)
     {
      if(ObjectFind(0, lineId) < 0) ObjectCreate(0, lineId, OBJ_TREND, 0, tStart, price, tEnd, price);
      else
        {
         ObjectSetInteger(0, lineId, OBJPROP_TIME, 0, tStart);
         ObjectSetDouble(0, lineId, OBJPROP_PRICE, 0, price);
         ObjectSetInteger(0, lineId, OBJPROP_TIME, 1, tEnd);
         ObjectSetDouble(0, lineId, OBJPROP_PRICE, 1, price);
        }
      ObjectSetInteger(0, lineId, OBJPROP_RAY_RIGHT, true);
     }
   else
     {
      if(ObjectFind(0, lineId) < 0) ObjectCreate(0, lineId, OBJ_HLINE, 0, 0, price);
      else ObjectSetDouble(0, lineId, OBJPROP_PRICE, 0, price);
     }

   ObjectSetInteger(0, lineId, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, lineId, OBJPROP_STYLE, style);
   ObjectSetInteger(0, lineId, OBJPROP_WIDTH, width);
   ObjectSetInteger(0, lineId, OBJPROP_BACK, true);

   if(ObjectFind(0, tagId) < 0) ObjectCreate(0, tagId, OBJ_TEXT, 0, tEnd, price);
   else
     {
      ObjectSetInteger(0, tagId, OBJPROP_TIME, 0, tEnd);
      ObjectSetDouble(0, tagId, OBJPROP_PRICE, 0, price);
     }
   ObjectSetString(0, tagId, OBJPROP_TEXT, "  " + tagText);
   ObjectSetInteger(0, tagId, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, tagId, OBJPROP_FONTSIZE, 8);
   ObjectSetString(0, tagId, OBJPROP_FONT, "Segoe UI Bold");
   ObjectSetInteger(0, tagId, OBJPROP_ANCHOR, ANCHOR_LEFT);
   ObjectSetInteger(0, tagId, OBJPROP_BACK, false);
  }

void UpdateObjects(const datetime &time[], const double &low[], const double &close[], const int n)
  {
   ObjDelAll();
   if(!g_statsReady) return;

   int eventAgeBars = (g_eventBar >= 0) ? (n - 1 - g_eventBar) : 999999;
   bool drawMap = (g_eventBar >= 0 && eventAgeBars <= InpMaxEventAgeBars);
   double trig = g_eventClose - InpDeepATR   * g_evATR;
   double z1   = g_eventClose - InpZone1ATR  * g_evATR;
   double z2   = g_eventClose - (g_avgDeepATR > 0 ? MathMax(g_avgDeepATR, InpZone1ATR) : 2.6) * g_evATR;
   int dg = (int)_Digits;
   string nm;

   datetime nowTime = time[n - 1];
   datetime futureTime = nowTime + PeriodSeconds() * 8;

   if(drawMap)
     {
      CreateLevelRay("trig", g_eventTime, futureTime, trig, InpTriggerColor, STYLE_DASH, 1, 
                     "TRIGGER (0.5x ATR): " + DoubleToString(trig, dg));
      CreateLevelRay("z1",   g_eventTime, futureTime, z1,   InpZoneColor,    STYLE_DASH, 1, 
                     "ZONE 1 (1.5x ATR): " + DoubleToString(z1, dg));
      CreateLevelRay("z2",   g_eventTime, futureTime, z2,   InpZoneColor,    STYLE_SOLID, 2, 
                     "ZONE 2 (Avg Deep): " + DoubleToString(z2, dg));

      if(InpShowTradePlan)
        {
         CreateLevelRay("sl",  g_eventTime, futureTime, g_tradeSL,  InpSLColor, STYLE_SOLID, 2, "STOP LOSS: " + DoubleToString(g_tradeSL, dg));
         CreateLevelRay("tp1", g_eventTime, futureTime, g_tradeTP1, InpTPColor, STYLE_SOLID, 2, "TP1 (Swing High): " + DoubleToString(g_tradeTP1, dg));
         CreateLevelRay("tp2", g_eventTime, futureTime, g_tradeTP2, InpTPColor, STYLE_DASH,  1, "TP2 (1.618 Fib): " + DoubleToString(g_tradeTP2, dg));
        }

      nm = g_prefix + "band";
      ObjectCreate(0, nm, OBJ_RECTANGLE, 0, g_eventTime, z1, futureTime, z2);
      ObjectSetInteger(0, nm, OBJPROP_COLOR, InpBandColor);
      ObjectSetInteger(0, nm, OBJPROP_FILL, true);
      ObjectSetInteger(0, nm, OBJPROP_BACK, true);

      nm = g_prefix + "evArrow";
      ObjectCreate(0, nm, OBJ_ARROW, 0, g_eventTime, low[g_eventBar]);
      ObjectSetInteger(0, nm, OBJPROP_ARROWCODE, 234);
      ObjectSetInteger(0, nm, OBJPROP_COLOR, InpTriggerColor);
      ObjectSetInteger(0, nm, OBJPROP_WIDTH, 2);
      ObjectSetInteger(0, nm, OBJPROP_ANCHOR, ANCHOR_TOP);

      nm = g_prefix + "evTxt";
      ObjectCreate(0, nm, OBJ_TEXT, 0, g_eventTime, low[g_eventBar]);
      ObjectSetString(0, nm, OBJPROP_TEXT, "  PRO PULLBACK SETUP\n  " + TimeToString(g_eventTime, TIME_DATE|TIME_MINUTES) + 
                                           "\n  Entry: " + DoubleToString(g_eventClose, dg));
      ObjectSetInteger(0, nm, OBJPROP_COLOR, InpTriggerColor);
      ObjectSetInteger(0, nm, OBJPROP_FONTSIZE, 8);
      ObjectSetString(0, nm, OBJPROP_FONT, "Segoe UI Semibold");
      ObjectSetInteger(0, nm, OBJPROP_ANCHOR, ANCHOR_TOP);
     }

   if(InpShowPanel)
     {
      int panelW = 310;
      int panelH = 230;

      string bgId = g_prefix + "hud_bg";
      ObjectCreate(0, bgId, OBJ_RECTANGLE_LABEL, 0, 0, 0);
      ObjectSetInteger(0, bgId, OBJPROP_CORNER, InpPanelCorner);
      ObjectSetInteger(0, bgId, OBJPROP_XDISTANCE, InpPanelX);
      ObjectSetInteger(0, bgId, OBJPROP_YDISTANCE, InpPanelY);
      ObjectSetInteger(0, bgId, OBJPROP_XSIZE, panelW);
      ObjectSetInteger(0, bgId, OBJPROP_YSIZE, panelH);
      ObjectSetInteger(0, bgId, OBJPROP_BGCOLOR, C'14,18,26');
      ObjectSetInteger(0, bgId, OBJPROP_BORDER_COLOR, C'45,60,85');
      ObjectSetInteger(0, bgId, OBJPROP_BORDER_TYPE, BORDER_FLAT);

      string barId = g_prefix + "hud_bar";
      ObjectCreate(0, barId, OBJ_RECTANGLE_LABEL, 0, 0, 0);
      ObjectSetInteger(0, barId, OBJPROP_CORNER, InpPanelCorner);
      ObjectSetInteger(0, barId, OBJPROP_XDISTANCE, InpPanelX);
      ObjectSetInteger(0, barId, OBJPROP_YDISTANCE, InpPanelY);
      ObjectSetInteger(0, barId, OBJPROP_XSIZE, panelW);
      ObjectSetInteger(0, barId, OBJPROP_YSIZE, 4);
      ObjectSetInteger(0, barId, OBJPROP_BGCOLOR, C'255,170,0');
      ObjectSetInteger(0, barId, OBJPROP_BORDER_COLOR, C'255,170,0');

      CreateHudLabel("title", 12, 10, "⚡ LPH QUANT & TRADE SUITE PRO", C'255,235,170', 10, true);
      CreateHudLabel("sub", 12, 26, _Symbol + " • " + EnumToString(_Period) + " (" + IntegerToString(g_total) + " verified setups)", C'140,160,190', 8);

      string fltStr = "Filters: Slope " + (InpUseSlopeFilter?"✓":"✗") + " | ADX(" + IntegerToString((int)InpMinADX) + ") " + (InpUseADXFilter?"✓":"✗") + " | RSI " + (InpUseRSIFilter?"✓":"✗");
      CreateHudLabel("flt", 12, 42, fltStr, C'0,200,255', 8);

      string badgeText = "⚪ MONITORING MARKET";
      color badgeColor = C'140,150,170';

      if(drawMap)
        {
         if(g_deepTriggered)
           {
            badgeText = "🔴 DEEP PATH (Target Zone " + DoubleToString(z1, dg) + "-" + DoubleToString(z2, dg) + ")";
            badgeColor = C'255,85,85';
           }
         else
           {
            double remDeep = RemainingDeepProb(g_survived);
            badgeText = "🟢 SHALLOW BOUNCE (" + IntegerToString(g_survived) + "/" + IntegerToString(InpSurvBars) + " bars safe)";
            badgeColor = C'0,230,130';
           }
        }
      else if(g_eventBar >= 0)
        {
         badgeText = "⚪ LAST SETUP " + IntegerToString(eventAgeBars) + " BARS AGO";
         badgeColor = C'140,150,170';
        }

      CreateHudLabel("badge", 12, 58, badgeText, badgeColor, 8, true);
      CreateHudLabel("div1", 12, 70, "────────────────────────────────────", C'35,45,65', 8);

      double pClean = g_total > 0 ? (100.0 * (double)g_clean / (double)g_total) : 0.0;
      double pDeep  = g_total > 0 ? (100.0 * (double)g_deep  / (double)g_total) : 0.0;

      CreateHudLabel("kpi1_l", 12, 86, "Clean Revert Rate:", C'170,185,210', 8);
      CreateHudLabel("kpi1_v", 210, 86, DoubleToString(pClean, 1) + "%", C'0,230,130', 8, true);

      CreateHudLabel("kpi2_l", 12, 104, "Deep Correction Rate:", C'170,185,210', 8);
      CreateHudLabel("kpi2_v", 210, 104, DoubleToString(pDeep, 1) + "%", C'255,160,50', 8, true);

      if(drawMap && !g_deepTriggered)
        {
         double remDeep = RemainingDeepProb(g_survived);
         CreateHudLabel("kpi3_l", 12, 122, "Remaining P(Deeper):", C'170,185,210', 8);
         CreateHudLabel("kpi3_v", 210, 122, DoubleToString(remDeep, 1) + "%", C'255,215,0', 8, true);
        }
      else
        {
         CreateHudLabel("kpi3_l", 12, 122, "Avg Deep Drawdown:", C'170,185,210', 8);
         CreateHudLabel("kpi3_v", 210, 122, DoubleToString(g_avgDeepATR, 2) + " ATR", C'220,230,245', 8, true);
        }

      CreateHudLabel("div2", 12, 134, "────────────────────────────────────", C'35,45,65', 8);

      if(drawMap && InpShowTradePlan)
        {
         CreateHudLabel("plan_h", 12, 148, "TRADE PLAN:", C'255,215,0', 8, true);
         CreateHudLabel("plan_rr", 120, 148, "Risk:Reward = 1 : " + DoubleToString(g_tradeRR, 2), C'0,230,130', 8, true);

         CreateHudLabel("sl_lbl", 12, 166, "SL: " + DoubleToString(g_tradeSL, dg), InpSLColor, 8);
         CreateHudLabel("tp1_lbl", 110, 166, "TP1: " + DoubleToString(g_tradeTP1, dg), InpTPColor, 8);
         CreateHudLabel("tp2_lbl", 210, 166, "TP2: " + DoubleToString(g_tradeTP2, dg), InpTPColor, 8);
        }
      else
        {
         CreateHudLabel("plan_m", 12, 156, "Waiting for fresh pullback confirmation...", C'120,140,165', 8);
        }

      CreateHudLabel("footer", 12, 206, "LPH Pro • Institutional Quantitative Trade Suite", C'90,110,140', 7);
     }
  }

int OnInit()
  {
   SetIndexBuffer(0, g_ema50, INDICATOR_DATA);
   SetIndexBuffer(1, g_ema8,  INDICATOR_DATA);
   SetIndexBuffer(2, g_ema20, INDICATOR_DATA);

   PlotIndexSetDouble(0, PLOT_EMPTY_VALUE, EMPTY_VALUE);
   PlotIndexSetDouble(1, PLOT_EMPTY_VALUE, EMPTY_VALUE);
   PlotIndexSetDouble(2, PLOT_EMPTY_VALUE, EMPTY_VALUE);

   PlotIndexSetInteger(0, PLOT_DRAW_BEGIN, InpEMA50);
   PlotIndexSetInteger(1, PLOT_DRAW_BEGIN, InpEMA8);
   PlotIndexSetInteger(2, PLOT_DRAW_BEGIN, InpEMA20);

   if(InpUseADXFilter) g_handleADX = iADX(_Symbol, _Period, InpADXPeriod);
   if(InpUseRSIFilter) g_handleRSI = iRSI(_Symbol, _Period, InpRSIPeriod, PRICE_CLOSE);

   g_firstCalculationDone = false;
   return INIT_SUCCEEDED;
  }

int OnCalculate(const int rates_total, const int prev_calculated,
                const datetime &time[], const double &open[], const double &high[],
                const double &low[], const double &close[], const long &tick_volume[],
                const long &volume[], const int &spread[])
  {
   if(rates_total < InpEMA50 + InpSurvBars + 10) return 0;

   // -------------------------------------------------------------------------
   // DYNAMIC ARRAY ORIENTATION HANDLER
   // Normalize input arrays to strict chronological order (0 = oldest, n-1 = newest)
   // -------------------------------------------------------------------------
   bool isSeries = ArrayGetAsSeries(close);

   static datetime wTime[];
   static double   wOpen[], wHigh[], wLow[], wClose[];
   ArrayResize(wTime,  rates_total);
   ArrayResize(wOpen,  rates_total);
   ArrayResize(wHigh,  rates_total);
   ArrayResize(wLow,   rates_total);
   ArrayResize(wClose, rates_total);

   for(int i = 0; i < rates_total; i++)
     {
      int src = isSeries ? (rates_total - 1 - i) : i;
      wTime[i]  = time[src];
      wOpen[i]  = open[src];
      wHigh[i]  = high[src];
      wLow[i]   = low[src];
      wClose[i] = close[src];
     }

   // Compute EMAs forward in time (chronological)
   double e50c[], e8c[], e20c[];
   ArrayResize(e50c, rates_total); ArrayResize(e8c, rates_total); ArrayResize(e20c, rates_total);
   CalcEMA(wClose, InpEMA50, e50c, rates_total);
   CalcEMA(wClose, InpEMA8,  e8c,  rates_total);
   CalcEMA(wClose, InpEMA20, e20c, rates_total);

   // Write into indicator plot buffers according to their orientation
   bool isBufferSeries = ArrayGetAsSeries(g_ema50);
   for(int i = 0; i < rates_total; i++)
     {
      int dst = isBufferSeries ? (rates_total - 1 - i) : i;
      g_ema50[dst] = e50c[i];
      g_ema8[dst]  = e8c[i];
      g_ema20[dst] = e20c[i];
     }

   static int lastBar = 0;
   if(!g_statsReady || lastBar != rates_total)
     {
      ComputeStats(wTime, wOpen, wHigh, wLow, wClose, rates_total);
      lastBar = rates_total;
     }
   else
     {
      if(g_eventBar >= 0)
        {
         double trig = g_eventClose - InpDeepATR * g_evATR;
         g_survived = 0; g_deepTriggered = false;
         for(int k = g_eventBar + 1; k < rates_total; k++)
           {
            if(wClose[k] <= trig) { g_deepTriggered = true; break; }
            g_survived++;
           }
        }
     }

   // Smart Alerts (no alerts on TF change)
   if(!g_firstCalculationDone || prev_calculated == 0)
     {
      g_firstCalculationDone = true;
      g_lastAlertEvent = g_eventTime;
      g_lastAlertDeep  = g_deepTriggered ? g_eventTime : 0;
      g_lastAlertReb   = g_eventTime;
     }
   else
     {
      if(g_eventBar >= 0 && g_eventTime != g_lastAlertEvent)
        {
         if(InpAlertOnEvent && (rates_total - 1 - g_eventBar) <= 1)
           {
            SendSmartAlert("New Valid Pullback Event", "Price closed below EMA50 at " + DoubleToString(g_eventClose, _Digits) + ". Trend filters verified.");
            g_lastAlertEvent = g_eventTime;
           }
        }

      if(g_deepTriggered && g_eventTime != g_lastAlertDeep)
        {
         if(InpAlertOnDeep)
           {
            SendSmartAlert("Deep Path Triggered", "Price broke below trigger line (" + DoubleToString(g_eventClose - InpDeepATR * g_evATR, _Digits) + "). Target Zone below.");
            g_lastAlertDeep = g_eventTime;
           }
        }

      if(!g_deepTriggered && g_survived >= 1 && wClose[rates_total - 1] > e8c[rates_total - 1] && g_eventTime != g_lastAlertReb)
        {
         if(InpAlertOnRebound)
           {
            SendSmartAlert("Clean Rebound Confirmed", "Price closed back above EMA8. Shallow bounce active!");
            g_lastAlertReb = g_eventTime;
           }
        }
     }

   static datetime s_objTime = 0;
   static bool     s_objDeep = false;
   static int      s_objSurv = -1;
   if(s_objTime != wTime[rates_total - 1] || s_objDeep != g_deepTriggered || s_objSurv != g_survived)
     {
      UpdateObjects(wTime, wLow, wClose, rates_total);
      s_objTime = wTime[rates_total - 1];
      s_objDeep = g_deepTriggered;
      s_objSurv = g_survived;
     }

   return rates_total;
  }
//+------------------------------------------------------------------+

