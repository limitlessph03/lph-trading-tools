#property strict
#property indicator_chart_window

input bool   OnlyCurrentSymbol = true;
input bool   ShowOpenTrades    = true;
input bool   ShowHistoryTrades = false;
input int    HistoryDaysBack   = 30;
input int    ExtendOpenBars    = 80;
input color  EntryToTpColor    = clrPaleGreen;
input color  EntryToSlColor    = clrMistyRose;
input bool   DrawBehindCandles = true;
input int    BorderWidth       = 1;

// --- Basket shading fix
// When true, open trades on the same chart symbol and same direction are drawn as ONE clean basket box.
// This prevents the patchy/uneven blocks caused by separate rectangles per ticket in grid/basket trades.
input bool   UseBasketShadingForOpenTrades = true;
input bool   ShowIndividualOpenPipsLabels  = true;   // Keep per-ticket running pips labels while using basket shading
input bool   ShowBasketPipsLabel           = false;  // Optional extra basket label near price. Corner total still works.

// --- Running / closed P/L in pips display
input bool   ShowRunningPips       = true;      // Show live pips for open trades
input bool   ShowClosedPips        = true;      // Show final pips for history trades when ShowHistoryTrades=true
input bool   ShowTotalOpenPips     = true;      // Show total open pips on chart corner
input double CustomPipSize         = 0.0;       // 0 = auto. Example EURUSD 0.00010, USDJPY 0.010, XAUUSD 0.10/1.00 if preferred
input int    PipsDecimals          = 1;
input int    PipsLabelFontSize     = 9;
input string PipsLabelFont         = "Arial Bold";
input int    PipsLabelShiftBars    = 3;         // Move live pips label to the right of current candle
input double PipsLabelSpacingPips  = 5.0;       // Vertical spacing between multiple labels
input color  ProfitPipsColor       = clrLimeGreen;
input color  LossPipsColor         = clrTomato;
input color  BreakevenPipsColor    = clrSilver;
input int    TotalLabelCorner      = CORNER_LEFT_UPPER;
input int    TotalLabelX           = 12;
input int    TotalLabelY           = 18;

string Prefix = "EntryTpSlShade_";

int OnInit()
{
   IndicatorShortName("Entry TP/SL Shading + Running Pips");

   // Clear stale hidden objects from old versions / old settings.
   DeleteObjectsByPrefix(Prefix);

   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason)
{
   DeleteObjectsByPrefix(Prefix);
}

int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
   DrawAllTradeZones();
   return(rates_total);
}

void DrawAllTradeZones()
{
   DeleteObjectsByPrefix(Prefix);

   double total_open_pips = 0.0;
   int open_trade_count = 0;
   int open_label_index = 0;
   int history_label_index = 0;

   if(ShowOpenTrades)
   {
      // Basket shading is intentionally limited to the current chart symbol.
      // If OnlyCurrentSymbol=false, fall back to per-ticket drawing to avoid mixing prices from different symbols.
      if(UseBasketShadingForOpenTrades && OnlyCurrentSymbol)
         DrawOpenBasketZones(total_open_pips, open_trade_count, open_label_index);
      else
         DrawOpenTicketZones(total_open_pips, open_trade_count, open_label_index);
   }

   if(ShowHistoryTrades)
   {
      datetime earliest = TimeCurrent() - (HistoryDaysBack * 86400);

      for(int h = OrdersHistoryTotal() - 1; h >= 0; h--)
      {
         if(!OrderSelect(h, SELECT_BY_POS, MODE_HISTORY))
            continue;

         if(OrderOpenTime() < earliest)
            continue;

         if(!IsDrawableOrder(true))
            continue;

         DrawOrderZones(true, history_label_index);
         history_label_index++;
      }
   }

   if(ShowTotalOpenPips && ShowOpenTrades && open_trade_count > 0)
      DrawTotalOpenPipsLabel(total_open_pips, open_trade_count);
}

void DrawOpenTicketZones(double &total_open_pips, int &open_trade_count, int &open_label_index)
{
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
         continue;

      if(!IsDrawableOrder(false))
         continue;

      double order_pips = CalculateOrderPips(false);
      total_open_pips += order_pips;
      open_trade_count++;

      DrawOrderZones(false, open_label_index);
      open_label_index++;
   }
}

void DrawOpenBasketZones(double &total_open_pips, int &open_trade_count, int &open_label_index)
{
   // BUY basket accumulators
   int buy_count = 0;
   double buy_lots = 0.0;
   double buy_entry_weighted = 0.0;
   double buy_pips = 0.0;
   datetime buy_earliest = 0;
   bool buy_has_tp = false;
   bool buy_has_sl = false;
   double buy_tp = 0.0;
   double buy_sl = 0.0;

   // SELL basket accumulators
   int sell_count = 0;
   double sell_lots = 0.0;
   double sell_entry_weighted = 0.0;
   double sell_pips = 0.0;
   datetime sell_earliest = 0;
   bool sell_has_tp = false;
   bool sell_has_sl = false;
   double sell_tp = 0.0;
   double sell_sl = 0.0;

   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
         continue;

      if(!IsDrawableOrder(false))
         continue;

      int type = OrderType();
      double lots = OrderLots();
      if(lots <= 0.0)
         lots = 1.0;

      double order_pips = CalculateOrderPips(false);
      total_open_pips += order_pips;
      open_trade_count++;

      if(type == OP_BUY)
      {
         buy_count++;
         buy_lots += lots;
         buy_entry_weighted += (OrderOpenPrice() * lots);
         buy_pips += order_pips;

         if(buy_earliest == 0 || OrderOpenTime() < buy_earliest)
            buy_earliest = OrderOpenTime();

         if(OrderTakeProfit() > 0.0)
         {
            // BUY reward is above entry. Use the highest TP to show the full basket reward room.
            if(!buy_has_tp || OrderTakeProfit() > buy_tp)
               buy_tp = OrderTakeProfit();
            buy_has_tp = true;
         }

         if(OrderStopLoss() > 0.0)
         {
            // BUY risk is below entry. Use the lowest SL to show the full basket risk room.
            if(!buy_has_sl || OrderStopLoss() < buy_sl)
               buy_sl = OrderStopLoss();
            buy_has_sl = true;
         }
      }
      else if(type == OP_SELL)
      {
         sell_count++;
         sell_lots += lots;
         sell_entry_weighted += (OrderOpenPrice() * lots);
         sell_pips += order_pips;

         if(sell_earliest == 0 || OrderOpenTime() < sell_earliest)
            sell_earliest = OrderOpenTime();

         if(OrderTakeProfit() > 0.0)
         {
            // SELL reward is below entry. Use the lowest TP to show the full basket reward room.
            if(!sell_has_tp || OrderTakeProfit() < sell_tp)
               sell_tp = OrderTakeProfit();
            sell_has_tp = true;
         }

         if(OrderStopLoss() > 0.0)
         {
            // SELL risk is above entry. Use the highest SL to show the full basket risk room.
            if(!sell_has_sl || OrderStopLoss() > sell_sl)
               sell_sl = OrderStopLoss();
            sell_has_sl = true;
         }
      }

      if(ShowRunningPips && ShowIndividualOpenPipsLabels)
      {
         string base = Prefix + IntegerToString(OrderTicket()) + "_";
         DrawPipsLabel(base + "PIPS", OpenZoneEndTime(), order_pips, false, open_label_index);
         open_label_index++;
      }
   }

   if(buy_count > 0 && buy_lots > 0.0)
   {
      double buy_avg_entry = buy_entry_weighted / buy_lots;
      DrawBasketZones(OP_BUY, buy_count, buy_earliest, buy_avg_entry, buy_has_tp, buy_tp, buy_has_sl, buy_sl);

      if(ShowBasketPipsLabel)
         DrawBasketPipsLabel(OP_BUY, buy_count, buy_pips, buy_avg_entry, 0);
   }

   if(sell_count > 0 && sell_lots > 0.0)
   {
      double sell_avg_entry = sell_entry_weighted / sell_lots;
      DrawBasketZones(OP_SELL, sell_count, sell_earliest, sell_avg_entry, sell_has_tp, sell_tp, sell_has_sl, sell_sl);

      if(ShowBasketPipsLabel)
         DrawBasketPipsLabel(OP_SELL, sell_count, sell_pips, sell_avg_entry, 1);
   }
}

bool IsDrawableOrder(const bool is_history)
{
   int type = OrderType();

   if(type != OP_BUY && type != OP_SELL)
      return(false);

   if(OnlyCurrentSymbol && OrderSymbol() != Symbol())
      return(false);

   if(is_history && OrderCloseTime() <= 0)
      return(false);

   return(true);
}

void DrawOrderZones(const bool is_history, const int label_index)
{
   double entry = OrderOpenPrice();
   double tp    = OrderTakeProfit();
   double sl    = OrderStopLoss();

   datetime time1 = OrderOpenTime();
   datetime time2 = ZoneEndTime(is_history);

   string base = Prefix + IntegerToString(OrderTicket()) + "_";

   if(tp > 0.0)
      DrawZone(base + "TP", time1, time2, entry, tp, EntryToTpColor);

   if(sl > 0.0)
      DrawZone(base + "SL", time1, time2, entry, sl, EntryToSlColor);

   if((!is_history && ShowRunningPips) || (is_history && ShowClosedPips))
   {
      double pips = CalculateOrderPips(is_history);
      DrawPipsLabel(base + "PIPS", time2, pips, is_history, label_index);
   }
}

void DrawBasketZones(const int type,
                     const int trade_count,
                     const datetime earliest_open_time,
                     const double average_entry,
                     const bool has_tp,
                     const double basket_tp,
                     const bool has_sl,
                     const double basket_sl)
{
   if(trade_count <= 0 || average_entry <= 0.0 || earliest_open_time <= 0)
      return;

   datetime time1 = earliest_open_time;
   datetime time2 = OpenZoneEndTime();

   string side = (type == OP_BUY) ? "BUY" : "SELL";
   string base = Prefix + Symbol() + "_BASKET_" + side + "_";

   // Draw only valid reward/risk sides so TP/SL colors do not flip when a basket has unusual targets.
   if(has_tp && IsValidRewardTarget(type, average_entry, basket_tp))
      DrawZone(base + "TP", time1, time2, average_entry, basket_tp, EntryToTpColor);

   if(has_sl && IsValidRiskTarget(type, average_entry, basket_sl))
      DrawZone(base + "SL", time1, time2, average_entry, basket_sl, EntryToSlColor);
}

bool IsValidRewardTarget(const int type, const double entry, const double target)
{
   if(target <= 0.0 || entry <= 0.0)
      return(false);

   if(type == OP_BUY)
      return(target > entry);

   if(type == OP_SELL)
      return(target < entry);

   return(false);
}

bool IsValidRiskTarget(const int type, const double entry, const double target)
{
   if(target <= 0.0 || entry <= 0.0)
      return(false);

   if(type == OP_BUY)
      return(target < entry);

   if(type == OP_SELL)
      return(target > entry);

   return(false);
}

datetime ZoneEndTime(const bool is_history)
{
   if(is_history && OrderCloseTime() > 0)
      return(OrderCloseTime());

   return(OpenZoneEndTime());
}

datetime OpenZoneEndTime()
{
   int seconds_per_bar = PeriodSeconds(PERIOD_CURRENT);
   if(seconds_per_bar <= 0)
      seconds_per_bar = Period() * 60;

   return(TimeCurrent() + (ExtendOpenBars * seconds_per_bar));
}

datetime PipsLabelTime(const bool is_history)
{
   if(is_history && OrderCloseTime() > 0)
      return(OrderCloseTime());

   int seconds_per_bar = PeriodSeconds(PERIOD_CURRENT);
   if(seconds_per_bar <= 0)
      seconds_per_bar = Period() * 60;

   return(TimeCurrent() + (PipsLabelShiftBars * seconds_per_bar));
}

double PipSize(const string symbol)
{
   if(CustomPipSize > 0.0)
      return(CustomPipSize);

   double point = MarketInfo(symbol, MODE_POINT);
   int digits = (int)MarketInfo(symbol, MODE_DIGITS);

   if(point <= 0.0)
      point = Point;

   // Standard FX handling: 5-digit and 3-digit brokers quote fractional pips.
   if(digits == 5 || digits == 3)
      return(point * 10.0);

   // For indices, metals, crypto, and 2/4-digit symbols, use the broker point by default.
   return(point);
}

double CalculateOrderPips(const bool is_history)
{
   int type = OrderType();
   double entry = OrderOpenPrice();
   double exit_price = 0.0;

   if(is_history)
   {
      exit_price = OrderClosePrice();
   }
   else
   {
      if(type == OP_BUY)
         exit_price = MarketInfo(OrderSymbol(), MODE_BID);
      else if(type == OP_SELL)
         exit_price = MarketInfo(OrderSymbol(), MODE_ASK);
   }

   double pip = PipSize(OrderSymbol());
   if(pip <= 0.0)
      return(0.0);

   if(type == OP_BUY)
      return((exit_price - entry) / pip);

   if(type == OP_SELL)
      return((entry - exit_price) / pip);

   return(0.0);
}

string FormatSignedPips(const double pips)
{
   string sign = "";

   if(pips > 0.0)
      sign = "+";

   return(sign + DoubleToString(pips, PipsDecimals) + " pips");
}

color PipsColor(const double pips)
{
   double tiny = 0.0000001;

   if(pips > tiny)
      return(ProfitPipsColor);

   if(pips < -tiny)
      return(LossPipsColor);

   return(BreakevenPipsColor);
}

void DrawPipsLabel(const string name,
                   const datetime zone_end_time,
                   const double pips,
                   const bool is_history,
                   const int label_index)
{
   if(ObjectFind(0, name) >= 0)
      ObjectDelete(0, name);

   datetime label_time = PipsLabelTime(is_history);
   double pip = PipSize(OrderSymbol());

   double label_price = 0.0;
   if(is_history)
      label_price = OrderClosePrice();
   else if(OrderType() == OP_BUY)
      label_price = MarketInfo(OrderSymbol(), MODE_BID);
   else
      label_price = MarketInfo(OrderSymbol(), MODE_ASK);

   // Offset labels slightly so multiple open trades do not sit exactly on top of each other.
   if(pip > 0.0 && PipsLabelSpacingPips != 0.0)
      label_price += (label_index * PipsLabelSpacingPips * pip);

   if(!ObjectCreate(0, name, OBJ_TEXT, 0, label_time, label_price))
      return;

   string side = (OrderType() == OP_BUY) ? "BUY" : "SELL";
   string mode = is_history ? "Closed P/L" : "Running P/L";
   string text = side + " #" + IntegerToString(OrderTicket()) + " | " + mode + ": " + FormatSignedPips(pips);

   ObjectSetText(name, text, PipsLabelFontSize, PipsLabelFont, PipsColor(pips));
   ObjectSetInteger(0, name, OBJPROP_BACK, false);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_SELECTED, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
}

void DrawBasketPipsLabel(const int type,
                         const int trade_count,
                         const double basket_pips,
                         const double average_entry,
                         const int label_index)
{
   string side = (type == OP_BUY) ? "BUY" : "SELL";
   string name = Prefix + Symbol() + "_BASKET_" + side + "_PIPS";

   if(ObjectFind(0, name) >= 0)
      ObjectDelete(0, name);

   datetime label_time = PipsLabelTime(false);
   double pip = PipSize(Symbol());
   double label_price = average_entry;

   if(type == OP_BUY)
      label_price = MarketInfo(Symbol(), MODE_BID);
   else if(type == OP_SELL)
      label_price = MarketInfo(Symbol(), MODE_ASK);

   if(pip > 0.0 && PipsLabelSpacingPips != 0.0)
      label_price += (label_index * PipsLabelSpacingPips * pip);

   if(!ObjectCreate(0, name, OBJ_TEXT, 0, label_time, label_price))
      return;

   string text = side + " Basket | " + IntegerToString(trade_count) + " trades | Running P/L: " + FormatSignedPips(basket_pips);

   ObjectSetText(name, text, PipsLabelFontSize, PipsLabelFont, PipsColor(basket_pips));
   ObjectSetInteger(0, name, OBJPROP_BACK, false);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_SELECTED, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
}

void DrawTotalOpenPipsLabel(const double total_open_pips, const int open_trade_count)
{
   string name = Prefix + "TOTAL_OPEN_PIPS";

   if(ObjectFind(0, name) >= 0)
      ObjectDelete(0, name);

   if(!ObjectCreate(0, name, OBJ_LABEL, 0, 0, 0))
      return;

   string text = "Total Open P/L: " + FormatSignedPips(total_open_pips) + " (" + IntegerToString(open_trade_count) + " trades)";

   ObjectSetText(name, text, PipsLabelFontSize, PipsLabelFont, PipsColor(total_open_pips));
   ObjectSetInteger(0, name, OBJPROP_CORNER, TotalLabelCorner);
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE, TotalLabelX);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE, TotalLabelY);
   ObjectSetInteger(0, name, OBJPROP_BACK, false);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_SELECTED, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
}

void DrawZone(const string name,
              const datetime time1,
              const datetime time2,
              const double price_a,
              const double price_b,
              const color zone_color)
{
   double top    = MathMax(price_a, price_b);
   double bottom = MathMin(price_a, price_b);

   if(top == bottom)
      return;

   if(ObjectFind(0, name) >= 0)
      ObjectDelete(0, name);

   if(!ObjectCreate(0, name, OBJ_RECTANGLE, 0, time1, top, time2, bottom))
      return;

   // Reapply all visual settings every refresh so stale outline-only objects cannot survive.
   ObjectSetInteger(0, name, OBJPROP_COLOR, zone_color);
   ObjectSetInteger(0, name, OBJPROP_STYLE, STYLE_SOLID);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, BorderWidth);
   ObjectSetInteger(0, name, OBJPROP_BACK, DrawBehindCandles);
   ObjectSetInteger(0, name, OBJPROP_FILL, true);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_SELECTED, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
}

void DeleteObjectsByPrefix(const string prefix)
{
   for(int i = ObjectsTotal(0, 0, -1) - 1; i >= 0; i--)
   {
      string name = ObjectName(0, i, 0, -1);

      if(StringFind(name, prefix) == 0)
         ObjectDelete(0, name);
   }
}
