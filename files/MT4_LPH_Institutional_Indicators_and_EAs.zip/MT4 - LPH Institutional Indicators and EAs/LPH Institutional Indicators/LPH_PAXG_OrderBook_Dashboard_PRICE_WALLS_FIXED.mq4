#property strict
#property indicator_chart_window

input int RefreshSeconds = 5;
input int PanelX = 20;
input int PanelY = 20;
input int PanelWidth = 320;
input int PanelHeight = 250;
input string FontName = "Arial";
input int TitleSize = 12;
input int TextSize = 11;

input string Section_Price_Wall_Display = "----- PRICE WALL DISPLAY -----";
input bool Show_Wall_Price_Levels = true;       // Draw largest bid/ask walls on chart price levels
input int Wall_Line_Bars_Left = 35;             // How far left the wall line starts
input int Wall_Label_Bars_Right = 8;            // Label placement into right-side chart shift
input int Wall_Max_Line_Width = 4;              // Wall line gets thicker when wall volume is larger
input int Wall_Label_Font_Size = 9;
input bool Show_OffChart_Warning = true;        // Warn if PAXG/XAU levels are outside current chart scale
input bool Auto_Enable_Chart_Shift = true;      // Makes right-side price labels visible
input int Chart_Shift_Size_Percent = 25;

datetime lastReadTime = 0;

// Binance-like colors
color BG_COLOR       = C'18,22,28';
color BORDER_COLOR   = C'45,55,72';
color TITLE_COLOR    = clrWhite;
color LABEL_COLOR    = C'170,180,195';
color GREEN_COLOR    = C'14,203,129';
color RED_COLOR      = C'246,70,93';
color ACCENT_COLOR   = C'240,185,11';   // Binance yellow
color FOOTER_COLOR   = C'120,130,145';

string prefix = "PAXG_OB_";

//-----------------------------------
// Create or update text label
void SetLabel(string name, string text, int x, int y, color clr, int size, string font="Arial")
{
   string obj = prefix + name;

   if(ObjectFind(0, obj) < 0)
      ObjectCreate(0, obj, OBJ_LABEL, 0, 0, 0);

   ObjectSetInteger(0, obj, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, obj, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, obj, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, obj, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, obj, OBJPROP_FONTSIZE, size);
   ObjectSetString(0, obj, OBJPROP_FONT, font);
   ObjectSetString(0, obj, OBJPROP_TEXT, text);
}

//-----------------------------------
// Create or update panel background
void SetPanel()
{
   string obj = prefix + "BG";

   if(ObjectFind(0, obj) < 0)
      ObjectCreate(0, obj, OBJ_RECTANGLE_LABEL, 0, 0, 0);

   ObjectSetInteger(0, obj, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, obj, OBJPROP_XDISTANCE, PanelX);
   ObjectSetInteger(0, obj, OBJPROP_YDISTANCE, PanelY);
   ObjectSetInteger(0, obj, OBJPROP_XSIZE, PanelWidth);
   ObjectSetInteger(0, obj, OBJPROP_YSIZE, PanelHeight);
   ObjectSetInteger(0, obj, OBJPROP_BGCOLOR, BG_COLOR);
   ObjectSetInteger(0, obj, OBJPROP_BORDER_COLOR, BORDER_COLOR);
   ObjectSetInteger(0, obj, OBJPROP_STYLE, STYLE_SOLID);
   ObjectSetInteger(0, obj, OBJPROP_WIDTH, 1);
   ObjectSetInteger(0, obj, OBJPROP_BACK, false);
   ObjectSetInteger(0, obj, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, obj, OBJPROP_HIDDEN, true);
}

//-----------------------------------
void DrawDashboard(string bidVol, string askVol, string delta, string largestBid, string largestAsk, string bias)
{
   SetPanel();

   double dDelta = StrToDouble(delta);
   color deltaColor = (dDelta >= 0 ? GREEN_COLOR : RED_COLOR);
   string biasUpper = bias;
   StringToUpper(biasUpper);

   color biasColor = ACCENT_COLOR;
   if(StringFind(biasUpper, "BULL") >= 0) biasColor = GREEN_COLOR;
   if(StringFind(biasUpper, "BEAR") >= 0) biasColor = RED_COLOR;

   int x1 = PanelX + 12;
   int x2 = PanelX + 165;
   int y  = PanelY + 12;
   int gap = 24;

   // Title
   SetLabel("TITLE", "BINANCE PAXG ORDER BOOK", x1, y, TITLE_COLOR, TitleSize, "Arial Bold");
   y += gap;

   SetLabel("LINE1", "------------------------------", x1, y, BORDER_COLOR, TextSize, FontName);
   y += gap;

   // Bid Volume
   SetLabel("LBL_BID", "Bid Volume", x1, y, LABEL_COLOR, TextSize, FontName);
   SetLabel("VAL_BID", bidVol, x2, y, GREEN_COLOR, TextSize, "Arial Bold");
   y += gap;

   // Ask Volume
   SetLabel("LBL_ASK", "Ask Volume", x1, y, LABEL_COLOR, TextSize, FontName);
   SetLabel("VAL_ASK", askVol, x2, y, RED_COLOR, TextSize, "Arial Bold");
   y += gap;

   // Delta
   SetLabel("LBL_DELTA", "Delta", x1, y, LABEL_COLOR, TextSize, FontName);
   SetLabel("VAL_DELTA", delta, x2, y, deltaColor, TextSize, "Arial Bold");
   y += gap + 4;

   // Largest Bid
   SetLabel("LBL_LBID", "Largest Bid Wall", x1, y, LABEL_COLOR, TextSize, FontName);
   SetLabel("VAL_LBID", largestBid, x2, y, GREEN_COLOR, TextSize, "Arial Bold");
   y += gap;

   // Largest Ask
   SetLabel("LBL_LASK", "Largest Ask Wall", x1, y, LABEL_COLOR, TextSize, FontName);
   SetLabel("VAL_LASK", largestAsk, x2, y, RED_COLOR, TextSize, "Arial Bold");
   y += gap + 4;

   // Bias
   SetLabel("LBL_BIAS", "Liquidity Bias", x1, y, ACCENT_COLOR, TextSize, FontName);
   SetLabel("VAL_BIAS", bias, x2, y, biasColor, TextSize + 1, "Arial Bold");
   y += gap + 6;

   // Footer
   SetLabel("FOOT", "Last: " + TimeToString(TimeCurrent(), TIME_DATE|TIME_SECONDS) + " | Live | Top 50 levels", x1, y, FOOTER_COLOR, 9, FontName);
}

//-----------------------------------
string CleanText(string text)
{
   string t = text;
   t = StringTrimLeft(t);
   t = StringTrimRight(t);
   return(t);
}

//-----------------------------------
double ExtractWallPrice(string wallText)
{
   string t = wallText;
   int sep = StringFind(t, "/");
   if(sep >= 0)
      t = StringSubstr(t, 0, sep);

   return(StrToDouble(CleanText(t)));
}

//-----------------------------------
double ExtractWallVolume(string wallText)
{
   string t = wallText;
   int sep = StringFind(t, "/");
   if(sep < 0)
      return(0.0);

   t = StringSubstr(t, sep + 1);
   return(StrToDouble(CleanText(t)));
}

//-----------------------------------
int ChartStepSeconds()
{
   int sec = PeriodSeconds();
   if(sec <= 0) sec = Period() * 60;
   if(sec <= 0) sec = 60;
   return(sec);
}

//-----------------------------------
int ScaledWallWidth(double qty, double maxQty)
{
   if(maxQty <= 0.0 || qty <= 0.0)
      return(1);

   int width = 1 + (int)MathRound((qty / maxQty) * (Wall_Max_Line_Width - 1));
   if(width < 1) width = 1;
   if(width > Wall_Max_Line_Width) width = Wall_Max_Line_Width;

   return(width);
}

//-----------------------------------
bool PriceVisibleOnChart(double price)
{
   double minPrice = ChartGetDouble(0, CHART_PRICE_MIN, 0);
   double maxPrice = ChartGetDouble(0, CHART_PRICE_MAX, 0);

   if(minPrice == 0.0 && maxPrice == 0.0)
      return(true);

   return(price >= minPrice && price <= maxPrice);
}

//-----------------------------------
void SetWallLine(string side, double price, color clr, int width)
{
   string obj = prefix + "WALL_" + side + "_LINE";

   int barsBack = MathMin(Wall_Line_Bars_Left, Bars - 1);
   if(barsBack < 1) barsBack = 1;

   datetime t1 = iTime(NULL, 0, barsBack);
   datetime t2 = iTime(NULL, 0, 0) + ChartStepSeconds() * Wall_Label_Bars_Right;

   if(ObjectFind(0, obj) < 0)
      ObjectCreate(0, obj, OBJ_TREND, 0, t1, price, t2, price);

   ObjectMove(0, obj, 0, t1, price);
   ObjectMove(0, obj, 1, t2, price);
   ObjectSetInteger(0, obj, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, obj, OBJPROP_STYLE, STYLE_SOLID);
   ObjectSetInteger(0, obj, OBJPROP_WIDTH, width);
   ObjectSetInteger(0, obj, OBJPROP_RAY_RIGHT, false);
   ObjectSetInteger(0, obj, OBJPROP_BACK, false);
   ObjectSetInteger(0, obj, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, obj, OBJPROP_HIDDEN, true);
}

//-----------------------------------
void SetWallLabel(string side, double price, double qty, color clr)
{
   string obj = prefix + "WALL_" + side + "_LABEL";
   datetime labelTime = iTime(NULL, 0, 0) + ChartStepSeconds() * Wall_Label_Bars_Right;

   string sideText = (side == "BID" ? "BID WALL" : "ASK WALL");
   string text = StringConcatenate(sideText, "  ", DoubleToString(price, Digits), "  |  ", DoubleToString(qty, 2));

   if(ObjectFind(0, obj) < 0)
      ObjectCreate(0, obj, OBJ_TEXT, 0, labelTime, price);

   ObjectMove(0, obj, 0, labelTime, price);
   ObjectSetString(0, obj, OBJPROP_TEXT, text);
   ObjectSetString(0, obj, OBJPROP_FONT, "Arial Bold");
   ObjectSetInteger(0, obj, OBJPROP_FONTSIZE, Wall_Label_Font_Size);
   ObjectSetInteger(0, obj, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, obj, OBJPROP_ANCHOR, ANCHOR_LEFT);
   ObjectSetInteger(0, obj, OBJPROP_BACK, false);
   ObjectSetInteger(0, obj, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, obj, OBJPROP_HIDDEN, true);
}

//-----------------------------------
void DrawWallPriceLevels(string largestBid, string largestAsk)
{
   if(!Show_Wall_Price_Levels)
   {
      DeleteWallObjects();
      return;
   }

   double bidPrice = ExtractWallPrice(largestBid);
   double askPrice = ExtractWallPrice(largestAsk);
   double bidQty   = ExtractWallVolume(largestBid);
   double askQty   = ExtractWallVolume(largestAsk);

   double maxQty = MathMax(bidQty, askQty);

   if(bidPrice > 0.0)
   {
      SetWallLine("BID", bidPrice, GREEN_COLOR, ScaledWallWidth(bidQty, maxQty));
      SetWallLabel("BID", bidPrice, bidQty, GREEN_COLOR);
   }
   else
   {
      ObjectDelete(0, prefix + "WALL_BID_LINE");
      ObjectDelete(0, prefix + "WALL_BID_LABEL");
   }

   if(askPrice > 0.0)
   {
      SetWallLine("ASK", askPrice, RED_COLOR, ScaledWallWidth(askQty, maxQty));
      SetWallLabel("ASK", askPrice, askQty, RED_COLOR);
   }
   else
   {
      ObjectDelete(0, prefix + "WALL_ASK_LINE");
      ObjectDelete(0, prefix + "WALL_ASK_LABEL");
   }

   if(Show_OffChart_Warning)
   {
      bool bidVisible = (bidPrice <= 0.0 || PriceVisibleOnChart(bidPrice));
      bool askVisible = (askPrice <= 0.0 || PriceVisibleOnChart(askPrice));

      if(!bidVisible || !askVisible)
         SetLabel("SCALE_WARN", "Wall levels are outside this chart scale. Use XAU/PAXG-linked chart.",
                  PanelX + 12, PanelY + PanelHeight - 20, ACCENT_COLOR, 8, FontName);
      else
         ObjectDelete(0, prefix + "SCALE_WARN");
   }
}

//-----------------------------------
void DeleteWallObjects()
{
   ObjectDelete(0, prefix + "WALL_BID_LINE");
   ObjectDelete(0, prefix + "WALL_BID_LABEL");
   ObjectDelete(0, prefix + "WALL_ASK_LINE");
   ObjectDelete(0, prefix + "WALL_ASK_LABEL");
   ObjectDelete(0, prefix + "SCALE_WARN");
}

//-----------------------------------
void DrawError(string msg)
{
   DeleteWallObjects();
   SetPanel();
   SetLabel("TITLE", "BINANCE PAXG ORDER BOOK", PanelX + 12, PanelY + 12, TITLE_COLOR, TitleSize, "Arial Bold");
   SetLabel("ERR", msg, PanelX + 12, PanelY + 50, RED_COLOR, TextSize, "Arial Bold");
}

//-----------------------------------
void DeleteDashboard()
{
   string names[] =
   {
      "BG","TITLE","LINE1","LBL_BID","VAL_BID","LBL_ASK","VAL_ASK",
      "LBL_DELTA","VAL_DELTA","LBL_LBID","VAL_LBID","LBL_LASK","VAL_LASK",
      "LBL_BIAS","VAL_BIAS","FOOT","ERR","SCALE_WARN"
   };

   for(int i=0; i<ArraySize(names); i++)
      ObjectDelete(0, prefix + names[i]);

   DeleteWallObjects();
}

//-----------------------------------
int OnInit()
{
   if(Auto_Enable_Chart_Shift)
   {
      ChartSetInteger(0, CHART_SHIFT, true);
      ChartSetDouble(0, CHART_SHIFT_SIZE, Chart_Shift_Size_Percent);
   }

   SetPanel();
   return(INIT_SUCCEEDED);
}

//-----------------------------------
void OnDeinit(const int reason)
{
   DeleteDashboard();
}

//-----------------------------------
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
   if(TimeCurrent() - lastReadTime < RefreshSeconds)
      return(rates_total);

   lastReadTime = TimeCurrent();

   int handle = FileOpen("paxg_data.csv", FILE_READ | FILE_CSV | FILE_COMMON, ',');

   if(handle == INVALID_HANDLE)
   {
      DrawError("Cannot find paxg_data.csv");
      return(rates_total);
   }

   string bidVol     = FileReadString(handle);
   string askVol     = FileReadString(handle);
   string delta      = FileReadString(handle);
   string largestBid = FileReadString(handle);
   string largestAsk = FileReadString(handle);
   string bias       = FileReadString(handle);

   FileClose(handle);

   DrawDashboard(bidVol, askVol, delta, largestBid, largestAsk, bias);
   DrawWallPriceLevels(largestBid, largestAsk);

   return(rates_total);
}