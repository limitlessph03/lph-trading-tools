//+------------------------------------------------------------------+
//| LPH Institutional Derivatives Map - Phase 1                       |
//| MT4 display layer for COT, futures OI, and options OI walls.      |
//| MT4 does not scrape websites. It reads local JSON or a local API. |
//+------------------------------------------------------------------+
#property strict
#property indicator_chart_window

enum LPH_READ_MODE
{
   READ_LOCAL_FILE = 0,
   READ_LOCAL_API = 1
};

input LPH_READ_MODE ReadMode = READ_LOCAL_FILE;
input string SymbolOverride = "";
input string DataFolder = "LPH_Derivatives_Map";
input string SymbolMapFile = "LPH_Derivatives_Map\\symbol_map.csv";
input string ApiBaseUrl = "http://127.0.0.1:8787/derivatives";
input int RefreshIntervalSeconds = 60;
input int WebRequestTimeoutMs = 3000;
input double MaxLevelDistancePercent = 80.0;

input bool ShowCallWall = true;
input bool ShowPutWall = true;
input bool ShowMaxOI = true;
input bool ShowPinStrike = true;
input bool ShowPanel = true;
input bool ShowImportedOptionsLevels = true;
input bool ShowScrapedOptionsLevels = true;
input bool ShowNonRealOptionsLevels = false;

input color CallWallColor = clrLime;
input color PutWallColor = clrTomato;
input color MaxOIColor = clrDeepSkyBlue;
input color PinStrikeColor = clrGold;
input int LevelLineWidth = 2;
input int LevelLineStyle = STYLE_SOLID;

input int PanelCorner = CORNER_LEFT_UPPER;
input int PanelX = 10;
input int PanelY = 20;
input int PanelFontSize = 9;
input bool EnableDebugLog = false;

struct DerivativesData
{
   string symbol;
   string mapped_market;
   string last_updated;

   bool has_cot;
   string cot_source;
   string cot_report_date;
   string cot_bias;
   string cot_flow;
   double managed_money_net;
   double commercial_net;
   double primary_net_change;

   bool has_futures;
   string futures_source;
   string futures_contract;
   double futures_current_oi;
   double futures_previous_oi;
   string futures_trend;

   bool has_options;
   string options_status;
   string options_source;
   string options_data_date;
   string nearest_expiry;
   double call_wall;
   double put_wall;
   double max_oi_strike;
   double pin_strike;
};

string g_prefix = "";
string g_last_status = "";
string g_active_symbol = "";
bool g_has_data = false;
DerivativesData g_data;

int OnInit()
{
   g_prefix = "LPH_DM_" + CleanName(Symbol()) + "_" + IntegerToString(Period()) + "_";
   ResetData(g_data);
   int timer_seconds = RefreshIntervalSeconds < 5 ? 5 : RefreshIntervalSeconds;
   EventSetTimer(timer_seconds);
   RefreshData(true);
   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason)
{
   EventKillTimer();
   DeleteAllObjects();
}

void OnTimer()
{
   RefreshData(false);
}

int OnCalculate(
   const int rates_total,
   const int prev_calculated,
   const datetime &time[],
   const double &open[],
   const double &high[],
   const double &low[],
   const double &close[],
   const long &tick_volume[],
   const long &volume[],
   const int &spread[]
)
{
   return(rates_total);
}

void RefreshData(bool force)
{
   string requested_symbol = RequestedSymbol();
   string canonical_symbol = ResolveCanonicalSymbol(requested_symbol);
   g_active_symbol = canonical_symbol;

   string json = "";
   bool ok = false;
   if(ReadMode == READ_LOCAL_FILE)
      ok = ReadJsonFromFile(canonical_symbol, json);
   else
      ok = ReadJsonFromApi(canonical_symbol, json);

   if(!ok || StringLen(json) <= 0)
   {
      ResetData(g_data);
      g_data.symbol = requested_symbol;
      g_data.mapped_market = canonical_symbol;
      g_has_data = false;
      DeleteAllLevels();
      DrawPanel();
      ChartRedraw(0);
      return;
   }

   ResetData(g_data);
   if(!ParseDerivativeJson(json, g_data))
   {
      g_data.symbol = requested_symbol;
      g_data.mapped_market = canonical_symbol;
      g_has_data = false;
      DeleteAllLevels();
      DrawPanel();
      SetStatus("Could not parse derivatives JSON for " + canonical_symbol);
      ChartRedraw(0);
      return;
   }

   if(StringLen(g_data.symbol) <= 0)
      g_data.symbol = canonical_symbol;
   if(StringLen(g_data.mapped_market) <= 0)
      g_data.mapped_market = canonical_symbol;

   g_has_data = true;
   SetStatus("Loaded derivatives JSON for " + canonical_symbol);
   DrawAll();
   ChartRedraw(0);
}

string RequestedSymbol()
{
   if(StringLen(Trim(SymbolOverride)) > 0)
      return(Trim(SymbolOverride));
   return(Symbol());
}

bool ReadJsonFromFile(string canonical_symbol, string &json)
{
   string path = DataFolder + "\\" + canonical_symbol + ".json";
   bool ok = ReadTextFile(path, json);
   if(!ok)
      SetStatus("Data unavailable: missing " + path);
   return(ok);
}

bool ReadJsonFromApi(string canonical_symbol, string &json)
{
   string base = ApiBaseUrl;
   while(StringLen(base) > 0 && StringSubstr(base, StringLen(base) - 1, 1) == "/")
      base = StringSubstr(base, 0, StringLen(base) - 1);

   string url = base + "/" + canonical_symbol + ".json";
   char request[];
   char result[];
   string result_headers = "";
   ArrayResize(request, 0);
   ResetLastError();
   int response = WebRequest("GET", url, "", "", WebRequestTimeoutMs, request, 0, result, result_headers);
   if(response != 200)
   {
      SetStatus("Data unavailable: WebRequest " + IntegerToString(response) + " err " + IntegerToString(GetLastError()));
      return(false);
   }

   json = CharArrayToString(result, 0, -1, CP_UTF8);
   return(StringLen(json) > 0);
}

bool ReadTextFile(string path, string &text)
{
   int handle = FileOpen(path, FILE_READ | FILE_BIN);
   if(handle == INVALID_HANDLE)
      return(false);

   int bytes = (int)FileSize(handle);
   if(bytes <= 0)
   {
      FileClose(handle);
      text = "";
      return(false);
   }

   uchar data[];
   ArrayResize(data, bytes);
   int read = FileReadArray(handle, data, 0, bytes);
   FileClose(handle);

   if(read <= 0)
   {
      text = "";
      return(false);
   }

   text = CharArrayToString(data, 0, read, CP_UTF8);
   return(true);
}

string ResolveCanonicalSymbol(string requested_symbol)
{
   string target = NormalizeSymbolKey(requested_symbol);
   string canonical = "";

   if(TryResolveFromCsvMapFile(SymbolMapFile, target, canonical))
      return(canonical);

   string data_folder_csv = DataFolder + "\\symbol_map.csv";
   if(data_folder_csv != SymbolMapFile && TryResolveFromCsvMapFile(data_folder_csv, target, canonical))
      return(canonical);

   string data_folder_json = DataFolder + "\\symbol_map.json";
   if(TryResolveFromJsonMapFile(data_folder_json, target, canonical))
      return(canonical);

   if(TryResolveBuiltInAlias(target, canonical))
      return(canonical);

   return(requested_symbol);
}

bool TryResolveFromCsvMapFile(string path, string target, string &canonical)
{
   string map_text = "";
   if(!ReadTextFile(path, map_text))
      return(false);

   return(ResolveFromCsvMap(map_text, target, canonical));
}

bool ResolveFromCsvMap(string map_text, string target, string &canonical)
{
   ushort newline = 10;
   ushort comma = 44;
   string lines[];
   int line_count = StringSplit(map_text, newline, lines);

   for(int i = 0; i < line_count; i++)
   {
      string line = Trim(lines[i]);
      if(StringLen(line) <= 0)
         continue;
      if(StringSubstr(line, 0, 1) == "#")
         continue;
      if(StringFind(Upper(line), "ALIAS,CANONICAL") == 0)
         continue;

      string parts[];
      int part_count = StringSplit(line, comma, parts);
      if(part_count < 2)
         continue;

      string alias = NormalizeSymbolKey(parts[0]);
      string mapped_symbol = Trim(parts[1]);
      if(alias == target && StringLen(mapped_symbol) > 0)
      {
         canonical = mapped_symbol;
         return(true);
      }
   }

   return(false);
}

bool TryResolveFromJsonMapFile(string path, string target, string &canonical)
{
   string map_text = "";
   if(!ReadTextFile(path, map_text))
      return(false);

   string mapped_symbol = JsonString(map_text, target, "");
   if(StringLen(mapped_symbol) <= 0)
      return(false);

   canonical = mapped_symbol;
   return(true);
}

bool TryResolveBuiltInAlias(string target, string &canonical)
{
   if(target == "XAUUSD" || target == "XAUUSDZERO" || target == "GOLD")
   {
      canonical = "XAUUSD";
      return(true);
   }
   if(target == "XAGUSD" || target == "XAGUSDZERO" || target == "SILVER")
   {
      canonical = "XAGUSD";
      return(true);
   }
   if(target == "NAS100" || target == "NAS100.CASH" || target == "USTEC" || target == "USTEC.CASH")
   {
      canonical = "NAS100";
      return(true);
   }
   if(target == "US500" || target == "US500.CASH" || target == "SPX500" || target == "SP500")
   {
      canonical = "US500";
      return(true);
   }
   if(target == "USOIL" || target == "USOIL.CASH" || target == "WTI" || target == "CL")
   {
      canonical = "USOIL";
      return(true);
   }
   if(target == "EURUSD" || target == "EURUSDZERO")
   {
      canonical = "EURUSD";
      return(true);
   }
   if(target == "GBPUSD" || target == "GBPUSDZERO")
   {
      canonical = "GBPUSD";
      return(true);
   }
   if(target == "USDJPY" || target == "USDJPYZERO")
   {
      canonical = "USDJPY";
      return(true);
   }

   return(false);
}

string NormalizeSymbolKey(string value)
{
   return(Upper(Trim(value)));
}

bool ParseDerivativeJson(string json, DerivativesData &data)
{
   data.symbol = JsonString(json, "symbol", "");
   data.mapped_market = JsonString(json, "mapped_market", "");
   data.last_updated = JsonString(json, "last_updated", "");

   string cot = JsonObject(json, "cot");
   if(StringLen(cot) > 0)
   {
      data.cot_source = JsonString(cot, "source", "CFTC");
      data.cot_report_date = JsonString(cot, "report_date", "Unavailable");
      data.managed_money_net = JsonNumber(cot, "managed_money_net", 0.0);
      data.commercial_net = JsonNumber(cot, "commercial_net", 0.0);
      data.primary_net_change = JsonNumber(cot, "primary_net_change", 0.0);
      data.cot_flow = JsonString(cot, "flow", "");
      data.cot_bias = JsonString(cot, "bias", "Data unavailable");
      data.has_cot = data.cot_bias != "Data unavailable" || data.cot_report_date != "Unavailable";
   }

   string futures = JsonObject(json, "futures_oi");
   if(StringLen(futures) > 0)
   {
      data.futures_source = JsonString(futures, "source", "CME");
      data.futures_contract = JsonString(futures, "contract", "");
      data.futures_current_oi = JsonNumber(futures, "current_oi", 0.0);
      data.futures_previous_oi = JsonNumber(futures, "previous_oi", 0.0);
      data.futures_trend = JsonString(futures, "trend", "Data unavailable");
      data.has_futures = data.futures_trend != "Data unavailable" || data.futures_current_oi > 0.0 || data.futures_previous_oi > 0.0;
   }

   string options = JsonObject(json, "options_oi");
   if(StringLen(options) > 0)
   {
      data.options_status = JsonString(options, "status", "mock");
      data.options_source = JsonString(options, "source", "Options OI");
      data.options_data_date = JsonString(options, "data_date", "");
      data.nearest_expiry = JsonString(options, "nearest_expiry", "Unavailable");
      data.call_wall = JsonNumber(options, "call_wall", 0.0);
      data.put_wall = JsonNumber(options, "put_wall", 0.0);
      data.max_oi_strike = JsonNumber(options, "max_oi_strike", 0.0);
      data.pin_strike = JsonNumber(options, "pin_strike", 0.0);
      data.has_options = data.call_wall > 0.0 || data.put_wall > 0.0 || data.max_oi_strike > 0.0 || data.pin_strike > 0.0 || (StringLen(data.nearest_expiry) > 0 && data.nearest_expiry != "Unavailable");
   }

   return(StringLen(data.symbol) > 0 || StringLen(data.mapped_market) > 0 || data.has_options || data.has_cot || data.has_futures);
}

void DrawAll()
{
   if(g_has_data && OptionsLevelsAllowed())
   {
      DrawLevel("CALL_WALL", "CALL WALL", g_data.call_wall, ShowCallWall, CallWallColor);
      DrawLevel("PUT_WALL", "PUT WALL", g_data.put_wall, ShowPutWall, PutWallColor);
      DrawLevel("MAX_OI", "MAX OI", g_data.max_oi_strike, ShowMaxOI, MaxOIColor);
      DrawLevel("PIN_STRIKE", "PIN STRIKE", g_data.pin_strike, ShowPinStrike, PinStrikeColor);
   }
   else
   {
      DeleteAllLevels();
   }

   DrawPanel();
}

bool OptionsLevelsAllowed()
{
   if(!g_data.has_options)
      return(false);

   string status = Upper(g_data.options_status);
   if(status == "REAL")
      return(true);
   if(status == "IMPORTED" && ShowImportedOptionsLevels)
      return(ImportedLevelsAllowed());
   if(status == "SCRAPED" && ShowScrapedOptionsLevels)
      return(true);
   if(status == "STALE" && ShowNonRealOptionsLevels)
      return(true);
   return(false);
}

bool ImportedLevelsAllowed()
{
   if(StringLen(g_data.nearest_expiry) <= 0 || g_data.nearest_expiry == "Unavailable")
      return(false);
   if(g_data.call_wall <= 0.0 || g_data.put_wall <= 0.0)
      return(false);
   if(!IsValidLevel(g_data.call_wall) || !IsValidLevel(g_data.put_wall))
      return(false);
   if(g_data.max_oi_strike > 0.0 && !IsValidLevel(g_data.max_oi_strike))
      return(false);
   if(g_data.pin_strike > 0.0 && !IsValidLevel(g_data.pin_strike))
      return(false);
   return(true);
}

void DrawLevel(string id, string label, double price, bool enabled, color line_color)
{
   string line_name = g_prefix + id + "_LINE";
   string label_name = g_prefix + id + "_LABEL";

   if(!enabled || !IsValidLevel(price))
   {
      ObjectDelete(0, line_name);
      ObjectDelete(0, label_name);
      return;
   }

   if(ObjectFind(0, line_name) < 0)
      ObjectCreate(0, line_name, OBJ_HLINE, 0, 0, price);

   ObjectSetDouble(0, line_name, OBJPROP_PRICE1, price);
   ObjectSetInteger(0, line_name, OBJPROP_COLOR, line_color);
   ObjectSetInteger(0, line_name, OBJPROP_STYLE, LevelLineStyle);
   int line_width = LevelLineWidth < 1 ? 1 : LevelLineWidth;
   ObjectSetInteger(0, line_name, OBJPROP_WIDTH, line_width);
   ObjectSetInteger(0, line_name, OBJPROP_BACK, false);
   ObjectSetInteger(0, line_name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, line_name, OBJPROP_HIDDEN, true);

   datetime label_time = iTime(Symbol(), Period(), 0);
   if(label_time <= 0)
      label_time = TimeCurrent();
   label_time += Period() * 60 * 4;

   if(ObjectFind(0, label_name) < 0)
      ObjectCreate(0, label_name, OBJ_TEXT, 0, label_time, price);
   else
      ObjectMove(0, label_name, 0, label_time, price);

   ObjectSetText(label_name, label + " " + FormatLevel(price), 8, "Arial", line_color);
   ObjectSetInteger(0, label_name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, label_name, OBJPROP_HIDDEN, true);
}

bool IsValidLevel(double price)
{
   if(price <= 0.0)
      return(false);

   double current = Bid;
   if(current <= 0.0)
      current = iClose(Symbol(), Period(), 0);
   if(current <= 0.0)
      return(false);

   if(MaxLevelDistancePercent > 0.0)
   {
      double distance_percent = MathAbs(price - current) / current * 100.0;
      if(distance_percent > MaxLevelDistancePercent)
         return(false);
   }

   return(true);
}

void DrawPanel()
{
   if(!ShowPanel)
   {
      DeletePanelObjects();
      return;
   }

   string rows[16];
   int count = 0;
   rows[count++] = "LPH Institutional Derivatives Map";

   if(!g_has_data)
   {
      rows[count++] = "Symbol: " + RequestedSymbol();
      rows[count++] = "Source: " + g_active_symbol;
      rows[count++] = "Status: Data unavailable";
      rows[count++] = "Last updated: -";
   }
   else
   {
      rows[count++] = "Symbol: " + g_data.symbol;
      rows[count++] = "Source: " + g_data.mapped_market;
      rows[count++] = "COT bias: " + (g_data.has_cot ? g_data.cot_bias : "Data unavailable");
      rows[count++] = "COT flow: " + (g_data.has_cot ? FormatCotFlow(g_data.cot_flow, g_data.primary_net_change) : "Data unavailable");
      rows[count++] = "Futures OI: " + (g_data.has_futures ? g_data.futures_trend : "Data unavailable");
      rows[count++] = "Options OI: " + (StringLen(g_data.options_status) > 0 ? g_data.options_status : "unavailable");
      rows[count++] = "Options Source: " + (StringLen(g_data.options_source) > 0 ? g_data.options_source : "Data unavailable");
      rows[count++] = "Options Date: " + (StringLen(g_data.options_data_date) > 0 ? g_data.options_data_date : "Data unavailable");
      rows[count++] = "Call Wall: " + (OptionsLevelsAllowed() ? FormatLevel(g_data.call_wall) : "Data unavailable");
      rows[count++] = "Put Wall: " + (OptionsLevelsAllowed() ? FormatLevel(g_data.put_wall) : "Data unavailable");
      rows[count++] = "Max OI: " + (OptionsLevelsAllowed() ? FormatLevel(g_data.max_oi_strike) : "Data unavailable");
      rows[count++] = "Nearest Expiry: " + (OptionsLevelsAllowed() ? g_data.nearest_expiry : "Data unavailable");
      rows[count++] = "Last updated: " + (StringLen(g_data.last_updated) > 0 ? g_data.last_updated : "-");
   }

   int line_height = PanelFontSize + 5;
   int panel_width = 310;
   int panel_height = 12 + count * line_height;
   string bg = g_prefix + "PANEL_BG";

   if(ObjectFind(0, bg) < 0)
      ObjectCreate(0, bg, OBJ_RECTANGLE_LABEL, 0, 0, 0);

   ObjectSetInteger(0, bg, OBJPROP_CORNER, PanelCorner);
   ObjectSetInteger(0, bg, OBJPROP_XDISTANCE, PanelX);
   ObjectSetInteger(0, bg, OBJPROP_YDISTANCE, PanelY);
   ObjectSetInteger(0, bg, OBJPROP_XSIZE, panel_width);
   ObjectSetInteger(0, bg, OBJPROP_YSIZE, panel_height);
   ObjectSetInteger(0, bg, OBJPROP_BGCOLOR, clrBlack);
   ObjectSetInteger(0, bg, OBJPROP_COLOR, clrDimGray);
   ObjectSetInteger(0, bg, OBJPROP_BACK, false);
   ObjectSetInteger(0, bg, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, bg, OBJPROP_HIDDEN, true);

   for(int i = 0; i < count; i++)
   {
      string name = g_prefix + "PANEL_LINE_" + IntegerToString(i);
      if(ObjectFind(0, name) < 0)
         ObjectCreate(0, name, OBJ_LABEL, 0, 0, 0);

      ObjectSetInteger(0, name, OBJPROP_CORNER, PanelCorner);
      ObjectSetInteger(0, name, OBJPROP_XDISTANCE, PanelX + 8);
      ObjectSetInteger(0, name, OBJPROP_YDISTANCE, PanelY + 6 + i * line_height);
      ObjectSetInteger(0, name, OBJPROP_COLOR, i == 0 ? clrGold : clrWhite);
      ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
      ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
      ObjectSetText(name, rows[i], PanelFontSize, "Arial", i == 0 ? clrGold : clrWhite);
   }

   for(int j = count; j < 20; j++)
      ObjectDelete(0, g_prefix + "PANEL_LINE_" + IntegerToString(j));
}

void DeleteAllLevels()
{
   DeleteLevelObjects("CALL_WALL");
   DeleteLevelObjects("PUT_WALL");
   DeleteLevelObjects("MAX_OI");
   DeleteLevelObjects("PIN_STRIKE");
}

void DeleteLevelObjects(string id)
{
   ObjectDelete(0, g_prefix + id + "_LINE");
   ObjectDelete(0, g_prefix + id + "_LABEL");
}

void DeletePanelObjects()
{
   ObjectDelete(0, g_prefix + "PANEL_BG");
   for(int i = 0; i < 20; i++)
      ObjectDelete(0, g_prefix + "PANEL_LINE_" + IntegerToString(i));
}

void DeleteAllObjects()
{
   int total = ObjectsTotal(0, -1, -1);
   for(int i = total - 1; i >= 0; i--)
   {
      string name = ObjectName(0, i, -1, -1);
      if(StringFind(name, g_prefix) == 0)
         ObjectDelete(0, name);
   }
}

void ResetData(DerivativesData &data)
{
   data.symbol = "";
   data.mapped_market = "";
   data.last_updated = "";

   data.has_cot = false;
   data.cot_source = "";
   data.cot_report_date = "";
   data.cot_bias = "";
   data.cot_flow = "";
   data.managed_money_net = 0.0;
   data.commercial_net = 0.0;
   data.primary_net_change = 0.0;

   data.has_futures = false;
   data.futures_source = "";
   data.futures_contract = "";
   data.futures_current_oi = 0.0;
   data.futures_previous_oi = 0.0;
   data.futures_trend = "";

   data.has_options = false;
   data.options_status = "unavailable";
   data.options_source = "";
   data.options_data_date = "";
   data.nearest_expiry = "";
   data.call_wall = 0.0;
   data.put_wall = 0.0;
   data.max_oi_strike = 0.0;
   data.pin_strike = 0.0;
}

void SetStatus(string status)
{
   if(status == g_last_status)
      return;

   g_last_status = status;
   if(EnableDebugLog)
      Print("LPH Derivatives Map: ", status);
}

string JsonObject(string json, string key)
{
   int key_pos = FindJsonKey(json, key);
   if(key_pos < 0)
      return("");

   int colon = StringFind(json, ":", key_pos);
   if(colon < 0)
      return("");

   int start = SkipSpaces(json, colon + 1);
   if(start >= StringLen(json) || StringGetCharacter(json, start) != 123)
      return("");

   int depth = 0;
   bool in_string = false;
   bool escaped = false;
   int len = StringLen(json);

   for(int i = start; i < len; i++)
   {
      ushort c = StringGetCharacter(json, i);
      if(in_string)
      {
         if(escaped)
            escaped = false;
         else if(c == 92)
            escaped = true;
         else if(c == 34)
            in_string = false;
         continue;
      }

      if(c == 34)
         in_string = true;
      else if(c == 123)
         depth++;
      else if(c == 125)
      {
         depth--;
         if(depth == 0)
            return(StringSubstr(json, start, i - start + 1));
      }
   }

   return("");
}

string JsonString(string json, string key, string fallback)
{
   int key_pos = FindJsonKey(json, key);
   if(key_pos < 0)
      return(fallback);

   int colon = StringFind(json, ":", key_pos);
   if(colon < 0)
      return(fallback);

   int start = SkipSpaces(json, colon + 1);
   int len = StringLen(json);
   if(start >= len || StringGetCharacter(json, start) != 34)
      return(fallback);

   string value = "";
   bool escaped = false;
   for(int i = start + 1; i < len; i++)
   {
      ushort c = StringGetCharacter(json, i);
      if(escaped)
      {
         value += CharToString((uchar)c);
         escaped = false;
      }
      else if(c == 92)
      {
         escaped = true;
      }
      else if(c == 34)
      {
         return(value);
      }
      else
      {
         value += CharToString((uchar)c);
      }
   }

   return(fallback);
}

double JsonNumber(string json, string key, double fallback)
{
   int key_pos = FindJsonKey(json, key);
   if(key_pos < 0)
      return(fallback);

   int colon = StringFind(json, ":", key_pos);
   if(colon < 0)
      return(fallback);

   int start = SkipSpaces(json, colon + 1);
   int len = StringLen(json);
   string token = "";

   for(int i = start; i < len; i++)
   {
      ushort c = StringGetCharacter(json, i);
      if(IsNumberChar(c))
         token += CharToString((uchar)c);
      else
         break;
   }

   if(StringLen(token) <= 0)
      return(fallback);
   return(StringToDouble(token));
}

int FindJsonKey(string json, string key)
{
   return(StringFind(json, "\"" + key + "\""));
}

int SkipSpaces(string text, int pos)
{
   int len = StringLen(text);
   while(pos < len && IsWhitespace(StringGetCharacter(text, pos)))
      pos++;
   return(pos);
}

bool IsWhitespace(ushort c)
{
   return(c == 32 || c == 9 || c == 10 || c == 13);
}

bool IsNumberChar(ushort c)
{
   return((c >= 48 && c <= 57) || c == 45 || c == 43 || c == 46);
}

string Trim(string text)
{
   int len = StringLen(text);
   int start = 0;
   int end = len - 1;

   while(start < len && IsWhitespace(StringGetCharacter(text, start)))
      start++;
   while(end >= start && IsWhitespace(StringGetCharacter(text, end)))
      end--;

   if(end < start)
      return("");
   return(StringSubstr(text, start, end - start + 1));
}

string Upper(string text)
{
   string out = text;
   int len = StringLen(out);
   for(int i = 0; i < len; i++)
   {
      ushort c = StringGetCharacter(out, i);
      if(c >= 97 && c <= 122)
         StringSetCharacter(out, i, c - 32);
   }
   return(out);
}

string CleanName(string text)
{
   string out = "";
   int len = StringLen(text);
   for(int i = 0; i < len; i++)
   {
      ushort c = StringGetCharacter(text, i);
      bool ok = (c >= 48 && c <= 57) || (c >= 65 && c <= 90) || (c >= 97 && c <= 122);
      out += ok ? CharToString((uchar)c) : "_";
   }
   return(out);
}

string FormatLevel(double value)
{
   if(value <= 0.0)
      return("-");
   if(value >= 1000.0)
      return(DoubleToString(value, 0));
   if(value >= 10.0)
      return(DoubleToString(value, 2));
   return(DoubleToString(value, 5));
}

string FormatCotFlow(string flow, double net_change)
{
   string label = StringLen(flow) > 0 ? flow : "Net change";
   string sign = net_change > 0.0 ? "+" : "";
   return(label + " (" + sign + DoubleToString(net_change, 0) + ")");
}
