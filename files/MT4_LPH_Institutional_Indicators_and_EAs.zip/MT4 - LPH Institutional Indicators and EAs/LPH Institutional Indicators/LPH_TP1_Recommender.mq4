//+------------------------------------------------------------------+
//|                                          LPH_TP1_Recommender.mq4 |
//|  LimitlessPH — TP1 recommendation for DISCRETIONARY orders only. |
//|  Structure-first, ATR-bounded:                                    |
//|    TP1 = nearest opposing structure level within                  |
//|          [MinDistATR x ATR, MaxDistATR x ATR] of entry side;      |
//|    fallback = FallbackATR x ATR when no structure qualifies.      |
//|                                                                   |
//|  Display-only. No Alert(), SendNotification(), SendMail(),        |
//|  OrderSend(), or any trading calls.                               |
//+------------------------------------------------------------------+
#property strict
#property indicator_chart_window

//--- General
input string InpSectionGeneral    = "===== General =====";
input bool   InpShowLongTP1       = true;
input bool   InpShowShortTP1      = true;
input bool   InpUpdateOnNewBarOnly= true;  // true: lines fixed within the bar; false: live tick tracking
input int    InpRefreshSeconds    = 15;    // only used when InpUpdateOnNewBarOnly = false
input int    InpLabelFontSize     = 8;
input int    InpLabelOffsetBars   = 4;

//--- ATR engine
input string InpSectionATR        = "===== ATR =====";
input ENUM_TIMEFRAMES InpATRTF    = PERIOD_H1;
input int    InpATRPeriod         = 14;
input double InpMinDistATR        = 0.40;  // structure must be at least this x ATR away
input double InpMaxDistATR        = 1.50;  // structure must be at most this x ATR away
input double InpFallbackATR       = 1.00;  // pure-ATR TP1 when no structure qualifies

//--- Structure sources
input string InpSectionSources    = "===== Structure Sources =====";
input bool   InpUsePrevDayHL      = true;
input bool   InpUsePivotR1S1      = true;
input bool   InpUseSwingHL        = true;
input int    InpSwingLookbackBars = 48;    // chart-TF bars, excludes current bar
input bool   InpUseDailyVWAP      = true;
input ENUM_TIMEFRAMES InpVWAPCalcTF = PERIOD_M5;
input int    InpVWAPMaxBars       = 400;

//--- Colors
input string InpSectionColors     = "===== Colors =====";
input color  InpLongTPColor       = C'70,140,90';
input color  InpShortTPColor      = C'150,60,60';
input color  InpLabelColor        = C'155,155,155';

#define PREFIX "LPH_TP1_"
#define MAX_CANDIDATES 8

datetime g_lastBarTime  = 0;
datetime g_lastDrawTime = 0;

//+------------------------------------------------------------------+
int OnInit()
{
   IndicatorShortName("LPH TP1 Recommender");
   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   DeleteObjectsByPrefix(PREFIX);
}

//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
   if(rates_total < 10)
      return(rates_total);

   datetime now = TimeCurrent();
   bool newBar = (time[0] != g_lastBarTime);
   bool refreshDue = (!InpUpdateOnNewBarOnly && now - g_lastDrawTime >= InpRefreshSeconds);

   if(newBar || refreshDue || prev_calculated == 0)
   {
      g_lastBarTime = time[0];
      g_lastDrawTime = now;
      Redraw();
   }

   return(rates_total);
}

//+------------------------------------------------------------------+
void Redraw()
{
   DeleteObjectsByPrefix(PREFIX);

   double atr = CurrentATR();
   if(atr <= 0.0)
      return;   // no ATR -> no recommendation; never draw on bad data

   if(InpShowLongTP1)
      DrawTP1(true, atr);
   if(InpShowShortTP1)
      DrawTP1(false, atr);
}

//+------------------------------------------------------------------+
double CurrentATR()
{
   double atr = iATR(Symbol(), InpATRTF, InpATRPeriod, 1);
   if(atr <= 0.0)
      atr = iATR(Symbol(), InpATRTF, InpATRPeriod, 0);
   return(atr);
}

//+------------------------------------------------------------------+
void DrawTP1(const bool isLong, const double atr)
{
   // Anchored mode: measure from the bar's open so the recommendation is a
   // stable per-bar reference. Live mode: measure from current Ask/Bid.
   double basePrice;
   if(InpUpdateOnNewBarOnly)
      basePrice = Open[0];
   else
      basePrice = (isLong ? Ask : Bid);
   if(basePrice <= 0.0)
      basePrice = Close[0];

   double levels[MAX_CANDIDATES];
   string names[MAX_CANDIDATES];
   int    count = 0;

   CollectCandidates(isLong, levels, names, count);

   double minDist = InpMinDistATR * atr;
   double maxDist = InpMaxDistATR * atr;

   double bestLevel = 0.0;
   string bestName  = "";
   double bestDist  = 999999999.0;

   for(int i = 0; i < count; i++)
   {
      double dist = (isLong ? levels[i] - basePrice : basePrice - levels[i]);
      if(dist < minDist || dist > maxDist)
         continue;
      if(dist < bestDist)
      {
         bestDist  = dist;
         bestLevel = levels[i];
         bestName  = names[i];
      }
   }

   bool usedFallback = false;
   if(bestLevel <= 0.0)
   {
      bestLevel = (isLong ? basePrice + InpFallbackATR * atr
                          : basePrice - InpFallbackATR * atr);
      bestName  = "ATR x " + DoubleToString(InpFallbackATR, 2);
      bestDist  = InpFallbackATR * atr;
      usedFallback = true;
   }

   string tag  = (isLong ? "LONG" : "SHORT");
   color  clr  = (isLong ? InpLongTPColor : InpShortTPColor);
   double pips = bestDist / PipSize();

   string label = "TP1 " + tag + "  [" + bestName + "]  " +
                  DoubleToString(pips, 1) + " pips" +
                  (usedFallback ? "  (fallback)" : "");

   string name = PREFIX + tag;
   DrawHLine(name, bestLevel, clr, (usedFallback ? STYLE_DOT : STYLE_DASH),
             label + " " + DoubleToString(bestLevel, Digits));
   DrawText(name + "_LABEL", label, bestLevel, clr);
}

//+------------------------------------------------------------------+
void CollectCandidates(const bool isLong,
                       double &levels[],
                       string &names[],
                       int &count)
{
   count = 0;

   if(InpUsePrevDayHL)
   {
      double pdh = iHigh(Symbol(), PERIOD_D1, 1);
      double pdl = iLow(Symbol(), PERIOD_D1, 1);
      if(isLong && pdh > 0.0)
         AddCandidate(levels, names, count, pdh, "PrevDay High");
      if(!isLong && pdl > 0.0)
         AddCandidate(levels, names, count, pdl, "PrevDay Low");
   }

   if(InpUsePivotR1S1)
   {
      double h = iHigh(Symbol(), PERIOD_D1, 1);
      double l = iLow(Symbol(), PERIOD_D1, 1);
      double c = iClose(Symbol(), PERIOD_D1, 1);
      if(h > 0.0 && l > 0.0 && c > 0.0)
      {
         double p  = (h + l + c) / 3.0;
         double r1 = 2.0 * p - l;
         double s1 = 2.0 * p - h;
         if(isLong)
            AddCandidate(levels, names, count, r1, "Pivot R1");
         else
            AddCandidate(levels, names, count, s1, "Pivot S1");
      }
   }

   if(InpUseSwingHL)
   {
      int lookback = MathMax(5, InpSwingLookbackBars);
      int barsAvail = iBars(Symbol(), Period());
      if(barsAvail > lookback + 1)
      {
         if(isLong)
         {
            int hi = iHighest(Symbol(), Period(), MODE_HIGH, lookback, 1);
            if(hi >= 1)
               AddCandidate(levels, names, count,
                            iHigh(Symbol(), Period(), hi), "Swing High");
         }
         else
         {
            int lo = iLowest(Symbol(), Period(), MODE_LOW, lookback, 1);
            if(lo >= 1)
               AddCandidate(levels, names, count,
                            iLow(Symbol(), Period(), lo), "Swing Low");
         }
      }
   }

   if(InpUseDailyVWAP)
   {
      double vwap = DailyVWAPLevel();
      if(vwap > 0.0)
         AddCandidate(levels, names, count, vwap, "Daily VWAP");
   }
}

//+------------------------------------------------------------------+
void AddCandidate(double &levels[], string &names[], int &count,
                  const double level, const string name)
{
   if(count >= MAX_CANDIDATES)
      return;
   if(level <= 0.0)
      return;
   levels[count] = level;
   names[count]  = name;
   count++;
}

//+------------------------------------------------------------------+
double DailyVWAPLevel()
{
   datetime dayStart = StrToTime(TimeToString(TimeCurrent(), TIME_DATE));

   int bars = iBars(Symbol(), InpVWAPCalcTF);
   if(bars <= 1)
      return(0.0);

   int scanBars = MathMin(bars - 1, MathMax(10, InpVWAPMaxBars));
   double sumPV = 0.0;
   double sumV  = 0.0;
   int found = 0;

   for(int i = 0; i <= scanBars; i++)
   {
      datetime barTime = iTime(Symbol(), InpVWAPCalcTF, i);
      if(barTime <= 0)
         continue;
      if(barTime < dayStart)
         break;

      double h = iHigh(Symbol(), InpVWAPCalcTF, i);
      double l = iLow(Symbol(), InpVWAPCalcTF, i);
      double c = iClose(Symbol(), InpVWAPCalcTF, i);
      if(h <= 0.0 || l <= 0.0 || c <= 0.0)
         continue;

      double typical = (h + l + c) / 3.0;
      double vol = MathMax(1.0, (double)iVolume(Symbol(), InpVWAPCalcTF, i));

      sumPV += typical * vol;
      sumV  += vol;
      found++;
   }

   // Honest gate: require a real sample, never widen the window.
   if(found < 12 || sumV <= 0.0)
      return(0.0);

   return(sumPV / sumV);
}

//+------------------------------------------------------------------+
double PipSize()
{
   if(Digits == 3 || Digits == 5)
      return(10.0 * Point);
   return(Point);
}

//+------------------------------------------------------------------+
void DrawHLine(const string name, const double price, const color clr,
               const int style, const string tooltip)
{
   ObjectCreate(0, name, OBJ_HLINE, 0, 0, price);
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_STYLE, style);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, 1);
   ObjectSetInteger(0, name, OBJPROP_BACK, true);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
   ObjectSetString(0, name, OBJPROP_TOOLTIP, tooltip);
}

//+------------------------------------------------------------------+
void DrawText(const string name, const string text,
              const double price, const color clr)
{
   int offsetBars = MathMax(0, InpLabelOffsetBars);
   datetime t = Time[0] + offsetBars * PeriodSeconds();

   ObjectCreate(0, name, OBJ_TEXT, 0, t, price);
   ObjectSetString(0, name, OBJPROP_TEXT, text);
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, InpLabelFontSize);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
   ObjectSetInteger(0, name, OBJPROP_ANCHOR, ANCHOR_LEFT);
}

//+------------------------------------------------------------------+
void DeleteObjectsByPrefix(const string prefix)
{
   for(int i = ObjectsTotal(0, 0, -1) - 1; i >= 0; i--)
   {
      string name = ObjectName(0, i, 0, -1);
      if(StringFind(name, prefix) == 0)
         ObjectDelete(0, name);
   }
}
//+------------------------------------------------------------------+
