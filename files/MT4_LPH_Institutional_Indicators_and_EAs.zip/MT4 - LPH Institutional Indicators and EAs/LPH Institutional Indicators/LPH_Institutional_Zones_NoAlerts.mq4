//+------------------------------------------------------------------+
//|                              LPH_Institutional_Zones_NoAlerts.mq4 |
//|  Drawing-only institutional zones for MT4.                        |
//|                                                                  |
//|  No Alert(), SendNotification(), SendMail(), OrderSend(), or      |
//|  trading logic is used. This indicator only draws chart objects   |
//|  and optional VWAP buffers.                                       |
//+------------------------------------------------------------------+
#property strict
#property indicator_chart_window
#property indicator_buffers 4
#property indicator_plots   4

#property indicator_label1  "Session VWAP"
#property indicator_type1   DRAW_LINE
#property indicator_color1  clrDodgerBlue
#property indicator_width1  2

#property indicator_label2  "VWAP Upper"
#property indicator_type2   DRAW_LINE
#property indicator_color2  clrSlateGray
#property indicator_style2  STYLE_DOT

#property indicator_label3  "VWAP Lower"
#property indicator_type3   DRAW_LINE
#property indicator_color3  clrSlateGray
#property indicator_style3  STYLE_DOT

#property indicator_label4  "EMA 50"
#property indicator_type4   DRAW_LINE
#property indicator_color4  clrDarkGray
#property indicator_width4  1

input string InpSectionGeneral       = "===== General / Performance =====";
input bool   InpDrawVolumeProfiles   = true;
input bool   InpDrawSupportResistance= true;
input bool   InpDrawVWAP             = true;
input bool   InpDrawEMA50            = true;
input int    InpRefreshSeconds       = 10;
input int    InpProjectionBars       = 80;
input int    InpMaxBarsToScan        = 2500;
input int    InpLineLabelOffsetBars  = 6;
input int    InpLineLabelFontSize    = 7;

input string InpSectionProfiles      = "===== Volume Profile Zones =====";
input bool   InpDrawDailyProfile     = true;
input bool   InpDrawWeeklyProfile    = true;
input bool   InpDrawMonthlyProfile   = true;
input int    InpDailyFallbackBars    = 96;
input int    InpWeeklyFallbackBars   = 480;
input int    InpMonthlyFallbackBars  = 1500;
input int    InpProfileBins          = 36;
input int    InpMaxHVNZonesEach      = 3;
input int    InpMaxLVNZonesEach      = 3;
input double InpHVNPercentOfPOC      = 0.55;
input double InpLVNPercentOfPOC      = 0.35;

input string InpSectionSR            = "===== Support / Resistance =====";
input int    InpSRLookbackBars       = 450;
input int    InpPivotStrength        = 4;
input int    InpMinTouches           = 3;
input int    InpMaxSRZones           = 4;
input double InpMergeATRMultiple     = 0.25;
input double InpZoneATRPadding       = 0.06;

input string InpSectionVWAP          = "===== VWAP =====";
input bool   InpDrawCurvedVWAP       = true;
input int    InpCurvedVWAPMaxTFMin   = 60;
input bool   InpDrawVWAPLevels       = true;
input double InpVWAPBandStdev        = 1.0;
input bool   InpVWAPResetDaily       = true;

input string InpSectionKeyLevels     = "===== Session / Previous Day =====";
input bool   InpDrawAsiaHighLow      = true;
input string InpAsiaSession          = "00:00-06:00";
input bool   InpDrawPrevDayHighLow   = true;
input bool   InpDrawPivotLevels      = true;
input ENUM_TIMEFRAMES InpPivotSourceTF = PERIOD_D1;

input string InpSectionColors        = "===== Colors =====";
input color  InpEMA50Color           = clrDarkGray;
input color  InpVWAPLineColor        = clrLightSkyBlue;
input color  InpVWAPLevelColor       = clrCadetBlue;
input color  InpDailyPOCColor        = clrSteelBlue;
input color  InpWeeklyPOCColor       = clrGoldenrod;
input color  InpMonthlyPOCColor      = clrMediumOrchid;
input color  InpHVNColor             = clrLightSlateGray;
input color  InpLVNColor             = clrGainsboro;
input color  InpResistanceColor      = clrMistyRose;
input color  InpSupportColor         = clrHoneydew;
input color  InpPrevDayColor         = clrSilver;
input color  InpAsiaColor            = clrDarkSeaGreen;
input color  InpPivotColor           = clrSilver;
input color  InpPivotResistanceColor = clrLightCoral;
input color  InpPivotSupportColor    = clrDarkSeaGreen;
input color  InpLabelColor           = clrDimGray;

double g_vwap[];
double g_vwapUpper[];
double g_vwapLower[];
double g_ema50[];

string   PREFIX = "LPH_IZ_";
datetime g_lastDrawTime = 0;
datetime g_lastBarTime  = 0;

//+------------------------------------------------------------------+
int OnInit()
{
   IndicatorShortName("LPH Institutional Zones No Alerts");
   SetIndexBuffer(0, g_vwap);
   SetIndexBuffer(1, g_vwapUpper);
   SetIndexBuffer(2, g_vwapLower);
   SetIndexBuffer(3, g_ema50);
   SetIndexEmptyValue(0, EMPTY_VALUE);
   SetIndexEmptyValue(1, EMPTY_VALUE);
   SetIndexEmptyValue(2, EMPTY_VALUE);
   SetIndexEmptyValue(3, EMPTY_VALUE);
   SetIndexStyle(0, DRAW_LINE, STYLE_SOLID, 1, InpVWAPLineColor);
   SetIndexStyle(1, DRAW_LINE, STYLE_DOT, 1, InpVWAPLevelColor);
   SetIndexStyle(2, DRAW_LINE, STYLE_DOT, 1, InpVWAPLevelColor);
   SetIndexStyle(3, DRAW_LINE, STYLE_SOLID, 1, InpEMA50Color);
   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   DeleteObjectsByPrefix(PREFIX);
}

//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
   if(rates_total < 50)
      return(rates_total);

   if(InpDrawEMA50)
      CalculateEMA50(rates_total);
   else
      ClearBuffer(g_ema50, rates_total);

   if(ShouldDrawCurvedVWAP())
      CalculateVWAP(rates_total, time, high, low, close, tick_volume);
   else
      ClearVWAPBuffers(rates_total);

   datetime now = TimeCurrent();
   bool newBar = (time[0] != g_lastBarTime);
   bool refreshDue = (now - g_lastDrawTime >= InpRefreshSeconds);

   if(newBar || refreshDue || prev_calculated == 0)
   {
      g_lastBarTime = time[0];
      g_lastDrawTime = now;
      RedrawObjects(rates_total, time, high, low, close, tick_volume);
   }

   return(rates_total);
}

//+------------------------------------------------------------------+
void ClearVWAPBuffers(const int rates_total)
{
   ClearBuffer(g_vwap, rates_total);
   ClearBuffer(g_vwapUpper, rates_total);
   ClearBuffer(g_vwapLower, rates_total);
}

//+------------------------------------------------------------------+
void ClearBuffer(double &buffer[], const int rates_total)
{
   int maxBars = MathMin(rates_total, InpMaxBarsToScan);
   for(int i = 0; i < maxBars; i++)
      buffer[i] = EMPTY_VALUE;
}

//+------------------------------------------------------------------+
bool ShouldDrawCurvedVWAP()
{
   return(InpDrawVWAP && InpDrawCurvedVWAP && Period() <= InpCurvedVWAPMaxTFMin);
}

//+------------------------------------------------------------------+
void CalculateEMA50(const int rates_total)
{
   int period = 50;
   int maxBars = MathMin(rates_total - 1, InpMaxBarsToScan);
   for(int i = 0; i <= maxBars; i++)
      g_ema50[i] = iMA(Symbol(), Period(), period, 0, MODE_EMA, PRICE_CLOSE, i);
}

//+------------------------------------------------------------------+
void CalculateVWAP(const int rates_total,
                   const datetime &time[],
                   const double &high[],
                   const double &low[],
                   const double &close[],
                   const long &tick_volume[])
{
   int maxBars = MathMin(rates_total - 1, InpMaxBarsToScan);
   double sumPV = 0.0;
   double sumP2V = 0.0;
   double sumV = 0.0;
   int lastDay = -1;

   for(int i = maxBars; i >= 0; i--)
   {
      int dayKey = TimeYear(time[i]) * 1000 + TimeDayOfYear(time[i]);
      if(InpVWAPResetDaily && dayKey != lastDay)
      {
         sumPV = 0.0;
         sumP2V = 0.0;
         sumV = 0.0;
         lastDay = dayKey;
      }

      double typical = (high[i] + low[i] + close[i]) / 3.0;
      double vol = MathMax(1.0, (double)tick_volume[i]);

      sumPV += typical * vol;
      sumP2V += typical * typical * vol;
      sumV += vol;

      if(sumV <= 0.0)
      {
         g_vwap[i] = EMPTY_VALUE;
         g_vwapUpper[i] = EMPTY_VALUE;
         g_vwapLower[i] = EMPTY_VALUE;
         continue;
      }

      double vwap = sumPV / sumV;
      double variance = MathMax(0.0, (sumP2V / sumV) - (vwap * vwap));
      double stdev = MathSqrt(variance);

      g_vwap[i] = vwap;
      g_vwapUpper[i] = vwap + InpVWAPBandStdev * stdev;
      g_vwapLower[i] = vwap - InpVWAPBandStdev * stdev;
   }
}

//+------------------------------------------------------------------+
void RedrawObjects(const int rates_total,
                   const datetime &time[],
                   const double &high[],
                   const double &low[],
                   const double &close[],
                   const long &tick_volume[])
{
   DeleteObjectsByPrefix(PREFIX);

   if(InpDrawVolumeProfiles)
   {
      if(InpDrawDailyProfile)
         DrawProfile("D", GetDayStart(TimeCurrent()), InpDailyFallbackBars, InpDailyPOCColor,
                     rates_total, time, high, low, close, tick_volume);
      if(InpDrawWeeklyProfile)
         DrawProfile("W", GetWeekStart(TimeCurrent()), InpWeeklyFallbackBars, InpWeeklyPOCColor,
                     rates_total, time, high, low, close, tick_volume);
      if(InpDrawMonthlyProfile)
         DrawProfile("M", GetMonthStart(TimeCurrent()), InpMonthlyFallbackBars, InpMonthlyPOCColor,
                     rates_total, time, high, low, close, tick_volume);
   }

   if(InpDrawVWAP && InpDrawVWAPLevels)
      DrawVWAPLevels(rates_total, time, high, low, close, tick_volume);

   if(InpDrawPrevDayHighLow)
      DrawPreviousDayLevels();

   if(InpDrawAsiaHighLow)
      DrawAsiaLevels(rates_total, time, high, low);

   if(InpDrawPivotLevels)
      DrawPivotLevels();

   if(InpDrawSupportResistance)
      DrawSupportResistance(rates_total, time, high, low, tick_volume);
}

//+------------------------------------------------------------------+
void DrawProfile(const string tag,
                 const datetime windowStart,
                 const int fallbackBars,
                 const color pocColor,
                 const int rates_total,
                 const datetime &time[],
                 const double &high[],
                 const double &low[],
                 const double &close[],
                 const long &tick_volume[])
{
   int lastBar = FindOldestBarInWindow(windowStart, fallbackBars, rates_total, time);
   if(lastBar < 1)
      return;

   double rangeHigh = high[0];
   double rangeLow = low[0];
   for(int i = 0; i <= lastBar; i++)
   {
      rangeHigh = MathMax(rangeHigh, high[i]);
      rangeLow = MathMin(rangeLow, low[i]);
   }

   if(rangeHigh <= rangeLow)
      return;

   int bins = MathMax(8, MathMin(120, InpProfileBins));
   double binHeight = (rangeHigh - rangeLow) / bins;
   if(binHeight <= Point)
      return;

   double profile[];
   ArrayResize(profile, bins);
   ArrayInitialize(profile, 0.0);

   for(int bar = 0; bar <= lastBar; bar++)
   {
      double typical = (high[bar] + low[bar] + close[bar]) / 3.0;
      int bin = (int)MathFloor((typical - rangeLow) / binHeight);
      if(bin < 0)
         bin = 0;
      if(bin >= bins)
         bin = bins - 1;
      profile[bin] += MathMax(1.0, (double)tick_volume[bar]);
   }

   int pocBin = 0;
   double maxVol = profile[0];
   for(int b = 1; b < bins; b++)
   {
      if(profile[b] > maxVol)
      {
         maxVol = profile[b];
         pocBin = b;
      }
   }

   if(maxVol <= 0.0)
      return;

   datetime leftTime = time[lastBar];
   datetime rightTime = ZoneProjectionTime();
   datetime labelTime = LineLabelTime();
   double pocPrice = BinMid(rangeLow, binHeight, pocBin);

   DrawHLine(PREFIX + tag + "_POC", pocPrice, pocColor, STYLE_SOLID, 2,
             tag + " POC " + DoubleToString(pocPrice, Digits));
   DrawText(PREFIX + tag + "_POC_LABEL", tag + " POC", labelTime, pocPrice, pocColor);

   bool used[];
   ArrayResize(used, bins);
   ArrayInitialize(used, false);
   used[pocBin] = true;

   for(int hvnCount = 0; hvnCount < InpMaxHVNZonesEach; hvnCount++)
   {
      int hvnBin = FindHighestUnusedBin(profile, used, bins, maxVol * InpHVNPercentOfPOC);
      if(hvnBin < 0 && hvnCount == 0)
         hvnBin = FindHighestUnusedBin(profile, used, bins, 0.0);
      if(hvnBin < 0)
         break;

      used[hvnBin] = true;
      double hvnTop = rangeLow + (hvnBin + 1) * binHeight;
      double hvnBottom = rangeLow + hvnBin * binHeight;
      double hvnMid = BinMid(rangeLow, binHeight, hvnBin);
      string hvnName = PREFIX + tag + "_HVN_" + IntegerToString(hvnCount + 1);
      DrawZone(hvnName, leftTime, rightTime, hvnTop, hvnBottom, InpHVNColor, tag + " HVN");
      DrawHLine(hvnName + "_LINE", hvnMid, InpHVNColor, STYLE_DOT, 1, tag + " HVN " + DoubleToString(hvnMid, Digits));
      DrawText(hvnName + "_LABEL", tag + " HVN", labelTime, hvnMid, InpLabelColor);
   }

   for(int lvnCount = 0; lvnCount < InpMaxLVNZonesEach; lvnCount++)
   {
      int lvnBin = FindLowestUnusedBin(profile, used, bins, maxVol * InpLVNPercentOfPOC);
      if(lvnBin < 0 && lvnCount == 0)
         lvnBin = FindLowestUnusedBin(profile, used, bins, maxVol);
      if(lvnBin < 0)
         break;

      used[lvnBin] = true;
      double lvnTop = rangeLow + (lvnBin + 1) * binHeight;
      double lvnBottom = rangeLow + lvnBin * binHeight;
      double lvnMid = BinMid(rangeLow, binHeight, lvnBin);
      string lvnName = PREFIX + tag + "_LVN_" + IntegerToString(lvnCount + 1);
      DrawZone(lvnName, leftTime, rightTime, lvnTop, lvnBottom, InpLVNColor, tag + " LVN");
      DrawHLine(lvnName + "_LINE", lvnMid, InpLVNColor, STYLE_DOT, 1, tag + " LVN " + DoubleToString(lvnMid, Digits));
      DrawText(lvnName + "_LABEL", tag + " LVN", labelTime, lvnMid, InpLabelColor);
   }
}

//+------------------------------------------------------------------+
int FindHighestUnusedBin(const double &profile[],
                         const bool &used[],
                         const int bins,
                         const double minVolume)
{
   int bestBin = -1;
   double bestVol = -1.0;
   for(int i = 0; i < bins; i++)
   {
      if(used[i])
         continue;
      if(profile[i] < minVolume)
         continue;
      if(profile[i] > bestVol)
      {
         bestVol = profile[i];
         bestBin = i;
      }
   }
   return(bestBin);
}

//+------------------------------------------------------------------+
int FindLowestUnusedBin(const double &profile[],
                        const bool &used[],
                        const int bins,
                        const double maxVolume)
{
   int bestBin = -1;
   double bestVol = 999999999999.0;
   for(int i = 0; i < bins; i++)
   {
      if(used[i])
         continue;
      if(profile[i] <= 0.0 || profile[i] > maxVolume)
         continue;
      if(profile[i] < bestVol)
      {
         bestVol = profile[i];
         bestBin = i;
      }
   }
   return(bestBin);
}

//+------------------------------------------------------------------+
void DrawVWAPLevels(const int rates_total,
                    const datetime &time[],
                    const double &high[],
                    const double &low[],
                    const double &close[],
                    const long &tick_volume[])
{
   DrawVWAPLevelForWindow("D", GetDayStart(TimeCurrent()), InpDailyFallbackBars,
                          rates_total, time, high, low, close, tick_volume);
   DrawVWAPLevelForWindow("W", GetWeekStart(TimeCurrent()), InpWeeklyFallbackBars,
                          rates_total, time, high, low, close, tick_volume);
   DrawVWAPLevelForWindow("M", GetMonthStart(TimeCurrent()), InpMonthlyFallbackBars,
                          rates_total, time, high, low, close, tick_volume);
}

//+------------------------------------------------------------------+
void DrawVWAPLevelForWindow(const string tag,
                            const datetime windowStart,
                            const int fallbackBars,
                            const int rates_total,
                            const datetime &time[],
                            const double &high[],
                            const double &low[],
                            const double &close[],
                            const long &tick_volume[])
{
   int lastBar = FindOldestBarInWindow(windowStart, fallbackBars, rates_total, time);
   if(lastBar < 1)
      return;

   double sumPV = 0.0;
   double sumV = 0.0;
   for(int i = 0; i <= lastBar; i++)
   {
      double typical = (high[i] + low[i] + close[i]) / 3.0;
      double vol = MathMax(1.0, (double)tick_volume[i]);
      sumPV += typical * vol;
      sumV += vol;
   }

   if(sumV <= 0.0)
      return;

   double vwap = sumPV / sumV;
   datetime labelTime = LineLabelTime();
   string name = PREFIX + tag + "_VWAP_LEVEL";
   DrawHLine(name, vwap, InpVWAPLevelColor, STYLE_DASH, 1,
             tag + " VWAP " + DoubleToString(vwap, Digits));
   DrawText(name + "_LABEL", tag + " VWAP", labelTime, vwap, InpVWAPLevelColor);
}

//+------------------------------------------------------------------+
void DrawPreviousDayLevels()
{
   double prevHigh = iHigh(Symbol(), PERIOD_D1, 1);
   double prevLow = iLow(Symbol(), PERIOD_D1, 1);
   datetime labelTime = LineLabelTime();

   if(prevHigh > 0.0)
   {
      DrawHLine(PREFIX + "PDH", prevHigh, InpPrevDayColor, STYLE_DOT, 1,
                "Previous Day High " + DoubleToString(prevHigh, Digits));
      DrawText(PREFIX + "PDH_LABEL", "PDH", labelTime, prevHigh, InpPrevDayColor);
   }

   if(prevLow > 0.0)
   {
      DrawHLine(PREFIX + "PDL", prevLow, InpPrevDayColor, STYLE_DOT, 1,
                "Previous Day Low " + DoubleToString(prevLow, Digits));
      DrawText(PREFIX + "PDL_LABEL", "PDL", labelTime, prevLow, InpPrevDayColor);
   }
}

//+------------------------------------------------------------------+
void DrawAsiaLevels(const int rates_total,
                    const datetime &time[],
                    const double &high[],
                    const double &low[])
{
   int startMin = 0;
   int endMin = 360;
   if(!ParseSessionMinutes(InpAsiaSession, startMin, endMin))
      return;

   datetime dayStart = GetDayStart(TimeCurrent());
   double asiaHigh = -DBL_MAX;
   double asiaLow = DBL_MAX;
   int found = 0;
   int maxBars = MathMin(rates_total - 1, InpMaxBarsToScan);

   for(int i = 0; i <= maxBars; i++)
   {
      if(time[i] < dayStart)
         break;

      int minutes = TimeHour(time[i]) * 60 + TimeMinute(time[i]);
      bool inSession = false;
      if(startMin <= endMin)
         inSession = (minutes >= startMin && minutes <= endMin);
      else
         inSession = (minutes >= startMin || minutes <= endMin);

      if(inSession)
      {
         asiaHigh = MathMax(asiaHigh, high[i]);
         asiaLow = MathMin(asiaLow, low[i]);
         found++;
      }
   }

   if(found <= 0 || asiaHigh <= -DBL_MAX / 2 || asiaLow >= DBL_MAX / 2)
      return;

   datetime labelTime = LineLabelTime();
   DrawHLine(PREFIX + "ASIA_HIGH", asiaHigh, InpAsiaColor, STYLE_DOT, 1,
             "Asia High " + DoubleToString(asiaHigh, Digits));
   DrawHLine(PREFIX + "ASIA_LOW", asiaLow, InpAsiaColor, STYLE_DOT, 1,
             "Asia Low " + DoubleToString(asiaLow, Digits));
   DrawText(PREFIX + "ASIA_HIGH_LABEL", "Asia H", labelTime, asiaHigh, InpAsiaColor);
   DrawText(PREFIX + "ASIA_LOW_LABEL", "Asia L", labelTime, asiaLow, InpAsiaColor);
}

//+------------------------------------------------------------------+
void DrawPivotLevels()
{
   int tf = InpPivotSourceTF;
   if(tf <= 0)
      tf = PERIOD_D1;

   double prevHigh = iHigh(Symbol(), tf, 1);
   double prevLow = iLow(Symbol(), tf, 1);
   double prevClose = iClose(Symbol(), tf, 1);

   if(prevHigh <= 0.0 || prevLow <= 0.0 || prevClose <= 0.0 || prevHigh <= prevLow)
      return;

   double pp = (prevHigh + prevLow + prevClose) / 3.0;
   double r1 = (2.0 * pp) - prevLow;
   double s1 = (2.0 * pp) - prevHigh;
   double range = prevHigh - prevLow;
   double r2 = pp + range;
   double s2 = pp - range;
   double r3 = prevHigh + 2.0 * (pp - prevLow);
   double s3 = prevLow - 2.0 * (prevHigh - pp);

   DrawPivotLine("PP", pp, InpPivotColor, STYLE_DASH);
   DrawPivotLine("R1", r1, InpPivotResistanceColor, STYLE_DOT);
   DrawPivotLine("R2", r2, InpPivotResistanceColor, STYLE_DOT);
   DrawPivotLine("R3", r3, InpPivotResistanceColor, STYLE_DOT);
   DrawPivotLine("S1", s1, InpPivotSupportColor, STYLE_DOT);
   DrawPivotLine("S2", s2, InpPivotSupportColor, STYLE_DOT);
   DrawPivotLine("S3", s3, InpPivotSupportColor, STYLE_DOT);
}

//+------------------------------------------------------------------+
void DrawPivotLine(const string label, const double price, const color lineColor, const int style)
{
   string name = PREFIX + "PIVOT_" + label;
   DrawHLine(name, price, lineColor, style, 1, label + " " + DoubleToString(price, Digits));
   DrawText(name + "_LABEL", label, LineLabelTime(), price, lineColor);
}

//+------------------------------------------------------------------+
bool ParseSessionMinutes(const string sessionText, int &startMin, int &endMin)
{
   string parts[];
   int count = StringSplit(sessionText, '-', parts);
   if(count != 2)
      return(false);

   startMin = ParseHHMM(parts[0]);
   endMin = ParseHHMM(parts[1]);
   return(startMin >= 0 && endMin >= 0);
}

//+------------------------------------------------------------------+
int ParseHHMM(string value)
{
   StringTrimLeft(value);
   StringTrimRight(value);
   string parts[];
   int count = StringSplit(value, ':', parts);
   if(count != 2)
      return(-1);

   int hh = StrToInteger(parts[0]);
   int mm = StrToInteger(parts[1]);
   if(hh < 0 || hh > 23 || mm < 0 || mm > 59)
      return(-1);
   return(hh * 60 + mm);
}

//+------------------------------------------------------------------+
void DrawSupportResistance(const int rates_total,
                           const datetime &time[],
                           const double &high[],
                           const double &low[],
                           const long &tick_volume[])
{
   int lookback = MathMin(MathMin(InpSRLookbackBars, InpMaxBarsToScan), rates_total - InpPivotStrength - 2);
   if(lookback <= InpPivotStrength * 2)
      return;

   double atr = iATR(Symbol(), Period(), 14, 0);
   if(atr <= 0.0)
      atr = 20.0 * Point;

   double mergeDistance = MathMax(Point * 5.0, atr * InpMergeATRMultiple);
   double zonePadding = MathMax(Point * 3.0, atr * InpZoneATRPadding);

   double levels[];
   int touches[];
   int kind[];
   double weights[];
   ArrayResize(levels, 0);
   ArrayResize(touches, 0);
   ArrayResize(kind, 0);
   ArrayResize(weights, 0);

   for(int i = InpPivotStrength; i <= lookback; i++)
   {
      if(IsPivotHigh(i, high))
         AddCluster(high[i], 1, MathMax(1.0, (double)tick_volume[i]), mergeDistance, levels, touches, kind, weights);

      if(IsPivotLow(i, low))
         AddCluster(low[i], -1, MathMax(1.0, (double)tick_volume[i]), mergeDistance, levels, touches, kind, weights);
   }

   int count = ArraySize(levels);
   if(count <= 0)
      return;

   SortClusters(levels, touches, kind, weights);

   datetime leftTime = time[lookback];
   datetime rightTime = ZoneProjectionTime();
   int drawn = 0;

   for(int idx = 0; idx < count && drawn < InpMaxSRZones; idx++)
   {
      if(touches[idx] < InpMinTouches)
         continue;

      string side = (kind[idx] > 0 ? "Resistance" : "Support");
      color zoneColor = (kind[idx] > 0 ? InpResistanceColor : InpSupportColor);
      string name = PREFIX + "SR_" + side + "_" + IntegerToString(drawn + 1);
      DrawZone(name, leftTime, rightTime, levels[idx] + zonePadding, levels[idx] - zonePadding, zoneColor,
               side + " touches=" + IntegerToString(touches[idx]));
      drawn++;
   }
}

//+------------------------------------------------------------------+
bool IsPivotHigh(const int index, const double &high[])
{
   for(int k = 1; k <= InpPivotStrength; k++)
   {
      if(high[index] <= high[index - k])
         return(false);
      if(high[index] < high[index + k])
         return(false);
   }
   return(true);
}

//+------------------------------------------------------------------+
bool IsPivotLow(const int index, const double &low[])
{
   for(int k = 1; k <= InpPivotStrength; k++)
   {
      if(low[index] >= low[index - k])
         return(false);
      if(low[index] > low[index + k])
         return(false);
   }
   return(true);
}

//+------------------------------------------------------------------+
void AddCluster(const double level,
                const int levelKind,
                const double weight,
                const double mergeDistance,
                double &levels[],
                int &touches[],
                int &kind[],
                double &weights[])
{
   int count = ArraySize(levels);
   for(int i = 0; i < count; i++)
   {
      if(kind[i] == levelKind && MathAbs(levels[i] - level) <= mergeDistance)
      {
         double oldWeight = MathMax(1.0, weights[i]);
         levels[i] = ((levels[i] * oldWeight) + (level * weight)) / (oldWeight + weight);
         weights[i] = oldWeight + weight;
         touches[i]++;
         return;
      }
   }

   ArrayResize(levels, count + 1);
   ArrayResize(touches, count + 1);
   ArrayResize(kind, count + 1);
   ArrayResize(weights, count + 1);

   levels[count] = level;
   touches[count] = 1;
   kind[count] = levelKind;
   weights[count] = weight;
}

//+------------------------------------------------------------------+
void SortClusters(double &levels[], int &touches[], int &kind[], double &weights[])
{
   int count = ArraySize(levels);
   for(int i = 0; i < count - 1; i++)
   {
      for(int j = i + 1; j < count; j++)
      {
         bool swapNeeded = false;
         if(touches[j] > touches[i])
            swapNeeded = true;
         else if(touches[j] == touches[i] && weights[j] > weights[i])
            swapNeeded = true;

         if(swapNeeded)
         {
            double tmpLevel = levels[i];
            int tmpTouches = touches[i];
            int tmpKind = kind[i];
            double tmpWeight = weights[i];

            levels[i] = levels[j];
            touches[i] = touches[j];
            kind[i] = kind[j];
            weights[i] = weights[j];

            levels[j] = tmpLevel;
            touches[j] = tmpTouches;
            kind[j] = tmpKind;
            weights[j] = tmpWeight;
         }
      }
   }
}

//+------------------------------------------------------------------+
int FindOldestBarInWindow(const datetime windowStart,
                          const int fallbackBars,
                          const int rates_total,
                          const datetime &time[])
{
   int oldest = 0;
   int maxBars = MathMin(MathMin(fallbackBars, InpMaxBarsToScan), rates_total - 1);

   for(int i = 0; i <= maxBars; i++)
   {
      if(time[i] >= windowStart)
         oldest = i;
      else
         break;
   }

   if(oldest < MathMin(12, maxBars))
      oldest = maxBars;

   return(oldest);
}

//+------------------------------------------------------------------+
datetime GetDayStart(const datetime value)
{
   return(StrToTime(TimeToString(value, TIME_DATE)));
}

//+------------------------------------------------------------------+
datetime GetWeekStart(const datetime value)
{
   datetime dayStart = GetDayStart(value);
   int dow = TimeDayOfWeek(value);
   int daysBack = (dow == 0 ? 6 : dow - 1);
   return(dayStart - daysBack * 86400);
}

//+------------------------------------------------------------------+
datetime GetMonthStart(const datetime value)
{
   string yearText = IntegerToString(TimeYear(value));
   string monthText = IntegerToString(TimeMonth(value));
   if(StringLen(monthText) < 2)
      monthText = "0" + monthText;
   return(StrToTime(yearText + "." + monthText + ".01 00:00"));
}

//+------------------------------------------------------------------+
double BinMid(const double rangeLow, const double binHeight, const int bin)
{
   return(rangeLow + (bin + 0.5) * binHeight);
}

//+------------------------------------------------------------------+
int PeriodSecondsSafe()
{
   int seconds = PeriodSeconds();
   if(seconds <= 0)
      seconds = Period() * 60;
   if(seconds <= 0)
      seconds = 3600;
   return(seconds);
}

//+------------------------------------------------------------------+
datetime ZoneProjectionTime()
{
   return(Time[0] + PeriodSecondsSafe() * InpProjectionBars);
}

//+------------------------------------------------------------------+
datetime LineLabelTime()
{
   int offsetBars = MathMax(0, MathMin(20, InpLineLabelOffsetBars));
   return(Time[0] + PeriodSecondsSafe() * offsetBars);
}

//+------------------------------------------------------------------+
void DrawZone(const string name,
              const datetime leftTime,
              const datetime rightTime,
              const double top,
              const double bottom,
              const color zoneColor,
              const string tooltip)
{
   ObjectCreate(0, name, OBJ_RECTANGLE, 0, leftTime, top, rightTime, bottom);
   ObjectSetInteger(0, name, OBJPROP_COLOR, zoneColor);
   ObjectSetInteger(0, name, OBJPROP_STYLE, STYLE_SOLID);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, 1);
   ObjectSetInteger(0, name, OBJPROP_BACK, true);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
   ObjectSetString(0, name, OBJPROP_TOOLTIP, tooltip);
}

//+------------------------------------------------------------------+
void DrawHLine(const string name,
               const double price,
               const color lineColor,
               const int style,
               const int width,
               const string tooltip)
{
   ObjectCreate(0, name, OBJ_HLINE, 0, 0, price);
   ObjectSetInteger(0, name, OBJPROP_COLOR, lineColor);
   ObjectSetInteger(0, name, OBJPROP_STYLE, style);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, width);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
   ObjectSetString(0, name, OBJPROP_TOOLTIP, tooltip);
}

//+------------------------------------------------------------------+
void DrawText(const string name,
              const string text,
              const datetime textTime,
              const double price,
              const color textColor)
{
   ObjectCreate(0, name, OBJ_TEXT, 0, textTime, price);
   ObjectSetString(0, name, OBJPROP_TEXT, text);
   ObjectSetInteger(0, name, OBJPROP_COLOR, textColor);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, MathMax(6, MathMin(12, InpLineLabelFontSize)));
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
}

//+------------------------------------------------------------------+
void DeleteObjectsByPrefix(const string prefix)
{
   for(int i = ObjectsTotal(0, -1, -1) - 1; i >= 0; i--)
   {
      string name = ObjectName(0, i, -1, -1);
      if(StringFind(name, prefix, 0) == 0)
         ObjectDelete(0, name);
   }
}

//+------------------------------------------------------------------+
