//+------------------------------------------------------------------+
//|                                              Strict_ATR_Stop.mq4 |
//+------------------------------------------------------------------+
#property strict
#property indicator_chart_window
#property indicator_buffers 2
#property indicator_color1 clrDodgerBlue  // Color for Long Stop
#property indicator_color2 clrRed         // Color for Short Stop
#property indicator_width1 2
#property indicator_width2 2

// Adjustable parameters you can change in MT4
input int ATR_Period = 14;
input double ATR_Multiplier = 2.5;

// Buffers to hold the line data
double LongStopBuffer[];
double ShortStopBuffer[];

//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit()
{
   // Set up the Long Stop line
   SetIndexBuffer(0, LongStopBuffer);
   SetIndexStyle(0, DRAW_LINE);
   SetIndexLabel(0, "Long ATR Stop");
   SetIndexEmptyValue(0, 0.0);

   // Set up the Short Stop line
   SetIndexBuffer(1, ShortStopBuffer);
   SetIndexStyle(1, DRAW_LINE);
   SetIndexLabel(1, "Short ATR Stop");
   SetIndexEmptyValue(1, 0.0);

   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
   // Figure out how many candles we need to calculate
   int limit = rates_total - prev_calculated;
   
   // If it's the first time running, calculate all candles
   if(prev_calculated == 0) limit = rates_total - ATR_Period - 1;

   // The Loop: This is where 'i' is defined and counts through the candles
   for(int i = limit; i >= 0; i--)
   {
      // 1. Calculate the ATR value
      double current_atr = iATR(Symbol(), 0, ATR_Period, i);

      // 2. Find the highest high over the ATR period
      int highest_idx = iHighest(Symbol(), 0, MODE_HIGH, ATR_Period, i);
      double highest_high = High[highest_idx];
      
      // Plot the Long Stop
      LongStopBuffer[i] = highest_high - (current_atr * ATR_Multiplier);

      // 3. Find the lowest low over the ATR period
      int lowest_idx = iLowest(Symbol(), 0, MODE_LOW, ATR_Period, i);
      double lowest_low = Low[lowest_idx];
      
      // Plot the Short Stop
      ShortStopBuffer[i] = lowest_low + (current_atr * ATR_Multiplier);
   }

   return(rates_total);
}
//+------------------------------------------------------------------+