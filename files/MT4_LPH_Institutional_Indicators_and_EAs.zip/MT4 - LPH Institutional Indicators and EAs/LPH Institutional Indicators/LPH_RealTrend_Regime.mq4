//+------------------------------------------------------------------+
//|                                          LPH_RealTrend_Regime.mq4 |
//|  Evidence-based trend/regime filter for LPH4_lotfix v15 (MT4)    |
//|  Built from losing-trade analysis (2026-08-15):                  |
//|    Finding #1: losers cluster in chop (trend filter fires then   |
//|                reverses). -> Efficiency Ratio + ADX + Choppiness |
//|    Finding #4: loser side = counter-trend side of the range      |
//|                -> signed trend only when regime confirms.        |
//|    Finding #3: Monday-open/gap entries lose out of proportion    |
//|                -> REGIME drops to 0 on 00:00 Monday gap bars.    |
//|  Outputs (separate window):                                      |
//|    TREND       : signed trend strength (0 when regime=chop)       |
//|    REGIME_BULL : +1 tradeable bull (LimeGreen)                   |
//|    REGIME_BEAR : -1 tradeable bear (OrangeRed)                   |
//|    REGIME_FLAT :  0 chop/flat (DimGray)                          |
//|    ER          : Kaufman efficiency ratio (0..1)                 |
//|    CHOP        : Choppiness Index (>=61.8 = chop)                |
//|    ADX         : Wilder ADX trend strength                        |
//|    REGIME_RAW  : raw regime value (+1, -1, 0) for iCustom calls  |
//+------------------------------------------------------------------+
#property copyright   "MetaTrader Assistant / LPH research"
#property version     "1.00"
#property strict
#property indicator_separate_window
#property indicator_minimum  -100
#property indicator_maximum   100
#property indicator_buffers    8
#property indicator_plots      7

//--- plot 0: TREND
#property indicator_label1  "TREND"
#property indicator_type1   DRAW_HISTOGRAM
#property indicator_color1  clrDodgerBlue
#property indicator_style1  STYLE_SOLID
#property indicator_width1  2

//--- plot 1: REGIME_BULL
#property indicator_label2  "REGIME_BULL"
#property indicator_type2   DRAW_HISTOGRAM
#property indicator_color2  clrLimeGreen
#property indicator_style2  STYLE_SOLID
#property indicator_width2  3

//--- plot 2: REGIME_BEAR
#property indicator_label3  "REGIME_BEAR"
#property indicator_type3   DRAW_HISTOGRAM
#property indicator_color3  clrOrangeRed
#property indicator_style3  STYLE_SOLID
#property indicator_width3  3

//--- plot 3: REGIME_FLAT
#property indicator_label4  "REGIME_FLAT"
#property indicator_type4   DRAW_HISTOGRAM
#property indicator_color4  clrDimGray
#property indicator_style4  STYLE_SOLID
#property indicator_width4  3

//--- plot 4: ER
#property indicator_label5  "ER"
#property indicator_type5   DRAW_LINE
#property indicator_color5  clrGold
#property indicator_style5  STYLE_DOT
#property indicator_width5  1

//--- plot 5: CHOP
#property indicator_label6  "CHOP"
#property indicator_type6   DRAW_LINE
#property indicator_color6  clrMagenta
#property indicator_style6  STYLE_DOT
#property indicator_width6  1

//--- plot 6: ADX
#property indicator_label7  "ADX"
#property indicator_type7   DRAW_LINE
#property indicator_color7  clrWhite
#property indicator_style7  STYLE_DOT
#property indicator_width7  1

//--- inputs (evidence-tuned defaults)
input int    InpADXPeriod        = 14;   // ADX period (trend strength)
input double InpADXMin           = 20.0; // ADX min for "real trend" (chop guard)
input int    InpERPeriod         = 10;   // Kaufman efficiency-ratio period
input double InpERMin            = 0.30; // ER min for "real trend" (chop guard)
input int    InpChoppinessPeriod = 14;   // Choppiness Index period
input double InpChopMax          = 61.8; // Choppiness max (above = chop)
input int    InpEMAFast          = 8;    // fast EMA (matches LPH4)
input int    InpEMASlow          = 20;   // slow EMA (matches LPH4)
input int    InpEMAFilter        = 50;   // H4 EMA filter (matches LPH4)
input bool   InpBlockMondayGap   = true; // zero REGIME on 00:00 Monday reopen
input bool   InpShowWordLabel    = true; // show plain-word trend confirmation label on chart

//--- indicator buffers
double B_TREND[];
double B_REGIME_BULL[];
double B_REGIME_BEAR[];
double B_REGIME_FLAT[];
double B_ER[];
double B_CHOP[];
double B_ADX[];
double B_REGIME_RAW[];

string g_lastWord = "";
string g_labelName = "LPH_RealTrend_Regime_Word";

//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit()
  {
   IndicatorBuffers(8);

   SetIndexBuffer(0, B_TREND);
   SetIndexStyle(0, DRAW_HISTOGRAM, STYLE_SOLID, 2, clrDodgerBlue);
   SetIndexLabel(0, "TREND");

   SetIndexBuffer(1, B_REGIME_BULL);
   SetIndexStyle(1, DRAW_HISTOGRAM, STYLE_SOLID, 3, clrLimeGreen);
   SetIndexLabel(1, "REGIME_BULL");

   SetIndexBuffer(2, B_REGIME_BEAR);
   SetIndexStyle(2, DRAW_HISTOGRAM, STYLE_SOLID, 3, clrOrangeRed);
   SetIndexLabel(2, "REGIME_BEAR");

   SetIndexBuffer(3, B_REGIME_FLAT);
   SetIndexStyle(3, DRAW_HISTOGRAM, STYLE_SOLID, 3, clrDimGray);
   SetIndexLabel(3, "REGIME_FLAT");

   SetIndexBuffer(4, B_ER);
   SetIndexStyle(4, DRAW_LINE, STYLE_DOT, 1, clrGold);
   SetIndexLabel(4, "ER");

   SetIndexBuffer(5, B_CHOP);
   SetIndexStyle(5, DRAW_LINE, STYLE_DOT, 1, clrMagenta);
   SetIndexLabel(5, "CHOP");

   SetIndexBuffer(6, B_ADX);
   SetIndexStyle(6, DRAW_LINE, STYLE_DOT, 1, clrWhite);
   SetIndexLabel(6, "ADX");

   SetIndexBuffer(7, B_REGIME_RAW);
   SetIndexStyle(7, DRAW_NONE);
   SetIndexLabel(7, "REGIME");

   SetIndexEmptyValue(0, 0.0);
   SetIndexEmptyValue(1, EMPTY_VALUE);
   SetIndexEmptyValue(2, EMPTY_VALUE);
   SetIndexEmptyValue(3, EMPTY_VALUE);
   SetIndexEmptyValue(4, EMPTY_VALUE);
   SetIndexEmptyValue(5, EMPTY_VALUE);
   SetIndexEmptyValue(6, EMPTY_VALUE);
   SetIndexEmptyValue(7, 0.0);

   IndicatorDigits(2);
   IndicatorShortName("LPH_RealTrend_Regime");

   return(INIT_SUCCEEDED);
  }

//+------------------------------------------------------------------+
//| Custom indicator deinitialization function                       |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   ObjectDelete(0, g_labelName);
  }

//+------------------------------------------------------------------+
//| Timeframe string helper                                          |
//+------------------------------------------------------------------+
string TFToString(int tf)
  {
   if(tf == 0) tf = Period();
   switch(tf)
     {
      case PERIOD_M1:  return("M1");
      case PERIOD_M5:  return("M5");
      case PERIOD_M15: return("M15");
      case PERIOD_M30: return("M30");
      case PERIOD_H1:  return("H1");
      case PERIOD_H4:  return("H4");
      case PERIOD_D1:  return("D1");
      case PERIOD_W1:  return("W1");
      case PERIOD_MN1: return("MN1");
      default:         return(IntegerToString(tf));
     }
  }

//+------------------------------------------------------------------+
//| Kaufman Efficiency Ratio: |net move| / sum(|bar moves|) over N    |
//+------------------------------------------------------------------+
double EfficiencyRatio(int shift, int period)
  {
   int total = period + shift;
   if(total >= Bars || total < 1) return(0.0);
   double net = MathAbs(Close[shift] - Close[total]);
   double sum = 0.0;
   for(int i = shift; i < total; i++)
     {
      sum += MathAbs(Close[i] - Close[i + 1]);
     }
   if(sum <= 0.0) return(0.0);
   return(net / sum);
  }

//+------------------------------------------------------------------+
//| Choppiness Index: 100*log10( sum(TR,N) / (HH-LH) ) / log10(N)     |
//+------------------------------------------------------------------+
double ChoppinessIndex(int shift, int period)
  {
   int total = period + shift;
   if(total >= Bars || total < 1) return(0.0);
   double hh = -DBL_MAX, ll = DBL_MAX, sumTR = 0.0;
   for(int i = 0; i < period; i++)
     {
      double hi = High[shift + i];
      double lo = Low[shift + i];
      double prev = Close[shift + i + 1];
      double tr = MathMax(hi - lo, MathMax(MathAbs(hi - prev), MathAbs(lo - prev)));
      sumTR += tr;
      if(hi > hh) hh = hi;
      if(lo < ll) ll = lo;
     }
   if(hh <= ll || period <= 1) return(100.0);
   return(100.0 * MathLog10(sumTR / (hh - ll)) / MathLog10(period));
  }

//+------------------------------------------------------------------+
//| True if this bar is a Monday 00:00 reopen (weekend gap candle)    |
//+------------------------------------------------------------------+
bool IsMondayGap(int shift)
  {
   if(shift >= Bars - 1) return(false);
   datetime t = Time[shift];
   datetime p = Time[shift + 1];
   if(t <= 0 || p <= 0) return(false);
   MqlDateTime dt;
   TimeToStruct(t, dt);
   if(dt.day_of_week != 1 || dt.hour != 0 || dt.min != 0) return(false);
   return((t - p) > 4 * 3600);
  }

//+------------------------------------------------------------------+
//| Plain-word confirmation of the current trend regime (manual test) |
//+------------------------------------------------------------------+
string RegimeWord(int sh, double adx, double er, double chop)
  {
   double e8     = iMA(NULL, 0, InpEMAFast, 0, MODE_EMA, PRICE_CLOSE, sh);
   double e20    = iMA(NULL, 0, InpEMASlow, 0, MODE_EMA, PRICE_CLOSE, sh);
   double e50    = iMA(NULL, 0, InpEMAFilter, 0, MODE_EMA, PRICE_CLOSE, sh);
   double e20old = iMA(NULL, 0, InpEMASlow, 0, MODE_EMA, PRICE_CLOSE, sh + 5);
   double close  = Close[sh];

   int dir = 0;
   if(e8 > e20 && close > e50 && e20 > e20old) dir = 1;
   else if(e8 < e20 && close < e50 && e20 < e20old) dir = -1;

   if(dir == 0) return("NO_DIRECTION");
   if(adx < InpADXMin) return("CHOP_BLOCKED_ADX");
   if(er < InpERMin) return("CHOP_BLOCKED_ER");
   if(chop > InpChopMax) return("CHOP_BLOCKED_CHOP");
   if(InpBlockMondayGap && IsMondayGap(sh)) return("MONDAY_GAP_BLOCKED");
   return(dir == 1 ? "CONFIRMED_BULL" : "CONFIRMED_BEAR");
  }

//+------------------------------------------------------------------+
//| Update on-chart HUD text label                                   |
//+------------------------------------------------------------------+
void UpdateWordLabel(int rates_total)
  {
   if(!InpShowWordLabel || rates_total < 1) return;
   int sh = 0;
   double er = EfficiencyRatio(sh, InpERPeriod);
   double chop = ChoppinessIndex(sh, InpChoppinessPeriod);
   double adx = iADX(NULL, 0, InpADXPeriod, PRICE_CLOSE, MODE_MAIN, sh);

   string word = RegimeWord(sh, adx, er, chop);
   color col = clrDimGray;
   if(word == "CONFIRMED_BULL") col = clrLimeGreen;
   else if(word == "CONFIRMED_BEAR") col = clrOrangeRed;
   else if(word == "MONDAY_GAP_BLOCKED") col = clrOrange;
   else if(word == "NO_DIRECTION") col = clrSteelBlue;

   string txt = "LPH REAL TREND  (" + TFToString(Period()) + ")\nREGIME: " + word + "\nADX " + DoubleToString(adx, 1) + " | ER " + DoubleToString(er, 2) + " | CHOP " + DoubleToString(chop, 1);

   if(!ObjectCreate(0, g_labelName, OBJ_LABEL, 0, 0, 0))
     {
      int err = GetLastError();
      if(err != 4204 && err != 0) return; // 4204 = object already exists
     }

   ObjectSetInteger(0, g_labelName, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, g_labelName, OBJPROP_XDISTANCE, 10);
   ObjectSetInteger(0, g_labelName, OBJPROP_YDISTANCE, 10);
   ObjectSetInteger(0, g_labelName, OBJPROP_FONTSIZE, 11);
   ObjectSetString(0, g_labelName, OBJPROP_FONT, "Arial Bold");
   ObjectSetInteger(0, g_labelName, OBJPROP_COLOR, col);
   ObjectSetInteger(0, g_labelName, OBJPROP_BACK, false);
   ObjectSetInteger(0, g_labelName, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, g_labelName, OBJPROP_HIDDEN, true);
   ObjectSetString(0, g_labelName, OBJPROP_TEXT, txt);
   ChartRedraw(0);

   if(word != g_lastWord)
     {
      g_lastWord = word;
      Print("LPH_REALTREND ", Symbol(), " P=", TFToString(Period()), " REGIME=", word,
            " ADX=", DoubleToString(adx, 1), " ER=", DoubleToString(er, 2), " CHOP=", DoubleToString(chop, 1));
     }
  }

//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
   int minBars = InpChoppinessPeriod + InpERPeriod + InpEMAFilter + 10;
   if(rates_total < minBars) return(0);

   int limit;
   if(prev_calculated == 0)
      limit = rates_total - minBars;
   else
      limit = rates_total - prev_calculated + 1;

   if(limit > rates_total - minBars)
      limit = rates_total - minBars;

   for(int sh = limit; sh >= 0; sh--)
     {
      double er   = EfficiencyRatio(sh, InpERPeriod);
      double chop = ChoppinessIndex(sh, InpChoppinessPeriod);
      double adx  = iADX(NULL, 0, InpADXPeriod, PRICE_CLOSE, MODE_MAIN, sh);

      B_ER[sh]   = er;
      B_CHOP[sh] = chop;
      B_ADX[sh]  = adx;

      //--- trend direction (LPH4 logic: EMA fast>slow, price>EMA50)
      double e8     = iMA(NULL, 0, InpEMAFast, 0, MODE_EMA, PRICE_CLOSE, sh);
      double e20    = iMA(NULL, 0, InpEMASlow, 0, MODE_EMA, PRICE_CLOSE, sh);
      double e50    = iMA(NULL, 0, InpEMAFilter, 0, MODE_EMA, PRICE_CLOSE, sh);
      double e20old = iMA(NULL, 0, InpEMASlow, 0, MODE_EMA, PRICE_CLOSE, sh + 5);
      double cl     = Close[sh];

      int dir = 0;
      if(e8 > e20 && cl > e50 && e20 > e20old) dir = 1;
      else if(e8 < e20 && cl < e50 && e20 < e20old) dir = -1;

      //--- regime: tradeable only if trend quality high (evidence #1)
      bool realTrend = (adx >= InpADXMin && er >= InpERMin && chop <= InpChopMax);
      //--- gap guard (evidence #3): no trade on Monday 00:00 reopen
      if(realTrend && InpBlockMondayGap && IsMondayGap(sh)) realTrend = false;

      double strength = realTrend ? MathMin(100.0, adx * (0.5 + er)) : 0.0;
      B_TREND[sh] = dir * strength;

      if(dir != 0 && realTrend)
        {
         B_REGIME_RAW[sh] = (double)dir;
         if(dir > 0)
           {
            B_REGIME_BULL[sh] = 1.0;
            B_REGIME_BEAR[sh] = EMPTY_VALUE;
            B_REGIME_FLAT[sh] = EMPTY_VALUE;
           }
         else
           {
            B_REGIME_BULL[sh] = EMPTY_VALUE;
            B_REGIME_BEAR[sh] = -1.0;
            B_REGIME_FLAT[sh] = EMPTY_VALUE;
           }
        }
      else
        {
         B_REGIME_RAW[sh]  = 0.0;
         B_REGIME_BULL[sh] = EMPTY_VALUE;
         B_REGIME_BEAR[sh] = EMPTY_VALUE;
         B_REGIME_FLAT[sh] = 0.0;
        }
     }

   UpdateWordLabel(rates_total);
   return(rates_total);
  }
//+------------------------------------------------------------------+
