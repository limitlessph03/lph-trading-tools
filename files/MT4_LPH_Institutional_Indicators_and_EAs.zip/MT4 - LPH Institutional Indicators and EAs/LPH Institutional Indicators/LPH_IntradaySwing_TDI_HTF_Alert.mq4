//+------------------------------------------------------------------+
//| LPH_IntradaySwing_TDI_HTF_Alert.mq4                                   |
//| Intraday Swing / Ringed Low & Ringed High HTF alert indicator with TDI confirmation      |
//| Coach T / Limitless PH                                            |
//+------------------------------------------------------------------+
#property strict
#property indicator_chart_window
#property indicator_buffers 0
#property version   "1.11"
#property description "Alerts for editable H4/D1 Intraday Swing Ringed Low/Ringed High EMA pullback continuation setups using TDI confirmation."

//------------------------- Inputs ----------------------------------
input ENUM_TIMEFRAMES InpSignalTF                 = PERIOD_H4;   // Editable: use PERIOD_H4 or PERIOD_D1
input bool            InpScanMarketWatch          = false;       // true = scan all Market Watch symbols
input string          InpSymbols                  = "";          // comma list; blank = current chart symbol
input int             InpTimerSeconds             = 20;

input int             InpEMAFast                  = 8;
input int             InpEMASlow                  = 20;
input int             InpEMAFilter                = 50;
input int             InpATRPeriod                = 14;

input bool            InpUseATRGapFilter          = true;
input double          InpMinEMAGapATR             = 0.20;
input int             InpSlopeLookback            = 5;
input double          InpMinWickPercent           = 0.40;
input double          InpTouchToleranceATR        = 0.05;

input bool            InpUseTDIFilter             = true;
input int             InpTDIMode                  = 2;           // 1=Early slope, 2=Confirmed cross/continuation, 3=Strict
input int             InpTDIRSIPeriod             = 14;
input int             InpTDIPriceLine             = 2;           // Green line smoothing over RSI
input int             InpTDISignalLine            = 7;           // Red line smoothing over RSI
input int             InpTDIPrice                 = PRICE_CLOSE;
input double          InpTDIUpper                 = 68.0;
input double          InpTDILower                 = 32.0;
input double          InpTDIExtremeUpper          = 80.0;
input double          InpTDIExtremeLower          = 20.0;
input bool            InpUseTDIExhaustionFilter   = true;
input int             InpMaxTDIExtremeBars        = 5;
input bool            InpUseTDIHardExtremeBlock   = true;
input int             InpTDIConfirmLookback       = 3;

input bool            InpUseEMA50SafetyFilter     = false;
input bool            InpUseM30TDIFilter          = false;
input int             InpM30TDILookback           = 6;

input bool            InpUseSessionFilter         = false;
input int             InpSessionStartHour         = 0;           // server time
input int             InpSessionEndHour           = 23;          // server time

input double          InpH4EntryBufferPips        = 5.0;
input double          InpD1EntryBufferPips        = 10.0;
input double          InpRewardR                  = 1.0;
input double          InpMaxSpreadPips            = 3.0;
input double          InpPipOverridePrice         = 0.0;         // 0=auto. XAU may need 0.10 or 0.01 depending broker.

input bool            InpPopupAlert               = true;
input bool            InpPushNotification         = false;
input bool            InpEmailAlert               = false;
input bool            InpPrintLog                 = true;
input bool            InpAlertOnlyOncePerBar      = true;

input bool            InpDrawCurrentSymbolObjects = true;
input int             InpDrawForwardBars          = 20;
input color           InpBuyColor                 = clrLime;
input color           InpSellColor                = clrTomato;
input color           InpEntryColor               = clrDodgerBlue;
input color           InpSLColor                  = clrRed;
input color           InpTPColor                  = clrLimeGreen;

//------------------------- Runtime ---------------------------------
string   g_symbols[];
datetime g_lastCheckedBar[];
datetime g_lastBuyAlertBar[];
datetime g_lastSellAlertBar[];

//------------------------- Struct ----------------------------------
struct SignalData
{
   bool     valid;
   bool     isBuy;
   datetime signalTime;
   double   entry;
   double   sl;
   double   tp;
   double   riskPips;
   double   rewardPips;
   double   rr;
   double   ema8;
   double   ema20;
   double   ema50;
   double   atr14;
   double   gapMult;
   double   tdiGreen;
   double   tdiRed;
   int      extremeBars;
   double   wickPct;
   double   slope;
   string   rejectReason;
};

//------------------------- Helpers ---------------------------------
string TrimString(string text)
{
   text = StringTrimLeft(text);
   text = StringTrimRight(text);
   return text;
}

string TFToString(const int tf)
{
   if(tf == PERIOD_M1)  return "M1";
   if(tf == PERIOD_M5)  return "M5";
   if(tf == PERIOD_M15) return "M15";
   if(tf == PERIOD_M30) return "M30";
   if(tf == PERIOD_H1)  return "H1";
   if(tf == PERIOD_H4)  return "H4";
   if(tf == PERIOD_D1)  return "D1";
   if(tf == PERIOD_W1)  return "W1";
   if(tf == PERIOD_MN1) return "MN1";
   return IntegerToString(tf);
}

int TFSeconds(const int tf)
{
   if(tf == PERIOD_M1)  return 60;
   if(tf == PERIOD_M5)  return 300;
   if(tf == PERIOD_M15) return 900;
   if(tf == PERIOD_M30) return 1800;
   if(tf == PERIOD_H1)  return 3600;
   if(tf == PERIOD_H4)  return 14400;
   if(tf == PERIOD_D1)  return 86400;
   if(tf == PERIOD_W1)  return 604800;
   if(tf == PERIOD_MN1) return 2592000;
   return tf * 60;
}

double PipSize(const string sym)
{
   if(InpPipOverridePrice > 0.0) return InpPipOverridePrice;
   double pt = MarketInfo(sym, MODE_POINT);
   int digits = (int)MarketInfo(sym, MODE_DIGITS);
   if(digits == 3 || digits == 5) return pt * 10.0;
   return pt;
}

int DigitsForSymbol(const string sym)
{
   return (int)MarketInfo(sym, MODE_DIGITS);
}

double NormalizeSymPrice(const string sym, const double price)
{
   return NormalizeDouble(price, DigitsForSymbol(sym));
}

double SpreadPips(const string sym)
{
   double spreadPoints = MarketInfo(sym, MODE_SPREAD);
   double pt = MarketInfo(sym, MODE_POINT);
   double pip = PipSize(sym);
   if(pip <= 0.0) return 999999.0;
   return spreadPoints * pt / pip;
}

bool IsSessionAllowed(const datetime t)
{
   if(!InpUseSessionFilter) return true;
   int h = TimeHour(t);
   if(InpSessionStartHour <= InpSessionEndHour)
      return (h >= InpSessionStartHour && h <= InpSessionEndHour);
   return (h >= InpSessionStartHour || h <= InpSessionEndHour);
}

double EMA(const string sym, const int period, const int shift)
{
   return iMA(sym, InpSignalTF, period, 0, MODE_EMA, PRICE_CLOSE, shift);
}

double ATR(const string sym, const int shift)
{
   return iATR(sym, InpSignalTF, InpATRPeriod, shift);
}

double RSI_TF(const string sym, const int tf, const int shift)
{
   return iRSI(sym, tf, InpTDIRSIPeriod, InpTDIPrice, shift);
}

double RSI_SMA_TF(const string sym, const int tf, const int period, const int shift)
{
   int p = MathMax(1, period);
   double sum = 0.0;
   int valid = 0;
   for(int i = 0; i < p; i++)
   {
      double v = RSI_TF(sym, tf, shift + i);
      if(v == EMPTY_VALUE) continue;
      sum += v;
      valid++;
   }
   if(valid <= 0) return 50.0;
   return sum / valid;
}

double TDIGreenTF(const string sym, const int tf, const int shift)
{
   return RSI_SMA_TF(sym, tf, InpTDIPriceLine, shift);
}

double TDIRedTF(const string sym, const int tf, const int shift)
{
   return RSI_SMA_TF(sym, tf, InpTDISignalLine, shift);
}

int CountConsecutiveTDIExtreme(const string sym, const bool isBuy)
{
   int count = 0;
   int maxLook = MathMax(InpMaxTDIExtremeBars + 20, 30);
   for(int i = 1; i <= maxLook; i++)
   {
      double green = TDIGreenTF(sym, InpSignalTF, i);
      if(isBuy)
      {
         if(green > InpTDIUpper) count++;
         else break;
      }
      else
      {
         if(green < InpTDILower) count++;
         else break;
      }
   }
   return count;
}

bool RecentTDICross(const string sym, const int tf, const bool isBuy, const int lookback)
{
   int lb = MathMax(1, lookback);
   for(int i = 1; i <= lb; i++)
   {
      double g0 = TDIGreenTF(sym, tf, i);
      double r0 = TDIRedTF(sym, tf, i);
      double g1 = TDIGreenTF(sym, tf, i + 1);
      double r1 = TDIRedTF(sym, tf, i + 1);

      if(isBuy)
      {
         if(g0 > r0 && g1 <= r1) return true;
      }
      else
      {
         if(g0 < r0 && g1 >= r1) return true;
      }
   }
   return false;
}

bool TDIConfirmation(const string sym, const int tf, const bool isBuy)
{
   if(!InpUseTDIFilter) return true;

   double g1 = TDIGreenTF(sym, tf, 1);
   double r1 = TDIRedTF(sym, tf, 1);
   double g2 = TDIGreenTF(sym, tf, 2);
   double r2 = TDIRedTF(sym, tf, 2);
   bool crossed = RecentTDICross(sym, tf, isBuy, InpTDIConfirmLookback);

   if(isBuy)
   {
      if(InpUseTDIHardExtremeBlock && g1 >= InpTDIExtremeUpper) return false;
      if(InpTDIMode <= 1) return (g1 > g2);
      if(InpTDIMode == 2) return (crossed || (g1 > r1 && g1 > g2));
      return (crossed || (g1 > r1 && g1 > g2 && r1 >= r2));
   }
   else
   {
      if(InpUseTDIHardExtremeBlock && g1 <= InpTDIExtremeLower) return false;
      if(InpTDIMode <= 1) return (g1 < g2);
      if(InpTDIMode == 2) return (crossed || (g1 < r1 && g1 < g2));
      return (crossed || (g1 < r1 && g1 < g2 && r1 <= r2));
   }
}

bool RecentM30TDITiming(const string sym, const bool isBuy)
{
   if(!InpUseM30TDIFilter) return true;
   if(iBars(sym, PERIOD_M30) < InpM30TDILookback + 10) return false;
   return RecentTDICross(sym, PERIOD_M30, isBuy, InpM30TDILookback);
}

void ResetSignal(SignalData &s)
{
   s.valid = false;
   s.isBuy = true;
   s.signalTime = 0;
   s.entry = 0.0;
   s.sl = 0.0;
   s.tp = 0.0;
   s.riskPips = 0.0;
   s.rewardPips = 0.0;
   s.rr = InpRewardR;
   s.ema8 = 0.0;
   s.ema20 = 0.0;
   s.ema50 = 0.0;
   s.atr14 = 0.0;
   s.gapMult = 0.0;
   s.tdiGreen = 0.0;
   s.tdiRed = 0.0;
   s.extremeBars = 0;
   s.wickPct = 0.0;
   s.slope = 0.0;
   s.rejectReason = "";
}

bool BuildSignal(const string sym, const bool isBuy, SignalData &s)
{
   ResetSignal(s);
   s.isBuy = isBuy;
   s.signalTime = iTime(sym, InpSignalTF, 1);

   if(iBars(sym, InpSignalTF) < InpSlopeLookback + 20)
   {
      s.rejectReason = "Not enough bars";
      return false;
   }

   if(!IsSessionAllowed(s.signalTime))
   {
      s.rejectReason = "Session filter";
      return false;
   }

   double spread = SpreadPips(sym);
   if(InpMaxSpreadPips > 0.0 && spread > InpMaxSpreadPips)
   {
      s.rejectReason = "Spread too high";
      return false;
   }

   double open1  = iOpen(sym, InpSignalTF, 1);
   double high1  = iHigh(sym, InpSignalTF, 1);
   double low1   = iLow(sym, InpSignalTF, 1);
   double close1 = iClose(sym, InpSignalTF, 1);
   double range1 = high1 - low1;

   if(range1 <= 0.0)
   {
      s.rejectReason = "Zero candle range";
      return false;
   }

   s.ema8 = EMA(sym, InpEMAFast, 1);
   s.ema20 = EMA(sym, InpEMASlow, 1);
   s.ema50 = EMA(sym, InpEMAFilter, 1);
   s.atr14 = ATR(sym, 1);
   s.tdiGreen = TDIGreenTF(sym, InpSignalTF, 1);
   s.tdiRed = TDIRedTF(sym, InpSignalTF, 1);
   s.slope = s.ema20 - EMA(sym, InpEMASlow, 1 + InpSlopeLookback);

   if(s.atr14 <= 0.0)
   {
      s.rejectReason = "ATR unavailable";
      return false;
   }

   s.gapMult = MathAbs(s.ema8 - s.ema20) / s.atr14;
   if(InpUseATRGapFilter && s.gapMult < InpMinEMAGapATR)
   {
      s.rejectReason = "EMA gap too small";
      return false;
   }

   double bufferPips = (InpSignalTF == PERIOD_D1 ? InpD1EntryBufferPips : InpH4EntryBufferPips);
   double buffer = bufferPips * PipSize(sym);
   double tolerance = s.atr14 * InpTouchToleranceATR;

   s.extremeBars = CountConsecutiveTDIExtreme(sym, isBuy);
   if(InpUseTDIExhaustionFilter && s.extremeBars > InpMaxTDIExtremeBars)
   {
      s.rejectReason = "TDI held exhaustion zone too long";
      return false;
   }

   if(!TDIConfirmation(sym, InpSignalTF, isBuy))
   {
      s.rejectReason = "TDI confirmation filter";
      return false;
   }

   if(!RecentM30TDITiming(sym, isBuy))
   {
      s.rejectReason = "M30 TDI timing filter";
      return false;
   }

   if(isBuy)
   {
      if(!(s.ema8 > s.ema20))
      {
         s.rejectReason = "EMA8 not above EMA20";
         return false;
      }
      if(!(close1 > s.ema20 && s.slope > 0.0))
      {
         s.rejectReason = "Uptrend filter failed";
         return false;
      }
      if(InpUseEMA50SafetyFilter && close1 < s.ema50)
      {
         s.rejectReason = "Close below EMA50";
         return false;
      }

      bool touchedEMA8 = (low1 <= s.ema8 + tolerance);
      bool closedAbove = (close1 > s.ema8);
      double lowerWick = MathMin(open1, close1) - low1;
      s.wickPct = lowerWick / range1;

      if(!touchedEMA8 || !closedAbove || s.wickPct < InpMinWickPercent)
      {
         s.rejectReason = "Buy wick rejection failed";
         return false;
      }

      s.entry = NormalizeSymPrice(sym, high1 + buffer);
      s.sl    = NormalizeSymPrice(sym, low1 - buffer);
      double risk = s.entry - s.sl;
      if(risk <= 0.0)
      {
         s.rejectReason = "Invalid buy risk";
         return false;
      }
      s.tp = NormalizeSymPrice(sym, s.entry + risk * InpRewardR);
      s.riskPips = risk / PipSize(sym);
      s.rewardPips = (s.tp - s.entry) / PipSize(sym);
      s.rr = InpRewardR;
   }
   else
   {
      if(!(s.ema20 > s.ema8))
      {
         s.rejectReason = "EMA20 not above EMA8";
         return false;
      }
      if(!(close1 < s.ema20 && s.slope < 0.0))
      {
         s.rejectReason = "Downtrend filter failed";
         return false;
      }
      if(InpUseEMA50SafetyFilter && close1 > s.ema50)
      {
         s.rejectReason = "Close above EMA50";
         return false;
      }

      bool touchedEMA8 = (high1 >= s.ema8 - tolerance);
      bool closedBelow = (close1 < s.ema8);
      double upperWick = high1 - MathMax(open1, close1);
      s.wickPct = upperWick / range1;

      if(!touchedEMA8 || !closedBelow || s.wickPct < InpMinWickPercent)
      {
         s.rejectReason = "Sell wick rejection failed";
         return false;
      }

      s.entry = NormalizeSymPrice(sym, low1 - buffer);
      s.sl    = NormalizeSymPrice(sym, high1 + buffer);
      double risk = s.sl - s.entry;
      if(risk <= 0.0)
      {
         s.rejectReason = "Invalid sell risk";
         return false;
      }
      s.tp = NormalizeSymPrice(sym, s.entry - risk * InpRewardR);
      s.riskPips = risk / PipSize(sym);
      s.rewardPips = (s.entry - s.tp) / PipSize(sym);
      s.rr = InpRewardR;
   }

   s.valid = true;
   return true;
}

string SignalMessage(const string sym, SignalData &s)
{
   string direction = (s.isBuy ? "BUY STOP / Ringed Low" : "SELL STOP / Ringed High");
   return StringFormat(
      "LPH Intraday Swing %s %s setup | %s | Entry: %s | SL: %s | TP: %s | Risk: %.1f pips | RR: %.2f | EMA gap: %.2f ATR | Wick: %.0f%% | TDI Green/Red: %.1f/%.1f",
      sym,
      TFToString(InpSignalTF),
      direction,
      DoubleToString(s.entry, DigitsForSymbol(sym)),
      DoubleToString(s.sl, DigitsForSymbol(sym)),
      DoubleToString(s.tp, DigitsForSymbol(sym)),
      s.riskPips,
      s.rr,
      s.gapMult,
      s.wickPct * 100.0,
      s.tdiGreen,
      s.tdiRed
   );
}

void SendSignalAlert(const string sym, SignalData &s)
{
   string msg = SignalMessage(sym, s);
   if(InpPopupAlert) Alert(msg);
   if(InpPushNotification) SendNotification(msg);
   if(InpEmailAlert) SendMail("LPH Intraday Swing Alert", msg);
   if(InpPrintLog) Print(msg);
}

void DeleteOldObjectsForSignal(const string prefix)
{
   // keep objects; do not delete historical signal markings by default
}

void DrawTrendLineSegment(const string name, const datetime t1, const double price, const color clr, const int style, const int width)
{
   datetime t2 = t1 + TFSeconds((int)InpSignalTF) * InpDrawForwardBars;
   if(ObjectFind(0, name) < 0)
      ObjectCreate(0, name, OBJ_TREND, 0, t1, price, t2, price);
   else
   {
      ObjectMove(0, name, 0, t1, price);
      ObjectMove(0, name, 1, t2, price);
   }
   ObjectSetInteger(0, name, OBJPROP_RAY_RIGHT, false);
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_STYLE, style);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, width);
}

void DrawSignalObjects(const string sym, SignalData &s)
{
   if(!InpDrawCurrentSymbolObjects) return;
   if(sym != Symbol()) return;

   double high1 = iHigh(sym, InpSignalTF, 1);
   double low1  = iLow(sym, InpSignalTF, 1);
   datetime t = s.signalTime;
   string dir = (s.isBuy ? "BUY" : "SELL");
   string prefix = "LPH_ISS_" + sym + "_" + TFToString(InpSignalTF) + "_" + dir + "_" + IntegerToString((int)t) + "_";

   string arrowName = prefix + "ARROW";
   double arrowPrice = (s.isBuy ? low1 - (s.atr14 * 0.15) : high1 + (s.atr14 * 0.15));
   int arrowCode = (s.isBuy ? 233 : 234);
   color arrowColor = (s.isBuy ? InpBuyColor : InpSellColor);

   if(ObjectFind(0, arrowName) < 0)
      ObjectCreate(0, arrowName, OBJ_ARROW, 0, t, arrowPrice);
   else
      ObjectMove(0, arrowName, 0, t, arrowPrice);

   ObjectSetInteger(0, arrowName, OBJPROP_ARROWCODE, arrowCode);
   ObjectSetInteger(0, arrowName, OBJPROP_COLOR, arrowColor);
   ObjectSetInteger(0, arrowName, OBJPROP_WIDTH, 2);

   DrawTrendLineSegment(prefix + "ENTRY", t, s.entry, InpEntryColor, STYLE_SOLID, 2);
   DrawTrendLineSegment(prefix + "SL",    t, s.sl,    InpSLColor,    STYLE_SOLID, 1);
   DrawTrendLineSegment(prefix + "TP",    t, s.tp,    InpTPColor,    STYLE_DASH,  1);

   string labelName = prefix + "LABEL";
   double labelPrice = (s.isBuy ? arrowPrice - (s.atr14 * 0.20) : arrowPrice + (s.atr14 * 0.20));
   if(ObjectFind(0, labelName) < 0)
      ObjectCreate(0, labelName, OBJ_TEXT, 0, t, labelPrice);
   else
      ObjectMove(0, labelName, 0, t, labelPrice);

   ObjectSetText(labelName, dir + " ISS", 8, "Arial", arrowColor);
}

void BuildSymbolList()
{
   ArrayResize(g_symbols, 0);

   if(InpScanMarketWatch)
   {
      int total = SymbolsTotal(true);
      for(int i = 0; i < total; i++)
      {
         string s = SymbolName(i, true);
         if(s == "") continue;
         int n = ArraySize(g_symbols);
         ArrayResize(g_symbols, n + 1);
         g_symbols[n] = s;
      }
   }
   else if(TrimString(InpSymbols) != "")
   {
      string parts[];
      int count = StringSplit(InpSymbols, ',', parts);
      for(int j = 0; j < count; j++)
      {
         string item = TrimString(parts[j]);
         if(item == "") continue;
         SymbolSelect(item, true);
         int n2 = ArraySize(g_symbols);
         ArrayResize(g_symbols, n2 + 1);
         g_symbols[n2] = item;
      }
   }
   else
   {
      ArrayResize(g_symbols, 1);
      g_symbols[0] = Symbol();
   }

   int size = ArraySize(g_symbols);
   ArrayResize(g_lastCheckedBar, size);
   ArrayResize(g_lastBuyAlertBar, size);
   ArrayResize(g_lastSellAlertBar, size);

   for(int k = 0; k < size; k++)
   {
      g_lastCheckedBar[k] = 0;
      g_lastBuyAlertBar[k] = 0;
      g_lastSellAlertBar[k] = 0;
   }
}

void CheckSymbol(const int index)
{
   if(index < 0 || index >= ArraySize(g_symbols)) return;
   string sym = g_symbols[index];
   if(sym == "") return;

   SymbolSelect(sym, true);

   datetime currentBar = iTime(sym, InpSignalTF, 0);
   datetime signalBar  = iTime(sym, InpSignalTF, 1);

   if(currentBar <= 0 || signalBar <= 0)
   {
      if(InpPrintLog) Print("LPH ISS alert: no data for ", sym, " ", TFToString(InpSignalTF));
      return;
   }

   // Only evaluate once per new signal timeframe bar, unless user disables once-per-bar behavior.
   if(InpAlertOnlyOncePerBar && g_lastCheckedBar[index] == currentBar)
      return;

   g_lastCheckedBar[index] = currentBar;

   SignalData buySig;
   SignalData sellSig;
   bool hasBuy = BuildSignal(sym, true, buySig);
   bool hasSell = BuildSignal(sym, false, sellSig);

   if(hasBuy)
   {
      if(!InpAlertOnlyOncePerBar || g_lastBuyAlertBar[index] != buySig.signalTime)
      {
         SendSignalAlert(sym, buySig);
         DrawSignalObjects(sym, buySig);
         g_lastBuyAlertBar[index] = buySig.signalTime;
      }
   }

   if(hasSell)
   {
      if(!InpAlertOnlyOncePerBar || g_lastSellAlertBar[index] != sellSig.signalTime)
      {
         SendSignalAlert(sym, sellSig);
         DrawSignalObjects(sym, sellSig);
         g_lastSellAlertBar[index] = sellSig.signalTime;
      }
   }
}

void ScanAllSymbols()
{
   int total = ArraySize(g_symbols);
   for(int i = 0; i < total; i++)
      CheckSymbol(i);
}

//------------------------- MT4 events -------------------------------
int OnInit()
{
   if(InpSignalTF != PERIOD_H4 && InpSignalTF != PERIOD_D1)
      Print("LPH ISS alert note: strategy was designed for H4/D1. Current TF input = ", TFToString(InpSignalTF));

   BuildSymbolList();
   EventSetTimer(MathMax(5, InpTimerSeconds));

   if(InpPrintLog)
   {
      Print("LPH Intraday Swing TDI HTF Alert initialized. TF=", TFToString(InpSignalTF), ", symbols=", ArraySize(g_symbols));
      for(int i = 0; i < ArraySize(g_symbols); i++) Print("  scanning: ", g_symbols[i]);
   }

   // Run once on attach, but duplicate protection still applies.
   ScanAllSymbols();
   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason)
{
   EventKillTimer();
}

void OnTimer()
{
   ScanAllSymbols();
}

int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
   return(rates_total);
}
//+------------------------------------------------------------------+
