//+------------------------------------------------------------------+
//| LPH_IntradaySwing_H4_Alert.mq4                                   |
//| Intraday Swing / Ringed Low & Ringed High H4 alert indicator      |
//| Coach T / Limitless PH                                            |
//+------------------------------------------------------------------+
#property strict
#property indicator_chart_window
#property indicator_buffers 0
#property version   "1.00"
#property description "Alerts for H4/D1 Intraday Swing Ringed Low/Ringed High EMA pullback continuation setups."

//------------------------- Inputs ----------------------------------
input ENUM_TIMEFRAMES InpSignalTF                 = PERIOD_H4;   // Default: H4
input bool            InpScanMarketWatch          = false;       // true = scan all Market Watch symbols
input string          InpSymbols                  = "";          // comma list; blank = current chart symbol
input int             InpTimerSeconds             = 20;

input int             InpEMAFast                  = 8;
input int             InpEMASlow                  = 20;
input int             InpEMAFilter                = 50;
input int             InpATRPeriod                = 14;

input bool            InpUseATRGapFilter          = true;
input double          InpMinEMAGapATR             = 0.20;
input int             InpSlopeLookback            = 5;
input double          InpMinWickPercent           = 0.40;
input double          InpTouchToleranceATR        = 0.05;

input bool            InpUseStochExtremeFilter    = true;
input int             InpStochK                   = 5;
input int             InpStochD                   = 3;
input int             InpStochSlowing             = 3;
input int             InpStochMethod              = MODE_SMA;
input int             InpStochPriceField          = 0;           // 0 = Low/High, 1 = Close/Close
input double          InpStochOverbought          = 80.0;
input double          InpStochOversold            = 20.0;
input int             InpMaxStochExtremeBars      = 5;

input bool            InpUseEMA50SafetyFilter     = false;
input bool            InpUseM30StochTimingFilter  = false;
input int             InpM30StochLookback         = 6;

input bool            InpUseSessionFilter         = false;
input int             InpSessionStartHour         = 0;           // server time
input int             InpSessionEndHour           = 23;          // server time

input double          InpH4EntryBufferPips        = 5.0;
input double          InpD1EntryBufferPips        = 10.0;
input double          InpRewardR                  = 1.0;
input double          InpMaxSpreadPips            = 3.0;
input double          InpPipOverridePrice         = 0.0;         // 0=auto. XAU may need 0.10 or 0.01 depending broker.

input bool            InpPopupAlert               = true;
input bool            InpPushNotification         = false;
input bool            InpEmailAlert               = false;
input bool            InpPrintLog                 = true;
input bool            InpAlertOnlyOncePerBar      = true;

input bool            InpDrawCurrentSymbolObjects = true;
input int             InpDrawForwardBars          = 20;
input color           InpBuyColor                 = clrLime;
input color           InpSellColor                = clrTomato;
input color           InpEntryColor               = clrDodgerBlue;
input color           InpSLColor                  = clrRed;
input color           InpTPColor                  = clrLimeGreen;

//------------------------- Runtime ---------------------------------
string   g_symbols[];
datetime g_lastCheckedBar[];
datetime g_lastBuyAlertBar[];
datetime g_lastSellAlertBar[];

//------------------------- Struct ----------------------------------
struct SignalData
{
   bool     valid;
   bool     isBuy;
   datetime signalTime;
   double   entry;
   double   sl;
   double   tp;
   double   riskPips;
   double   rewardPips;
   double   rr;
   double   ema8;
   double   ema20;
   double   ema50;
   double   atr14;
   double   gapMult;
   double   stochMain;
   double   stochSignal;
   int      extremeBars;
   double   wickPct;
   double   slope;
   string   rejectReason;
};

//------------------------- Helpers ---------------------------------
string TrimString(string text)
{
   text = StringTrimLeft(text);
   text = StringTrimRight(text);
   return text;
}

string TFToString(const int tf)
{
   if(tf == PERIOD_M1)  return "M1";
   if(tf == PERIOD_M5)  return "M5";
   if(tf == PERIOD_M15) return "M15";
   if(tf == PERIOD_M30) return "M30";
   if(tf == PERIOD_H1)  return "H1";
   if(tf == PERIOD_H4)  return "H4";
   if(tf == PERIOD_D1)  return "D1";
   if(tf == PERIOD_W1)  return "W1";
   if(tf == PERIOD_MN1) return "MN1";
   return IntegerToString(tf);
}

int TFSeconds(const int tf)
{
   if(tf == PERIOD_M1)  return 60;
   if(tf == PERIOD_M5)  return 300;
   if(tf == PERIOD_M15) return 900;
   if(tf == PERIOD_M30) return 1800;
   if(tf == PERIOD_H1)  return 3600;
   if(tf == PERIOD_H4)  return 14400;
   if(tf == PERIOD_D1)  return 86400;
   if(tf == PERIOD_W1)  return 604800;
   if(tf == PERIOD_MN1) return 2592000;
   return tf * 60;
}

double PipSize(const string sym)
{
   if(InpPipOverridePrice > 0.0) return InpPipOverridePrice;
   double pt = MarketInfo(sym, MODE_POINT);
   int digits = (int)MarketInfo(sym, MODE_DIGITS);
   if(digits == 3 || digits == 5) return pt * 10.0;
   return pt;
}

int DigitsForSymbol(const string sym)
{
   return (int)MarketInfo(sym, MODE_DIGITS);
}

double NormalizeSymPrice(const string sym, const double price)
{
   return NormalizeDouble(price, DigitsForSymbol(sym));
}

double SpreadPips(const string sym)
{
   double spreadPoints = MarketInfo(sym, MODE_SPREAD);
   double pt = MarketInfo(sym, MODE_POINT);
   double pip = PipSize(sym);
   if(pip <= 0.0) return 999999.0;
   return spreadPoints * pt / pip;
}

bool IsSessionAllowed(const datetime t)
{
   if(!InpUseSessionFilter) return true;
   int h = TimeHour(t);
   if(InpSessionStartHour <= InpSessionEndHour)
      return (h >= InpSessionStartHour && h <= InpSessionEndHour);
   return (h >= InpSessionStartHour || h <= InpSessionEndHour);
}

double EMA(const string sym, const int period, const int shift)
{
   return iMA(sym, InpSignalTF, period, 0, MODE_EMA, PRICE_CLOSE, shift);
}

double ATR(const string sym, const int shift)
{
   return iATR(sym, InpSignalTF, InpATRPeriod, shift);
}

double StochMainTF(const string sym, const int tf, const int shift)
{
   return iStochastic(sym, tf, InpStochK, InpStochD, InpStochSlowing, InpStochMethod, InpStochPriceField, MODE_MAIN, shift);
}

double StochSignalTF(const string sym, const int tf, const int shift)
{
   return iStochastic(sym, tf, InpStochK, InpStochD, InpStochSlowing, InpStochMethod, InpStochPriceField, MODE_SIGNAL, shift);
}

int CountConsecutiveStochExtreme(const string sym, const bool isBuy)
{
   int count = 0;
   int maxLook = MathMax(InpMaxStochExtremeBars + 20, 30);
   for(int i = 1; i <= maxLook; i++)
   {
      double main = StochMainTF(sym, InpSignalTF, i);
      if(isBuy)
      {
         if(main > InpStochOverbought) count++;
         else break;
      }
      else
      {
         if(main < InpStochOversold) count++;
         else break;
      }
   }
   return count;
}

bool RecentM30StochTiming(const string sym, const bool isBuy)
{
   if(!InpUseM30StochTimingFilter) return true;

   if(iBars(sym, PERIOD_M30) < InpM30StochLookback + 5) return false;

   for(int i = 1; i <= InpM30StochLookback; i++)
   {
      double m0 = StochMainTF(sym, PERIOD_M30, i);
      double s0 = StochSignalTF(sym, PERIOD_M30, i);
      double m1 = StochMainTF(sym, PERIOD_M30, i + 1);
      double s1 = StochSignalTF(sym, PERIOD_M30, i + 1);

      if(isBuy)
      {
         bool crossedUp = (m0 > s0 && m1 <= s1);
         bool cameFromOversold = (m1 <= InpStochOversold || m0 <= InpStochOversold);
         if(crossedUp && cameFromOversold) return true;
      }
      else
      {
         bool crossedDown = (m0 < s0 && m1 >= s1);
         bool cameFromOverbought = (m1 >= InpStochOverbought || m0 >= InpStochOverbought);
         if(crossedDown && cameFromOverbought) return true;
      }
   }
   return false;
}

void ResetSignal(SignalData &s)
{
   s.valid = false;
   s.isBuy = true;
   s.signalTime = 0;
   s.entry = 0.0;
   s.sl = 0.0;
   s.tp = 0.0;
   s.riskPips = 0.0;
   s.rewardPips = 0.0;
   s.rr = InpRewardR;
   s.ema8 = 0.0;
   s.ema20 = 0.0;
   s.ema50 = 0.0;
   s.atr14 = 0.0;
   s.gapMult = 0.0;
   s.stochMain = 0.0;
   s.stochSignal = 0.0;
   s.extremeBars = 0;
   s.wickPct = 0.0;
   s.slope = 0.0;
   s.rejectReason = "";
}

bool BuildSignal(const string sym, const bool isBuy, SignalData &s)
{
   ResetSignal(s);
   s.isBuy = isBuy;
   s.signalTime = iTime(sym, InpSignalTF, 1);

   if(iBars(sym, InpSignalTF) < InpSlopeLookback + 20)
   {
      s.rejectReason = "Not enough bars";
      return false;
   }

   if(!IsSessionAllowed(s.signalTime))
   {
      s.rejectReason = "Session filter";
      return false;
   }

   double spread = SpreadPips(sym);
   if(InpMaxSpreadPips > 0.0 && spread > InpMaxSpreadPips)
   {
      s.rejectReason = "Spread too high";
      return false;
   }

   double open1  = iOpen(sym, InpSignalTF, 1);
   double high1  = iHigh(sym, InpSignalTF, 1);
   double low1   = iLow(sym, InpSignalTF, 1);
   double close1 = iClose(sym, InpSignalTF, 1);
   double range1 = high1 - low1;

   if(range1 <= 0.0)
   {
      s.rejectReason = "Zero candle range";
      return false;
   }

   s.ema8 = EMA(sym, InpEMAFast, 1);
   s.ema20 = EMA(sym, InpEMASlow, 1);
   s.ema50 = EMA(sym, InpEMAFilter, 1);
   s.atr14 = ATR(sym, 1);
   s.stochMain = StochMainTF(sym, InpSignalTF, 1);
   s.stochSignal = StochSignalTF(sym, InpSignalTF, 1);
   s.slope = s.ema20 - EMA(sym, InpEMASlow, 1 + InpSlopeLookback);

   if(s.atr14 <= 0.0)
   {
      s.rejectReason = "ATR unavailable";
      return false;
   }

   s.gapMult = MathAbs(s.ema8 - s.ema20) / s.atr14;
   if(InpUseATRGapFilter && s.gapMult < InpMinEMAGapATR)
   {
      s.rejectReason = "EMA gap too small";
      return false;
   }

   double bufferPips = (InpSignalTF == PERIOD_D1 ? InpD1EntryBufferPips : InpH4EntryBufferPips);
   double buffer = bufferPips * PipSize(sym);
   double tolerance = s.atr14 * InpTouchToleranceATR;

   s.extremeBars = CountConsecutiveStochExtreme(sym, isBuy);
   if(InpUseStochExtremeFilter && s.extremeBars > InpMaxStochExtremeBars)
   {
      s.rejectReason = "Stoch held extreme too long";
      return false;
   }

   if(!RecentM30StochTiming(sym, isBuy))
   {
      s.rejectReason = "M30 stoch timing filter";
      return false;
   }

   if(isBuy)
   {
      if(!(s.ema8 > s.ema20))
      {
         s.rejectReason = "EMA8 not above EMA20";
         return false;
      }
      if(!(close1 > s.ema20 && s.slope > 0.0))
      {
         s.rejectReason = "Uptrend filter failed";
         return false;
      }
      if(InpUseEMA50SafetyFilter && close1 < s.ema50)
      {
         s.rejectReason = "Close below EMA50";
         return false;
      }

      bool touchedEMA8 = (low1 <= s.ema8 + tolerance);
      bool closedAbove = (close1 > s.ema8);
      double lowerWick = MathMin(open1, close1) - low1;
      s.wickPct = lowerWick / range1;

      if(!touchedEMA8 || !closedAbove || s.wickPct < InpMinWickPercent)
      {
         s.rejectReason = "Buy wick rejection failed";
         return false;
      }

      s.entry = NormalizeSymPrice(sym, high1 + buffer);
      s.sl    = NormalizeSymPrice(sym, low1 - buffer);
      double risk = s.entry - s.sl;
      if(risk <= 0.0)
      {
         s.rejectReason = "Invalid buy risk";
         return false;
      }
      s.tp = NormalizeSymPrice(sym, s.entry + risk * InpRewardR);
      s.riskPips = risk / PipSize(sym);
      s.rewardPips = (s.tp - s.entry) / PipSize(sym);
      s.rr = InpRewardR;
   }
   else
   {
      if(!(s.ema20 > s.ema8))
      {
         s.rejectReason = "EMA20 not above EMA8";
         return false;
      }
      if(!(close1 < s.ema20 && s.slope < 0.0))
      {
         s.rejectReason = "Downtrend filter failed";
         return false;
      }
      if(InpUseEMA50SafetyFilter && close1 > s.ema50)
      {
         s.rejectReason = "Close above EMA50";
         return false;
      }

      bool touchedEMA8 = (high1 >= s.ema8 - tolerance);
      bool closedBelow = (close1 < s.ema8);
      double upperWick = high1 - MathMax(open1, close1);
      s.wickPct = upperWick / range1;

      if(!touchedEMA8 || !closedBelow || s.wickPct < InpMinWickPercent)
      {
         s.rejectReason = "Sell wick rejection failed";
         return false;
      }

      s.entry = NormalizeSymPrice(sym, low1 - buffer);
      s.sl    = NormalizeSymPrice(sym, high1 + buffer);
      double risk = s.sl - s.entry;
      if(risk <= 0.0)
      {
         s.rejectReason = "Invalid sell risk";
         return false;
      }
      s.tp = NormalizeSymPrice(sym, s.entry - risk * InpRewardR);
      s.riskPips = risk / PipSize(sym);
      s.rewardPips = (s.entry - s.tp) / PipSize(sym);
      s.rr = InpRewardR;
   }

   s.valid = true;
   return true;
}

string SignalMessage(const string sym, SignalData &s)
{
   string direction = (s.isBuy ? "BUY STOP / Ringed Low" : "SELL STOP / Ringed High");
   return StringFormat(
      "LPH Intraday Swing %s %s setup | %s | Entry: %s | SL: %s | TP: %s | Risk: %.1f pips | RR: %.2f | EMA gap: %.2f ATR | Wick: %.0f%% | Stoch: %.1f",
      sym,
      TFToString(InpSignalTF),
      direction,
      DoubleToString(s.entry, DigitsForSymbol(sym)),
      DoubleToString(s.sl, DigitsForSymbol(sym)),
      DoubleToString(s.tp, DigitsForSymbol(sym)),
      s.riskPips,
      s.rr,
      s.gapMult,
      s.wickPct * 100.0,
      s.stochMain
   );
}

void SendSignalAlert(const string sym, SignalData &s)
{
   string msg = SignalMessage(sym, s);
   if(InpPopupAlert) Alert(msg);
   if(InpPushNotification) SendNotification(msg);
   if(InpEmailAlert) SendMail("LPH Intraday Swing Alert", msg);
   if(InpPrintLog) Print(msg);
}

void DeleteOldObjectsForSignal(const string prefix)
{
   // keep objects; do not delete historical signal markings by default
}

void DrawTrendLineSegment(const string name, const datetime t1, const double price, const color clr, const int style, const int width)
{
   datetime t2 = t1 + TFSeconds((int)InpSignalTF) * InpDrawForwardBars;
   if(ObjectFind(0, name) < 0)
      ObjectCreate(0, name, OBJ_TREND, 0, t1, price, t2, price);
   else
   {
      ObjectMove(0, name, 0, t1, price);
      ObjectMove(0, name, 1, t2, price);
   }
   ObjectSetInteger(0, name, OBJPROP_RAY_RIGHT, false);
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_STYLE, style);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, width);
}

void DrawSignalObjects(const string sym, SignalData &s)
{
   if(!InpDrawCurrentSymbolObjects) return;
   if(sym != Symbol()) return;

   double high1 = iHigh(sym, InpSignalTF, 1);
   double low1  = iLow(sym, InpSignalTF, 1);
   datetime t = s.signalTime;
   string dir = (s.isBuy ? "BUY" : "SELL");
   string prefix = "LPH_ISS_" + sym + "_" + TFToString(InpSignalTF) + "_" + dir + "_" + IntegerToString((int)t) + "_";

   string arrowName = prefix + "ARROW";
   double arrowPrice = (s.isBuy ? low1 - (s.atr14 * 0.15) : high1 + (s.atr14 * 0.15));
   int arrowCode = (s.isBuy ? 233 : 234);
   color arrowColor = (s.isBuy ? InpBuyColor : InpSellColor);

   if(ObjectFind(0, arrowName) < 0)
      ObjectCreate(0, arrowName, OBJ_ARROW, 0, t, arrowPrice);
   else
      ObjectMove(0, arrowName, 0, t, arrowPrice);

   ObjectSetInteger(0, arrowName, OBJPROP_ARROWCODE, arrowCode);
   ObjectSetInteger(0, arrowName, OBJPROP_COLOR, arrowColor);
   ObjectSetInteger(0, arrowName, OBJPROP_WIDTH, 2);

   DrawTrendLineSegment(prefix + "ENTRY", t, s.entry, InpEntryColor, STYLE_SOLID, 2);
   DrawTrendLineSegment(prefix + "SL",    t, s.sl,    InpSLColor,    STYLE_SOLID, 1);
   DrawTrendLineSegment(prefix + "TP",    t, s.tp,    InpTPColor,    STYLE_DASH,  1);

   string labelName = prefix + "LABEL";
   double labelPrice = (s.isBuy ? arrowPrice - (s.atr14 * 0.20) : arrowPrice + (s.atr14 * 0.20));
   if(ObjectFind(0, labelName) < 0)
      ObjectCreate(0, labelName, OBJ_TEXT, 0, t, labelPrice);
   else
      ObjectMove(0, labelName, 0, t, labelPrice);

   ObjectSetText(labelName, dir + " ISS", 8, "Arial", arrowColor);
}

void BuildSymbolList()
{
   ArrayResize(g_symbols, 0);

   if(InpScanMarketWatch)
   {
      int total = SymbolsTotal(true);
      for(int i = 0; i < total; i++)
      {
         string s = SymbolName(i, true);
         if(s == "") continue;
         int n = ArraySize(g_symbols);
         ArrayResize(g_symbols, n + 1);
         g_symbols[n] = s;
      }
   }
   else if(TrimString(InpSymbols) != "")
   {
      string parts[];
      int count = StringSplit(InpSymbols, ',', parts);
      for(int j = 0; j < count; j++)
      {
         string item = TrimString(parts[j]);
         if(item == "") continue;
         SymbolSelect(item, true);
         int n2 = ArraySize(g_symbols);
         ArrayResize(g_symbols, n2 + 1);
         g_symbols[n2] = item;
      }
   }
   else
   {
      ArrayResize(g_symbols, 1);
      g_symbols[0] = Symbol();
   }

   int size = ArraySize(g_symbols);
   ArrayResize(g_lastCheckedBar, size);
   ArrayResize(g_lastBuyAlertBar, size);
   ArrayResize(g_lastSellAlertBar, size);

   for(int k = 0; k < size; k++)
   {
      g_lastCheckedBar[k] = 0;
      g_lastBuyAlertBar[k] = 0;
      g_lastSellAlertBar[k] = 0;
   }
}

void CheckSymbol(const int index)
{
   if(index < 0 || index >= ArraySize(g_symbols)) return;
   string sym = g_symbols[index];
   if(sym == "") return;

   SymbolSelect(sym, true);

   datetime currentBar = iTime(sym, InpSignalTF, 0);
   datetime signalBar  = iTime(sym, InpSignalTF, 1);

   if(currentBar <= 0 || signalBar <= 0)
   {
      if(InpPrintLog) Print("LPH ISS alert: no data for ", sym, " ", TFToString(InpSignalTF));
      return;
   }

   // Only evaluate once per new signal timeframe bar, unless user disables once-per-bar behavior.
   if(InpAlertOnlyOncePerBar && g_lastCheckedBar[index] == currentBar)
      return;

   g_lastCheckedBar[index] = currentBar;

   SignalData buySig;
   SignalData sellSig;
   bool hasBuy = BuildSignal(sym, true, buySig);
   bool hasSell = BuildSignal(sym, false, sellSig);

   if(hasBuy)
   {
      if(!InpAlertOnlyOncePerBar || g_lastBuyAlertBar[index] != buySig.signalTime)
      {
         SendSignalAlert(sym, buySig);
         DrawSignalObjects(sym, buySig);
         g_lastBuyAlertBar[index] = buySig.signalTime;
      }
   }

   if(hasSell)
   {
      if(!InpAlertOnlyOncePerBar || g_lastSellAlertBar[index] != sellSig.signalTime)
      {
         SendSignalAlert(sym, sellSig);
         DrawSignalObjects(sym, sellSig);
         g_lastSellAlertBar[index] = sellSig.signalTime;
      }
   }
}

void ScanAllSymbols()
{
   int total = ArraySize(g_symbols);
   for(int i = 0; i < total; i++)
      CheckSymbol(i);
}

//------------------------- MT4 events -------------------------------
int OnInit()
{
   if(InpSignalTF != PERIOD_H4 && InpSignalTF != PERIOD_D1)
      Print("LPH ISS alert note: strategy was designed for H4/D1. Current TF input = ", TFToString(InpSignalTF));

   BuildSymbolList();
   EventSetTimer(MathMax(5, InpTimerSeconds));

   if(InpPrintLog)
   {
      Print("LPH Intraday Swing Alert initialized. TF=", TFToString(InpSignalTF), ", symbols=", ArraySize(g_symbols));
      for(int i = 0; i < ArraySize(g_symbols); i++) Print("  scanning: ", g_symbols[i]);
   }

   // Run once on attach, but duplicate protection still applies.
   ScanAllSymbols();
   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason)
{
   EventKillTimer();
}

void OnTimer()
{
   ScanAllSymbols();
}

int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
   return(rates_total);
}
//+------------------------------------------------------------------+
