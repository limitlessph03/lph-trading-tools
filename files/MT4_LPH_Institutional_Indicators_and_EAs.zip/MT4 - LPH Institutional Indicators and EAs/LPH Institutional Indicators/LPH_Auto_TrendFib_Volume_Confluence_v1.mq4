//+------------------------------------------------------------------+
//| LPH_Auto_TrendFib_Volume_Confluence_v1.mq4                       |
//| Auto trendlines + Fibonacci + volume-supported confluence         |
//| Built for Limitless PH / Coach T                                  |
//+------------------------------------------------------------------+
#property strict
#property indicator_chart_window
#property version "1.00"

// This is a visual analysis indicator. It does not trade.

input string Section_Analysis              = "----- ANALYSIS SETTINGS -----";
input int    AnalysisTimeframe             = 0;        // 0 = current chart timeframe
input int    LookbackBars                  = 650;
input int    PivotStrength                 = 5;
input int    MaxPivotsToScan               = 35;
input int    ATRPeriod                     = 14;
input double TouchToleranceATR             = 0.18;
input int    MinTrendlineSpanBars          = 35;
input int    MaxTrendlineBreaks            = 3;
input bool   RequireSlopeDirection         = true;     // rising support / falling resistance

input string Section_Volume                = "----- VOLUME SUPPORT -----";
input bool   UseVolumeConfirmation         = true;
input int    VolumeAvgPeriod               = 30;
input double VolumeConfirmMultiplier       = 1.20;
input double VolumeScoreWeight             = 2.50;

input string Section_Fib                   = "----- FIB SETTINGS -----";
input bool   DrawAutoFibonacci             = true;
input bool   UseEMAForFibBias              = true;
input int    BiasEMAPeriod                 = 50;
input int    BiasEMASlopeBars              = 5;
input double MinFibRangeATR                = 1.50;
input bool   DrawGoldenPocket              = true;
input double GoldenPocketA                 = 0.618;
input double GoldenPocketB                 = 0.650;

input string Section_Trendlines            = "----- TRENDLINE SETTINGS -----";
input bool   DrawAutoTrendlines            = true;
input bool   DrawSupportTrendline          = true;
input bool   DrawResistanceTrendline       = true;
input bool   ExtendTrendlinesRight         = true;
input bool   DrawTrendlineTouchLabels      = true;

input string Section_Alerts                = "----- ALERTS -----";
input bool   AlertsEnabled                 = false;
input bool   PushNotifications             = false;
input bool   AlertOncePerBar               = true;
input double ConfluenceAlertATR            = 0.25;     // price near fib + trendline within ATR distance

input string Section_Display               = "----- DISPLAY -----";
input bool   ShowDashboard                 = true;
input int    PanelCorner                   = 0;
input int    PanelX                        = 12;
input int    PanelY                        = 24;
input int    FontSize                      = 9;
input string FontName                      = "Consolas";
input int    FutureBarsForZones            = 60;
input bool   CleanOldObjectsEachRefresh    = true;

input string Section_Colors                = "----- COLORS -----";
input color  SupportColor                  = C'0,180,255';
input color  ResistanceColor               = C'255,120,40';
input color  FibColor                      = C'255,210,80';
input color  GoldenPocketColor             = C'120,90,20';
input color  VolumeConfirmedColor          = C'0,230,140';
input color  WeakColor                     = C'150,155,165';
input color  TextColor                     = C'230,230,230';
input color  WarningColor                  = C'255,70,80';

string PREFIX = "LPH_ATF_VOL_";
datetime lastAlertBarTime = 0;

//+------------------------------------------------------------------+
//| Structs                                                          |
//+------------------------------------------------------------------+
struct PivotPoint
{
   int shift;
   datetime time;
   double price;
   double volRatio;
};

struct TrendLineInfo
{
   bool valid;
   bool isSupport;
   int olderShift;
   int newerShift;
   datetime olderTime;
   datetime newerTime;
   double olderPrice;
   double newerPrice;
   double currentValue;
   int touches;
   int breaks;
   double volumeScore;
   double score;
};

struct FibInfo
{
   bool valid;
   bool bullish;
   int startShift;
   int endShift;
   datetime startTime;
   datetime endTime;
   double startPrice;
   double endPrice;
   double range;
   double fib236;
   double fib382;
   double fib500;
   double fib618;
   double fib650;
   double fib786;
   double anchorVolScore;
};

//+------------------------------------------------------------------+
//| Helpers                                                          |
//+------------------------------------------------------------------+
int TF()
{
   if(AnalysisTimeframe <= 0) return Period();
   return AnalysisTimeframe;
}

string TFName(int tf)
{
   if(tf == PERIOD_M1)  return "M1";
   if(tf == PERIOD_M5)  return "M5";
   if(tf == PERIOD_M15) return "M15";
   if(tf == PERIOD_M30) return "M30";
   if(tf == PERIOD_H1)  return "H1";
   if(tf == PERIOD_H4)  return "H4";
   if(tf == PERIOD_D1)  return "D1";
   if(tf == PERIOD_W1)  return "W1";
   if(tf == PERIOD_MN1) return "MN1";
   return IntegerToString(tf);
}

double PointValue()
{
   double p = MarketInfo(Symbol(), MODE_POINT);
   if(p <= 0.0) p = Point;
   return p;
}

double GetATR()
{
   double atr = iATR(Symbol(), TF(), ATRPeriod, 0);
   if(atr <= 0.0) atr = PointValue() * 100.0;
   return atr;
}

double H(int shift){ return iHigh(Symbol(), TF(), shift); }
double L(int shift){ return iLow(Symbol(), TF(), shift); }
double C(int shift){ return iClose(Symbol(), TF(), shift); }
datetime T(int shift){ return iTime(Symbol(), TF(), shift); }

double AvgVolume(int shift)
{
   double sum = 0.0;
   int n = 0;
   int bars = iBars(Symbol(), TF());

   for(int i = shift; i < shift + VolumeAvgPeriod && i < bars; i++)
   {
      sum += (double)iVolume(Symbol(), TF(), i);
      n++;
   }

   if(n <= 0) return 1.0;
   return sum / n;
}

double VolumeRatio(int shift)
{
   double avg = AvgVolume(shift + 1);
   if(avg <= 0.0) return 1.0;
   return (double)iVolume(Symbol(), TF(), shift) / avg;
}

bool IsSwingHigh(int shift)
{
   int bars = iBars(Symbol(), TF());
   if(shift < PivotStrength || shift + PivotStrength >= bars) return false;

   double p = H(shift);

   for(int i = 1; i <= PivotStrength; i++)
   {
      if(p <= H(shift - i)) return false; // newer side
      if(p <  H(shift + i)) return false; // older side
   }
   return true;
}

bool IsSwingLow(int shift)
{
   int bars = iBars(Symbol(), TF());
   if(shift < PivotStrength || shift + PivotStrength >= bars) return false;

   double p = L(shift);

   for(int i = 1; i <= PivotStrength; i++)
   {
      if(p >= L(shift - i)) return false; // newer side
      if(p >  L(shift + i)) return false; // older side
   }
   return true;
}

void AddPivot(PivotPoint &arr[], int &count, int shift, double price)
{
   ArrayResize(arr, count + 1);
   arr[count].shift = shift;
   arr[count].time = T(shift);
   arr[count].price = price;
   arr[count].volRatio = VolumeRatio(shift);
   count++;
}

void CollectPivots(PivotPoint &highs[], int &highCount, PivotPoint &lows[], int &lowCount)
{
   ArrayResize(highs, 0);
   ArrayResize(lows, 0);
   highCount = 0;
   lowCount = 0;

   int bars = iBars(Symbol(), TF());
   int maxShift = MathMin(LookbackBars, bars - PivotStrength - 2);

   for(int s = PivotStrength + 1; s <= maxShift; s++)
   {
      if(highCount < MaxPivotsToScan && IsSwingHigh(s))
         AddPivot(highs, highCount, s, H(s));

      if(lowCount < MaxPivotsToScan && IsSwingLow(s))
         AddPivot(lows, lowCount, s, L(s));

      if(highCount >= MaxPivotsToScan && lowCount >= MaxPivotsToScan)
         break;
   }
}

double LineValueByShift(int shift, int olderShift, double olderPrice, int newerShift, double newerPrice)
{
   if(olderShift == newerShift) return newerPrice;

   double ratio = (double)(shift - newerShift) / (double)(olderShift - newerShift);
   return newerPrice + (olderPrice - newerPrice) * ratio;
}

void ResetTrend(TrendLineInfo &tl)
{
   tl.valid = false;
   tl.isSupport = true;
   tl.olderShift = 0;
   tl.newerShift = 0;
   tl.olderTime = 0;
   tl.newerTime = 0;
   tl.olderPrice = 0.0;
   tl.newerPrice = 0.0;
   tl.currentValue = 0.0;
   tl.touches = 0;
   tl.breaks = 0;
   tl.volumeScore = 0.0;
   tl.score = -999999.0;
}

void FindBestTrendLine(PivotPoint &pivots[], int pivotCount, bool support, TrendLineInfo &best)
{
   ResetTrend(best);
   best.isSupport = support;

   if(pivotCount < 2) return;

   double atr = GetATR();
   double tol = atr * TouchToleranceATR;

   for(int newer = 0; newer < pivotCount - 1; newer++)
   {
      for(int older = newer + 1; older < pivotCount; older++)
      {
         int newerShift = pivots[newer].shift;
         int olderShift = pivots[older].shift;

         if(olderShift - newerShift < MinTrendlineSpanBars)
            continue;

         double newerPrice = pivots[newer].price;
         double olderPrice = pivots[older].price;

         if(RequireSlopeDirection)
         {
            if(support && newerPrice <= olderPrice) continue;       // rising support
            if(!support && newerPrice >= olderPrice) continue;      // falling resistance
         }

         int touches = 2;
         int breaks = 0;
         double volScore = pivots[newer].volRatio + pivots[older].volRatio;

         for(int s = newerShift; s <= olderShift; s++)
         {
            double line = LineValueByShift(s, olderShift, olderPrice, newerShift, newerPrice);

            if(support)
            {
               if(L(s) < line - tol) breaks++;
               if(MathAbs(L(s) - line) <= tol)
               {
                  touches++;
                  volScore += VolumeRatio(s);
               }
            }
            else
            {
               if(H(s) > line + tol) breaks++;
               if(MathAbs(H(s) - line) <= tol)
               {
                  touches++;
                  volScore += VolumeRatio(s);
               }
            }

            if(breaks > MaxTrendlineBreaks)
               break;
         }

         if(breaks > MaxTrendlineBreaks)
            continue;

         double currentLine = LineValueByShift(0, olderShift, olderPrice, newerShift, newerPrice);
         double distNow = MathAbs(C(0) - currentLine);
         double recencyBoost = 30.0 / MathMax(1.0, newerShift);
         double spanBoost = MathMin(20.0, (olderShift - newerShift) / 20.0);

         double score = touches * 10.0
                        - breaks * 12.0
                        + volScore * VolumeScoreWeight
                        + recencyBoost
                        + spanBoost;

         if(distNow < atr * 2.0)
            score += 6.0;

         if(score > best.score)
         {
            best.valid = true;
            best.isSupport = support;
            best.olderShift = olderShift;
            best.newerShift = newerShift;
            best.olderTime = pivots[older].time;
            best.newerTime = pivots[newer].time;
            best.olderPrice = olderPrice;
            best.newerPrice = newerPrice;
            best.currentValue = currentLine;
            best.touches = touches;
            best.breaks = breaks;
            best.volumeScore = volScore;
            best.score = score;
         }
      }
   }
}

bool BiasBullish()
{
   if(!UseEMAForFibBias)
   {
      double c0 = C(0);
      double cN = C(MathMax(1, BiasEMASlopeBars));
      return c0 >= cN;
   }

   double ema0 = iMA(Symbol(), TF(), BiasEMAPeriod, 0, MODE_EMA, PRICE_CLOSE, 0);
   double emaN = iMA(Symbol(), TF(), BiasEMAPeriod, 0, MODE_EMA, PRICE_CLOSE, BiasEMASlopeBars);

   return (C(0) >= ema0 && ema0 >= emaN);
}

void ResetFib(FibInfo &f)
{
   f.valid = false;
   f.bullish = true;
   f.startShift = 0;
   f.endShift = 0;
   f.startTime = 0;
   f.endTime = 0;
   f.startPrice = 0.0;
   f.endPrice = 0.0;
   f.range = 0.0;
   f.fib236 = 0.0;
   f.fib382 = 0.0;
   f.fib500 = 0.0;
   f.fib618 = 0.0;
   f.fib650 = 0.0;
   f.fib786 = 0.0;
   f.anchorVolScore = 0.0;
}

void BuildFibLevels(FibInfo &f)
{
   double hi, lo;

   if(f.bullish)
   {
      lo = f.startPrice;
      hi = f.endPrice;
      f.range = hi - lo;
      f.fib236 = hi - f.range * 0.236;
      f.fib382 = hi - f.range * 0.382;
      f.fib500 = hi - f.range * 0.500;
      f.fib618 = hi - f.range * 0.618;
      f.fib650 = hi - f.range * 0.650;
      f.fib786 = hi - f.range * 0.786;
   }
   else
   {
      hi = f.startPrice;
      lo = f.endPrice;
      f.range = hi - lo;
      f.fib236 = lo + f.range * 0.236;
      f.fib382 = lo + f.range * 0.382;
      f.fib500 = lo + f.range * 0.500;
      f.fib618 = lo + f.range * 0.618;
      f.fib650 = lo + f.range * 0.650;
      f.fib786 = lo + f.range * 0.786;
   }
}

void FindAutoFib(PivotPoint &highs[], int highCount, PivotPoint &lows[], int lowCount, FibInfo &fib)
{
   ResetFib(fib);

   if(highCount <= 0 || lowCount <= 0) return;

   bool bullish = BiasBullish();
   double atr = GetATR();

   double bestScore = -999999.0;

   if(bullish)
   {
      for(int lidx = 0; lidx < lowCount; lidx++)
      {
         for(int hidx = 0; hidx < highCount; hidx++)
         {
            // bullish impulse: low is older, high is newer
            if(lows[lidx].shift <= highs[hidx].shift) continue;

            double range = highs[hidx].price - lows[lidx].price;
            if(range < atr * MinFibRangeATR) continue;

            double volScore = lows[lidx].volRatio + highs[hidx].volRatio;
            double recency = 50.0 / MathMax(1.0, highs[hidx].shift);
            double score = (range / atr) * 5.0 + volScore * 8.0 + recency;

            if(score > bestScore)
            {
               bestScore = score;
               fib.valid = true;
               fib.bullish = true;
               fib.startShift = lows[lidx].shift;
               fib.endShift = highs[hidx].shift;
               fib.startTime = lows[lidx].time;
               fib.endTime = highs[hidx].time;
               fib.startPrice = lows[lidx].price;
               fib.endPrice = highs[hidx].price;
               fib.anchorVolScore = volScore;
            }
         }
      }
   }
   else
   {
      for(int hidx = 0; hidx < highCount; hidx++)
      {
         for(int lidx = 0; lidx < lowCount; lidx++)
         {
            // bearish impulse: high is older, low is newer
            if(highs[hidx].shift <= lows[lidx].shift) continue;

            double range = highs[hidx].price - lows[lidx].price;
            if(range < atr * MinFibRangeATR) continue;

            double volScore = highs[hidx].volRatio + lows[lidx].volRatio;
            double recency = 50.0 / MathMax(1.0, lows[lidx].shift);
            double score = (range / atr) * 5.0 + volScore * 8.0 + recency;

            if(score > bestScore)
            {
               bestScore = score;
               fib.valid = true;
               fib.bullish = false;
               fib.startShift = highs[hidx].shift;
               fib.endShift = lows[lidx].shift;
               fib.startTime = highs[hidx].time;
               fib.endTime = lows[lidx].time;
               fib.startPrice = highs[hidx].price;
               fib.endPrice = lows[lidx].price;
               fib.anchorVolScore = volScore;
            }
         }
      }
   }

   if(fib.valid)
      BuildFibLevels(fib);
}

//+------------------------------------------------------------------+
//| Object helpers                                                   |
//+------------------------------------------------------------------+
void DeleteByPrefix(string pfx)
{
   int total = ObjectsTotal();
   for(int i = total - 1; i >= 0; i--)
   {
      string name = ObjectName(i);
      if(StringFind(name, pfx) == 0)
         ObjectDelete(name);
   }
}

void DrawLabel(string name, string text, int x, int y, color clr, int size, string font="")
{
   if(font == "") font = FontName;

   string obj = PREFIX + name;
   if(ObjectFind(0, obj) < 0)
      ObjectCreate(0, obj, OBJ_LABEL, 0, 0, 0);

   ObjectSetInteger(0, obj, OBJPROP_CORNER, PanelCorner);
   ObjectSetInteger(0, obj, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, obj, OBJPROP_YDISTANCE, y);
   ObjectSetString(0, obj, OBJPROP_TEXT, text);
   ObjectSetInteger(0, obj, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, obj, OBJPROP_FONTSIZE, size);
   ObjectSetString(0, obj, OBJPROP_FONT, font);
   ObjectSetInteger(0, obj, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, obj, OBJPROP_HIDDEN, true);
}

void DrawPanel()
{
   string obj = PREFIX + "PANEL_BG";
   if(ObjectFind(0, obj) < 0)
      ObjectCreate(0, obj, OBJ_RECTANGLE_LABEL, 0, 0, 0);

   ObjectSetInteger(0, obj, OBJPROP_CORNER, PanelCorner);
   ObjectSetInteger(0, obj, OBJPROP_XDISTANCE, PanelX - 8);
   ObjectSetInteger(0, obj, OBJPROP_YDISTANCE, PanelY - 8);
   ObjectSetInteger(0, obj, OBJPROP_XSIZE, 455);
   ObjectSetInteger(0, obj, OBJPROP_YSIZE, 165);
   ObjectSetInteger(0, obj, OBJPROP_BGCOLOR, C'8,10,16');
   ObjectSetInteger(0, obj, OBJPROP_BORDER_COLOR, C'70,75,85');
   ObjectSetInteger(0, obj, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, obj, OBJPROP_HIDDEN, true);
}

void DrawTrendObj(string name, TrendLineInfo &tl, color clr)
{
   if(!tl.valid) return;

   string obj = PREFIX + name;
   if(ObjectFind(0, obj) < 0)
      ObjectCreate(0, obj, OBJ_TREND, 0, tl.olderTime, tl.olderPrice, tl.newerTime, tl.newerPrice);

   ObjectSetInteger(0, obj, OBJPROP_TIME1, tl.olderTime);
   ObjectSetDouble(0, obj, OBJPROP_PRICE1, tl.olderPrice);
   ObjectSetInteger(0, obj, OBJPROP_TIME2, tl.newerTime);
   ObjectSetDouble(0, obj, OBJPROP_PRICE2, tl.newerPrice);
   ObjectSetInteger(0, obj, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, obj, OBJPROP_WIDTH, 2);
   ObjectSetInteger(0, obj, OBJPROP_STYLE, STYLE_SOLID);
   ObjectSetInteger(0, obj, OBJPROP_BACK, true);
   ObjectSetInteger(0, obj, OBJPROP_RAY_RIGHT, ExtendTrendlinesRight);
   ObjectSetInteger(0, obj, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, obj, OBJPROP_HIDDEN, true);

   if(DrawTrendlineTouchLabels)
   {
      string label = PREFIX + name + "_LABEL";
      datetime future = T(0) + PeriodSeconds(TF()) * FutureBarsForZones;

      if(ObjectFind(0, label) < 0)
         ObjectCreate(0, label, OBJ_TEXT, 0, future, tl.currentValue);

      string side = tl.isSupport ? "AUTO SUPPORT TL" : "AUTO RESISTANCE TL";
      string txt = side + " | touches " + IntegerToString(tl.touches) +
                   " | vol " + DoubleToString(tl.volumeScore, 1);

      ObjectSetInteger(0, label, OBJPROP_TIME1, future);
      ObjectSetDouble(0, label, OBJPROP_PRICE1, tl.currentValue);
      ObjectSetString(0, label, OBJPROP_TEXT, txt);
      ObjectSetInteger(0, label, OBJPROP_COLOR, clr);
      ObjectSetInteger(0, label, OBJPROP_FONTSIZE, 9);
      ObjectSetString(0, label, OBJPROP_FONT, "Arial Bold");
      ObjectSetInteger(0, label, OBJPROP_SELECTABLE, false);
      ObjectSetInteger(0, label, OBJPROP_HIDDEN, true);
   }
}

void DrawHLineText(string name, double price, string text, color clr, int style=STYLE_DOT)
{
   string line = PREFIX + name;
   if(ObjectFind(0, line) < 0)
      ObjectCreate(0, line, OBJ_HLINE, 0, 0, price);

   ObjectSetDouble(0, line, OBJPROP_PRICE1, price);
   ObjectSetInteger(0, line, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, line, OBJPROP_STYLE, style);
   ObjectSetInteger(0, line, OBJPROP_WIDTH, 1);
   ObjectSetInteger(0, line, OBJPROP_BACK, true);
   ObjectSetInteger(0, line, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, line, OBJPROP_HIDDEN, true);

   string label = PREFIX + name + "_TXT";
   datetime future = T(0) + PeriodSeconds(TF()) * FutureBarsForZones;

   if(ObjectFind(0, label) < 0)
      ObjectCreate(0, label, OBJ_TEXT, 0, future, price);

   ObjectSetInteger(0, label, OBJPROP_TIME1, future);
   ObjectSetDouble(0, label, OBJPROP_PRICE1, price);
   ObjectSetString(0, label, OBJPROP_TEXT, text + " " + DoubleToString(price, Digits));
   ObjectSetInteger(0, label, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, label, OBJPROP_FONTSIZE, 8);
   ObjectSetString(0, label, OBJPROP_FONT, "Arial");
   ObjectSetInteger(0, label, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, label, OBJPROP_HIDDEN, true);
}

void DrawZone(string name, double p1, double p2, color clr)
{
   if(!DrawGoldenPocket) return;

   double top = MathMax(p1, p2);
   double bot = MathMin(p1, p2);
   string obj = PREFIX + name;

   datetime t1 = T(MathMin(LookbackBars, iBars(Symbol(), TF()) - 2));
   datetime t2 = T(0) + PeriodSeconds(TF()) * FutureBarsForZones;

   if(ObjectFind(0, obj) < 0)
      ObjectCreate(0, obj, OBJ_RECTANGLE, 0, t1, top, t2, bot);

   ObjectSetInteger(0, obj, OBJPROP_TIME1, t1);
   ObjectSetDouble(0, obj, OBJPROP_PRICE1, top);
   ObjectSetInteger(0, obj, OBJPROP_TIME2, t2);
   ObjectSetDouble(0, obj, OBJPROP_PRICE2, bot);
   ObjectSetInteger(0, obj, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, obj, OBJPROP_STYLE, STYLE_SOLID);
   ObjectSetInteger(0, obj, OBJPROP_WIDTH, 1);
   ObjectSetInteger(0, obj, OBJPROP_BACK, true);
   ObjectSetInteger(0, obj, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, obj, OBJPROP_HIDDEN, true);
}

void DrawFibObjects(FibInfo &fib)
{
   if(!fib.valid || !DrawAutoFibonacci) return;

   DrawHLineText("FIB_236", fib.fib236, "Fib 23.6", WeakColor, STYLE_DOT);
   DrawHLineText("FIB_382", fib.fib382, "Fib 38.2", FibColor, STYLE_DOT);
   DrawHLineText("FIB_500", fib.fib500, "Fib 50.0", FibColor, STYLE_DASH);
   DrawHLineText("FIB_618", fib.fib618, "Fib 61.8", FibColor, STYLE_SOLID);
   DrawHLineText("FIB_786", fib.fib786, "Fib 78.6", WeakColor, STYLE_DOT);

   if(DrawGoldenPocket)
   {
      DrawZone("GOLDEN_POCKET", fib.fib618, fib.fib650, GoldenPocketColor);
      DrawHLineText("FIB_650", fib.fib650, "Fib 65.0", FibColor, STYLE_DOT);
   }

   string a1 = PREFIX + "FIB_ANCHOR_LINE";
   if(ObjectFind(0, a1) < 0)
      ObjectCreate(0, a1, OBJ_TREND, 0, fib.startTime, fib.startPrice, fib.endTime, fib.endPrice);

   ObjectSetInteger(0, a1, OBJPROP_TIME1, fib.startTime);
   ObjectSetDouble(0, a1, OBJPROP_PRICE1, fib.startPrice);
   ObjectSetInteger(0, a1, OBJPROP_TIME2, fib.endTime);
   ObjectSetDouble(0, a1, OBJPROP_PRICE2, fib.endPrice);
   ObjectSetInteger(0, a1, OBJPROP_COLOR, FibColor);
   ObjectSetInteger(0, a1, OBJPROP_STYLE, STYLE_DASH);
   ObjectSetInteger(0, a1, OBJPROP_WIDTH, 1);
   ObjectSetInteger(0, a1, OBJPROP_RAY_RIGHT, false);
   ObjectSetInteger(0, a1, OBJPROP_BACK, true);
   ObjectSetInteger(0, a1, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, a1, OBJPROP_HIDDEN, true);
}

void DrawDashboard(TrendLineInfo &support, TrendLineInfo &resistance, FibInfo &fib)
{
   if(!ShowDashboard) return;

   DrawPanel();

   int y = PanelY;
   DrawLabel("DASH_TITLE", "LPH AUTO TREND + FIB + VOLUME", PanelX, y, clrGold, FontSize + 2, "Arial Bold");
   y += 18;

   DrawLabel("DASH_TF", "TF: " + TFName(TF()) +
            " | Pivot strength: " + IntegerToString(PivotStrength) +
            " | Vol filter: " + (UseVolumeConfirmation ? "ON" : "OFF"),
            PanelX, y, TextColor, FontSize, FontName);
   y += 17;

   string sLine = "Support TL: ";
   if(support.valid)
      sLine += "score " + DoubleToString(support.score, 1) +
               " | touches " + IntegerToString(support.touches) +
               " | breaks " + IntegerToString(support.breaks) +
               " | now " + DoubleToString(support.currentValue, Digits);
   else
      sLine += "not enough clean pivots";

   DrawLabel("DASH_SUPPORT", sLine, PanelX, y, support.valid ? SupportColor : WeakColor, FontSize, FontName);
   y += 17;

   string rLine = "Resistance TL: ";
   if(resistance.valid)
      rLine += "score " + DoubleToString(resistance.score, 1) +
               " | touches " + IntegerToString(resistance.touches) +
               " | breaks " + IntegerToString(resistance.breaks) +
               " | now " + DoubleToString(resistance.currentValue, Digits);
   else
      rLine += "not enough clean pivots";

   DrawLabel("DASH_RESIST", rLine, PanelX, y, resistance.valid ? ResistanceColor : WeakColor, FontSize, FontName);
   y += 17;

   string fibLine = "Auto Fib: ";
   if(fib.valid)
   {
      fibLine += (fib.bullish ? "Bullish pullback map" : "Bearish pullback map") +
                 " | GP " + DoubleToString(MathMin(fib.fib618, fib.fib650), Digits) +
                 "-" + DoubleToString(MathMax(fib.fib618, fib.fib650), Digits) +
                 " | anchor vol " + DoubleToString(fib.anchorVolScore, 1);
   }
   else
      fibLine += "no valid impulse range";

   DrawLabel("DASH_FIB", fibLine, PanelX, y, fib.valid ? FibColor : WeakColor, FontSize, FontName);
   y += 17;

   string conf = "Confluence: ";
   double atr = GetATR();
   double price = C(0);
   bool nearFib = false;
   bool nearTL = false;

   if(fib.valid)
      nearFib = (MathAbs(price - fib.fib618) <= atr * ConfluenceAlertATR ||
                 MathAbs(price - fib.fib650) <= atr * ConfluenceAlertATR ||
                 MathAbs(price - fib.fib500) <= atr * ConfluenceAlertATR);

   if(support.valid && MathAbs(price - support.currentValue) <= atr * ConfluenceAlertATR) nearTL = true;
   if(resistance.valid && MathAbs(price - resistance.currentValue) <= atr * ConfluenceAlertATR) nearTL = true;

   if(nearFib && nearTL)
      conf += "PRICE NEAR FIB + TRENDLINE";
   else if(nearFib)
      conf += "price near fib level";
   else if(nearTL)
      conf += "price near trendline";
   else
      conf += "waiting";

   DrawLabel("DASH_CONF", conf, PanelX, y, (nearFib && nearTL) ? VolumeConfirmedColor : TextColor, FontSize, FontName);
}

void CheckConfluenceAlert(TrendLineInfo &support, TrendLineInfo &resistance, FibInfo &fib)
{
   if(!AlertsEnabled) return;

   datetime barTime = T(0);
   if(AlertOncePerBar && lastAlertBarTime == barTime) return;

   double atr = GetATR();
   double price = C(0);

   bool nearFib = false;
   bool nearTL = false;

   if(fib.valid)
      nearFib = (MathAbs(price - fib.fib618) <= atr * ConfluenceAlertATR ||
                 MathAbs(price - fib.fib650) <= atr * ConfluenceAlertATR ||
                 MathAbs(price - fib.fib500) <= atr * ConfluenceAlertATR);

   if(support.valid && MathAbs(price - support.currentValue) <= atr * ConfluenceAlertATR) nearTL = true;
   if(resistance.valid && MathAbs(price - resistance.currentValue) <= atr * ConfluenceAlertATR) nearTL = true;

   if(nearFib && nearTL)
   {
      string msg = "LPH TrendFib Volume | " + Symbol() + " " + TFName(TF()) + " near Fib + Trendline confluence.";
      Alert(msg);
      if(PushNotifications) SendNotification(msg);
      lastAlertBarTime = barTime;
   }
}

//+------------------------------------------------------------------+
//| Main                                                             |
//+------------------------------------------------------------------+
void Refresh()
{
   if(CleanOldObjectsEachRefresh)
      DeleteByPrefix(PREFIX);

   PivotPoint highs[];
   PivotPoint lows[];
   int highCount = 0;
   int lowCount = 0;

   CollectPivots(highs, highCount, lows, lowCount);

   TrendLineInfo support;
   TrendLineInfo resistance;
   ResetTrend(support);
   ResetTrend(resistance);

   if(DrawAutoTrendlines)
   {
      if(DrawSupportTrendline)
         FindBestTrendLine(lows, lowCount, true, support);

      if(DrawResistanceTrendline)
         FindBestTrendLine(highs, highCount, false, resistance);

      DrawTrendObj("SUPPORT_TL", support, SupportColor);
      DrawTrendObj("RESISTANCE_TL", resistance, ResistanceColor);
   }

   FibInfo fib;
   ResetFib(fib);

   if(DrawAutoFibonacci)
   {
      FindAutoFib(highs, highCount, lows, lowCount, fib);
      DrawFibObjects(fib);
   }

   DrawDashboard(support, resistance, fib);
   CheckConfluenceAlert(support, resistance, fib);

   ChartRedraw(0);
}

int OnInit()
{
   IndicatorShortName("LPH Auto Trend + Fib + Volume v1");
   Refresh();
   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason)
{
   DeleteByPrefix(PREFIX);
}

int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
   static datetime lastRun = 0;

   if(TimeCurrent() - lastRun >= 2)
   {
      Refresh();
      lastRun = TimeCurrent();
   }

   return(rates_total);
}
//+------------------------------------------------------------------+
