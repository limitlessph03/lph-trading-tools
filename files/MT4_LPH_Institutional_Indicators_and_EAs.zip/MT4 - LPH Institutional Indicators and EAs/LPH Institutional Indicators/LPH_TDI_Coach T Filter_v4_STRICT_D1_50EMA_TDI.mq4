//+------------------------------------------------------------------+
//|                          CoachT_TDI_Filter_v4_STRICT_D1_50EMA_TDI.mq4 |
//|                        TDI Macro Bias / Momentum Confirmation Tool|
//|                                        Built for LimitlessPH CoachT|
//+------------------------------------------------------------------+
#property strict
#property indicator_separate_window
#property indicator_minimum 0
#property indicator_maximum 100
#property indicator_buffers 7

#property indicator_color1 Lime
#property indicator_color2 Red
#property indicator_color3 Gold
#property indicator_color4 DodgerBlue
#property indicator_color5 DodgerBlue

#property indicator_width1 2
#property indicator_width2 1
#property indicator_width3 2
#property indicator_width4 1
#property indicator_width5 1

#property indicator_level1 32
#property indicator_level2 50
#property indicator_level3 68
#property indicator_levelcolor DimGray
#property indicator_levelstyle STYLE_DOT

//------------------------- USER INPUTS -----------------------------

enum BiasMode
{
   Bias_Neutral = 0,   // Allow both bullish and bearish states
   Bias_Bullish = 1,   // Only bullish continuation/reload states
   Bias_Bearish = 2    // Only bearish continuation/reload states
};

input string   Section_TDI_Settings      = "----- TDI SETTINGS -----";
input int      RSI_Period                = 14;
input int      Volatility_Band_Period    = 40;
input int      RSI_Price_Line_MA         = 2;     // Green line
input int      Trade_Signal_Line_MA      = 7;     // Red line
input int      Market_Base_Line_MA       = 50;    // Yellow line
input double   Band_Deviation            = 1.6185;

input string   Section_Bias_Filter       = "----- MACRO / TREND FILTER -----";
input BiasMode External_Bias             = Bias_Neutral;
input bool     Use_EMA_Filter            = true;
input int      Fast_EMA_Period           = 50;
input int      Slow_EMA_Period           = 200;
input bool     Require_200EMA_Agreement  = true;
input double   EMA_Touch_Tolerance_Pips  = 8.0;
input bool     Require_Fresh_EMA_Rejection = true;
input int      EMA_Pullback_Lookback_Bars  = 1;      // 1 = latest closed candle only
input bool     Use_EMA_Chop_Filter         = true;
input int      EMA_Chop_Lookback_Bars      = 10;
input int      Max_EMA_Crosses_For_Trade   = 2;

input string   Section_Signal_Logic      = "----- SIGNAL LOGIC -----";
input int      Signal_Shift              = 1;     // 1 = closed candle, 0 = live candle
input double   Slope_Minimum             = 0.80;  // Minimum TDI movement in RSI points
input double   Yellow_Flat_Tolerance     = 0.20;  // Allows flat-to-rising/falling yellow line
input double   Chop_Zone_Around_50       = 5.0;   // Green/red tangled around 50
input double   Min_Band_Width            = 10.0;  // Tight bands = chop
input int      Lookback_For_Sharkfin     = 1;

input string   Section_Alerts            = "----- ALERTS / DISPLAY -----";
input bool     Enable_Alerts             = true;
input bool     Alert_Continuation        = false;
input bool     Alert_Reload              = true;  // actual pullback/reload setup alerts
input bool     Alert_Chop_Warning        = true;
input string   Section_Alert_Control     = "----- ALERT CONTROL -----";
input bool     Restrict_Alerts_To_Timeframe = true;   // true = only alert on Alert_Timeframe
input ENUM_TIMEFRAMES Alert_Timeframe    = PERIOD_D1; // Daily-only alerts by default
input bool     Alert_Only_When_Status_Changes = true; // prevents repeated continuation alerts
input bool     Suppress_Initial_Alert    = true;      // prevents alert spam when loading template
input int      Alert_Cooldown_Minutes    = 0;         // 0 = no cooldown
input bool     Popup_Alert               = true;
input bool     Push_Notification         = true;
input bool     Email_Alert               = false;
input bool     Show_Status_Label         = true;
input bool     Label_Compact_Mode        = true;      // true = subtle one-line label
input bool     Label_Use_Status_Color    = false;     // false = always use subtle fixed color
input color    Label_Text_Color          = clrSilver; // subtle fixed label color
input string   Label_Font                = "Arial";
input int      Label_Corner              = 1;         // 0 TL, 1 TR, 2 BL, 3 BR
input int      Label_X_Distance          = 20;
input int      Label_Y_Distance          = 20;
input int      Label_Font_Size           = 12;
input bool     Label_In_TDI_Window       = true;      // true = place status label inside the TDI subwindow

//------------------------- BUFFERS ---------------------------------

double GreenBuffer[];     // RSI Price Line
double RedBuffer[];       // Trade Signal Line
double YellowBuffer[];    // Market Base Line
double UpperBandBuffer[]; // Upper volatility band
double LowerBandBuffer[]; // Lower volatility band
double RsiRawBuffer[];    // calculation buffer
double BandBasisBuffer[]; // calculation buffer

//------------------------- GLOBALS ---------------------------------

datetime LastAlertBarTime = 0;
datetime LastAlertSendTime = 0;
string   LastAlertStatus = "";
bool     AlertEngineReady = false;
string   StatusObjectName;
string   IndicatorWindowTitle;

//+------------------------------------------------------------------+
//| Custom indicator initialization                                  |
//+------------------------------------------------------------------+
int OnInit()
{
   IndicatorShortName("CoachT TDI Macro Filter v4 STRICT D1 50EMA");
   IndicatorWindowTitle = "CoachT TDI Macro Filter v4 STRICT D1 50EMA";

   SetIndexBuffer(0, GreenBuffer);
   SetIndexStyle(0, DRAW_LINE);
   SetIndexLabel(0, "TDI Green / RSI Price Line");

   SetIndexBuffer(1, RedBuffer);
   SetIndexStyle(1, DRAW_LINE);
   SetIndexLabel(1, "TDI Red / Trade Signal");

   SetIndexBuffer(2, YellowBuffer);
   SetIndexStyle(2, DRAW_LINE);
   SetIndexLabel(2, "TDI Yellow / Market Base Line");

   SetIndexBuffer(3, UpperBandBuffer);
   SetIndexStyle(3, DRAW_LINE);
   SetIndexLabel(3, "TDI Upper Volatility Band");

   SetIndexBuffer(4, LowerBandBuffer);
   SetIndexStyle(4, DRAW_LINE);
   SetIndexLabel(4, "TDI Lower Volatility Band");

   SetIndexBuffer(5, RsiRawBuffer);
   SetIndexStyle(5, DRAW_NONE);

   SetIndexBuffer(6, BandBasisBuffer);
   SetIndexStyle(6, DRAW_NONE);

   ArraySetAsSeries(GreenBuffer, true);
   ArraySetAsSeries(RedBuffer, true);
   ArraySetAsSeries(YellowBuffer, true);
   ArraySetAsSeries(UpperBandBuffer, true);
   ArraySetAsSeries(LowerBandBuffer, true);
   ArraySetAsSeries(RsiRawBuffer, true);
   ArraySetAsSeries(BandBasisBuffer, true);

   StatusObjectName = "CoachT_TDI_Status_v4_TDIpane_" + Symbol() + "_" + IntegerToString(Period());

   // Remove old stuck labels from v1/v2/v3 so they do not appear on the right side.
   CleanupOldStatusLabels();

   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
//| Deinitialization                                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   if(ObjectFind(0, StatusObjectName) >= 0)
      ObjectDelete(0, StatusObjectName);
}

//+------------------------------------------------------------------+
//| Custom indicator calculation                                     |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
   if(rates_total < MathMax(Market_Base_Line_MA, Volatility_Band_Period) + 10)
      return(0);

   ArraySetAsSeries(time, true);
   ArraySetAsSeries(open, true);
   ArraySetAsSeries(high, true);
   ArraySetAsSeries(low, true);
   ArraySetAsSeries(close, true);

   int start = rates_total - prev_calculated;
   if(prev_calculated == 0 || start > rates_total - 1)
      start = rates_total - 1;

   // Recalculate enough historical bars for MA-on-array accuracy.
   int maxPeriod = MathMax(MathMax(RSI_Price_Line_MA, Trade_Signal_Line_MA),
                           MathMax(Market_Base_Line_MA, Volatility_Band_Period));
   start = MathMin(rates_total - 1, start + maxPeriod + 10);

   // Raw RSI
   for(int i = start; i >= 0; i--)
   {
      RsiRawBuffer[i] = iRSI(NULL, 0, RSI_Period, PRICE_CLOSE, i);
   }

   // TDI lines
   for(int j = start; j >= 0; j--)
   {
      GreenBuffer[j]  = iMAOnArray(RsiRawBuffer, rates_total, RSI_Price_Line_MA,    0, MODE_SMA, j);
      RedBuffer[j]    = iMAOnArray(RsiRawBuffer, rates_total, Trade_Signal_Line_MA, 0, MODE_SMA, j);
      YellowBuffer[j] = iMAOnArray(RsiRawBuffer, rates_total, Market_Base_Line_MA,  0, MODE_SMA, j);
   }

   // Volatility bands based on smoothed RSI price line.
   for(int k = start; k >= 0; k--)
   {
      double basis = AverageOnSeries(GreenBuffer, k, Volatility_Band_Period, rates_total);
      double dev   = StdDevOnSeries(GreenBuffer, k, Volatility_Band_Period, rates_total, basis);

      BandBasisBuffer[k] = basis;

      if(basis == EMPTY_VALUE || dev == EMPTY_VALUE)
      {
         UpperBandBuffer[k] = EMPTY_VALUE;
         LowerBandBuffer[k] = EMPTY_VALUE;
      }
      else
      {
         UpperBandBuffer[k] = basis + (Band_Deviation * dev);
         LowerBandBuffer[k] = basis - (Band_Deviation * dev);
      }
   }

   int s = Signal_Shift;
   if(s < 0) s = 0;

   int safetyLookback = MathMax(MathMax(Lookback_For_Sharkfin, EMA_Pullback_Lookback_Bars), EMA_Chop_Lookback_Bars);
   if(s + safetyLookback + 5 >= rates_total)
      return(rates_total);

   string status = GetTDIStatus(s, time, open, high, low, close);
   color statusColor = StatusColor(status);

   if(Show_Status_Label)
      DrawStatusLabel(status, statusColor);

   if(Enable_Alerts)
      ProcessAlerts(status, s, time);

   return(rates_total);
}

//+------------------------------------------------------------------+
//| Core TDI status logic                                            |
//+------------------------------------------------------------------+
string GetTDIStatus(int s,
                    const datetime &time[],
                    const double &open[],
                    const double &high[],
                    const double &low[],
                    const double &close[])
{
   double greenNow  = GreenBuffer[s];
   double greenPrev = GreenBuffer[s+1];
   double greenOld  = GreenBuffer[s+2];

   double redNow    = RedBuffer[s];
   double redPrev   = RedBuffer[s+1];

   double yellowNow = YellowBuffer[s];
   double yellowOld = YellowBuffer[s+2];

   double upperNow  = UpperBandBuffer[s];
   double lowerNow  = LowerBandBuffer[s];

   if(greenNow == EMPTY_VALUE || redNow == EMPTY_VALUE || yellowNow == EMPTY_VALUE ||
      upperNow == EMPTY_VALUE || lowerNow == EMPTY_VALUE)
      return("WAIT: not enough TDI data");

   bool crossUp       = (greenNow > redNow && greenPrev <= redPrev);
   bool crossDown     = (greenNow < redNow && greenPrev >= redPrev);
   bool greenRising   = (greenNow - greenOld >= Slope_Minimum);
   bool greenFalling  = (greenOld - greenNow >= Slope_Minimum);
   bool yellowRising  = (yellowNow - yellowOld >= -Yellow_Flat_Tolerance);
   bool yellowFalling = (yellowOld - yellowNow >= -Yellow_Flat_Tolerance);

   bool above50       = (greenNow >= 50.0);
   bool below50       = (greenNow <= 50.0);

   bool greenAboveRed    = (greenNow > redNow);
   bool greenBelowRed    = (greenNow < redNow);
   bool greenAboveYellow = (greenNow > yellowNow);
   bool greenBelowYellow = (greenNow < yellowNow);

   bool bullBiasAllowed = (External_Bias == Bias_Neutral || External_Bias == Bias_Bullish);
   bool bearBiasAllowed = (External_Bias == Bias_Neutral || External_Bias == Bias_Bearish);

   bool priceBullOK = true;
   bool priceBearOK = true;
   bool bullPullbackZone = true;
   bool bearPullbackZone = true;

   if(Use_EMA_Filter)
   {
      double emaFastNow = iMA(NULL, 0, Fast_EMA_Period, 0, MODE_EMA, PRICE_CLOSE, s);
      double emaSlowNow = iMA(NULL, 0, Slow_EMA_Period, 0, MODE_EMA, PRICE_CLOSE, s);

      double tol = EMA_Touch_Tolerance_Pips * PipValue();

      priceBullOK = (close[s] > emaFastNow);
      priceBearOK = (close[s] < emaFastNow);

      if(Require_200EMA_Agreement)
      {
         priceBullOK = priceBullOK && close[s] > emaSlowNow;
         priceBearOK = priceBearOK && close[s] < emaSlowNow;
      }

      // Fresh 50 EMA rejection logic.
      // Default EMA_Pullback_Lookback_Bars = 1 means only the latest closed candle counts.
      bullPullbackZone = false;
      bearPullbackZone = false;

      int emaLookback = MathMax(1, EMA_Pullback_Lookback_Bars);
      for(int lb = 0; lb < emaLookback; lb++)
      {
         int idx = s + lb;
         double emaFastAt = iMA(NULL, 0, Fast_EMA_Period, 0, MODE_EMA, PRICE_CLOSE, idx);

         bool bullTouchedEMA = (low[idx] <= emaFastAt + tol);
         bool bearTouchedEMA = (high[idx] >= emaFastAt - tol);

         bool bullClosedBack = (!Require_Fresh_EMA_Rejection || close[idx] > emaFastAt);
         bool bearClosedBack = (!Require_Fresh_EMA_Rejection || close[idx] < emaFastAt);

         if(bullTouchedEMA && bullClosedBack)
            bullPullbackZone = true;

         if(bearTouchedEMA && bearClosedBack)
            bearPullbackZone = true;
      }
   }

   bool sharkfinBull = BullishSharkfin(s);
   bool sharkfinBear = BearishSharkfin(s);

   double bandWidth = upperNow - lowerNow;
   bool tangledAround50 = (MathAbs(greenNow - 50.0) <= Chop_Zone_Around_50 &&
                           MathAbs(redNow   - 50.0) <= Chop_Zone_Around_50);

   bool tightBands = (bandWidth <= Min_Band_Width);
   bool emaChop = (Use_EMA_Filter && Use_EMA_Chop_Filter && IsEMAChoppy(s, close));

   bool chop = (tangledAround50 || tightBands || emaChop);

   // 1. Bullish continuation:
   // Bias favors long, price above/reclaiming 50 EMA, green > red/yellow,
   // yellow flat-to-rising, green above 50.
   bool bullishContinuation =
      bullBiasAllowed &&
      priceBullOK &&
      greenAboveRed &&
      greenAboveYellow &&
      yellowRising &&
      above50 &&
      !chop;

   // 2. Bullish pullback/reload:
   // Bias favors long, price pulled back into EMA/support area,
   // TDI was stretched below band/32, then hooks/crosses up.
   bool bullishReload =
      bullBiasAllowed &&
      bullPullbackZone &&
      (sharkfinBull || GreenBuffer[s+1] <= 32.0 || GreenBuffer[s] <= 32.0) &&
      (crossUp || greenRising) &&
      !chop;

   // 3. Bearish continuation:
   // Bias favors short, price below/rejecting 50 EMA, green < red/yellow,
   // yellow flat-to-falling, green below 50.
   bool bearishContinuation =
      bearBiasAllowed &&
      priceBearOK &&
      greenBelowRed &&
      greenBelowYellow &&
      yellowFalling &&
      below50 &&
      !chop;

   // 4. Bearish pullback/reload:
   // Bias favors short, price rallied into EMA/resistance area,
   // TDI was stretched above band/68, then hooks/crosses down.
   bool bearishReload =
      bearBiasAllowed &&
      bearPullbackZone &&
      (sharkfinBear || GreenBuffer[s+1] >= 68.0 || GreenBuffer[s] >= 68.0) &&
      (crossDown || greenFalling) &&
      !chop;

   // Strongest states first.
   if(bullishReload)
      return("BULLISH RELOAD: sharkfin/hook up from pullback zone");
   if(bearishReload)
      return("BEARISH RELOAD: sharkfin/hook down from pullback zone");
   if(bullishContinuation)
      return("BULLISH CONTINUATION: TDI momentum supports long bias");
   if(bearishContinuation)
      return("BEARISH CONTINUATION: TDI momentum supports short bias");

   if(chop)
      return("NO TRADE: TDI/EMA chop - tangled around 50, tight bands, or repeated 50 EMA crosses");

   // Weak timing states.
   if(crossUp && greenRising)
      return("WEAK BUY: TDI crossed up, but not full confirmation");
   if(crossDown && greenFalling)
      return("WEAK SELL: TDI crossed down, but not full confirmation");

   if(greenAboveRed && greenNow > 50.0)
      return("WATCHLIST BUY: momentum improving, wait for location/structure");
   if(greenBelowRed && greenNow < 50.0)
      return("WATCHLIST SELL: momentum weakening, wait for location/structure");

   return("NEUTRAL: wait for clean TDI confirmation");
}

//+------------------------------------------------------------------+
//| EMA chop check                                                   |
//+------------------------------------------------------------------+
bool IsEMAChoppy(int s, const double &close[])
{
   int crosses = 0;

   for(int i = s; i < s + EMA_Chop_Lookback_Bars; i++)
   {
      double closeNow  = close[i];
      double closePrev = close[i+1];

      double emaNow  = iMA(NULL, 0, Fast_EMA_Period, 0, MODE_EMA, PRICE_CLOSE, i);
      double emaPrev = iMA(NULL, 0, Fast_EMA_Period, 0, MODE_EMA, PRICE_CLOSE, i+1);

      double sideNow  = closeNow - emaNow;
      double sidePrev = closePrev - emaPrev;

      if(sideNow * sidePrev < 0)
         crosses++;
   }

   return(crosses >= Max_EMA_Crosses_For_Trade);
}

//+------------------------------------------------------------------+
//| Sharkfin checks                                                  |
//+------------------------------------------------------------------+
bool BullishSharkfin(int s)
{
   // Green line pierced below the lower volatility band recently,
   // then came back inside and started hooking upward.
   for(int i = s + 1; i <= s + Lookback_For_Sharkfin; i++)
   {
      if(GreenBuffer[i] < LowerBandBuffer[i])
      {
         bool backInside = (GreenBuffer[s] > LowerBandBuffer[s]);
         bool hookUp     = (GreenBuffer[s] > GreenBuffer[s+1]);
         return(backInside && hookUp);
      }
   }
   return(false);
}

bool BearishSharkfin(int s)
{
   // Green line pierced above the upper volatility band recently,
   // then came back inside and started hooking downward.
   for(int i = s + 1; i <= s + Lookback_For_Sharkfin; i++)
   {
      if(GreenBuffer[i] > UpperBandBuffer[i])
      {
         bool backInside = (GreenBuffer[s] < UpperBandBuffer[s]);
         bool hookDown   = (GreenBuffer[s] < GreenBuffer[s+1]);
         return(backInside && hookDown);
      }
   }
   return(false);
}

//+------------------------------------------------------------------+
//| Alert handling                                                   |
//+------------------------------------------------------------------+
void ProcessAlerts(string status, int s, const datetime &time[])
{
   // Important: this indicator calculates from the CURRENT CHART timeframe.
   // Signal_Shift=1 means the last CLOSED candle on that chart, not automatically Daily.
   // This filter prevents H1/M30/H4 charts from firing when you only want D1 alerts.
   if(Restrict_Alerts_To_Timeframe && Period() != Alert_Timeframe)
      return;

   // Only process once per selected closed candle.
   if(time[s] == LastAlertBarTime)
      return;

   // Avoid alert spam the moment a template/indicator is loaded.
   if(!AlertEngineReady)
   {
      AlertEngineReady = true;
      LastAlertBarTime = time[s];
      LastAlertStatus  = status;
      LastAlertSendTime = TimeCurrent();

      if(Suppress_Initial_Alert)
         return;
   }

   bool shouldAlert = false;

   if(Alert_Reload &&
      (StringFind(status, "BULLISH RELOAD") >= 0 ||
       StringFind(status, "BEARISH RELOAD") >= 0))
      shouldAlert = true;

   if(Alert_Continuation &&
      (StringFind(status, "BULLISH CONTINUATION") >= 0 ||
       StringFind(status, "BEARISH CONTINUATION") >= 0))
      shouldAlert = true;

   if(Alert_Chop_Warning && StringFind(status, "NO TRADE") >= 0)
      shouldAlert = true;

   // Stop repeated alerts like "BULLISH CONTINUATION" every candle.
   // It will only alert when the status changes into a new alert state.
   if(Alert_Only_When_Status_Changes && status == LastAlertStatus)
      shouldAlert = false;

   // Optional cooldown across alerts from this chart instance.
   if(Alert_Cooldown_Minutes > 0 && LastAlertSendTime > 0)
   {
      if((TimeCurrent() - LastAlertSendTime) < Alert_Cooldown_Minutes * 60)
         shouldAlert = false;
   }

   // Mark this candle as processed whether it alerts or not.
   LastAlertBarTime = time[s];
   LastAlertStatus  = status;

   if(!shouldAlert)
      return;

   LastAlertSendTime = TimeCurrent();

   string msg = StringConcatenate(Symbol(), " ", TFToString(Period()),
                                  " | CoachT TDI Filter | ", status,
                                  " | Price: ", DoubleToString(Close[s], Digits));

   if(Popup_Alert)
      Alert(msg);

   if(Push_Notification)
      SendNotification(msg);

   if(Email_Alert)
      SendMail("CoachT TDI Filter Alert", msg);
}

//+------------------------------------------------------------------+
//| Status label                                                     |
//+------------------------------------------------------------------+
int GetStatusLabelWindow()
{
   if(!Label_In_TDI_Window)
      return(0);

   int w = WindowFind(IndicatorWindowTitle);
   if(w >= 0)
      return(w);

   // Fallback: if WindowFind fails, keep it on the main chart instead of breaking.
   return(0);
}

void DrawStatusLabel(string status, color clr)
{
   int targetWindow = GetStatusLabelWindow();

   // ObjectFind(chart_id,name) returns the subwindow index in modern MT4.
   // Do NOT use OBJPROP_WINDOW here because some MT4 builds do not support it.
   int currentWindow = ObjectFind(0, StatusObjectName);
   if(currentWindow >= 0 && currentWindow != targetWindow)
      ObjectDelete(0, StatusObjectName);

   if(ObjectFind(0, StatusObjectName) < 0)
      ObjectCreate(0, StatusObjectName, OBJ_LABEL, targetWindow, 0, 0);

   ObjectSetInteger(0, StatusObjectName, OBJPROP_CORNER, Label_Corner);

   ENUM_ANCHOR_POINT anchor = ANCHOR_LEFT_UPPER;
   if(Label_Corner == 1) anchor = ANCHOR_RIGHT_UPPER;
   if(Label_Corner == 2) anchor = ANCHOR_LEFT_LOWER;
   if(Label_Corner == 3) anchor = ANCHOR_RIGHT_LOWER;
   ObjectSetInteger(0, StatusObjectName, OBJPROP_ANCHOR, anchor);

   ObjectSetInteger(0, StatusObjectName, OBJPROP_XDISTANCE, Label_X_Distance);
   ObjectSetInteger(0, StatusObjectName, OBJPROP_YDISTANCE, Label_Y_Distance);
   ObjectSetString(0, StatusObjectName, OBJPROP_FONT, Label_Font);
   ObjectSetInteger(0, StatusObjectName, OBJPROP_FONTSIZE, Label_Font_Size);
   ObjectSetInteger(0, StatusObjectName, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, StatusObjectName, OBJPROP_HIDDEN, true);
   ObjectSetString(0, StatusObjectName, OBJPROP_TOOLTIP, status);

   string biasText = "Neutral";
   if(External_Bias == Bias_Bullish) biasText = "Bullish";
   if(External_Bias == Bias_Bearish) biasText = "Bearish";

   string shortStatus = ShortStatusText(status);

   string text;
   if(Label_Compact_Mode)
      text = StringConcatenate("TDI ", TFToString(Period()), " | ", biasText, " | ", shortStatus);
   else
      text = StringConcatenate("CoachT TDI | ", Symbol(), " ", TFToString(Period()),
                               " | Bias: ", biasText, " | ", shortStatus);

   color labelColor = clr;
   if(!Label_Use_Status_Color)
      labelColor = Label_Text_Color;

   ObjectSetString(0, StatusObjectName, OBJPROP_TEXT, text);
   ObjectSetInteger(0, StatusObjectName, OBJPROP_COLOR, labelColor);
}

string ShortStatusText(string status)
{
   if(StringFind(status, "BULLISH") >= 0 && StringFind(status, "CONTINUATION") >= 0) return("Bull cont");
   if(StringFind(status, "BULLISH") >= 0 && StringFind(status, "RELOAD") >= 0)       return("Bull reload");
   if(StringFind(status, "BEARISH") >= 0 && StringFind(status, "CONTINUATION") >= 0) return("Bear cont");
   if(StringFind(status, "BEARISH") >= 0 && StringFind(status, "RELOAD") >= 0)       return("Bear reload");
   if(StringFind(status, "WEAK BUY") >= 0)  return("Weak buy");
   if(StringFind(status, "WEAK SELL") >= 0) return("Weak sell");
   if(StringFind(status, "CHOP") >= 0)      return("Chop");
   if(StringFind(status, "NEUTRAL") >= 0)   return("Neutral");
   return(status);
}

void CleanupOldStatusLabels()
{
   int total = ObjectsTotal(0, -1, -1);
   for(int i = total - 1; i >= 0; i--)
   {
      string name = ObjectName(0, i, -1, -1);
      if(StringFind(name, "CoachT_TDI_Status_") == 0 && name != StatusObjectName)
         ObjectDelete(0, name);
   }
}

//+------------------------------------------------------------------+
//| Utility functions                                                |
//+------------------------------------------------------------------+
double AverageOnSeries(double &arr[], int start, int period, int total)
{
   if(start + period >= total)
      return(EMPTY_VALUE);

   double sum = 0.0;
   int count = 0;

   for(int i = start; i < start + period; i++)
   {
      if(arr[i] == EMPTY_VALUE)
         continue;

      sum += arr[i];
      count++;
   }

   if(count <= 0)
      return(EMPTY_VALUE);

   return(sum / count);
}

double StdDevOnSeries(double &arr[], int start, int period, int total, double mean)
{
   if(mean == EMPTY_VALUE || start + period >= total)
      return(EMPTY_VALUE);

   double sum = 0.0;
   int count = 0;

   for(int i = start; i < start + period; i++)
   {
      if(arr[i] == EMPTY_VALUE)
         continue;

      double diff = arr[i] - mean;
      sum += diff * diff;
      count++;
   }

   if(count <= 1)
      return(EMPTY_VALUE);

   return(MathSqrt(sum / count));
}

double PipValue()
{
   if(Digits == 3 || Digits == 5)
      return(Point * 10.0);

   return(Point);
}

string TFToString(int tf)
{
   switch(tf)
   {
      case PERIOD_M1:  return("M1");
      case PERIOD_M5:  return("M5");
      case PERIOD_M15: return("M15");
      case PERIOD_M30: return("M30");
      case PERIOD_H1:  return("H1");
      case PERIOD_H4:  return("H4");
      case PERIOD_D1:  return("D1");
      case PERIOD_W1:  return("W1");
      case PERIOD_MN1: return("MN1");
      default:         return(IntegerToString(tf));
   }
}

color StatusColor(string status)
{
   if(StringFind(status, "BULLISH") >= 0) return(Lime);
   if(StringFind(status, "BEARISH") >= 0) return(Tomato);
   if(StringFind(status, "WEAK BUY") >= 0) return(LimeGreen);
   if(StringFind(status, "WEAK SELL") >= 0) return(OrangeRed);
   if(StringFind(status, "NO TRADE") >= 0) return(Gray);
   if(StringFind(status, "WATCHLIST BUY") >= 0) return(Aqua);
   if(StringFind(status, "WATCHLIST SELL") >= 0) return(Orange);
   return(White);
}
//+------------------------------------------------------------------+
