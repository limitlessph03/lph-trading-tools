//+------------------------------------------------------------------+
//|                 LPH_MacroTechnical_MultiScanner_v1.mq4           |
//|         Limitless PH Multi-Pair Macro-Technical + Fade Context   |
//|         Simultaneous Multi-Currency Scanner (Canonical Alignment)|
//+------------------------------------------------------------------+
#property strict
#property indicator_chart_window
#property indicator_buffers 0

#include "LPH_MacroTechnical_Core.mqh"

//------------------------- USER INPUTS -----------------------------
input string   Section_Scanner_Config     = "===== MULTI-PAIR SCANNER CONFIG =====";
input string   Symbol_List                = "EURUSD,GBPUSD,AUDUSD,NZDUSD,USDCAD,USDCHF,USDJPY,XAUUSD";
input int      Scan_Interval_Seconds      = 5;

input string   Section_TDI_Settings      = "===== TDI PARAMETERS =====";
input int      RSI_Period                = 14;
input int      RSI_Price_Line_MA         = 2;     // Green line
input int      Trade_Signal_Line_MA      = 7;     // Red line
input int      Market_Base_Line_MA       = 40;    // Canonical TDI market base line
input double   Band_Deviation            = 1.6185;

input string   Section_Macro_Settings    = "===== MACRO CACHE PARAMETERS =====";
input double   Min_Macro_Differential    = 20.0;
input double   Macro_Conflict_Tolerance  = 10.0;
input int      Stale_Warning_Hours       = 12;
input int      Disable_Signals_After_Hours = 36;

input string   Section_EMA_Settings      = "===== EMA TREND PARAMETERS =====";
input int      Fast_EMA_Period           = 50;
input int      Slow_EMA_Period           = 200;

input string   Section_Alerts            = "===== NOTIFICATIONS =====";
input bool     Enable_All_Green_Alerts   = true;
input bool     Enable_All_Red_Alerts     = true;
input bool     Popup_Alert               = true;
input bool     Push_Notification         = true;
input bool     Email_Alert               = false;
input int      Alert_Cooldown_Seconds    = 300;   // Cooldown per symbol (seconds)

input string   Section_Webhook           = "===== DASHBOARD WEBHOOK =====";
input bool     Enable_Website_Webhook    = true;
input string   Webhook_URL               = "http://127.0.0.1:8080/api/v1/macrotechnical/scan-update";
input int      Webhook_Timeout_MS        = 3000;

//------------------------- STRUCTURES & GLOBALS --------------------
struct SymbolScanResult
{
   string   symbol;
   string   resolved_symbol;
   string   decision;
   string   macro_bias;
   string   d1_regime;
   string   h4_regime;
   string   h1_regime;
   string   m15_regime;
   string   gates_buy;         // e.g. "Y/N/N/N"
   string   gates_sell;        // e.g. "Y/Y/N/N"
   double   tdi_green_h1;
   double   tdi_red_h1;
   double   tdi_yellow_h1;
   bool     all_green;
   bool     all_red;
};

datetime LastScanTime = 0;
string   ParsedSymbols[];
int      ParsedSymbolCount = 0;
datetime LastAlertTimestamps[];
string   LastAlertStatuses[];
LphCacheMeta ScannerCacheMeta;
LphCurrency  ScannerCacheRows[];

//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit()
{
   IndicatorShortName("Limitless PH Multi-Pair MacroTechnical Scanner v1");
   ParseSymbolList();
   EventSetTimer(Scan_Interval_Seconds);
   Print("[LPH_MACROTECH_SCANNER_MT4] Initialized Multi-Pair Scanner. Symbols count: ", ParsedSymbolCount);
   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
//| Custom indicator deinitialization function                       |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   EventKillTimer();
}

//+------------------------------------------------------------------+
//| Timer Event Handler                                              |
//+------------------------------------------------------------------+
void OnTimer()
{
   ExecuteMultiPairScan();
}

//+------------------------------------------------------------------+
//| OnCalculate Handler                                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                 const int prev_calculated,
                 const datetime &time[],
                 const double &open[],
                 const double &high[],
                 const double &low[],
                 const double &close[],
                 const long &tick_volume[],
                 const long &volume[],
                 const int &spread[])
{
   datetime now = TimeCurrent();
   if(now - LastScanTime >= Scan_Interval_Seconds)
   {
      ExecuteMultiPairScan();
   }
   return(rates_total);
}

//+------------------------------------------------------------------+
//| Parses input comma-separated symbol string into array            |
//+------------------------------------------------------------------+
void ParseSymbolList()
{
   string symbolsStr = Symbol_List;
   StringTrimLeft(symbolsStr);
   StringTrimRight(symbolsStr);
   
   ushort u_sep = StringGetCharacter(",", 0);
   string result[];
   int count = StringSplit(symbolsStr, u_sep, result);
   
   ArrayResize(ParsedSymbols, count);
   ArrayResize(LastAlertTimestamps, count);
   ArrayResize(LastAlertStatuses, count);
   ParsedSymbolCount = 0;
   
   for(int i = 0; i < count; i++)
   {
      string sym = result[i];
      StringTrimLeft(sym);
      StringTrimRight(sym);
      if(StringLen(sym) > 0)
      {
         ParsedSymbols[ParsedSymbolCount] = sym;
         LastAlertTimestamps[ParsedSymbolCount] = 0;
         LastAlertStatuses[ParsedSymbolCount] = "";
         ParsedSymbolCount++;
      }
   }
}

//+------------------------------------------------------------------+
//| Auto-resolves broker symbol suffixes (e.g. USDCHF -> USDCHFzero) |
//+------------------------------------------------------------------+
string ResolveBrokerSymbol(string baseSym)
{
   if(SymbolSelect(baseSym, true) && MarketInfo(baseSym, MODE_BID) > 0) return(baseSym);

   LphSymbolInfo wanted = LphResolveSymbol(baseSym, "", "");
   int total = SymbolsTotal(false);
   for(int i = 0; i < total; i++)
   {
      string candidate = SymbolName(i, false);
      LphSymbolInfo found = LphResolveSymbol(candidate, "", "");
      bool sameFx = wanted.resolved && wanted.isFx && found.resolved && found.isFx &&
                    wanted.base == found.base && wanted.quote == found.quote;
      bool sameAsset = wanted.resolved && !wanted.isFx && found.resolved && !found.isFx &&
                       wanted.assetCode == found.assetCode;
      if((sameFx || sameAsset) && SymbolSelect(candidate, true)) return(candidate);
   }
   return baseSym;
}

//+------------------------------------------------------------------+
//| Performs multi-pair calculation across all configured symbols    |
//+------------------------------------------------------------------+
void ExecuteMultiPairScan()
{
   LastScanTime = TimeCurrent();
   if(ParsedSymbolCount <= 0) return;

   // One validated shared-cache read per scan; every pair uses the same dataset.
   // Retain the last good snapshot during the bridge's brief replace window.
   LphCacheMeta readMeta;
   LphCurrency readRows[];
   if(LphReadCache(readMeta, readRows))
   {
      ScannerCacheMeta = readMeta;
      ArrayResize(ScannerCacheRows, ArraySize(readRows));
      for(int cacheRow = 0; cacheRow < ArraySize(readRows); cacheRow++)
         ScannerCacheRows[cacheRow] = readRows[cacheRow];
   }
   else if(!ScannerCacheMeta.valid)
   {
      ScannerCacheMeta = readMeta;
      ArrayResize(ScannerCacheRows, 0);
   }
   
   SymbolScanResult results[];
   ArrayResize(results, ParsedSymbolCount);
   string jsonSymbolsPayload = "[";
   
   for(int i = 0; i < ParsedSymbolCount; i++)
   {
      string baseSym = ParsedSymbols[i];
      string actualSym = ResolveBrokerSymbol(baseSym);
      
      ScanMacroTechnicalRegime(actualSym, results[i]);
      results[i].symbol = baseSym; // Normalize symbol for dashboard
      
      CheckAndSendNotifications(i, results[i]);
      
      string symJson = StringFormat(
         "{\"symbol\":\"%s\",\"status\":\"%s\",\"decision\":\"%s\",\"macro_bias\":\"%s\",\"d1_regime\":\"%s\",\"h4_regime\":\"%s\",\"h1_regime\":\"%s\",\"m15_regime\":\"%s\",\"gates_buy\":\"%s\",\"gates_sell\":\"%s\",\"tdi_green\":%.2f,\"tdi_red\":%.2f,\"tdi_yellow\":%.2f,\"all_green\":%s,\"all_red\":%s}",
         results[i].symbol,
         results[i].decision,
         results[i].decision,
         results[i].macro_bias,
         results[i].d1_regime,
         results[i].h4_regime,
         results[i].h1_regime,
         results[i].m15_regime,
         results[i].gates_buy,
         results[i].gates_sell,
         results[i].tdi_green_h1,
         results[i].tdi_red_h1,
         results[i].tdi_yellow_h1,
         results[i].all_green ? "true" : "false",
         results[i].all_red ? "true" : "false"
      );
      
      jsonSymbolsPayload += symJson;
      if(i < ParsedSymbolCount - 1) jsonSymbolsPayload += ",";
   }
   jsonSymbolsPayload += "]";
   
   if(Enable_Website_Webhook)
   {
      SendScanDataToWebsite(jsonSymbolsPayload);
   }
}

//+------------------------------------------------------------------+
//| Scans a single symbol matching canonical Macro-Technical panel   |
//+------------------------------------------------------------------+
void ScanMacroTechnicalRegime(string sym, SymbolScanResult &res)
{
   res.resolved_symbol = sym;
   res.decision = "NO TRADE - CONDITIONS CONFLICT";
   res.macro_bias = "NEUTRAL";
   res.d1_regime = "NEUTRAL";
   res.h4_regime = "NEUTRAL";
   res.h1_regime = "NEUTRAL";
   res.m15_regime = "NEUTRAL";
   res.gates_buy = "N/N/N/N";
   res.gates_sell = "N/N/N/N";
   res.tdi_green_h1 = 50.0;
   res.tdi_red_h1 = 50.0;
   res.tdi_yellow_h1 = 50.0;
   res.all_green = false;
   res.all_red = false;
   
   LphSymbolInfo symbolInfo = LphResolveSymbol(sym, "", "");
   if(!symbolInfo.resolved)
   {
      res.decision = "UNSUPPORTED_SYMBOL";
      res.macro_bias = "UNAVAILABLE";
      return;
   }

   ENUM_LPH_FRESH freshness = LphClassifyFreshness(ScannerCacheMeta, TimeGMT(),
                                                    Stale_Warning_Hours,
                                                    Disable_Signals_After_Hours);
   ENUM_LPH_MACRO macro = ScannerMacro(symbolInfo);
   res.macro_bias = LphMacroLabel(macro);
   if(!ScannerCacheMeta.valid || LphFreshnessDisablesSignals(freshness) ||
      macro == LPH_MACRO_UNAVAILABLE || macro == LPH_MACRO_PARTIAL)
   {
      res.decision = "MACRO_UNAVAILABLE_OR_STALE";
      return;
   }

   int required = MathMax(Fast_EMA_Period + 3,
                          LphTdiRequiredBars(RSI_Period, RSI_Price_Line_MA,
                                             Trade_Signal_Line_MA,
                                             Market_Base_Line_MA));
   if(iBars(sym, PERIOD_D1) < required || iBars(sym, PERIOD_H4) < required ||
      iBars(sym, PERIOD_H1) < required || iBars(sym, PERIOD_M15) < required)
   {
      res.decision = "WAITING_FOR_HISTORY";
      return;
   }

   double closeD1, emaD1, closeH4, emaH4, closeH1, emaH1, closeM15, emaM15;
   ENUM_LPH_DIR emaDirD1 = LphEmaDirection(sym, PERIOD_D1, Fast_EMA_Period,
                                           PRICE_CLOSE, 0.0, closeD1, emaD1);
   ENUM_LPH_DIR emaDirH4 = LphEmaDirection(sym, PERIOD_H4, Fast_EMA_Period,
                                           PRICE_CLOSE, 0.0, closeH4, emaH4);
   ENUM_LPH_DIR emaDirH1 = LphEmaDirection(sym, PERIOD_H1, Fast_EMA_Period,
                                           PRICE_CLOSE, 0.0, closeH1, emaH1);
   ENUM_LPH_DIR emaDirM15 = LphEmaDirection(sym, PERIOD_M15, Fast_EMA_Period,
                                            PRICE_CLOSE, 0.0, closeM15, emaM15);

   bool freshBull, freshBear, okD1, okH4, okH1, okM15;
   double gD1, rD1, yD1, gH4, rH4, yH4, gH1, rH1, yH1, gM15, rM15, yM15;
   ENUM_LPH_DIR tdiD1 = LphTdiDirection(sym, PERIOD_D1, RSI_Period, PRICE_CLOSE,
                                        RSI_Price_Line_MA, Trade_Signal_Line_MA,
                                        Market_Base_Line_MA, freshBull, freshBear,
                                        okD1, gD1, rD1, yD1);
   ENUM_LPH_DIR tdiH4 = LphTdiDirection(sym, PERIOD_H4, RSI_Period, PRICE_CLOSE,
                                        RSI_Price_Line_MA, Trade_Signal_Line_MA,
                                        Market_Base_Line_MA, freshBull, freshBear,
                                        okH4, gH4, rH4, yH4);
   ENUM_LPH_DIR tdiH1 = LphTdiDirection(sym, PERIOD_H1, RSI_Period, PRICE_CLOSE,
                                        RSI_Price_Line_MA, Trade_Signal_Line_MA,
                                        Market_Base_Line_MA, freshBull, freshBear,
                                        okH1, gH1, rH1, yH1);
   ENUM_LPH_DIR tdiM15 = LphTdiDirection(sym, PERIOD_M15, RSI_Period, PRICE_CLOSE,
                                         RSI_Price_Line_MA, Trade_Signal_Line_MA,
                                         Market_Base_Line_MA, freshBull, freshBear,
                                         okM15, gM15, rM15, yM15);
   if(emaDirD1 == LPH_DIR_NA || emaDirH4 == LPH_DIR_NA || emaDirH1 == LPH_DIR_NA ||
      emaDirM15 == LPH_DIR_NA || !okD1 || !okH4 || !okH1 || !okM15)
   {
      res.decision = "WAITING_FOR_HISTORY";
      return;
   }

   res.tdi_green_h1 = NormalizeDouble(gH1, 2);
   res.tdi_red_h1 = NormalizeDouble(rH1, 2);
   res.tdi_yellow_h1 = NormalizeDouble(yH1, 2);

   bool d1Bullish = emaDirD1 == LPH_DIR_BULL && tdiD1 == LPH_DIR_BULL;
   bool d1Bearish = emaDirD1 == LPH_DIR_BEAR && tdiD1 == LPH_DIR_BEAR;
   bool h4Bullish = emaDirH4 == LPH_DIR_BULL && tdiH4 == LPH_DIR_BULL;
   bool h4Bearish = emaDirH4 == LPH_DIR_BEAR && tdiH4 == LPH_DIR_BEAR;
   bool h1Bullish = emaDirH1 == LPH_DIR_BULL && tdiH1 == LPH_DIR_BULL;
   bool h1Bearish = emaDirH1 == LPH_DIR_BEAR && tdiH1 == LPH_DIR_BEAR;
   bool m15Bullish = emaDirM15 == LPH_DIR_BULL && tdiM15 == LPH_DIR_BULL;
   bool m15Bearish = emaDirM15 == LPH_DIR_BEAR && tdiM15 == LPH_DIR_BEAR;
   res.d1_regime = d1Bullish ? "BULLISH" : (d1Bearish ? "BEARISH" : "NEUTRAL");
   res.h4_regime = h4Bullish ? "BULLISH" : (h4Bearish ? "BEARISH" : "NEUTRAL");
   res.h1_regime = h1Bullish ? "BULLISH" : (h1Bearish ? "BEARISH" : "NEUTRAL");
   res.m15_regime = m15Bullish ? "BULLISH" : (m15Bearish ? "BEARISH" : "NEUTRAL");

   bool buyGateD1 = d1Bullish;
   bool buyGateMacro = LphMacroIsBull(macro);
   bool buyGateLevel = h4Bullish && h1Bullish;
   bool buyGateM15 = m15Bullish;
   bool sellGateD1 = d1Bearish;
   bool sellGateMacro = LphMacroIsBear(macro);
   bool sellGateLevel = h4Bearish && h1Bearish;
   bool sellGateM15 = m15Bearish;
   
   res.gates_buy = StringFormat("%s/%s/%s/%s", 
                                buyGateD1 ? "Y" : "N",
                                buyGateMacro ? "Y" : "N",
                                buyGateLevel ? "Y" : "N",
                                buyGateM15 ? "Y" : "N");
                                
   res.gates_sell = StringFormat("%s/%s/%s/%s", 
                                 sellGateD1 ? "Y" : "N",
                                 sellGateMacro ? "Y" : "N",
                                 sellGateLevel ? "Y" : "N",
                                 sellGateM15 ? "Y" : "N");
                                 
   bool allBuyGatesPassed  = (buyGateD1 && buyGateMacro && buyGateLevel && buyGateM15);
   bool allSellGatesPassed = (sellGateD1 && sellGateMacro && sellGateLevel && sellGateM15);
   
   if(allBuyGatesPassed)
   {
      res.decision = "ALL GREEN TARGET: BUY_READY (GATES Y/Y/Y/Y)";
      res.all_green = true;
   }
   else if(allSellGatesPassed)
   {
      res.decision = "ALL RED TARGET: SELL_READY (GATES Y/Y/Y/Y)";
      res.all_red = true;
   }
   else if((LphMacroIsBull(macro) && (d1Bearish || h4Bearish)) ||
           (LphMacroIsBear(macro) && (d1Bullish || h4Bullish)) ||
           macro == LPH_MACRO_MIXED)
   {
      res.decision = "NO TRADE - CONDITIONS CONFLICT";
   }
   else
   {
      res.decision = "NEUTRAL / NO ACTIVE SETUP";
      res.macro_bias = "NEUTRAL";
   }
}

ENUM_LPH_MACRO ScannerMacro(LphSymbolInfo &info)
{
   if(!ScannerCacheMeta.valid || !info.resolved) return(LPH_MACRO_UNAVAILABLE);
   if(info.isFx)
   {
      int baseIndex = LphFindCurrency(ScannerCacheRows, info.base);
      int quoteIndex = LphFindCurrency(ScannerCacheRows, info.quote);
      if(baseIndex < 0 || quoteIndex < 0 ||
         !ScannerCacheRows[baseIndex].has7d || !ScannerCacheRows[baseIndex].has30d ||
         !ScannerCacheRows[quoteIndex].has7d || !ScannerCacheRows[quoteIndex].has30d)
         return(LPH_MACRO_PARTIAL);
      double diff7 = ScannerCacheRows[baseIndex].score7d - ScannerCacheRows[quoteIndex].score7d;
      double diff30 = ScannerCacheRows[baseIndex].score30d - ScannerCacheRows[quoteIndex].score30d;
      return(LphClassifyMacro(diff7, diff30, Min_Macro_Differential,
                              Macro_Conflict_Tolerance));
   }

   int assetIndex = LphFindCurrency(ScannerCacheRows, info.assetCode);
   if(assetIndex < 0 || ScannerCacheRows[assetIndex].status == "no_data")
      return(LPH_MACRO_UNAVAILABLE);
   double score = 0.0;
   if(ScannerCacheRows[assetIndex].hasComposite)
      score = ScannerCacheRows[assetIndex].compositeScore;
   else if(ScannerCacheRows[assetIndex].hasStable)
      score = ScannerCacheRows[assetIndex].stableScore;
   else
      return(LPH_MACRO_PARTIAL);
   return(LphClassifyMacro(score, score, Min_Macro_Differential,
                           Macro_Conflict_Tolerance));
}

//+------------------------------------------------------------------+
//| Evaluates and dispatches alerts for "ALL GREEN" / "ALL RED"      |
//+------------------------------------------------------------------+
void CheckAndSendNotifications(int symbolIndex, const SymbolScanResult &res)
{
   datetime now = TimeCurrent();
   datetime lastAlert = LastAlertTimestamps[symbolIndex];
   string currentTarget = res.all_green ? "BUY" : (res.all_red ? "SELL" : "");
   if(currentTarget == "")
   {
      // Reset on confirmed exit so a later re-entry is a genuinely new setup.
      LastAlertStatuses[symbolIndex] = "";
      return;
   }
   bool isNewTarget = (res.decision != LastAlertStatuses[symbolIndex]);
   if(!isNewTarget || now - lastAlert < Alert_Cooldown_Seconds) return;
   
   if(res.all_green && Enable_All_Green_Alerts && isNewTarget)
   {
      string msg = StringFormat("[LPH MACRO-TECH SCANNER] ALL GREEN TARGET hit on %s! Decision: %s | Gates BUY: %s | TDI G:%.1f R:%.1f Y:%.1f",
                                res.symbol, res.decision, res.gates_buy, res.tdi_green_h1, res.tdi_red_h1, res.tdi_yellow_h1);
                                
      if(Popup_Alert) Alert(msg);
      if(Push_Notification) SendNotification(msg);
      if(Email_Alert) SendMail("MacroTechnical Alert: " + res.symbol + " ALL GREEN", msg);
      
      LastAlertTimestamps[symbolIndex] = now;
      LastAlertStatuses[symbolIndex] = res.decision;
   }
   else if(res.all_red && Enable_All_Red_Alerts && isNewTarget)
   {
      string msg = StringFormat("[LPH MACRO-TECH SCANNER] ALL RED TARGET hit on %s! Decision: %s | Gates SELL: %s | TDI G:%.1f R:%.1f Y:%.1f",
                                res.symbol, res.decision, res.gates_sell, res.tdi_green_h1, res.tdi_red_h1, res.tdi_yellow_h1);
                                
      if(Popup_Alert) Alert(msg);
      if(Push_Notification) SendNotification(msg);
      if(Email_Alert) SendMail("MacroTechnical Alert: " + res.symbol + " ALL RED", msg);
      
      LastAlertTimestamps[symbolIndex] = now;
      LastAlertStatuses[symbolIndex] = res.decision;
   }
}

//+------------------------------------------------------------------+
//| Webhook POST transmission to Website Backend Server               |
//+------------------------------------------------------------------+
void SendScanDataToWebsite(string jsonSymbolsPayload)
{
   string headers = "Content-Type: application/json\r\n";
   char postData[];
   char resultData[];
   string resultHeaders;
   
   string fullPayload = StringFormat(
      "{\"scanner_id\":\"LPH_MacroTechnical_MultiScanner_v1\",\"timestamp\":\"%s\",\"pairs_count\":%d,\"symbols\":%s}",
      TimeToString(TimeCurrent(), TIME_DATE|TIME_SECONDS),
      ParsedSymbolCount,
      jsonSymbolsPayload
   );
   
   StringToCharArray(fullPayload, postData, 0, StringLen(fullPayload), CP_UTF8);
   
   WebRequest("POST", Webhook_URL, headers, Webhook_Timeout_MS, postData, resultData, resultHeaders);
}
//+------------------------------------------------------------------+
