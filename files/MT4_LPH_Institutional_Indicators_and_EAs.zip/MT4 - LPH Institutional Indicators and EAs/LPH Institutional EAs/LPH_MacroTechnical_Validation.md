# LPH Macro-Technical Alignment — Validation Report

Date: 2026-07-22

## A. Compilation (real compiler)

Compiled with the local MetaEditor at
`...\Terminal\C4CDF73A71F130DAE20FA58893179B03\metaeditor.exe`.

| File | Result |
|------|--------|
| `LPH_MacroBridge_EA.mq4` | **0 errors, 0 warnings** → `LPH_MacroBridge_EA.ex4` (61,786 bytes) |
| `LPH_MacroTechnical_Alignment.mq4` | **0 errors, 0 warnings** → `LPH_MacroTechnical_Alignment.ex4` (89,842 bytes) |
| `LPH_MacroTechnical_Core.mqh` | Included cleanly by both. |

Compiler logs are saved next to each source as `*.compile.log`.

## B. Backend endpoint (live)

`GET http://localhost:4173/api/mt4/macro-heatmap` → HTTP **200**, valid JSON,
`schema_version: 1`, 14 currencies (USD EUR GBP JPY CHF CAD AUD NZD + XAUUSD XAGUSD
NAS100 DJ30 SP500 USOIL). Timestamp is ISO-8601 UTC. Adding the route left all existing
routes unchanged (`/api/asset-scorecard`, `/api/comprehensive-score` still 200).

Cache round-trip: the bridge's CSV writer format was reproduced from the live payload
into `LPH_MacroHeatmap_Cache_v1.example.csv`; every `CCY` row has the 11 columns the
reader (`LphReadCache`) expects, `META` has 6, `STATUS` has 5.

## C. Logic checks (algorithm mirror, 27/27 passed)

The symbol-resolution scan and the macro classifier were mirrored exactly in a Node
harness and run against the spec's checklist. All passed:

**Symbol handling** — EURUSD, GBPJPY, AUDCAD, NZDUSD resolve base/quote correctly;
prefixes/suffixes EURUSD.a, m.GBPJPY, EURUSDzero, GBPJPYpro, USDCHFzero resolve;
XAUUSD / XAUUSDzero / GOLD → metal (not FX); NAS100 → index; BTCUSD → unsupported;
manual override honoured.

**Macro arithmetic** — `EUR(34) − USD(−15) = +49`; `GBP(48) − JPY(−2) = +50`;
`USD(−20) − CAD(65) = −85` (negative differential correct, formula never reversed).

**Classification (min=20, tol=10)** — strong bull/bear, bull/bear with flat or mildly
opposing 7D, MIXED when 7D opposes the 30D regime beyond tolerance or opposes outright,
MIXED when only 7D passes, NEUTRAL below the minimum.

## D. Static / design checklist

| Requirement | Status |
|-------------|--------|
| Indicator never calls `WebRequest` | ✔ (only the bridge does) |
| No DLL imports anywhere | ✔ |
| Read-only token never printed to logs | ✔ (`BridgeLog` excludes token; headers never logged) |
| Closed candles only (shift 1 signal, shift 2 compare) | ✔ (`iClose(...,1)`, TDI shifts 1/2) |
| Insufficient history → `WAITING FOR HISTORY`, no false signal | ✔ (`LphTdiRequiredBars`, `iBars` check) |
| ATR-scaled EMA neutral band | ✔ (`EMANeutralToleranceATR × ATR`) |
| TDI computed internally (RSI→PriceLine→Signal→MarketBase) | ✔ |
| Fresh TDI cross detected as secondary info only | ✔ (never overrides EMA/macro) |
| Base−Quote differential, never reversed | ✔ |
| Missing currency never becomes 0 | ✔ (`NA` token, `has*` flags) |
| Opposing 7D/30D → MIXED | ✔ |
| Gold/indices: only authoritative asset scores used, else USD-context partial | ✔ |
| Unsupported symbol message, technical still works | ✔ |
| Stale bands LIVE/AGING/STALE/CACHED/INVALID/MISSING | ✔ |
| STALE disables directional labels; AGING warns but allows | ✔ |
| API failure preserves last valid cache (atomic temp→move) | ✔ (`WriteCacheAtomic`, `UpdateStatusRowOnly`) |
| Bridge validates HTTP/size/schema/timestamp/fields/duplicates | ✔ |
| Duplicate bridge instances → one PRIMARY, others PASSIVE | ✔ (GlobalVariable owner + heartbeat) |
| Bounded retry/backoff | ✔ (exponential, capped by `MaxBackoffSeconds`) |
| Alerts only on state change / new H4 state / new dataset | ✔ (no per-tick spam) |
| No "guaranteed / high-probability / safe" language | ✔ |
| Objects prefixed with `ChartID()`; deleted on deinit | ✔ (`LPHMTC_<id>_`, `ObjectsDeleteAll`) |
| `CHARTEVENT_CHART_CHANGE` reposition | ✔ |
| Recalc only on new D1/H4 candle / init / input change | ✔ (`NewCandle()` gating) |
| Strict compilation | ✔ (`#property strict`, 0/0) |

## E. Manual live verification (to run in MT4)

These require an attached terminal and are the recommended acceptance steps:

1. Attach the bridge on a dedicated chart; confirm panel → `CONNECTED`, dataset UTC time,
   currency count. Add the domain to the WebRequest allowlist first.
2. Attach the indicator to EURUSD, GBPJPY, AUDCAD, NZDUSD, XAUUSD, and a
   suffixed symbol (e.g. `EURUSD.a`); confirm symbol resolution + differentials.
3. Cross-check a few pairs' 30D/7D differentials against the live web heatmap
   (`Base − Quote`).
4. Cross-check D1/H4 EMA(50) and RSI/TDI against native MT4 indicators on the same chart.
5. Force failure cases: wrong URL (→ `ENDPOINT_ERROR`, cache preserved), bad token
   (→ `AUTH_ERROR`), stop the server past `DisableSignalsAfterHours`
   (→ `STALE / SIGNAL DISABLED`).

## F. Known limitations

- Fallback macro thresholds (`MinMacroDifferential`, `MacroConflictTolerance`) are
  **provisional** pending attribution testing.
- The macro model provides no per-currency **confidence**; the panel shows `n/a`.
- CFD coverage depends on the backend actually publishing an authoritative score for the
  asset; otherwise only USD context is shown (never a fabricated differential).
- Section E steps are the only ones that require a live MT4 terminal and were not executed
  in this environment.
