//+------------------------------------------------------------------+
//|        PAXG_Binance_OrderBook_Panel_EA_PRICE_WALLS_LIVE.mq4       |
//|        Live Binance PAXG order book panel + major price wall overlay + cluster mode    |
//|        Built for Limitless PH / Coach T                           |
//+------------------------------------------------------------------+
#property strict
#property version   "1.05"

// IMPORTANT:
// This is an Expert Advisor, not a custom indicator.
// MT4 WebRequest is designed for EAs/scripts. Put this file in MQL4/Experts.
// Add this URL in MT4: Tools > Options > Expert Advisors > Allow WebRequest:
// https://api.binance.com

input string ApiBaseUrl                 = "https://api.binance.com"; // alternatives: https://data-api.binance.vision or https://api-gcp.binance.com
input string BinanceSymbol              = "PAXGUSDT";
input int    DepthLimit                 = 1000;    // Binance supported: 5,10,20,50,100,500,1000,5000. Higher = farther walls
input int    RefreshSeconds             = 10;      // use slower refresh when DepthLimit is high
input int    RequestTimeoutMs           = 5000;

input bool   ShowPanel                  = true;
input int    PanelX                     = 20;
input int    PanelY                     = 20;
input int    PanelWidth                 = 330;
input int    PanelHeight                = 245;
input string FontName                   = "Arial";
input int    TitleSize                  = 12;
input int    TextSize                   = 10;

input bool   DrawPriceWalls             = true;
input int    TopWallsPerSide            = 3;       // draw top N bid and ask walls after filtering
input bool   DrawLargestOnly            = false;    // true = biggest bid + biggest ask only
input bool   AlwaysDrawLargestBidAsk    = true;    // force largest bid and largest ask to show even if % filter would hide one side
input double MinimumWallQuantity        = 0.0;     // 0 = no absolute minimum filter
input bool   ShowOnlyMajorWalls         = true;    // true = hide small orders and show only the biggest walls
input double MinWallPercentOfLargest    = 40.0;    // draw only walls >= this % of the largest qty in the fetched book, except forced largest bid/ask
input int    WallLineStartBarsRight     = 4;       // start farther right so candles stay clean
input int    WallLineEndBarsRight       = 22;
input int    WallLabelBarsRight         = 24;
input int    WallLabelFontSize          = 9;
input bool   ScaleWallLineWidth         = false;   // false = all wall lines stay thin
input int    WallLineWidth              = 1;       // recommended 1
input int    MaxScaledWallLineWidth     = 2;       // only used if ScaleWallLineWidth=true
input int    WallLabelOffsetPoints      = 55;      // label below line by this many points
input int    WallLabelStackStepPoints   = 25;      // extra offset for #2/#3 labels

input string Section_Cluster_Mode       = "----- CLUSTER MODE -----";
input bool   UseClusterMode             = true;    // combine nearby overlapping walls into one clean label
input double ClusterDistancePoints      = 150.0;   // walls within this point distance are grouped together
input bool   ShowClusterTotalVolume     = true;    // show combined quantity for clustered walls
input bool   ShowClusterPriceRange      = true;    // show min-max price range for clustered walls

input double ChartShiftPercent          = 32.0;
input bool   AutoEnableChartShift       = true;
input bool   AutoScaleToShowFarWalls    = false;   // true = force chart scale to include far order-book walls
input double AutoScalePaddingPercent    = 5.0;     // padding around current price + farthest selected walls
input bool   RestoreAutoScaleOnRemove   = true;    // reset chart to auto scale when EA is removed
input bool   DrawFullHorizontalLines    = false;   // false = right-side segments only
input bool   DrawWallLinesBehindPrice   = true;    // lines behind candles/text

input bool   PrintDebug                 = false;

// Binance-like colors
color BG_COLOR       = C'18,22,28';
color BORDER_COLOR   = C'70,80,95';
color TITLE_COLOR    = clrWhite;
color LABEL_COLOR    = C'190,205,225';
color GREEN_COLOR    = C'14,203,129';
color RED_COLOR      = C'246,70,93';
color ACCENT_COLOR   = C'240,185,11';
color FOOTER_COLOR   = C'120,130,145';
color WARN_COLOR     = C'255,185,80';

string prefix = "PAXG_OB_LIVE_";
datetime lastFetchTime = 0;

struct WallInfo
{
   double price;
   double qty;
   int    rank;
   bool   isBid;
};

//+------------------------------------------------------------------+
//| Utility: period seconds fallback                                 |
//+------------------------------------------------------------------+
int TFSeconds()
{
   int tf = Period();
   if(tf == PERIOD_M1)  return 60;
   if(tf == PERIOD_M5)  return 300;
   if(tf == PERIOD_M15) return 900;
   if(tf == PERIOD_M30) return 1800;
   if(tf == PERIOD_H1)  return 3600;
   if(tf == PERIOD_H4)  return 14400;
   if(tf == PERIOD_D1)  return 86400;
   if(tf == PERIOD_W1)  return 604800;
   if(tf == PERIOD_MN1) return 2592000;
   return 3600;
}

string Dbl(double v, int digits=2)
{
   return DoubleToString(v, digits);
}

//+------------------------------------------------------------------+
//| Object helpers                                                   |
//+------------------------------------------------------------------+
void SetLabel(string name, string text, int x, int y, color clr, int size, string font="Arial")
{
   string obj = prefix + name;

   if(ObjectFind(0, obj) < 0)
      ObjectCreate(0, obj, OBJ_LABEL, 0, 0, 0);

   ObjectSetInteger(0, obj, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, obj, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, obj, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, obj, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, obj, OBJPROP_FONTSIZE, size);
   ObjectSetString(0, obj, OBJPROP_FONT, font);
   ObjectSetString(0, obj, OBJPROP_TEXT, text);
   ObjectSetInteger(0, obj, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, obj, OBJPROP_HIDDEN, true);
}

void SetPanel()
{
   string obj = prefix + "BG";

   if(ObjectFind(0, obj) < 0)
      ObjectCreate(0, obj, OBJ_RECTANGLE_LABEL, 0, 0, 0);

   ObjectSetInteger(0, obj, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, obj, OBJPROP_XDISTANCE, PanelX);
   ObjectSetInteger(0, obj, OBJPROP_YDISTANCE, PanelY);
   ObjectSetInteger(0, obj, OBJPROP_XSIZE, PanelWidth);
   ObjectSetInteger(0, obj, OBJPROP_YSIZE, PanelHeight);
   ObjectSetInteger(0, obj, OBJPROP_BGCOLOR, BG_COLOR);
   ObjectSetInteger(0, obj, OBJPROP_BORDER_COLOR, BORDER_COLOR);
   ObjectSetInteger(0, obj, OBJPROP_STYLE, STYLE_SOLID);
   ObjectSetInteger(0, obj, OBJPROP_WIDTH, 1);
   ObjectSetInteger(0, obj, OBJPROP_BACK, false);
   ObjectSetInteger(0, obj, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, obj, OBJPROP_HIDDEN, true);
}

void DeleteByPrefix(string pfx)
{
   int total = ObjectsTotal(0, -1, -1);
   for(int i = total - 1; i >= 0; i--)
   {
      string name = ObjectName(0, i, -1, -1);
      if(StringFind(name, pfx) == 0)
         ObjectDelete(0, name);
   }
}

void DeleteWallObjects()
{
   DeleteByPrefix(prefix + "WALL_");
}

//+------------------------------------------------------------------+
//| Parse Binance JSON side                                          |
//+------------------------------------------------------------------+
int ParseSide(string json, string sideKey, double &prices[], double &qtys[], int maxLevels)
{
   ArrayResize(prices, maxLevels);
   ArrayResize(qtys, maxLevels);

   string key = "\"" + sideKey + "\":[";
   int pos = StringFind(json, key, 0);
   if(pos < 0)
      return 0;

   int p = pos + StringLen(key);
   int endPos = StringLen(json);

   if(sideKey == "bids")
   {
      int askPos = StringFind(json, "\"asks\":[", p);
      if(askPos > 0)
         endPos = askPos;
   }

   int count = 0;
   while(count < maxLevels && p < endPos)
   {
      int q1 = StringFind(json, "\"", p);
      if(q1 < 0 || q1 >= endPos) break;
      int q2 = StringFind(json, "\"", q1 + 1);
      if(q2 < 0 || q2 >= endPos) break;

      int q3 = StringFind(json, "\"", q2 + 1);
      if(q3 < 0 || q3 >= endPos) break;
      int q4 = StringFind(json, "\"", q3 + 1);
      if(q4 < 0 || q4 >= endPos) break;

      string priceStr = StringSubstr(json, q1 + 1, q2 - q1 - 1);
      string qtyStr   = StringSubstr(json, q3 + 1, q4 - q3 - 1);

      prices[count] = StrToDouble(priceStr);
      qtys[count]   = StrToDouble(qtyStr);

      count++;
      p = q4 + 1;
   }

   return count;
}

//+------------------------------------------------------------------+
//| Fetch live Binance depth                                         |
//+------------------------------------------------------------------+
bool FetchDepth(string &json, string &errorText)
{
   string base = ApiBaseUrl;
   if(StringLen(base) <= 0)
      base = "https://api.binance.com";

   // Remove trailing slash so URL composition is stable.
   while(StringLen(base) > 0 && StringSubstr(base, StringLen(base) - 1, 1) == "/")
      base = StringSubstr(base, 0, StringLen(base) - 1);

   string url = base + "/api/v3/depth?symbol=" + BinanceSymbol + "&limit=" + IntegerToString(DepthLimit);

   char data[];
   char result[];
   string resultHeaders = "";

   ArrayResize(data, 0);
   ArrayResize(result, 0);

   ResetLastError();
   int httpStatus = WebRequest("GET", url, "", RequestTimeoutMs, data, result, resultHeaders);
   int err = GetLastError();

   if(httpStatus == -1)
   {
      errorText = "WebRequest failed. Error " + IntegerToString(err) + ". Allow " + base;
      return false;
   }

   // IMPORTANT: WebRequest() returns the HTTP status code, NOT the body length.
   // The old version used the HTTP code as length, so it only read ~200 chars and often missed the asks array.
   int bodyLen = ArraySize(result);
   json = CharArrayToString(result, 0, bodyLen);

   if(PrintDebug)
   {
      Print("PAXG OB request URL: ", url);
      Print("PAXG OB HTTP status: ", IntegerToString(httpStatus), " body length: ", IntegerToString(bodyLen));
      Print("PAXG OB response head: ", StringSubstr(json, 0, 250));
   }

   if(httpStatus != 200)
   {
      errorText = "Binance HTTP " + IntegerToString(httpStatus) + ": " + StringSubstr(json, 0, 110);
      return false;
   }

   if(StringFind(json, "\"bids\"") < 0 || StringFind(json, "\"asks\"") < 0)
   {
      errorText = "Invalid Binance body: " + StringSubstr(json, 0, 110);
      if(PrintDebug) Print("Full Binance response: ", json);
      return false;
   }

   return true;
}

//+------------------------------------------------------------------+
//| Data math                                                        |
//+------------------------------------------------------------------+
double SumQty(double &qtys[], int count)
{
   double s = 0.0;
   for(int i = 0; i < count; i++)
      s += qtys[i];
   return s;
}

int LargestIndex(double &qtys[], int count)
{
   int idx = -1;
   double best = -1.0;
   for(int i = 0; i < count; i++)
   {
      if(qtys[i] > best)
      {
         best = qtys[i];
         idx = i;
      }
   }
   return idx;
}

string BiasText(double bidVol, double askVol)
{
   double total = bidVol + askVol;
   if(total <= 0.0) return "NEUTRAL";

   double delta = bidVol - askVol;
   double ratio = MathAbs(delta) / total;

   if(ratio < 0.08) return "NEUTRAL";
   if(delta > 0.0) return "BULLISH";
   return "BEARISH";
}

color BiasColor(string bias)
{
   string b = bias;
   StringToUpper(b);
   if(StringFind(b, "BULL") >= 0) return GREEN_COLOR;
   if(StringFind(b, "BEAR") >= 0) return RED_COLOR;
   return ACCENT_COLOR;
}

//+------------------------------------------------------------------+
//| Draw panel                                                       |
//+------------------------------------------------------------------+
void DrawDashboard(double bidVol, double askVol, double delta,
                   double largestBidPrice, double largestBidQty,
                   double largestAskPrice, double largestAskQty,
                   string bias, string sourceText)
{
   if(!ShowPanel) return;

   SetPanel();

   color deltaColor = (delta >= 0.0 ? GREEN_COLOR : RED_COLOR);

   int x1 = PanelX + 12;
   int x2 = PanelX + 170;
   int y  = PanelY + 12;
   int gap = 23;

   SetLabel("TITLE", "BINANCE PAXG ORDER BOOK", x1, y, TITLE_COLOR, TitleSize, "Arial Bold");
   y += gap;

   SetLabel("LINE1", "--------------------------------", x1, y, BORDER_COLOR, TextSize, FontName);
   y += gap;

   SetLabel("LBL_BID", "Bid Volume", x1, y, LABEL_COLOR, TextSize, FontName);
   SetLabel("VAL_BID", Dbl(bidVol, 2), x2, y, GREEN_COLOR, TextSize, "Arial Bold");
   y += gap;

   SetLabel("LBL_ASK", "Ask Volume", x1, y, LABEL_COLOR, TextSize, FontName);
   SetLabel("VAL_ASK", Dbl(askVol, 2), x2, y, RED_COLOR, TextSize, "Arial Bold");
   y += gap;

   SetLabel("LBL_DELTA", "Delta", x1, y, LABEL_COLOR, TextSize, FontName);
   SetLabel("VAL_DELTA", Dbl(delta, 2), x2, y, deltaColor, TextSize, "Arial Bold");
   y += gap + 3;

   SetLabel("LBL_LBID", "Largest Bid Wall", x1, y, LABEL_COLOR, TextSize, FontName);
   SetLabel("VAL_LBID", Dbl(largestBidPrice, 2) + " / " + Dbl(largestBidQty, 2), x2, y, GREEN_COLOR, TextSize, "Arial Bold");
   y += gap;

   SetLabel("LBL_LASK", "Largest Ask Wall", x1, y, LABEL_COLOR, TextSize, FontName);
   SetLabel("VAL_LASK", Dbl(largestAskPrice, 2) + " / " + Dbl(largestAskQty, 2), x2, y, RED_COLOR, TextSize, "Arial Bold");
   y += gap + 3;

   SetLabel("LBL_BIAS", "Liquidity Bias", x1, y, ACCENT_COLOR, TextSize, FontName);
   SetLabel("VAL_BIAS", bias, x2, y, BiasColor(bias), TextSize + 1, "Arial Bold");
   y += gap + 5;

   SetLabel("FOOT", sourceText, x1, y, FOOTER_COLOR, 8, FontName);
}

void DrawError(string msg)
{
   if(!ShowPanel) return;

   SetPanel();
   SetLabel("TITLE", "BINANCE PAXG ORDER BOOK", PanelX + 12, PanelY + 12, TITLE_COLOR, TitleSize, "Arial Bold");
   SetLabel("ERR", msg, PanelX + 12, PanelY + 50, WARN_COLOR, TextSize, "Arial Bold");
   SetLabel("FOOT", "Allow WebRequest for ApiBaseUrl. Turn PrintDebug=true if needed.", PanelX + 12, PanelY + 80, FOOTER_COLOR, 8, FontName);
}

//+------------------------------------------------------------------+
//| Draw price walls                                                 |
//+------------------------------------------------------------------+

bool WallPassesMajorFilter(double qty, double maxQty)
{
   if(qty <= 0.0) return(false);
   if(MinimumWallQuantity > 0.0 && qty < MinimumWallQuantity) return(false);

   if(ShowOnlyMajorWalls && maxQty > 0.0)
   {
      double threshold = maxQty * MathMax(0.0, MinWallPercentOfLargest) / 100.0;
      if(qty < threshold)
         return(false);
   }

   return(true);
}

void UpdateWallRange(double price, bool &hasRange, double &minWallPrice, double &maxWallPrice)
{
   if(price <= 0.0) return;

   if(!hasRange)
   {
      minWallPrice = price;
      maxWallPrice = price;
      hasRange = true;
      return;
   }

   if(price < minWallPrice) minWallPrice = price;
   if(price > maxWallPrice) maxWallPrice = price;
}

void ApplyAutoScaleForWalls(bool hasRange, double minWallPrice, double maxWallPrice)
{
   if(!AutoScaleToShowFarWalls || !hasRange)
      return;

   double minPrice = minWallPrice;
   double maxPrice = maxWallPrice;

   double currentPrice = Bid;
   if(currentPrice <= 0.0) currentPrice = Close[0];
   if(currentPrice > 0.0)
   {
      if(currentPrice < minPrice) minPrice = currentPrice;
      if(currentPrice > maxPrice) maxPrice = currentPrice;
   }

   int barsToInclude = MathMin(Bars - 1, 80);
   for(int i = 0; i <= barsToInclude; i++)
   {
      if(Low[i]  > 0.0 && Low[i]  < minPrice) minPrice = Low[i];
      if(High[i] > 0.0 && High[i] > maxPrice) maxPrice = High[i];
   }

   double range = maxPrice - minPrice;
   if(range <= 0.0)
      return;

   double pad = range * MathMax(0.0, AutoScalePaddingPercent) / 100.0;

   ChartSetInteger(0, CHART_SCALEFIX, true);
   ChartSetDouble(0, CHART_FIXED_MIN, minPrice - pad);
   ChartSetDouble(0, CHART_FIXED_MAX, maxPrice + pad);
}

void AddSelectedWall(double price, double qty, bool isLargest,
                     double &prices[], double &qtys[], bool &largestFlags[])
{
   if(price <= 0.0 || qty <= 0.0)
      return;

   int n = ArraySize(prices);
   ArrayResize(prices, n + 1);
   ArrayResize(qtys, n + 1);
   ArrayResize(largestFlags, n + 1);

   prices[n] = price;
   qtys[n] = qty;
   largestFlags[n] = isLargest;
}

void DrawWallObject(string name, double linePrice, double labelPrice, double qty,
                    int rank, bool isBid, double maxQty, string wallText)
{
   if(linePrice <= 0.0 || qty <= 0.0) return;

   color clr = isBid ? GREEN_COLOR : RED_COLOR;

   int sec = TFSeconds();
   datetime t0 = iTime(Symbol(), Period(), 0);
   if(t0 <= 0) t0 = TimeCurrent();

   datetime t1 = t0 + WallLineStartBarsRight * sec;
   datetime t2 = t0 + WallLineEndBarsRight   * sec;
   datetime tl = t0 + WallLabelBarsRight     * sec;

   int width = MathMax(1, WallLineWidth);
   if(ScaleWallLineWidth && maxQty > 0.0)
      width = MathMax(1, MathMin(MaxScaledWallLineWidth, (int)MathRound(1.0 + (MaxScaledWallLineWidth - 1.0) * qty / maxQty)));

   string lineName = prefix + "WALL_LINE_" + name;
   string textName = prefix + "WALL_TEXT_" + name;

   if(DrawFullHorizontalLines)
   {
      if(ObjectFind(0, lineName) < 0)
         ObjectCreate(0, lineName, OBJ_HLINE, 0, 0, linePrice);
      ObjectSetDouble(0, lineName, OBJPROP_PRICE1, linePrice);
   }
   else
   {
      if(ObjectFind(0, lineName) < 0)
         ObjectCreate(0, lineName, OBJ_TREND, 0, t1, linePrice, t2, linePrice);

      ObjectSetInteger(0, lineName, OBJPROP_TIME1, t1);
      ObjectSetDouble(0, lineName, OBJPROP_PRICE1, linePrice);
      ObjectSetInteger(0, lineName, OBJPROP_TIME2, t2);
      ObjectSetDouble(0, lineName, OBJPROP_PRICE2, linePrice);
      ObjectSetInteger(0, lineName, OBJPROP_RAY, false);
   }

   ObjectSetInteger(0, lineName, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, lineName, OBJPROP_STYLE, STYLE_SOLID);
   ObjectSetInteger(0, lineName, OBJPROP_WIDTH, width);
   ObjectSetInteger(0, lineName, OBJPROP_BACK, DrawWallLinesBehindPrice);
   ObjectSetInteger(0, lineName, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, lineName, OBJPROP_HIDDEN, true);

   if(ObjectFind(0, textName) < 0)
      ObjectCreate(0, textName, OBJ_TEXT, 0, tl, labelPrice);

   ObjectSetInteger(0, textName, OBJPROP_TIME1, tl);
   ObjectSetDouble(0, textName, OBJPROP_PRICE1, labelPrice);
   ObjectSetString(0, textName, OBJPROP_TEXT, wallText);
   ObjectSetInteger(0, textName, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, textName, OBJPROP_FONTSIZE, WallLabelFontSize);
   ObjectSetString(0, textName, OBJPROP_FONT, "Arial Bold");
   ObjectSetInteger(0, textName, OBJPROP_ANCHOR, ANCHOR_LEFT);
   ObjectSetInteger(0, textName, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, textName, OBJPROP_HIDDEN, true);
}

void DrawSingleWall(string name, double price, double qty, int rank, bool isBid, double maxQty, bool isLargestWall)
{
   if(price <= 0.0 || qty <= 0.0) return;

   string side = isBid ? "BID" : "ASK";

   double labelOffset = (WallLabelOffsetPoints + (rank - 1) * WallLabelStackStepPoints) * Point;
   double labelPrice  = price - labelOffset;

   string wallText;
   if(isLargestWall)
      wallText = "LARGEST " + side + "  " + Dbl(price, 2) + " | " + Dbl(qty, 2);
   else
      wallText = side + " #" + IntegerToString(rank) + "  " + Dbl(price, 2) + " | " + Dbl(qty, 2);

   DrawWallObject(name, price, labelPrice, qty, rank, isBid, maxQty, wallText);
}

void DrawClusterWall(string name, double minPrice, double maxPrice, double totalQty,
                     int rank, bool isBid, double maxQty, bool containsLargest, int memberCount)
{
   if(minPrice <= 0.0 || maxPrice <= 0.0 || totalQty <= 0.0) return;

   string side = isBid ? "BID" : "ASK";
   double linePrice = (minPrice + maxPrice) / 2.0;

   double labelOffset = (WallLabelOffsetPoints + (rank - 1) * WallLabelStackStepPoints) * Point;
   double labelPrice  = linePrice - labelOffset;

   string wallText = "";

   if(memberCount > 1)
   {
      wallText = side + " CLUSTER ";

      if(ShowClusterPriceRange)
         wallText = wallText + Dbl(minPrice, 2) + "-" + Dbl(maxPrice, 2);
      else
         wallText = wallText + Dbl(linePrice, 2);

      if(ShowClusterTotalVolume)
         wallText = wallText + " | TOTAL " + Dbl(totalQty, 2);
      else
         wallText = wallText + " | " + Dbl(totalQty, 2);

      if(containsLargest)
         wallText = "LARGEST " + wallText;
   }
   else
   {
      if(containsLargest)
         wallText = "LARGEST " + side + "  " + Dbl(linePrice, 2) + " | " + Dbl(totalQty, 2);
      else
         wallText = side + " #" + IntegerToString(rank) + "  " + Dbl(linePrice, 2) + " | " + Dbl(totalQty, 2);
   }

   DrawWallObject(name, linePrice, labelPrice, totalQty, rank, isBid, maxQty, wallText);
}

void DrawWallCollection(string sideName, double &prices[], double &qtys[], bool &largestFlags[],
                        bool isBid, double maxQty, bool &hasRange, double &minWallPrice, double &maxWallPrice)
{
   int count = ArraySize(prices);
   if(count <= 0)
      return;

   // No clustering: draw each selected wall separately.
   if(!UseClusterMode)
   {
      for(int i = 0; i < count; i++)
      {
         int rank = i + 1;
         DrawSingleWall(sideName + "_" + IntegerToString(rank), prices[i], qtys[i], rank, isBid, maxQty, largestFlags[i]);
         UpdateWallRange(prices[i], hasRange, minWallPrice, maxWallPrice);
      }
      return;
   }

   double clusterDistance = MathMax(0.0, ClusterDistancePoints) * Point;

   bool used[];
   ArrayResize(used, count);
   for(int u = 0; u < count; u++)
      used[u] = false;

   int clusterRank = 0;

   for(int i = 0; i < count; i++)
   {
      if(used[i])
         continue;

      double minP = prices[i];
      double maxP = prices[i];
      double totalQ = qtys[i];
      bool containsLargest = largestFlags[i];
      int members = 1;

      used[i] = true;

      // Group any selected wall that sits close to this wall/cluster.
      bool expanded = true;
      while(expanded)
      {
         expanded = false;

         for(int j = 0; j < count; j++)
         {
            if(used[j])
               continue;

            bool nearCluster = false;

            if(MathAbs(prices[j] - minP) <= clusterDistance || MathAbs(prices[j] - maxP) <= clusterDistance)
               nearCluster = true;

            if(prices[j] >= minP - clusterDistance && prices[j] <= maxP + clusterDistance)
               nearCluster = true;

            if(nearCluster)
            {
               used[j] = true;
               if(prices[j] < minP) minP = prices[j];
               if(prices[j] > maxP) maxP = prices[j];
               totalQ += qtys[j];
               containsLargest = containsLargest || largestFlags[j];
               members++;
               expanded = true;
            }
         }
      }

      clusterRank++;

      DrawClusterWall(sideName + "_CLUSTER_" + IntegerToString(clusterRank),
                      minP, maxP, totalQ, clusterRank, isBid, maxQty, containsLargest, members);

      UpdateWallRange(minP, hasRange, minWallPrice, maxWallPrice);
      UpdateWallRange(maxP, hasRange, minWallPrice, maxWallPrice);
   }
}

void DrawTopWalls(double &bidPrices[], double &bidQtys[], int bidCount,
                  double &askPrices[], double &askQtys[], int askCount)
{
   if(!DrawPriceWalls) return;

   DeleteWallObjects();

   if(AutoEnableChartShift)
   {
      ChartSetInteger(0, CHART_SHIFT, true);
      ChartSetDouble(0, CHART_SHIFT_SIZE, ChartShiftPercent);
   }

   int topN = TopWallsPerSide;
   if(DrawLargestOnly) topN = 1;
   if(topN < 1) topN = 1;
   if(topN > 10) topN = 10;

   int largestBidIndex = LargestIndex(bidQtys, bidCount);
   int largestAskIndex = LargestIndex(askQtys, askCount);

   double maxQty = 0.0;
   for(int a=0; a<bidCount; a++) if(bidQtys[a] > maxQty) maxQty = bidQtys[a];
   for(int b=0; b<askCount; b++) if(askQtys[b] > maxQty) maxQty = askQtys[b];

   bool bidUsed[];
   bool askUsed[];
   ArrayResize(bidUsed, bidCount);
   ArrayResize(askUsed, askCount);
   for(int i=0; i<bidCount; i++) bidUsed[i] = false;
   for(int j=0; j<askCount; j++) askUsed[j] = false;

   double selectedBidPrices[];
   double selectedBidQtys[];
   bool   selectedBidLargest[];

   double selectedAskPrices[];
   double selectedAskQtys[];
   bool   selectedAskLargest[];

   bool hasWallRange = false;
   double minWallPrice = 0.0;
   double maxWallPrice = 0.0;

   int selectedBidCount = 0;
   int selectedAskCount = 0;

   // First, force the single largest bid and single largest ask to appear.
   if(AlwaysDrawLargestBidAsk)
   {
      if(largestBidIndex >= 0 && bidQtys[largestBidIndex] > 0.0)
      {
         bidUsed[largestBidIndex] = true;
         AddSelectedWall(bidPrices[largestBidIndex], bidQtys[largestBidIndex], true,
                         selectedBidPrices, selectedBidQtys, selectedBidLargest);
         selectedBidCount++;
      }

      if(largestAskIndex >= 0 && askQtys[largestAskIndex] > 0.0)
      {
         askUsed[largestAskIndex] = true;
         AddSelectedWall(askPrices[largestAskIndex], askQtys[largestAskIndex], true,
                         selectedAskPrices, selectedAskQtys, selectedAskLargest);
         selectedAskCount++;
      }
   }

   // If forced largest is off, select from the full book using the same ranking/filter logic.
   if(!AlwaysDrawLargestBidAsk)
   {
      selectedBidCount = 0;
      selectedAskCount = 0;
   }

   // Then select additional major bid walls.
   while(selectedBidCount < topN)
   {
      int bestBid = -1;
      double bestBidQty = -1.0;

      for(int bi=0; bi<bidCount; bi++)
      {
         if(!bidUsed[bi] && bidQtys[bi] > bestBidQty)
         {
            bestBidQty = bidQtys[bi];
            bestBid = bi;
         }
      }

      if(bestBid < 0) break;
      bidUsed[bestBid] = true;

      if(WallPassesMajorFilter(bidQtys[bestBid], maxQty))
      {
         AddSelectedWall(bidPrices[bestBid], bidQtys[bestBid], (bestBid == largestBidIndex),
                         selectedBidPrices, selectedBidQtys, selectedBidLargest);
         selectedBidCount++;
      }
      else if(bestBidQty < maxQty * MathMax(0.0, MinWallPercentOfLargest) / 100.0)
      {
         break;
      }
   }

   // Then select additional major ask walls.
   while(selectedAskCount < topN)
   {
      int bestAsk = -1;
      double bestAskQty = -1.0;

      for(int ai=0; ai<askCount; ai++)
      {
         if(!askUsed[ai] && askQtys[ai] > bestAskQty)
         {
            bestAskQty = askQtys[ai];
            bestAsk = ai;
         }
      }

      if(bestAsk < 0) break;
      askUsed[bestAsk] = true;

      if(WallPassesMajorFilter(askQtys[bestAsk], maxQty))
      {
         AddSelectedWall(askPrices[bestAsk], askQtys[bestAsk], (bestAsk == largestAskIndex),
                         selectedAskPrices, selectedAskQtys, selectedAskLargest);
         selectedAskCount++;
      }
      else if(bestAskQty < maxQty * MathMax(0.0, MinWallPercentOfLargest) / 100.0)
      {
         break;
      }
   }

   DrawWallCollection("BID", selectedBidPrices, selectedBidQtys, selectedBidLargest,
                      true, maxQty, hasWallRange, minWallPrice, maxWallPrice);

   DrawWallCollection("ASK", selectedAskPrices, selectedAskQtys, selectedAskLargest,
                      false, maxQty, hasWallRange, minWallPrice, maxWallPrice);

   ApplyAutoScaleForWalls(hasWallRange, minWallPrice, maxWallPrice);
}

//+------------------------------------------------------------------+
//| Main refresh                                                     |
//+------------------------------------------------------------------+
void RefreshOrderBook()
{
   string json = "";
   string err = "";

   if(!FetchDepth(json, err))
   {
      DrawError(err);
      if(PrintDebug) Print(err);
      return;
   }

   double bidPrices[], bidQtys[], askPrices[], askQtys[];
   int bidCount = ParseSide(json, "bids", bidPrices, bidQtys, DepthLimit);
   int askCount = ParseSide(json, "asks", askPrices, askQtys, DepthLimit);

   if(bidCount <= 0 || askCount <= 0)
   {
      DrawError("Could not parse Binance order book.");
      if(PrintDebug) Print("Parse failed. JSON: ", json);
      return;
   }

   double bidVol = SumQty(bidQtys, bidCount);
   double askVol = SumQty(askQtys, askCount);
   double delta = bidVol - askVol;

   int lb = LargestIndex(bidQtys, bidCount);
   int la = LargestIndex(askQtys, askCount);

   double largestBidPrice = bidPrices[lb];
   double largestBidQty   = bidQtys[lb];
   double largestAskPrice = askPrices[la];
   double largestAskQty   = askQtys[la];

   string bias = BiasText(bidVol, askVol);
   string source = "Last: " + TimeToString(TimeLocal(), TIME_DATE|TIME_SECONDS) + " | Live API | " + BinanceSymbol + " top " + IntegerToString(DepthLimit);

   DrawDashboard(bidVol, askVol, delta, largestBidPrice, largestBidQty, largestAskPrice, largestAskQty, bias, source);
   DrawTopWalls(bidPrices, bidQtys, bidCount, askPrices, askQtys, askCount);

   if(PrintDebug)
   {
      Print("PAXG OB ", BinanceSymbol,
            " BidVol=", DoubleToString(bidVol,2),
            " AskVol=", DoubleToString(askVol,2),
            " LargestBid=", DoubleToString(largestBidPrice,2),"/",DoubleToString(largestBidQty,2),
            " LargestAsk=", DoubleToString(largestAskPrice,2),"/",DoubleToString(largestAskQty,2));
   }
}

//+------------------------------------------------------------------+
//| Expert events                                                    |
//+------------------------------------------------------------------+
int OnInit()
{
   int timerSec = RefreshSeconds;
   if(timerSec < 1) timerSec = 1;

   EventSetTimer(timerSec);
   RefreshOrderBook();
   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason)
{
   EventKillTimer();
   DeleteByPrefix(prefix);

   if(RestoreAutoScaleOnRemove)
      ChartSetInteger(0, CHART_SCALEFIX, false);
}

void OnTick()
{
   // no tick logic needed; timer keeps it updating even on quiet markets
}

void OnTimer()
{
   if(TimeLocal() - lastFetchTime < RefreshSeconds)
      return;

   lastFetchTime = TimeLocal();
   RefreshOrderBook();
}
//+------------------------------------------------------------------+
