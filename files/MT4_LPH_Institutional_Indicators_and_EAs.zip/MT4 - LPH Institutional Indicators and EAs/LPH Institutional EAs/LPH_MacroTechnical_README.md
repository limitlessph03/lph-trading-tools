# LPH Macro-Technical Alignment

Chart-based decision-support system that shows the authoritative **LPH Macro Heatmap**
reading for the current symbol and combines it with local **D1/H4 regime**, an **H1 watch**
layer, and an optional **M15 timing** layer. All technical signals use completed candles.

> **Decision support only.** These programs never open, modify, or close any order.
> No DLLs. Only the bridge EA touches the network (via `WebRequest`).

---

## 1. Components

| File | Type | Role |
|------|------|------|
| `LPH_MacroBridge_EA.mq4` | Expert Advisor | Fetches the macro feed over HTTPS, validates + parses it, writes the shared cache. Runs on **one** dedicated chart. |
| `LPH_MacroTechnical_Alignment.mq4` | Indicator | Reads the cache, computes D1/H4 EMA + TDI, draws the dashboard, raises alerts. No network. |
| `LPH_MacroTechnical_Core.mqh` | Include | Shared symbol/macro/technical logic used by both. |
| `LPH_MacroTechnical_Default.set` | Preset | Default indicator inputs. |
| `LPH_MacroTechnical_ActiveTrader.set` | Preset | Optional preset that enables the noisier M15 timing module. |
| `LPH_MacroBridge_Default.set` | Preset | Default bridge inputs (fill in your URL). |
| `LPH_MacroHeatmap_Cache_v1.example.csv` | Reference | Example of the cache the bridge writes. |

**Backend endpoint used:** `GET /api/mt4/macro-heatmap` (added to `dev-server.js`).
See `LPH_MacroTechnical_API_Contract.md` for the exact response contract.

---

## 2. Install

1. Copy into your MT4 **data folder** (File → Open Data Folder):
   - `LPH_MacroBridge_EA.mq4` → `MQL4\Experts\`
   - `LPH_MacroTechnical_Alignment.mq4` → `MQL4\Indicators\`
   - `LPH_MacroTechnical_Core.mqh` → **both** `MQL4\Experts\` and `MQL4\Indicators\`
     (the `#include` is path-relative, so the `.mqh` must sit next to each `.mq4`).
2. In **MetaEditor**, compile `LPH_MacroBridge_EA.mq4` and
   `LPH_MacroTechnical_Alignment.mq4` (0 errors / 0 warnings expected).
   Pre-built `.ex4` files are included and were compiled cleanly, but recompiling
   in your own terminal is recommended.
3. Allow the API domain: **Tools → Options → Expert Advisors →
   "Allow WebRequest for listed URL"** and add your host, e.g.
   `https://limitless-ph-heatmap.onrender.com` (scheme + host, no path).

---

## 3. Run the bridge (one per terminal)

1. Open a **dedicated** chart (any symbol/timeframe) for the bridge.
   An EA and another trading EA cannot share a chart, so give the bridge its own.
2. Attach `LPH_MacroBridge_EA`. Enable **Allow live trading / Allow WebRequest**
   in the EA dialog (the "live trading" checkbox only gates timers/WebRequest here —
   the EA places no orders).
3. Set inputs:
   - `MacroAPIUrl` = `https://limitless-ph-heatmap.onrender.com/api/mt4/macro-heatmap`
   - `ReadOnlyAPIToken` = only if you set `MT4_READONLY_TOKEN` on the server (optional).
   - Leave the rest at defaults (`FetchIntervalSeconds = 120`).
4. Confirm the on-chart status panel shows **CONNECTED** (or **USING CACHE**).
   Only **one** bridge is needed per terminal; extra bridge instances auto-detect
   each other and run **PASSIVE** (no duplicate requests).

Bridge status meanings:

| State | Meaning |
|-------|---------|
| `CONNECTED` | Last fetch succeeded; cache is fresh. |
| `USING_CACHE` | Latest fetch failed but the last good dataset is still fresh enough. |
| `STALE` | Data older than `DisableSignalsAfterHours`. |
| `AUTH_ERROR` | HTTP 401/403 — check `ReadOnlyAPIToken`. |
| `ENDPOINT_ERROR` | Transport/HTTP error — check URL + WebRequest allowlist. |
| `INVALID_RESPONSE` | Response failed validation (schema/timestamp/fields). |

---

## 4. Run the indicator (any symbol chart)

1. Attach `LPH_MacroTechnical_Alignment` to any symbol chart you want to analyse.
2. Verify on the panel:
   - **Symbol** resolves (e.g. `EURUSD [FX]`, `XAUUSD [METAL]`).
   - **Updated** timestamp + freshness (`LIVE / AGING / STALE / CACHED`).
   - **Base/Quote 30D** scores and the **30D / 7D differentials**.
   - **D1/H4 50 EMA** and **D1/H4 TDI** regime readings.
   - H4 ATR-normalized location, extension, and structure validity.
   - **H1 EMA/TDI Watch** and optional **M15 Trigger** readings.
   - Primary state, A+ trend confirmation, and entry-quality warning.

The indicator works on any chart timeframe — the technical calculations always use
**fixed D1, H4, H1 and M15** on the current symbol, and only **closed candles**
(shift 1 = confirmed candle, shift 2 = previous candle). If history is still loading it
shows `WAITING FOR HISTORY`; missing history never becomes a false neutral signal.

## 5. Signal hierarchy and meaning

- **Macro + D1** define the directional regime.
- **H4** validates structure and identifies pullback, invalidation, or extension.
- **H1 BUY/SELL WATCH** means start monitoring the pair and assess the chart. It is not
  an instruction to enter.
- **M15 BUY/SELL TRIGGER — CHECK CHART** is an optional execution-timing alert. It can
  exist only while the matching H1 Watch remains valid and defaults to OFF.
- **A+ BUY/SELL TREND CONFIRMATION** confirms an established D1/H4 trend. H1 and M15
  are deliberately not required, so a lower-timeframe pullback does not cancel A+.
- **EXTENDED — DO NOT CHASE** means the direction may still be valid but the present
  entry location is poor.
- **H4 STRUCTURE INVALIDATED** requires an ATR-tolerant EMA breach plus confirmed
  opposing H4 TDI; a small move across the EMA alone does not invalidate the setup.

`EnableM15TriggerModule=false` in the default preset. Load
`LPH_MacroTechnical_ActiveTrader.set` only if the member wants M15 timing alerts.
The ATR thresholds are provisional research settings and should be validated before tuning.

> **Do not blindly buy or sell from an alert. The alert identifies a pair and direction
> worth inspecting; the trading strategy determines whether a valid entry exists.**

Before acting, members must assess entry structure, pullback/retest, support/resistance,
liquidity and volume context, stop placement, available reward-to-risk, and news/event risk.

---

## 6. Macro interpretation

- **30-day** = regime; **7-day** = fresh pressure. They are shown separately and never
  merged into one hidden number.
- Pair differential (never reversed):
  `30D Diff = Base 30D − Quote 30D`, `7D Diff = Base 7D − Quote 7D`.
  Example: `EURUSD = EUR − USD`, `GBPJPY = GBP − JPY`.
- Fallback bias thresholds are **inputs** and **provisional** until attribution testing:
  - `MinMacroDifferential` (default 20) — minimum |differential| for a regime.
  - `MacroConflictTolerance` (default 10) — how far 7D may oppose the 30D regime.
- **Gold / Silver / indices / oil:** used **only** if the API supplies an authoritative
  score for that asset. If not, the panel shows `PARTIAL MACRO DATA - USD CONTEXT ONLY`
  and does **not** fabricate a differential. Unresolvable symbols show
  `UNSUPPORTED SYMBOL - MACRO SIGNAL UNAVAILABLE` while the technical section still works.

## 7. Stale-data behaviour

| State | Effect |
|-------|--------|
| **LIVE** | Current data — full alignment. |
| **AGING** | Older than `StaleWarningHours` — warned but alignment still allowed. |
| **STALE** | Older than `DisableSignalsAfterHours` — directional labels disabled (`STALE / SIGNAL DISABLED`). |
| **CACHED** | Fresh enough, but bridge is serving the last good dataset — alignment allowed, labelled CACHED. |
| **INVALID** | Cache present but failed validation — macro unavailable, technical still shown. |
| **MISSING** | No cache — macro unavailable, technical still shown. |

Missing macro data is never treated as zero or as "neutral conditions".

## 8. Alerts

Enable with `EnableAlerts`. Channels: popup / push / email / sound.
Alerts are deduplicated by symbol, alert type, direction, confirmed candle timestamp,
and macro dataset timestamp. H1 Watch uses the closed H1 timestamp; M15 Trigger uses the
closed M15 timestamp; extension/invalidation use the closed H4 timestamp; A+ uses the
latest closed D1/H4 timestamp. They never repeat on every tick.

`AlertAPlusOnly=true` suppresses H1, M15, conflict, extension and invalidation alerts and
notifies only for valid, non-extended A+ trend confirmations. The individual alert inputs
control Watch, Trigger, A+, extension, and invalidation notifications.

Example:
`LPH WATCH | EURUSD | H1 BUY WATCH | Macro bullish | H4 structure valid | H1 EMA + TDI bullish | Inspect chart - no blind entry`

## 9. Notes / limitations

- The macro model is **not** re-implemented in MT4 — the indicator consumes the
  backend's per-currency 7D/30D scores and only performs the base-minus-quote subtraction.
- The backend does not publish a per-currency macro **confidence**; the panel shows
  `Confidence: n/a` rather than inventing one.
- Fallback thresholds are provisional; tune against the live web heatmap.
- H4 ATR location thresholds are provisional and have not yet been attribution-tested.
- M15 timing is intentionally optional and can produce more noise than H1/D1/H4.
- This is not a probability or expected-return estimate and never claims a "safe" or
  "high-probability" trade.
