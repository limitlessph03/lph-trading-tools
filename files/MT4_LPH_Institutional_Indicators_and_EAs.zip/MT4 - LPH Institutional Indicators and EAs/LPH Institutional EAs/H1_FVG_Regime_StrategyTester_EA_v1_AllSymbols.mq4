//+------------------------------------------------------------------+
//|             H1_FVG_Regime_StrategyTester_EA_v1_AllSymbols.mq4    |
//| Strategy Tester execution EA converted from H1 FVG Regime Alert. |
//|                                                                  |
//| Places real Strategy Tester pending orders only.                  |
//| Default logic: H1 FVG + H4 FVG confirmation + D1 opposite block. |
//+------------------------------------------------------------------+
#property strict
#property version   "1.00"
#property description "H1 FVG Strategy Tester EA for all symbols. Tester-safe by default."

// ------------------------- Safety ---------------------------------
input bool   AllowLiveTrading                 = false;
input bool   ConfirmLiveTrading               = false;
input bool   DrawChartObjects                 = true;
input bool   DebugMode                        = true;

// ------------------------- Symbol / timeframe ----------------------
input bool   AllowAllSymbols                  = true;
input string AllowedSymbols                   = "XAUUSDzero,XAGUSDzero,NAS100,DJ30,SP500,GBPNZDzero,EURNZDzero,NZDCHFzero,NZDUSDzero,AUDNZDzero,AUDCHFzero,AUDUSDzero,EURUSDzero,USDCHFzero,USDCADzero,GBPUSDzero";
input int    InpSignalTimeframe               = PERIOD_H1;

// ------------------------- FVG model settings ----------------------
input int    InpATRPeriod                     = 14;
input double InpMinATRMultiple                = 1.0;
input double InpEntryMitigation               = 0.50;
input int    InpPendingExpiryCandles          = 10;
input bool   InpOneSetupPerDirection          = false;
input int    InpMaxActiveSetupsPerDirection   = 10;

// Most recent H1 default levels from our research.
input double InpSL1_ATR_Multiple              = 1.5;
input double InpSL2_ATR_Multiple              = 2.5;
input double InpTP1_ATR_Multiple              = 2.0;
input double InpTP2_ATR_Multiple              = 3.0;

// 0 = C_SL1_PARTIAL_50_50: both legs use SL1, TP1/TP2
// 1 = D_SL2_PARTIAL_50_50: both legs use SL2, TP1/TP2
input int    InpTradeManagement               = 0;

// ------------------------- Risk / execution ------------------------
input int    InpMagicBase                     = 920100;
input int    InpSlippagePoints                = 30;
input bool   UseRiskPercent                   = true;
input double RiskPercent                      = 2.0;
input double RiskEquityOverride               = 1000.0; // 0 = use AccountEquity. Useful when MT4 ignores tester deposit.
input double FixedLot                         = 0.10;   // interpreted as total position if UseRiskPercent=false
input bool   FixedLotIsTotalPosition          = true;
input int    MaxSpreadPoints                  = 0;      // 0 = off

// ------------------------- Session filter --------------------------
input bool   UseSessionFilter                 = false;
input int    SessionStartHour                 = 0;
input int    SessionEndHour                   = 24;

// ------------------------- Regime filters --------------------------
// Defaults follow the most recent quality idea: H1 FVG + H4 FVG agreement + D1 not actively opposite.
input bool   UseH4FVGConfirmation             = true;
input int    H4FVGConfirmLookbackBars         = 30;
input bool   UseD1OppositeFVGBlock            = true;
input int    D1OppositeFVGLookbackBars        = 20;

input bool   UseH4EMAFilter                   = false;
input int    H4EMAPeriod                      = 50;
input bool   H4EMAUseClosedBarOnly            = true;

input bool   UseH4EMADistanceFilter           = false;
input int    H4EMADistanceATRPeriod           = 14;
input double MinH4EMADistanceATR              = 0.50;

input bool   UseH4ADXFilter                   = false;
input int    H4ADXPeriod                      = 14;
input double MinH4ADX                         = 18.0;

input bool   UseH4EMASlopeFilter              = false;
input int    H4EMASlopeLookback               = 5;
input double MinH4EMASlopeATR                 = 0.20;

input bool   UseD1EMAFilter                   = false;
input int    D1EMAPeriod                      = 50;
input bool   D1EMAUseClosedBarOnly            = true;

input bool   UseATRRegimeFilter               = false;
input int    ATRFastPeriod                    = 14;
input int    ATRSlowPeriod                    = 100;
input double ATRMaxExpansionMultiple          = 1.30;

input bool   UseOversizedCandleFilter         = false;
input double OversizedCandleATRMultiple       = 1.80;
input int    OversizedLookbackShift           = 1;

input bool   UseVWAPDistanceFilter            = false;
input double VWAPDistanceATRMultiple          = 2.0;

// ------------------------- CSV logging -----------------------------
input bool   ExportCSV                        = true;
input string InpValidTradeLogFile             = "h1_fvg_strategytester_valid_trades.csv";
input string InpPendingAuditFile              = "h1_fvg_strategytester_pending_audit.csv";
input bool   ResetCSVOnInit                   = true;

// ------------------------- Internal state --------------------------
datetime g_lastSignalBarTime = 0;
int      g_loggedTickets[];
int      g_createdPendingTickets[];

struct FvgSetup
{
   bool     valid;
   int      direction;    // 1 bullish, -1 bearish
   datetime setupTime;
   int      setupShift;
   double   fvgHigh;
   double   fvgLow;
   double   fvgMid;
   double   gapPrice;
   double   atr;
   double   vwap;
};

//+------------------------------------------------------------------+
int OnInit()
{
   Print("H1 FVG Strategy Tester EA loaded. Symbol=", Symbol(),
         " ChartTF=", Period(), " SignalTF=", InpSignalTimeframe,
         " AllowAllSymbols=", BoolText(AllowAllSymbols),
         " H4FVGConfirm=", BoolText(UseH4FVGConfirmation),
         " D1OppBlock=", BoolText(UseD1OppositeFVGBlock));

   if(!IsTesting() && !(AllowLiveTrading && ConfirmLiveTrading))
      Print("SAFETY: not in Strategy Tester and live trading not confirmed. EA will not send orders.");

   if(Period() != InpSignalTimeframe)
      Print("WARNING: for clean Strategy Tester results, run the chart timeframe as H1 / InpSignalTimeframe. Current Period=", Period());

   if(!SymbolAllowed())
      Print("WARNING: current symbol not allowed by AllowedSymbols. Set AllowAllSymbols=true or add ", Symbol());

   if(ExportCSV && ResetCSVOnInit)
   {
      WriteTradeLogHeader();
      WritePendingAuditHeader();
   }

   return INIT_SUCCEEDED;
}

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   LogClosedTrades();
   Print("H1 FVG Strategy Tester EA removed. reason=", reason, " Symbol=", Symbol());
}

//+------------------------------------------------------------------+
void OnTick()
{
   if(!TradingAllowedBySafety())
      return;

   if(!SymbolAllowed())
      return;

   if(MaxSpreadPoints > 0 && MarketInfo(Symbol(), MODE_SPREAD) > MaxSpreadPoints)
      return;

   ManagePendingExpiry();
   LogClosedTrades();

   if(iBars(Symbol(), InpSignalTimeframe) < 120)
      return;

   datetime signalBarTime = iTime(Symbol(), InpSignalTimeframe, 0);
   if(signalBarTime == g_lastSignalBarTime)
      return;
   g_lastSignalBarTime = signalBarTime;

   if(!SessionAllowed())
      return;

   FvgSetup setup;
   if(!DetectFVGAtShift(1, setup))
      return;

   string status = "";
   string reasons = "";
   bool filtersPassed = RegimeFiltersOk(setup, status, reasons);
   if(!filtersPassed)
   {
      if(DebugMode)
         Print("REJECTED ", Symbol(), " ", DirectionName(setup.direction), " setup=", TimeToString(setup.setupTime, TIME_DATE|TIME_MINUTES), " reasons=", reasons, " status=", status);
      return;
   }

   double entry = NormalizePrice(setup.fvgMid);
   double stopMultiplier = (InpTradeManagement == 1 ? InpSL2_ATR_Multiple : InpSL1_ATR_Multiple);
   double sl = NormalizePrice(setup.direction == 1 ? entry - setup.atr * stopMultiplier : entry + setup.atr * stopMultiplier);
   double sl1 = NormalizePrice(setup.direction == 1 ? entry - setup.atr * InpSL1_ATR_Multiple : entry + setup.atr * InpSL1_ATR_Multiple);
   double sl2 = NormalizePrice(setup.direction == 1 ? entry - setup.atr * InpSL2_ATR_Multiple : entry + setup.atr * InpSL2_ATR_Multiple);
   double tp1 = NormalizePrice(setup.direction == 1 ? entry + setup.atr * InpTP1_ATR_Multiple : entry - setup.atr * InpTP1_ATR_Multiple);
   double tp2 = NormalizePrice(setup.direction == 1 ? entry + setup.atr * InpTP2_ATR_Multiple : entry - setup.atr * InpTP2_ATR_Multiple);

   if(DrawChartObjects)
      DrawSetup(setup, entry, sl1, sl2, tp1, tp2, status, reasons, true);

   if(SetupAlreadyExists(setup))
      return;
   if(InpOneSetupPerDirection && HasActiveDirection(setup.direction))
      return;
   if(ActiveSetupsByDirection(setup.direction) >= InpMaxActiveSetupsPerDirection)
      return;

   PlacePartialPendingOrders(setup, entry, sl, tp1, tp2, status, reasons);
}

//+------------------------------------------------------------------+
bool TradingAllowedBySafety()
{
   if(IsTesting())
      return true;
   return (AllowLiveTrading && ConfirmLiveTrading);
}

//+------------------------------------------------------------------+
bool SymbolAllowed()
{
   if(AllowAllSymbols)
      return true;
   string list = "," + AllowedSymbols + ",";
   string sym = "," + Symbol() + ",";
   return (StringFind(list, sym, 0) >= 0);
}

//+------------------------------------------------------------------+
bool SessionAllowed()
{
   if(!UseSessionFilter)
      return true;
   int hour = TimeHour(iTime(Symbol(), InpSignalTimeframe, 1));
   if(SessionStartHour == SessionEndHour)
      return true;
   if(SessionStartHour < SessionEndHour)
      return (hour >= SessionStartHour && hour < SessionEndHour);
   return (hour >= SessionStartHour || hour < SessionEndHour);
}

//+------------------------------------------------------------------+
bool DetectFVGAtShift(const int shift, FvgSetup &setup)
{
   setup.valid = false;
   if(shift < 1)
      return false;

   int tf = InpSignalTimeframe;
   if(iBars(Symbol(), tf) < shift + 5)
      return false;

   double c1High = iHigh(Symbol(), tf, shift + 2);
   double c1Low  = iLow(Symbol(), tf, shift + 2);
   double c3High = iHigh(Symbol(), tf, shift);
   double c3Low  = iLow(Symbol(), tf, shift);
   double atr    = iATR(Symbol(), tf, InpATRPeriod, shift);
   if(c1High <= 0.0 || c1Low <= 0.0 || c3High <= 0.0 || c3Low <= 0.0 || atr <= 0.0)
      return false;

   if(c1High < c3Low)
   {
      setup.direction = 1;
      setup.fvgHigh = c3Low;
      setup.fvgLow = c1High;
   }
   else if(c1Low > c3High)
   {
      setup.direction = -1;
      setup.fvgHigh = c1Low;
      setup.fvgLow = c3High;
   }
   else
      return false;

   setup.gapPrice = setup.fvgHigh - setup.fvgLow;
   if(setup.gapPrice < atr * InpMinATRMultiple)
      return false;

   setup.setupTime = iTime(Symbol(), tf, shift);
   setup.setupShift = shift;
   setup.fvgMid = EntryFromMitigation(setup.direction, setup.fvgHigh, setup.fvgLow, InpEntryMitigation);
   setup.atr = atr;
   setup.vwap = DailyVWAP(Symbol(), tf, shift);
   setup.valid = true;
   return true;
}

//+------------------------------------------------------------------+
bool RegimeFiltersOk(const FvgSetup &setup, string &status, string &rejectReasons)
{
   bool pass = true;
   status = "";
   rejectReasons = "";

   CheckFilter(UseH4FVGConfirmation, "H4_FVG_CONFIRM", H4FVGConfirmOk(setup.direction), "H4_FVG_CONFIRM_FAIL", status, rejectReasons, pass);
   CheckFilter(UseD1OppositeFVGBlock, "D1_OPPOSITE_BLOCK", !D1OppositeFVGExists(setup.direction), "D1_OPPOSITE_FVG_FAIL", status, rejectReasons, pass);

   CheckFilter(UseH4EMAFilter, "H4_EMA", EmaBiasOk(PERIOD_H4, H4EMAPeriod, setup.direction, H4EMAUseClosedBarOnly), "H4_EMA_BIAS_FAIL", status, rejectReasons, pass);
   CheckFilter(UseH4EMADistanceFilter, "H4_EMA_DISTANCE", H4EMADistanceOk(), "H4_EMA_DISTANCE_FAIL", status, rejectReasons, pass);
   CheckFilter(UseH4ADXFilter, "H4_ADX", H4ADXOk(), "H4_ADX_FAIL", status, rejectReasons, pass);
   CheckFilter(UseH4EMASlopeFilter, "H4_EMA_SLOPE", H4EMASlopeOk(setup.direction), "H4_EMA_SLOPE_FAIL", status, rejectReasons, pass);
   CheckFilter(UseD1EMAFilter, "D1_EMA", EmaBiasOk(PERIOD_D1, D1EMAPeriod, setup.direction, D1EMAUseClosedBarOnly), "D1_EMA_BIAS_FAIL", status, rejectReasons, pass);

   bool atrPass = true;
   if(UseATRRegimeFilter)
   {
      double fast = iATR(Symbol(), InpSignalTimeframe, ATRFastPeriod, 1);
      double slow = iATR(Symbol(), InpSignalTimeframe, ATRSlowPeriod, 1);
      atrPass = fast > 0.0 && slow > 0.0 && fast <= slow * ATRMaxExpansionMultiple;
   }
   CheckFilter(UseATRRegimeFilter, "ATR_REGIME", atrPass, "ATR_EXPANSION_FAIL", status, rejectReasons, pass);

   bool oversizedPass = true;
   if(UseOversizedCandleFilter)
   {
      int s = MathMax(1, OversizedLookbackShift);
      double range = iHigh(Symbol(), InpSignalTimeframe, s) - iLow(Symbol(), InpSignalTimeframe, s);
      double atr = iATR(Symbol(), InpSignalTimeframe, ATRFastPeriod, s);
      oversizedPass = range > 0.0 && atr > 0.0 && range <= atr * OversizedCandleATRMultiple;
   }
   CheckFilter(UseOversizedCandleFilter, "OVERSIZED_CANDLE", oversizedPass, "OVERSIZED_CANDLE_FAIL", status, rejectReasons, pass);

   bool vwapPass = true;
   if(UseVWAPDistanceFilter)
   {
      double vwap = DailyVWAP(Symbol(), InpSignalTimeframe, 1);
      double atr = iATR(Symbol(), InpSignalTimeframe, ATRFastPeriod, 1);
      vwapPass = vwap > 0.0 && atr > 0.0 && MathAbs(setup.fvgMid - vwap) <= atr * VWAPDistanceATRMultiple;
      if(vwap <= 0.0)
         CheckFilter(true, "VWAP_DISTANCE", false, "VWAP_UNAVAILABLE", status, rejectReasons, pass);
      else
         CheckFilter(true, "VWAP_DISTANCE", vwapPass, "VWAP_DISTANCE_FAIL", status, rejectReasons, pass);
   }
   else
      CheckFilter(false, "VWAP_DISTANCE", true, "", status, rejectReasons, pass);

   if(rejectReasons == "")
      rejectReasons = "PASS";
   return pass;
}

//+------------------------------------------------------------------+
void CheckFilter(const bool enabled, const string name, const bool filterPass, const string reason,
                 string &status, string &reasons, bool &overallPass)
{
   if(status != "")
      status += "|";
   if(!enabled)
   {
      status += name + ":off";
      return;
   }
   status += name + ":" + (filterPass ? "pass" : "fail");
   if(!filterPass)
   {
      if(reasons != "")
         reasons += "|";
      reasons += reason;
      overallPass = false;
   }
}

//+------------------------------------------------------------------+
bool EmaBiasOk(const int timeframe, const int period, const int direction, const bool closedOnly)
{
   int shift = closedOnly ? 1 : 0;
   if(iBars(Symbol(), timeframe) < period + shift + 5)
      return false;
   double closeValue = iClose(Symbol(), timeframe, shift);
   double ema = iMA(Symbol(), timeframe, period, 0, MODE_EMA, PRICE_CLOSE, shift);
   if(closeValue <= 0.0 || ema <= 0.0)
      return false;
   if(direction == 1)
      return closeValue > ema;
   return closeValue < ema;
}

//+------------------------------------------------------------------+
bool H4EMADistanceOk()
{
   int shift = 1;
   int bars = iBars(Symbol(), PERIOD_H4);
   int minBars = MathMax(H4EMAPeriod, H4EMADistanceATRPeriod) + shift + 5;
   if(bars < minBars)
      return false;

   double h4Close = iClose(Symbol(), PERIOD_H4, shift);
   double h4Ema = iMA(Symbol(), PERIOD_H4, H4EMAPeriod, 0, MODE_EMA, PRICE_CLOSE, shift);
   double h4Atr = iATR(Symbol(), PERIOD_H4, H4EMADistanceATRPeriod, shift);
   if(h4Close <= 0.0 || h4Ema <= 0.0 || h4Atr <= 0.0)
      return false;

   return MathAbs(h4Close - h4Ema) >= h4Atr * MinH4EMADistanceATR;
}

//+------------------------------------------------------------------+
bool H4ADXOk()
{
   int shift = 1;
   int bars = iBars(Symbol(), PERIOD_H4);
   if(bars < H4ADXPeriod + shift + 5)
      return false;

   double adx = iADX(Symbol(), PERIOD_H4, H4ADXPeriod, PRICE_CLOSE, MODE_MAIN, shift);
   return adx >= MinH4ADX;
}

//+------------------------------------------------------------------+
bool H4EMASlopeOk(const int direction)
{
   int currentShift = 1;
   int pastShift = currentShift + MathMax(1, H4EMASlopeLookback);
   int bars = iBars(Symbol(), PERIOD_H4);
   int minBars = MathMax(MathMax(H4EMAPeriod, H4EMADistanceATRPeriod), H4EMAPeriod + pastShift) + 5;
   if(bars < minBars)
      return false;

   double emaNow = iMA(Symbol(), PERIOD_H4, H4EMAPeriod, 0, MODE_EMA, PRICE_CLOSE, currentShift);
   double emaPast = iMA(Symbol(), PERIOD_H4, H4EMAPeriod, 0, MODE_EMA, PRICE_CLOSE, pastShift);
   double h4Atr = iATR(Symbol(), PERIOD_H4, H4EMADistanceATRPeriod, currentShift);
   if(emaNow <= 0.0 || emaPast <= 0.0 || h4Atr <= 0.0)
      return false;

   double requiredSlope = h4Atr * MinH4EMASlopeATR;
   double slope = emaNow - emaPast;
   if(direction == 1)
      return slope >= requiredSlope;
   return slope <= -requiredSlope;
}

//+------------------------------------------------------------------+
bool H4FVGConfirmOk(const int direction)
{
   return FVGExistsOnTimeframe(PERIOD_H4, direction, H4FVGConfirmLookbackBars);
}

//+------------------------------------------------------------------+
bool D1OppositeFVGExists(const int direction)
{
   int opposite = -direction;
   return FVGExistsOnTimeframe(PERIOD_D1, opposite, D1OppositeFVGLookbackBars);
}

//+------------------------------------------------------------------+
bool FVGExistsOnTimeframe(const int timeframe, const int direction, const int lookbackBars)
{
   int maxLookback = MathMax(3, lookbackBars);
   for(int shift = 1; shift <= maxLookback; shift++)
   {
      if(iBars(Symbol(), timeframe) < shift + 5)
         return false;
      double c1High = iHigh(Symbol(), timeframe, shift + 2);
      double c1Low  = iLow(Symbol(), timeframe, shift + 2);
      double c3High = iHigh(Symbol(), timeframe, shift);
      double c3Low  = iLow(Symbol(), timeframe, shift);
      double atr = iATR(Symbol(), timeframe, InpATRPeriod, shift);
      if(c1High <= 0.0 || c1Low <= 0.0 || c3High <= 0.0 || c3Low <= 0.0 || atr <= 0.0)
         continue;

      if(direction == 1 && c1High < c3Low && (c3Low - c1High) >= atr * InpMinATRMultiple)
         return true;
      if(direction == -1 && c1Low > c3High && (c1Low - c3High) >= atr * InpMinATRMultiple)
         return true;
   }
   return false;
}

//+------------------------------------------------------------------+
void PlacePartialPendingOrders(const FvgSetup &setup, const double entry, const double sl,
                               const double tp1, const double tp2, const string status, const string reasons)
{
   int orderType = (setup.direction == 1 ? OP_BUYLIMIT : OP_SELLLIMIT);

   RefreshRates();
   if(orderType == OP_BUYLIMIT && entry >= Ask)
   {
      if(DebugMode) Print("SKIP: bullish FVG entry is not below Ask. entry=", PriceToString(entry), " Ask=", PriceToString(Ask));
      return;
   }
   if(orderType == OP_SELLLIMIT && entry <= Bid)
   {
      if(DebugMode) Print("SKIP: bearish FVG entry is not above Bid. entry=", PriceToString(entry), " Bid=", PriceToString(Bid));
      return;
   }

   double legLot = CalculateLegLot(entry, sl);
   if(legLot <= 0.0)
   {
      Print("SKIP: calculated leg lot is 0. entry=", PriceToString(entry), " sl=", PriceToString(sl));
      return;
   }

   datetime expiration = TimeCurrent() + InpPendingExpiryCandles * PeriodSeconds(InpSignalTimeframe);
   string setupToken = SetupToken(setup);

   int t1 = SendPending(orderType, legLot, entry, sl, tp1, expiration, setupToken + "|L1");
   int t2 = SendPending(orderType, legLot, entry, sl, tp2, expiration, setupToken + "|L2");

   if(DebugMode)
      Print("SETUP SENT ", Symbol(), " ", DirectionName(setup.direction), " setup=", TimeToString(setup.setupTime, TIME_DATE|TIME_MINUTES),
            " entry=", PriceToString(entry), " sl=", PriceToString(sl), " tp1=", PriceToString(tp1), " tp2=", PriceToString(tp2),
            " lot/leg=", DoubleToString(legLot, 2), " tickets=", t1, ",", t2, " status=", status, " reasons=", reasons);
}

//+------------------------------------------------------------------+
int SendPending(const int orderType, const double lots, const double entry, const double sl, const double tp,
                const datetime expiration, const string comment)
{
   int ticket = OrderSend(Symbol(), orderType, lots, entry, InpSlippagePoints, sl, tp, comment, InpMagicBase, expiration, clrNONE);
   if(ticket < 0)
   {
      int err = GetLastError();
      Print("OrderSend failed. err=", err, " type=", orderType, " lots=", DoubleToString(lots, 2),
            " entry=", PriceToString(entry), " sl=", PriceToString(sl), " tp=", PriceToString(tp), " comment=", comment);
      ResetLastError();
      return -1;
   }

   MarkIntKey(g_createdPendingTickets, ticket);
   if(ExportCSV)
      AppendPendingAudit("PLACED", ticket, orderType, lots, entry, sl, tp, expiration, comment, "");
   return ticket;
}

//+------------------------------------------------------------------+
double CalculateLegLot(const double entry, const double sl)
{
   double totalLots = FixedLot;
   if(UseRiskPercent)
   {
      double equity = RiskEquityOverride > 0.0 ? RiskEquityOverride : AccountEquity();
      double riskMoney = equity * RiskPercent / 100.0;
      double distance = MathAbs(entry - sl);
      double tickSize = MarketInfo(Symbol(), MODE_TICKSIZE);
      double tickValue = MarketInfo(Symbol(), MODE_TICKVALUE);
      if(distance <= 0.0 || tickSize <= 0.0 || tickValue <= 0.0)
         return 0.0;
      double riskPerLot = distance / tickSize * tickValue;
      if(riskPerLot <= 0.0)
         return 0.0;
      totalLots = riskMoney / riskPerLot;
   }

   double legLots = FixedLotIsTotalPosition || UseRiskPercent ? totalLots * 0.5 : totalLots;
   return NormalizeLots(legLots);
}

//+------------------------------------------------------------------+
double NormalizeLots(double lots)
{
   double minLot = MarketInfo(Symbol(), MODE_MINLOT);
   double maxLot = MarketInfo(Symbol(), MODE_MAXLOT);
   double lotStep = MarketInfo(Symbol(), MODE_LOTSTEP);
   if(lotStep <= 0.0)
      lotStep = 0.01;

   lots = MathFloor(lots / lotStep) * lotStep;
   if(lots < minLot)
      lots = minLot;
   if(lots > maxLot)
      lots = maxLot;
   return NormalizeDouble(lots, 2);
}

//+------------------------------------------------------------------+
void ManagePendingExpiry()
{
   datetime now = TimeCurrent();
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
         continue;
      if(OrderSymbol() != Symbol() || OrderMagicNumber() != InpMagicBase)
         continue;
      int type = OrderType();
      if(type != OP_BUYLIMIT && type != OP_SELLLIMIT)
         continue;

      datetime setupTime = ExtractSetupTime(OrderComment());
      if(setupTime <= 0)
         continue;
      datetime expireTime = setupTime + InpPendingExpiryCandles * PeriodSeconds(InpSignalTimeframe);
      if(now >= expireTime)
      {
         int ticket = OrderTicket();
         bool deleted = OrderDelete(ticket, clrNONE);
         if(ExportCSV)
            AppendPendingAudit(deleted ? "EXPIRED_DELETED" : "EXPIRE_DELETE_FAILED", ticket, type, OrderLots(), OrderOpenPrice(), OrderStopLoss(), OrderTakeProfit(), expireTime, OrderComment(), deleted ? "" : IntegerToString(GetLastError()));
         if(!deleted)
            ResetLastError();
      }
   }
}

//+------------------------------------------------------------------+
bool SetupAlreadyExists(const FvgSetup &setup)
{
   string token = SetupToken(setup);
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
         continue;
      if(OrderSymbol() == Symbol() && OrderMagicNumber() == InpMagicBase && StringFind(OrderComment(), token, 0) >= 0)
         return true;
   }
   for(int h = OrdersHistoryTotal() - 1; h >= 0; h--)
   {
      if(!OrderSelect(h, SELECT_BY_POS, MODE_HISTORY))
         continue;
      if(OrderSymbol() == Symbol() && OrderMagicNumber() == InpMagicBase && StringFind(OrderComment(), token, 0) >= 0)
         return true;
   }
   return false;
}

//+------------------------------------------------------------------+
bool HasActiveDirection(const int direction)
{
   return ActiveSetupsByDirection(direction) > 0;
}

//+------------------------------------------------------------------+
int ActiveSetupsByDirection(const int direction)
{
   int count = 0;
   string dirTag = direction == 1 ? "BUY" : "SELL";
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
         continue;
      if(OrderSymbol() != Symbol() || OrderMagicNumber() != InpMagicBase)
         continue;
      if(StringFind(OrderComment(), "H1FVG_" + dirTag, 0) >= 0)
         count++;
   }
   return count;
}

//+------------------------------------------------------------------+
string SetupToken(const FvgSetup &setup)
{
   string dir = setup.direction == 1 ? "BUY" : "SELL";
   return "H1FVG_" + dir + "_T" + IntegerToString((int)setup.setupTime);
}

//+------------------------------------------------------------------+
datetime ExtractSetupTime(const string comment)
{
   int p = StringFind(comment, "_T", 0);
   if(p < 0)
      return 0;
   int start = p + 2;
   int end = StringFind(comment, "|", start);
   if(end < 0)
      end = StringLen(comment);
   string v = StringSubstr(comment, start, end - start);
   return (datetime)StrToInteger(v);
}

//+------------------------------------------------------------------+
double DailyVWAP(const string symbol, const int tf, const int shift)
{
   datetime anchor = iTime(symbol, tf, shift);
   if(anchor <= 0)
      return 0.0;

   int day = TimeDay(anchor);
   int month = TimeMonth(anchor);
   int year = TimeYear(anchor);
   double pv = 0.0;
   double vol = 0.0;
   int bars = iBars(symbol, tf);
   int maxBars = MathMin(bars, shift + 96);

   for(int s = shift; s < maxBars; s++)
   {
      datetime t = iTime(symbol, tf, s);
      if(TimeDay(t) != day || TimeMonth(t) != month || TimeYear(t) != year)
         break;
      double typical = (iHigh(symbol, tf, s) + iLow(symbol, tf, s) + iClose(symbol, tf, s)) / 3.0;
      double volume = MathMax(1.0, (double)iVolume(symbol, tf, s));
      pv += typical * volume;
      vol += volume;
   }
   return vol > 0.0 ? pv / vol : 0.0;
}

//+------------------------------------------------------------------+
void LogClosedTrades()
{
   if(!ExportCSV)
      return;
   for(int i = OrdersHistoryTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_HISTORY))
         continue;
      if(OrderSymbol() != Symbol() || OrderMagicNumber() != InpMagicBase)
         continue;
      int type = OrderType();
      if(type != OP_BUY && type != OP_SELL)
         continue;
      int ticket = OrderTicket();
      if(IntKeyExists(g_loggedTickets, ticket))
         continue;
      AppendTradeLog(ticket);
      MarkIntKey(g_loggedTickets, ticket);
   }
}

//+------------------------------------------------------------------+
void WriteTradeLogHeader()
{
   int h = FileOpen(InpValidTradeLogFile, FILE_CSV|FILE_WRITE, ',');
   if(h < 0)
      return;
   FileWrite(h, "ticket", "symbol", "type", "lots", "open_time", "close_time", "open_price", "close_price", "sl", "tp", "profit", "swap", "commission", "comment");
   FileClose(h);
}

//+------------------------------------------------------------------+
void AppendTradeLog(const int ticket)
{
   int h = FileOpen(InpValidTradeLogFile, FILE_CSV|FILE_READ|FILE_WRITE, ',');
   if(h < 0)
      return;
   FileSeek(h, 0, SEEK_END);
   FileWrite(h,
             ticket,
             OrderSymbol(),
             OrderType() == OP_BUY ? "BUY" : "SELL",
             DoubleToString(OrderLots(), 2),
             TimeToString(OrderOpenTime(), TIME_DATE|TIME_MINUTES),
             TimeToString(OrderCloseTime(), TIME_DATE|TIME_MINUTES),
             DoubleToString(OrderOpenPrice(), Digits),
             DoubleToString(OrderClosePrice(), Digits),
             DoubleToString(OrderStopLoss(), Digits),
             DoubleToString(OrderTakeProfit(), Digits),
             DoubleToString(OrderProfit(), 2),
             DoubleToString(OrderSwap(), 2),
             DoubleToString(OrderCommission(), 2),
             OrderComment());
   FileClose(h);
}

//+------------------------------------------------------------------+
void WritePendingAuditHeader()
{
   int h = FileOpen(InpPendingAuditFile, FILE_CSV|FILE_WRITE, ',');
   if(h < 0)
      return;
   FileWrite(h, "event", "ticket", "symbol", "type", "lots", "time", "price", "sl", "tp", "expiration", "comment", "note");
   FileClose(h);
}

//+------------------------------------------------------------------+
void AppendPendingAudit(const string event, const int ticket, const int type, const double lots, const double price,
                        const double sl, const double tp, const datetime expiration, const string comment, const string note)
{
   int h = FileOpen(InpPendingAuditFile, FILE_CSV|FILE_READ|FILE_WRITE, ',');
   if(h < 0)
      return;
   FileSeek(h, 0, SEEK_END);
   FileWrite(h,
             event,
             ticket,
             Symbol(),
             OrderTypeName(type),
             DoubleToString(lots, 2),
             TimeToString(TimeCurrent(), TIME_DATE|TIME_MINUTES),
             DoubleToString(price, Digits),
             DoubleToString(sl, Digits),
             DoubleToString(tp, Digits),
             TimeToString(expiration, TIME_DATE|TIME_MINUTES),
             comment,
             note);
   FileClose(h);
}

//+------------------------------------------------------------------+
string OrderTypeName(const int type)
{
   if(type == OP_BUY) return "BUY";
   if(type == OP_SELL) return "SELL";
   if(type == OP_BUYLIMIT) return "BUYLIMIT";
   if(type == OP_SELLLIMIT) return "SELLLIMIT";
   if(type == OP_BUYSTOP) return "BUYSTOP";
   if(type == OP_SELLSTOP) return "SELLSTOP";
   return "UNKNOWN";
}

//+------------------------------------------------------------------+
bool IntKeyExists(int &arr[], const int key)
{
   int n = ArraySize(arr);
   for(int i = 0; i < n; i++)
   {
      if(arr[i] == key)
         return true;
   }
   return false;
}

//+------------------------------------------------------------------+
void MarkIntKey(int &arr[], const int key)
{
   int n = ArraySize(arr);
   ArrayResize(arr, n + 1);
   arr[n] = key;
   if(ArraySize(arr) > 1000)
   {
      for(int i = 1; i < ArraySize(arr); i++)
         arr[i - 1] = arr[i];
      ArrayResize(arr, 1000);
   }
}

//+------------------------------------------------------------------+
void DrawSetup(const FvgSetup &setup, const double entry, const double sl1, const double sl2,
               const double tp1, const double tp2, const string status, const string reasons, const bool passed)
{
   string prefix = "H1_FVG_ST_" + Symbol() + "_" + IntegerToString((int)setup.setupTime) + "_" + DirectionName(setup.direction);
   datetime left = setup.setupTime;
   int tfSeconds = PeriodSeconds(InpSignalTimeframe);
   datetime right = TimeCurrent() + tfSeconds * 24;
   color zoneColor = setup.direction == 1 ? clrDarkGreen : clrMaroon;

   DrawZone(prefix + "_ZONE", left, right, setup.fvgHigh, setup.fvgLow, zoneColor);
   DrawLevel(prefix + "_ENTRY", left, right, entry, clrDodgerBlue, "Entry");
   DrawLevel(prefix + "_SL1", left, right, sl1, clrTomato, "SL1");
   DrawLevel(prefix + "_SL2", left, right, sl2, clrOrangeRed, "SL2");
   DrawLevel(prefix + "_TP1", left, right, tp1, clrMediumSeaGreen, "TP1");
   DrawLevel(prefix + "_TP2", left, right, tp2, clrSeaGreen, "TP2");

   string label = StringFormat("%s H1 FVG %s\nH4 FVG: %s\nD1 Opp Block: %s\nH4 EMA: %s\nH4 Dist: %s\nH4 ADX: %s\nFinal: %s\nReason: %s",
                               Symbol(), DirectionName(setup.direction),
                               StatusPart(status, "H4_FVG_CONFIRM"), StatusPart(status, "D1_OPPOSITE_BLOCK"),
                               StatusPart(status, "H4_EMA"), StatusPart(status, "H4_EMA_DISTANCE"),
                               StatusPart(status, "H4_ADX"), passed ? "valid" : "rejected", reasons);
   DrawDashboard(prefix + "_LABEL", label, passed ? clrLimeGreen : clrTomato, 24);
}

//+------------------------------------------------------------------+
string StatusPart(const string status, const string key)
{
   int start = StringFind(status, key + ":");
   if(start < 0)
      return "off";
   int valueStart = start + StringLen(key) + 1;
   int end = StringFind(status, "|", valueStart);
   if(end < 0)
      end = StringLen(status);
   return StringSubstr(status, valueStart, end - valueStart);
}

//+------------------------------------------------------------------+
void DrawZone(const string name, const datetime left, const datetime right, const double top, const double bottom, const color clr)
{
   if(ObjectFind(0, name) < 0)
      ObjectCreate(0, name, OBJ_RECTANGLE, 0, left, top, right, bottom);
   else
   {
      ObjectMove(0, name, 0, left, top);
      ObjectMove(0, name, 1, right, bottom);
   }
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_BACK, true);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
}

//+------------------------------------------------------------------+
void DrawLevel(const string name, const datetime left, const datetime right, const double price, const color clr, const string text)
{
   if(ObjectFind(0, name) < 0)
      ObjectCreate(0, name, OBJ_TREND, 0, left, price, right, price);
   else
   {
      ObjectMove(0, name, 0, left, price);
      ObjectMove(0, name, 1, right, price);
   }
   ObjectSetInteger(0, name, OBJPROP_RAY_RIGHT, false);
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, 1);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);

   string label = name + "_TEXT";
   int tfSeconds = PeriodSeconds(InpSignalTimeframe);
   if(ObjectFind(0, label) < 0)
      ObjectCreate(0, label, OBJ_TEXT, 0, right + tfSeconds, price);
   else
      ObjectMove(0, label, 0, right + tfSeconds, price);
   ObjectSetText(label, text + " " + PriceToString(price), 8, "Arial", clr);
   ObjectSetInteger(0, label, OBJPROP_SELECTABLE, false);
}

//+------------------------------------------------------------------+
void DrawDashboard(const string name, const string text, const color clr, const int yDistance)
{
   if(ObjectFind(0, name) < 0)
      ObjectCreate(0, name, OBJ_LABEL, 0, 0, 0);
   ObjectSetInteger(0, name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE, 12);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE, yDistance);
   ObjectSetText(name, text, 9, "Arial", clr);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
}

//+------------------------------------------------------------------+
double EntryFromMitigation(const int direction, const double top, const double bottom, const double mitigation)
{
   double m = MathMax(0.0, MathMin(1.0, mitigation));
   double gap = top - bottom;
   if(direction == 1)
      return bottom + gap * (1.0 - m);
   return bottom + gap * m;
}

//+------------------------------------------------------------------+
double NormalizePrice(const double value)
{
   return NormalizeDouble(value, Digits);
}

//+------------------------------------------------------------------+
string PriceToString(const double value)
{
   return DoubleToString(value, Digits);
}

//+------------------------------------------------------------------+
string DirectionName(const int direction)
{
   if(direction == 1)
      return "Bullish";
   if(direction == -1)
      return "Bearish";
   return "Unknown";
}

//+------------------------------------------------------------------+
string BoolText(const bool value)
{
   return value ? "true" : "false";
}

//+------------------------------------------------------------------+
