//+------------------------------------------------------------------+
//|                                        LPH_MacroBridge_EA.mq4     |
//|                     Limitless PH Macro-Technical Alignment        |
//|                                                                  |
//|  The ONLY component that performs WebRequest. It fetches the LPH  |
//|  Macro Heatmap terminal feed, validates + parses it, and writes a |
//|  versioned macro cache to the shared FILE_COMMON folder for the   |
//|  LPH_MacroTechnical_Alignment indicator to consume.               |
//|                                                                  |
//|  Decision support only. It NEVER opens, modifies or closes trades.|
//|  No DLLs. The read-only API token is never printed to logs.       |
//|                                                                  |
//|  IMPORTANT: add your API domain under                             |
//|    MT4 -> Tools -> Options -> Expert Advisors                     |
//|    -> "Allow WebRequest for listed URL"                           |
//+------------------------------------------------------------------+
#property strict
#property copyright "Limitless PH"
#property version   "1.00"
#property description "Fetches the LPH Macro Heatmap and writes a shared macro cache. Decision support only."

#include "LPH_MacroTechnical_Core.mqh"

//==================================================================
// Inputs
//==================================================================
input string  MacroAPIUrl               = "";        // Full URL, e.g. https://host/api/mt4/macro-heatmap
input string  ReadOnlyAPIToken          = "";        // Optional read-only token (never logged)
input int     FetchIntervalSeconds      = 120;       // Normal poll interval
input int     RequestTimeoutMilliseconds= 5000;      // WebRequest timeout
input int     StaleWarningHours         = 12;        // AGING threshold (panel)
input int     DisableSignalsAfterHours  = 36;        // STALE threshold (panel)
input int     MaxResponseBytes          = 262144;    // Reject oversized responses
input int     MaxBackoffSeconds         = 900;       // Cap for retry backoff
input bool    EnableBridgeLogging       = true;      // Print status transitions to Experts log
input bool    ShowBridgePanel           = true;      // Draw a small status panel / Comment

//==================================================================
// State
//==================================================================
string   g_state            = LPH_BS_STARTING;
string   g_prevState        = "";
datetime g_lastAttemptEpoch = 0;   // last request attempt (GMT)
datetime g_lastSuccessEpoch = 0;   // last successful request (GMT)
datetime g_generatedEpoch   = 0;   // server dataset generation time
string   g_generatedAtUtc   = "";
datetime g_nextFetchAt      = 0;
int      g_consecutiveFail  = 0;
int      g_lastCcyCount     = 0;
string   g_lastMessage      = "";
bool     g_isPrimary        = true;

#define LPH_TMP_FILENAME  "LPH_MacroHeatmap_Cache_v1.tmp"
#define LPH_GV_OWNER      "LPH_MacroBridge_Owner"
#define LPH_GV_HEARTBEAT  "LPH_MacroBridge_Heartbeat"

//==================================================================
// Lifecycle
//==================================================================
int OnInit()
  {
   g_state       = LPH_BS_STARTING;
   g_nextFetchAt = 0;   // fetch immediately on first timer tick

   if(LphTrim(MacroAPIUrl) == "")
     {
      g_state = LPH_BS_ENDPOINT_ERROR;
      g_lastMessage = "MacroAPIUrl is empty. Set it to your /api/mt4/macro-heatmap URL.";
      BridgeLog(g_lastMessage);
     }
   else
      if(StringFind(LphUpper(MacroAPIUrl), "HTTPS://") != 0)
        {
         // Allow HTTP only if the user deliberately typed it; warn otherwise.
         BridgeLog("WARNING: MacroAPIUrl is not HTTPS. HTTPS is strongly recommended.");
        }

   ClaimOwnership();

   EventSetTimer(1);
   DrawPanel();
   return(INIT_SUCCEEDED);
  }

void OnDeinit(const int reason)
  {
   EventKillTimer();
   // Release ownership only if we currently hold it.
   if(g_isPrimary && GlobalVariableCheck(LPH_GV_OWNER) &&
      (long)GlobalVariableGet(LPH_GV_OWNER) == (long)ChartID())
     {
      GlobalVariableDel(LPH_GV_OWNER);
      GlobalVariableDel(LPH_GV_HEARTBEAT);
     }
   Comment("");
   ObjectsDeleteAll(0, "LPHBRG_");
  }

// Scheduled work only; never fetch on tick.
void OnTimer()
  {
   datetime now = TimeGMT();

   RefreshOwnership(now);

   if(g_isPrimary && now >= g_nextFetchAt)
      DoFetchCycle(now);

   if(ShowBridgePanel)
      DrawPanel();
  }

//==================================================================
// Duplicate-instance guard (one active fetcher per terminal)
//==================================================================
void ClaimOwnership()
  {
   datetime now = TimeGMT();
   bool ownerFresh = false;
   if(GlobalVariableCheck(LPH_GV_HEARTBEAT))
     {
      datetime hb = (datetime)GlobalVariableGet(LPH_GV_HEARTBEAT);
      ownerFresh = (now - hb) < (3 * MathMax(5, FetchIntervalSeconds));
     }
   long owner = GlobalVariableCheck(LPH_GV_OWNER) ? (long)GlobalVariableGet(LPH_GV_OWNER) : 0;

   if(ownerFresh && owner != 0 && owner != (long)ChartID())
     {
      g_isPrimary = false;
      g_lastMessage = "Another LPH bridge is active (chart " + IntegerToString((int)owner) + "). Running passive.";
      BridgeLog(g_lastMessage);
      return;
     }

   g_isPrimary = true;
   GlobalVariableSet(LPH_GV_OWNER, (double)(long)ChartID());
   GlobalVariableSet(LPH_GV_HEARTBEAT, (double)now);
  }

void RefreshOwnership(datetime now)
  {
   if(g_isPrimary)
     {
      GlobalVariableSet(LPH_GV_OWNER, (double)(long)ChartID());
      GlobalVariableSet(LPH_GV_HEARTBEAT, (double)now);
      return;
     }
   // Passive instance: take over only if the previous owner went silent.
   if(GlobalVariableCheck(LPH_GV_HEARTBEAT))
     {
      datetime hb = (datetime)GlobalVariableGet(LPH_GV_HEARTBEAT);
      if((now - hb) >= (3 * MathMax(5, FetchIntervalSeconds)))
         ClaimOwnership();
     }
   else
      ClaimOwnership();
  }

//==================================================================
// Fetch + validate + parse + cache
//==================================================================
void DoFetchCycle(datetime now)
  {
   g_lastAttemptEpoch = now;

   string body = "";
   int http = HttpGet(MacroAPIUrl, ReadOnlyAPIToken, body);

   if(http == 401 || http == 403)
     {
      OnFetchFailure(LPH_BS_AUTH_ERROR, "HTTP " + IntegerToString(http) + " (auth). Check ReadOnlyAPIToken.", now);
      return;
     }
   if(http <= 0)
     {
      OnFetchFailure(LPH_BS_ENDPOINT_ERROR, "Transport error (" + IntegerToString(http) +
                     "). Is the URL in the WebRequest allowlist?", now);
      return;
     }
   if(http != 200)
     {
      OnFetchFailure(LPH_BS_ENDPOINT_ERROR, "HTTP " + IntegerToString(http) + " from server.", now);
      return;
     }
   if(StringLen(body) == 0)
     {
      OnFetchFailure(LPH_BS_INVALID, "Empty response body.", now);
      return;
     }
   if(StringLen(body) > MaxResponseBytes)
     {
      OnFetchFailure(LPH_BS_INVALID, "Response exceeds MaxResponseBytes.", now);
      return;
     }

   // ---- Validate + parse ----
   double schemaD = 0;
   if(!JsonGetNumber(body, "schema_version", schemaD) || (int)schemaD != LPH_SUPPORTED_SCHEMA)
     {
      OnFetchFailure(LPH_BS_INVALID, "Unsupported/missing schema_version.", now);
      return;
     }

   string genUtc = JsonGetString(body, "generated_at_utc");
   datetime genEpoch = LphIsoToEpoch(genUtc);
   if(genEpoch <= 0)
     {
      OnFetchFailure(LPH_BS_INVALID, "Invalid generated_at_utc timestamp.", now);
      return;
     }

   LphCurrency rows[];
   int count = ParseCurrencies(body, rows);
   if(count < 6)   // require the core FX set at minimum
     {
      OnFetchFailure(LPH_BS_INVALID, "Too few valid currency records (" + IntegerToString(count) + ").", now);
      return;
     }

   // ---- Atomic cache write ----
   g_generatedEpoch  = genEpoch;
   g_generatedAtUtc  = genUtc;
   g_lastSuccessEpoch= now;
   g_consecutiveFail = 0;
   g_lastCcyCount    = count;
   g_state           = LPH_BS_CONNECTED;

   if(!WriteCacheAtomic(rows, count))
     {
      // Write failed: keep last good cache, report but don't lose data.
      g_lastMessage = "Cache write failed; previous cache preserved.";
      BridgeLog(g_lastMessage);
     }
   else
      g_lastMessage = "Fetched " + IntegerToString(count) + " currencies.";

   g_nextFetchAt = now + MathMax(5, FetchIntervalSeconds);
   LogStateTransition();
  }

void OnFetchFailure(string state, string message, datetime now)
  {
   g_consecutiveFail++;
   g_lastMessage = message;
   // Preserve last valid data: if we still have a fresh dataset, mark USING_CACHE.
   double ageHours = (g_generatedEpoch > 0) ? (double)(now - g_generatedEpoch) / 3600.0 : 1e9;
   if(g_generatedEpoch > 0 && ageHours <= (double)DisableSignalsAfterHours)
      g_state = LPH_BS_USING_CACHE;
   else
      if(g_generatedEpoch > 0)
         g_state = LPH_BS_STALE;
      else
         g_state = state;   // never had data -> surface the raw error

   // Refresh only the STATUS row so consumers see the current bridge state,
   // without touching the last valid currency data.
   UpdateStatusRowOnly();

   // Bounded exponential backoff.
   int backoff = (int)MathMin((double)MaxBackoffSeconds,
                              (double)MathMax(5, FetchIntervalSeconds) * MathPow(2.0, MathMin(6, g_consecutiveFail)));
   g_nextFetchAt = now + backoff;

   LogStateTransition();
  }

//==================================================================
// HTTP GET. Returns HTTP status code (>0) or <=0 on transport error.
//==================================================================
int HttpGet(string url, string token, string &bodyOut)
  {
   bodyOut = "";
   char   data[];
   char   result[];
   string resultHeaders = "";
   ArrayResize(data, 0);

   string headers = "Accept: application/json\r\n";
   if(LphTrim(token) != "")
      headers += "Authorization: Bearer " + LphTrim(token) + "\r\n";

   ResetLastError();
   int res = WebRequest("GET", url, headers, RequestTimeoutMilliseconds, data, result, resultHeaders);

   if(res == -1)
     {
      int err = GetLastError();
      // Do not include token or headers in the log.
      BridgeLog("WebRequest failed, error " + IntegerToString(err) +
                (err == 4060 ? " (URL not in WebRequest allowlist?)." : "."));
      return(-1);
     }

   if(ArraySize(result) > 0)
      bodyOut = CharArrayToString(result, 0, ArraySize(result), CP_UTF8);
   return(res);
  }

//==================================================================
// Minimal, defensive JSON helpers (no DLL). Tailored to the lean feed.
//==================================================================
int JsonSkipWsColon(const string js, int p)
  {
   int n = StringLen(js);
   while(p < n)
     {
      int c = StringGetChar(js, p);
      if(c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == ':')
        {
         p++;
         continue;
        }
      break;
     }
   return(p);
  }

// Position just past "key" : , at the value start (or -1).
int JsonValuePos(const string js, const string key, int from)
  {
   string needle = "\"" + key + "\"";
   int k = StringFind(js, needle, from);
   if(k < 0)
      return(-1);
   return(JsonSkipWsColon(js, k + StringLen(needle)));
  }

string JsonReadStringAt(const string js, int p)
  {
   int n = StringLen(js);
   if(p < 0 || p >= n || StringGetChar(js, p) != '"')
      return("");
   p++;
   string out = "";
   while(p < n)
     {
      int c = StringGetChar(js, p);
      if(c == '\\')
        {
         p++;
         if(p >= n)
            break;
         int e = StringGetChar(js, p);
         if(e == 'n')      out += " ";
         else if(e == 't') out += " ";
         else              out += CharToStr((uchar)e);
         p++;
         continue;
        }
      if(c == '"')
         break;
      out += CharToStr((uchar)c);
      p++;
     }
   return(out);
  }

string JsonReadTokenAt(const string js, int p)
  {
   int n = StringLen(js);
   string out = "";
   while(p < n)
     {
      int c = StringGetChar(js, p);
      if(c == ',' || c == '}' || c == ']' || c == ' ' || c == '\t' || c == '\r' || c == '\n')
         break;
      out += CharToStr((uchar)c);
      p++;
     }
   return(out);
  }

// Top-level string field (searches whole doc; fine for the flat header fields).
string JsonGetString(const string js, const string key)
  {
   int p = JsonValuePos(js, key, 0);
   if(p < 0)
      return("");
   if(StringGetChar(js, p) == '"')
      return(JsonReadStringAt(js, p));
   return(JsonReadTokenAt(js, p));
  }

bool JsonGetNumber(const string js, const string key, double &val)
  {
   val = 0;
   int p = JsonValuePos(js, key, 0);
   if(p < 0)
      return(false);
   string tok;
   if(StringGetChar(js, p) == '"')
      tok = JsonReadStringAt(js, p);
   else
      tok = JsonReadTokenAt(js, p);
   tok = LphTrim(tok);
   if(tok == "" || tok == "null")
      return(false);
   val = StringToDouble(tok);
   return(MathIsValidNumber(val));
  }

// Field lookups scoped to a single object substring.
string ObjString(const string obj, const string key)
  {
   int p = JsonValuePos(obj, key, 0);
   if(p < 0)
      return("");
   if(StringGetChar(obj, p) == '"')
      return(JsonReadStringAt(obj, p));
   string tok = LphTrim(JsonReadTokenAt(obj, p));
   if(tok == "null")
      return("");
   return(tok);
  }

bool ObjNumber(const string obj, const string key, double &val)
  {
   val = 0;
   int p = JsonValuePos(obj, key, 0);
   if(p < 0)
      return(false);
   string tok;
   if(StringGetChar(obj, p) == '"')
      tok = JsonReadStringAt(obj, p);
   else
      tok = JsonReadTokenAt(obj, p);
   tok = LphTrim(tok);
   if(tok == "" || tok == "null")
      return(false);
   val = StringToDouble(tok);
   return(MathIsValidNumber(val));
  }

// Parse the "currencies" array into rows[]. Skips malformed / duplicate records.
int ParseCurrencies(const string js, LphCurrency &rows[])
  {
   ArrayResize(rows, 0);
   int count = 0;

   int arrPos = JsonValuePos(js, "currencies", 0);
   if(arrPos < 0 || StringGetChar(js, arrPos) != '[')
      return(0);

   int n = StringLen(js);
   int p = arrPos + 1;

   while(p < n)
     {
      int c = StringGetChar(js, p);
      if(c == ']')
         break;
      if(c != '{')
        {
         p++;
         continue;
        }
      // Brace-match one object.
      int objStart = p;
      int depth = 0;
      while(p < n)
        {
         int cc = StringGetChar(js, p);
         if(cc == '{')
            depth++;
         else
            if(cc == '}')
              {
               depth--;
               if(depth == 0)
                 {
                  p++;
                  break;
                 }
              }
         p++;
        }
      string obj = StringSubstr(js, objStart, p - objStart);

      LphCurrency row;
      row.code = LphUpper(LphTrim(ObjString(obj, "code")));
      if(row.code == "")
         continue;                          // invalid record
      if(LphFindCurrency(rows, row.code) >= 0)
         continue;                          // duplicate code -> skip

      row.assetClass  = ObjString(obj, "asset_class");
      row.bias7d      = ObjString(obj, "bias_7d");
      row.bias30d     = ObjString(obj, "bias_30d");
      row.status      = ObjString(obj, "status");
      row.stableLabel = LphSanitizeField(ObjString(obj, "stable_label"));

      row.has7d        = ObjNumber(obj, "score_7d",        row.score7d);
      row.has30d       = ObjNumber(obj, "score_30d",       row.score30d);
      row.hasStable    = ObjNumber(obj, "stable_score",    row.stableScore);
      row.hasComposite = ObjNumber(obj, "composite_score", row.compositeScore);

      // Reject records whose present numbers are non-finite (already filtered by
      // ObjNumber's MathIsValidNumber check, so nothing more to do here).

      ArrayResize(rows, count + 1);
      rows[count] = row;
      count++;
     }

   return(count);
  }

//==================================================================
// Atomic cache write: build temp file, then move over the live cache.
//==================================================================
string NumOrNa(bool has, double v)
  {
   if(!has)
      return(LPH_NA_TOKEN);
   return(DoubleToString(v, 2));
  }

bool WriteCacheAtomic(LphCurrency &rows[], int count)
  {
   int h = FileOpen(LPH_TMP_FILENAME, FILE_WRITE | FILE_TXT | FILE_COMMON | FILE_ANSI);
   if(h == INVALID_HANDLE)
     {
      BridgeLog("FileOpen(temp) failed, error " + IntegerToString(GetLastError()));
      return(false);
     }

   string d = CharToStr((uchar)LPH_CACHE_DELIM);
   bool ok = true;

   ok = ok && (FileWriteString(h, LPH_CACHE_MAGIC + d + IntegerToString(LPH_CACHE_FORMAT_VER) + "\r\n") > 0);
   ok = ok && (FileWriteString(h, "META" + d + IntegerToString(LPH_SUPPORTED_SCHEMA) + d +
                                LphSanitizeField(g_generatedAtUtc) + d +
                                IntegerToString((int)g_generatedEpoch) + d +
                                IntegerToString((int)g_lastAttemptEpoch) + d +
                                IntegerToString((int)g_lastSuccessEpoch) + "\r\n") > 0);
   ok = ok && (FileWriteString(h, "STATUS" + d + g_state + d +
                                IntegerToString((int)g_lastAttemptEpoch) + d +
                                IntegerToString((int)g_lastSuccessEpoch) + d +
                                IntegerToString(g_consecutiveFail) + "\r\n") > 0);

   for(int i = 0; i < count && ok; i++)
     {
      string line = "CCY" + d + rows[i].code + d +
                    NumOrNa(rows[i].has7d,        rows[i].score7d) + d +
                    NumOrNa(rows[i].has30d,       rows[i].score30d) + d +
                    NumOrNa(rows[i].hasStable,    rows[i].stableScore) + d +
                    NumOrNa(rows[i].hasComposite, rows[i].compositeScore) + d +
                    (rows[i].bias7d == ""  ? "na" : rows[i].bias7d) + d +
                    (rows[i].bias30d == "" ? "na" : rows[i].bias30d) + d +
                    (rows[i].status == ""  ? "unknown" : rows[i].status) + d +
                    (rows[i].assetClass == "" ? "other" : rows[i].assetClass) + d +
                    LphSanitizeField(rows[i].stableLabel) + "\r\n";
      ok = ok && (FileWriteString(h, line) > 0);
     }
   FileClose(h);

   if(!ok)
     {
      FileDelete(LPH_TMP_FILENAME, FILE_COMMON);
      return(false);
     }

   // Replace the live cache atomically.
   if(FileIsExist(LPH_CACHE_FILENAME, FILE_COMMON))
      FileDelete(LPH_CACHE_FILENAME, FILE_COMMON);
   if(!FileMove(LPH_TMP_FILENAME, FILE_COMMON, LPH_CACHE_FILENAME, FILE_COMMON | FILE_REWRITE))
     {
      BridgeLog("FileMove(temp->cache) failed, error " + IntegerToString(GetLastError()));
      return(false);
     }
   return(true);
  }

// Rewrite ONLY the STATUS/META rows against the existing cache so a failed
// fetch still updates the visible bridge state without discarding good data.
void UpdateStatusRowOnly()
  {
   LphCacheMeta meta;
   LphCurrency rows[];
   if(!LphReadCache(meta, rows))
      return;                       // nothing valid to preserve
   // Re-emit with the current state; last good currency rows are kept verbatim.
   int h = FileOpen(LPH_TMP_FILENAME, FILE_WRITE | FILE_TXT | FILE_COMMON | FILE_ANSI);
   if(h == INVALID_HANDLE)
      return;
   string d = CharToStr((uchar)LPH_CACHE_DELIM);
   bool ok = true;
   ok = ok && (FileWriteString(h, LPH_CACHE_MAGIC + d + IntegerToString(LPH_CACHE_FORMAT_VER) + "\r\n") > 0);
   ok = ok && (FileWriteString(h, "META" + d + IntegerToString(meta.schemaVersion) + d +
                                LphSanitizeField(meta.generatedAtUtc) + d +
                                IntegerToString((int)meta.generatedEpoch) + d +
                                IntegerToString((int)g_lastAttemptEpoch) + d +
                                IntegerToString((int)g_lastSuccessEpoch) + "\r\n") > 0);
   ok = ok && (FileWriteString(h, "STATUS" + d + g_state + d +
                                IntegerToString((int)g_lastAttemptEpoch) + d +
                                IntegerToString((int)g_lastSuccessEpoch) + d +
                                IntegerToString(g_consecutiveFail) + "\r\n") > 0);
   for(int i = 0; i < meta.count && ok; i++)
     {
      string line = "CCY" + d + rows[i].code + d +
                    NumOrNa(rows[i].has7d,        rows[i].score7d) + d +
                    NumOrNa(rows[i].has30d,       rows[i].score30d) + d +
                    NumOrNa(rows[i].hasStable,    rows[i].stableScore) + d +
                    NumOrNa(rows[i].hasComposite, rows[i].compositeScore) + d +
                    (rows[i].bias7d == ""  ? "na" : rows[i].bias7d) + d +
                    (rows[i].bias30d == "" ? "na" : rows[i].bias30d) + d +
                    (rows[i].status == ""  ? "unknown" : rows[i].status) + d +
                    (rows[i].assetClass == "" ? "other" : rows[i].assetClass) + d +
                    LphSanitizeField(rows[i].stableLabel) + "\r\n";
      ok = ok && (FileWriteString(h, line) > 0);
     }
   FileClose(h);
   if(!ok)
     {
      FileDelete(LPH_TMP_FILENAME, FILE_COMMON);
      return;
     }
   if(FileIsExist(LPH_CACHE_FILENAME, FILE_COMMON))
      FileDelete(LPH_CACHE_FILENAME, FILE_COMMON);
   FileMove(LPH_TMP_FILENAME, FILE_COMMON, LPH_CACHE_FILENAME, FILE_COMMON | FILE_REWRITE);
  }

//==================================================================
// Panel + logging
//==================================================================
void DrawPanel()
  {
   if(!ShowBridgePanel)
     {
      Comment("");
      return;
     }
   string age = (g_generatedEpoch > 0)
                ? DoubleToString((double)(TimeGMT() - g_generatedEpoch) / 3600.0, 1) + "h"
                : "n/a";
   string lines =
      "LPH MACRO BRIDGE  [" + (g_isPrimary ? "PRIMARY" : "PASSIVE") + "]\n" +
      "State: " + g_state + "\n" +
      "Dataset (UTC): " + (g_generatedAtUtc == "" ? "none" : g_generatedAtUtc) + "  age " + age + "\n" +
      "Last attempt: " + TimeToString(g_lastAttemptEpoch, TIME_DATE | TIME_SECONDS) + " GMT\n" +
      "Last success: " + (g_lastSuccessEpoch > 0 ? TimeToString(g_lastSuccessEpoch, TIME_DATE | TIME_SECONDS) : "never") + " GMT\n" +
      "Currencies: " + IntegerToString(g_lastCcyCount) + "   Fails: " + IntegerToString(g_consecutiveFail) + "\n" +
      "Next fetch: " + TimeToString(g_nextFetchAt, TIME_SECONDS) + " GMT\n" +
      (g_lastMessage == "" ? "" : ("Note: " + g_lastMessage + "\n")) +
      "Decision support only";
   Comment(lines);
  }

void LogStateTransition()
  {
   if(g_state != g_prevState)
     {
      BridgeLog("State -> " + g_state + (g_lastMessage == "" ? "" : (" | " + g_lastMessage)));
      g_prevState = g_state;
     }
  }

void BridgeLog(string message)
  {
   if(EnableBridgeLogging)
      Print("[LPH_MacroBridge] " + message);   // never contains the token
  }
//+------------------------------------------------------------------+
