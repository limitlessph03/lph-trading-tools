# LPH MT4 Macro Feed — API Contract

Lean, read-only endpoint added to `dev-server.js` for MT4 terminal clients
(`LPH_MacroBridge_EA`). It exposes **only** the per-currency macro scores the terminal
needs — no admin, COT, technical, database, or credential fields.

## Endpoint

```
GET /api/mt4/macro-heatmap
```

- **Content-Type:** `application/json; charset=utf-8`
- **Cache-Control:** `no-store`
- Built by reusing the existing `getAssetScorecardPayload()` — it does **not** re-derive
  the macro model. Fields are selected/renamed by `buildMt4MacroHeatmapPayload()`.

### Authentication

Public by default (same posture as `/api/asset-scorecard`, which already exposes these
scores in sanitized form). To lock it down, set env `MT4_READONLY_TOKEN`; the endpoint
then requires it via `Authorization: Bearer <token>`, header `x-mt4-token`, or `?token=`.
Admin Basic-Auth also satisfies the gate. Rate limited to 120 req/min per IP.

## Response schema

```jsonc
{
  "schema_version": 1,
  "source": "limitless-ph-fx-macro-heatmap",
  "generated_at_utc": "2026-07-22T06:29:46.277Z",   // ISO-8601 UTC
  "score_range": "-100 to +100",
  "bias_thresholds": { "strong": 60, "normal": 25 },
  "currency_count": 14,
  "currencies": [
    {
      "code": "USD",              // FX currency or CFD asset code
      "asset_class": "fx",        // fx | metal | index | energy | other
      "score_7d": 0,              // 7-day macro score  (number or null)
      "score_30d": -20,           // 30-day macro score (number or null)
      "stable_score": -20,        // blended stable regime score (number or null)
      "composite_score": -15.4,   // full scorecard composite (number or null)
      "bias_7d": "neutral",       // derived: strong_bullish|bullish|neutral|bearish|strong_bearish|na
      "bias_30d": "neutral",
      "stable_label": "Macro Neutral / Mixed",
      "composite_label": "Neutral",
      "confidence": null,         // not published by the macro model
      "status": "active"          // active | partial | standalone | no_data
    }
    // ... USD EUR GBP JPY CHF CAD AUD NZD XAUUSD XAGUSD NAS100 DJ30 SP500 USOIL
  ]
}
```

### Field mapping (source → feed)

| Feed field | Source (`assets[code]`) |
|------------|-------------------------|
| `score_7d` | `seven_day_macro_score` |
| `score_30d` | `thirty_day_macro_score` |
| `stable_score` | `stable_macro_bias_score` |
| `composite_score` | `final_score` |
| `stable_label` | `stable_macro_bias_label` |
| `composite_label` | `final_label` |
| `status` | derived from `scorecard_status` + `fundamentals_macro_status` |
| `bias_7d/30d` | derived from the score via backend macro thresholds (±60 strong, ±25 normal) |

### Status semantics

| `status` | Meaning |
|----------|---------|
| `active` | FX currency with 7d/30d windows available. |
| `partial` | Some macro data present but not the full window set. |
| `standalone` | CFD (e.g. gold) with its own composite score but no FX-style windows. |
| `no_data` | No usable macro score — the terminal must not fabricate one. |

### Null handling

Numeric fields are `null` when the backend has no value. The bridge writes `NA` into the
cache for nulls and the indicator treats `NA` as "not available" — **never** as zero.

## Client validation (enforced by the bridge)

The bridge rejects a response (and preserves the last good cache) unless **all** hold:
HTTP 200 · non-empty · size ≤ `MaxResponseBytes` · `schema_version == 1` ·
parseable `generated_at_utc` · ≥ 6 valid currency records · finite numbers · no
duplicate codes.

## Notes

- Pair differentials (`base − quote`) are computed **client-side** in MT4 per spec.
  The backend's `pair_scorecards` were intentionally **not** used because they blend
  COT/technical/crowd into the score, whereas this system needs the pure 7D/30D macro.
- Adding this endpoint changes no existing route or behaviour.
