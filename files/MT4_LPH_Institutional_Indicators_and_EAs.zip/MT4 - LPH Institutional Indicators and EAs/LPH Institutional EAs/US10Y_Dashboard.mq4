#property strict

// --- Input Parameters ---
input int Update_Minutes = 15;

// --- Entry Point: Initialization ---
int OnInit()
{
   // Set the timer to trigger every X minutes
   EventSetTimer(Update_Minutes * 60);
   
   // Pull the data immediately on startup
   FetchUS10Y();
   
   return(INIT_SUCCEEDED);
}

// --- Entry Point: De-initialization ---
void OnDeinit(const int reason)
{
   EventKillTimer();
   ObjectDelete(0, "US10Y_Label");
}

// --- Entry Point: Timer ---
void OnTimer()
{
   FetchUS10Y();
}

// --- Main Data Function ---
void FetchUS10Y()
{
   string cookie=NULL, headers;
   char post[], result[];
   string url = "https://query1.finance.yahoo.com/v8/finance/chart/%5ETNX";

   ResetLastError();
   int res = WebRequest("GET", url, cookie, NULL, 5000, post, 0, result, headers);

   if(res == 200) 
   {
      string json = CharArrayToString(result);
      int priceIndex = StringFind(json, "\"regularMarketPrice\":");
      if(priceIndex != -1)
      {
         int start = priceIndex + 21; 
         int end = StringFind(json, ",", start);
         string priceStr = StringSubstr(json, start, end - start);
         
         double live_us10y = StringToDouble(priceStr);
         
         // Update the dashboard label
         UpdateDashboard(DoubleToString(live_us10y, 3));
      }
   }
   else 
   {
      Print("HTTP Error: ", res, " | MT4 Error: ", GetLastError());
   }
}

// --- Drawing Helper ---
void UpdateDashboard(string yield_value)
{
   string obj_name = "US10Y_Label";
   
   // Create the object if it doesn't exist
   if(ObjectFind(0, obj_name) < 0) 
   {
      ObjectCreate(0, obj_name, OBJ_LABEL, 0, 0, 0);
      ObjectSetInteger(0, obj_name, OBJPROP_CORNER, CORNER_RIGHT_UPPER);
      ObjectSetInteger(0, obj_name, OBJPROP_XDISTANCE, 20);
      ObjectSetInteger(0, obj_name, OBJPROP_YDISTANCE, 50);
      ObjectSetInteger(0, obj_name, OBJPROP_COLOR, clrWhite);
      ObjectSetString(0, obj_name, OBJPROP_FONT, "Arial");
      ObjectSetInteger(0, obj_name, OBJPROP_FONTSIZE, 12);
   }
   
   // Update the text
   ObjectSetString(0, obj_name, OBJPROP_TEXT, "US10Y Yield: " + yield_value + "%");
}