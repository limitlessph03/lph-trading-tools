//+------------------------------------------------------------------+
//|               LPH_Open_Position_Pain_Risk_Dashboard_v4_4_ADAPTIVE.mq4        |
//|               Account-wide open position risk / pain scanner + hedge/recovery guidance      |
//|               Developed by Coach T / Limitless PH                 |
//|               v4.4: pain score no longer scores ATR distance/     |
//|               volatility/lot size on PROFITABLE trades as "pain"; |
//|               reduce % is severity-scaled instead of fixed 50%;   |
//|               added deposit-needed-to-hedge line. Reviewed by     |
//|               Claude as a patch on Coach T's v4.3 base -- confirm |
//|               against a couple of real baskets in visual mode.    |
//+------------------------------------------------------------------+
#property strict

// This is an EA dashboard, not an indicator.
// Put in: MQL4 > Experts
// Attach to ONE chart only. It scans all open market positions on the account.

//------------------------- INPUTS ----------------------------------
input string   Section_Display            = "----- DISPLAY -----";
input bool     Show_Dashboard             = true;
input int      RefreshSeconds             = 5;

// v3 full-screen layout for a dedicated / blank chart
input bool     FullscreenDashboard        = true;
input bool     CleanBlankChartMode        = true;    // dark blank chart style for dashboard-only use
input bool     AutoScaleInterface         = true;    // auto font/spacing based on chart size
input bool     TwoColumnLayout            = true;    // left = positions, right = exposure summary
input int      DashboardMargin            = 18;
input int      PanelPadding               = 14;
input int      PanelCorner                = 0;       // fallback only. 0 TL, 1 TR, 2 BL, 3 BR
input int      PanelX                     = 15;      // fallback only
input int      PanelY                     = 20;      // fallback only
input int      LineSpacing                = 16;      // fallback only
input int      FontSize                   = 9;       // fallback only
input string   FontName                   = "Consolas";
input color    HeaderColor                = clrGold;
input color    NormalColor                = clrSilver;
input color    ProfitColor                = clrLimeGreen;
input color    LossColor                  = clrTomato;
input color    WarningColor               = clrOrange;
input color    DangerColor                = clrRed;
input color    PanelBGColor               = C'8,10,14';
input color    PanelBorderColor           = C'45,52,65';
input color    CardBGColor                = C'14,17,24';
input color    AccentColor                = C'0,210,230';
input int      TopPositionsToShow         = 10;
input int      TopSymbolsToShow           = 8;

input string   Section_Filter             = "----- FILTERS -----";
input bool     IncludeOnlyCurrentSymbol   = false;
input int      MagicNumberFilter          = -1;      // -1 = all magic numbers
input bool     IncludeBuyPositions        = true;
input bool     IncludeSellPositions       = true;

input string   Section_Volatility         = "----- VOLATILITY / ATR -----";
input ENUM_TIMEFRAMES ATR_Timeframe       = PERIOD_H1;
input int      ATR_Period                 = 14;
input bool     GoldPipIsTenPoints         = false;   // false: XAU 0.01 pip on 2-digit quotes. true: XAU 0.10 pip.
input bool     UseATRDistanceInPainScore  = true;

input string   Section_Pain_Score         = "----- PAIN SCORE SETTINGS -----";
input double   Weight_LossPct             = 45.0;    // floating loss as % of equity
input double   Weight_ATRDistance         = 25.0;    // adverse move versus ATR
input double   Weight_Volatility          = 15.0;    // ATR % of price
input double   Weight_LotExposure         = 15.0;    // lots exposure
input double   LossPctMultiplier          = 25.0;    // 4% floating loss = 100 loss score
input double   ATRDistanceMultiplier      = 50.0;    // 2 ATR adverse move = 100 ATR score
input double   VolatilityPctMultiplier    = 80.0;    // 1.25% ATR/price = 100 vol score
input double   MaxLotsForScore            = 5.0;     // lots >= this = 100 lot score
input double   FavorableMoveDiscount      = 0.15;    // v4.4: multiplier on ATR/vol/lot components when money >= 0 (a trade moving IN your favor isn't "pain"). 0 = ignore those components entirely on winners, 1 = no discount (old behavior).

input string   Section_Action_Guide       = "----- RECOMMENDED ACTION GUIDE -----";
input bool     Show_Action_Column         = true;
input double   CloseWorstPainLevel        = 90.0;    // very high pain + loss
input double   ReducePainLevel            = 75.0;    // high pain + loss
input double   HedgeWatchPainLevel        = 65.0;    // risk rising, do not add blindly
input double   HighATRDistance            = 1.50;    // trade has moved 1.5 ATR or more
input double   HighVolatilityPercent      = 1.20;    // ATR/price percent considered volatile
input double   MainDDSymbolPainLevel      = 75.0;    // symbol-level DD driver threshold
input double   HedgedExposureRatio        = 0.30;    // net lots <= 30% gross lots = hedged/mixed

input string   Section_Recovery_Guide     = "----- HEDGE / RECOVERY GUIDE -----";
input bool     Show_Recovery_Guide        = true;    // shows hedge, SL/TP, and breakeven plan
input double   HedgeTriggerPainLevel      = 65.0;    // start hedge planning at/above this pain score
input double   HedgeLotMultiplier         = 1.00;    // 1.00 = hedge full net/worst exposure, 0.50 = half hedge
input double   ReducePercentSuggestion    = 50.0;    // DEPRECATED v4.4: no longer used directly, kept for saved input sets. See MinReducePercent/MaxReducePercent below.
input double   MinReducePercent          = 15.0;    // v4.4: smallest reduction ever suggested
input double   MaxReducePercent          = 75.0;    // v4.4: largest reduction ever suggested
input double   ReduceScalePerPainPoint   = 1.50;     // v4.4: % added per pain point above ReducePainLevel
input double   ReduceDepositMarginBuffer = 20.0;     // v4.4: safety cushion (%) added on top of bare hedge margin requirement
input double   HedgeSL_ATR_Multiple       = 0.75;    // ATR-based hedge stop guide
input double   HedgeTP_ATR_Multiple       = 1.00;    // ATR-based hedge target guide
input double   CurrentGuardSL_ATR_Multiple= 0.50;    // emergency guard level for worst open trade
input bool     PreferSameSymbolHedge      = true;    // same-symbol hedge is usually the cleanest MT4 hedge

input string   Section_Alerts             = "----- ALERTS -----";
input bool     EnableAlerts               = true;
input double   PainAlertLevel             = 75.0;
input double   PositionLossAlertMoney     = 0.0;     // 0 = disabled. Example: 300 alerts if one trade loss <= -300
input double   SymbolLossAlertMoney       = 0.0;     // 0 = disabled. Example: 500 alerts if symbol total loss <= -500
input int      AlertCooldownMinutes       = 15;
input bool     PopupAlert                 = true;
input bool     PushNotification           = false;
input bool     EmailAlert                 = false;
input bool     PrintToExperts             = true;

//------------------------- STRUCTS ---------------------------------
struct PositionRow
{
   int      ticket;
   string   symbol;
   int      type;
   double   lots;
   double   entry;
   double   current;
   double   pips;
   double   money;
   double   atrPips;
   double   atrDistance;
   double   volPct;
   double   lossPct;
   double   pain;
   datetime openTime;
};

struct SymbolRow
{
   string symbol;
   int    count;
   double buyLots;
   double sellLots;
   double netLots;
   double money;
   double atrPips;
   double volPct;
   double worstPain;
   double symbolPain;
};

//------------------------- GLOBALS ---------------------------------
string   PREFIX = "LPH_OPR_";
datetime LastAlertTime = 0;
string   LastAlertKey = "";

//+------------------------------------------------------------------+
//| OnInit                                                           |
//+------------------------------------------------------------------+
int OnInit()
{
   EventSetTimer(MathMax(1, RefreshSeconds));
   UpdateDashboard();
   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
//| OnDeinit                                                         |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   EventKillTimer();
   ClearObjects();
}

//+------------------------------------------------------------------+
//| OnTick                                                           |
//+------------------------------------------------------------------+
void OnTick()
{
   // Keep light. Main refresh runs on timer.
}

//+------------------------------------------------------------------+
//| OnTimer                                                          |
//+------------------------------------------------------------------+
void OnTimer()
{
   UpdateDashboard();
}

//+------------------------------------------------------------------+
//| Main update                                                      |
//+------------------------------------------------------------------+
void UpdateDashboard()
{
   PositionRow rows[];
   SymbolRow symbols[];

   CollectPositions(rows);
   BuildSymbolSummary(rows, symbols);

   SortPositionsByPain(rows);
   SortSymbolsByPain(symbols);

   if(Show_Dashboard)
      DrawDashboard(rows, symbols);

   if(EnableAlerts)
      ProcessRiskAlerts(rows, symbols);
}

//+------------------------------------------------------------------+
//| Collect open positions                                           |
//+------------------------------------------------------------------+
int CollectPositions(PositionRow &rows[])
{
   ArrayResize(rows, 0);

   int total = OrdersTotal();

   for(int i = 0; i < total; i++)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
         continue;

      int type = OrderType();

      if(type != OP_BUY && type != OP_SELL)
         continue;

      if(type == OP_BUY && !IncludeBuyPositions)
         continue;

      if(type == OP_SELL && !IncludeSellPositions)
         continue;

      string sym = OrderSymbol();

      if(IncludeOnlyCurrentSymbol && sym != Symbol())
         continue;

      if(MagicNumberFilter >= 0 && OrderMagicNumber() != MagicNumberFilter)
         continue;

      PositionRow r;
      r.ticket = OrderTicket();
      r.symbol = sym;
      r.type = type;
      r.lots = OrderLots();
      r.entry = OrderOpenPrice();
      r.money = OrderProfit() + OrderSwap() + OrderCommission();
      r.openTime = OrderOpenTime();

      double bid = MarketInfo(sym, MODE_BID);
      double ask = MarketInfo(sym, MODE_ASK);

      if(type == OP_BUY)
         r.current = bid;
      else
         r.current = ask;

      double pip = PipSize(sym);
      if(pip <= 0)
         pip = MarketInfo(sym, MODE_POINT);

      if(type == OP_BUY)
         r.pips = (r.current - r.entry) / pip;
      else
         r.pips = (r.entry - r.current) / pip;

      double atr = iATR(sym, ATR_Timeframe, ATR_Period, 0);
      if(atr <= 0)
         atr = iATR(sym, PERIOD_D1, ATR_Period, 0);

      r.atrPips = (pip > 0 && atr > 0) ? atr / pip : 0.0;
      r.atrDistance = (r.atrPips > 0) ? MathAbs(r.pips) / r.atrPips : 0.0;

      double price = MathMax(0.0000001, r.current);
      r.volPct = (atr > 0) ? (atr / price) * 100.0 : 0.0;

      double eq = MathMax(1.0, AccountEquity());
      r.lossPct = (r.money < 0) ? MathAbs(r.money) / eq * 100.0 : 0.0;

      r.pain = CalculatePainScore(r);

      int n = ArraySize(rows);
      ArrayResize(rows, n + 1);
      rows[n] = r;
   }

   return(ArraySize(rows));
}

//+------------------------------------------------------------------+
//| Build symbol summary                                             |
//+------------------------------------------------------------------+
void BuildSymbolSummary(PositionRow &rows[], SymbolRow &symbols[])
{
   ArrayResize(symbols, 0);

   for(int i = 0; i < ArraySize(rows); i++)
   {
      int idx = FindSymbolRow(symbols, rows[i].symbol);

      if(idx < 0)
      {
         SymbolRow s;
         s.symbol = rows[i].symbol;
         s.count = 0;
         s.buyLots = 0.0;
         s.sellLots = 0.0;
         s.netLots = 0.0;
         s.money = 0.0;
         s.atrPips = rows[i].atrPips;
         s.volPct = rows[i].volPct;
         s.worstPain = 0.0;
         s.symbolPain = 0.0;

         int n = ArraySize(symbols);
         ArrayResize(symbols, n + 1);
         symbols[n] = s;
         idx = n;
      }

      symbols[idx].count++;
      symbols[idx].money += rows[i].money;

      if(rows[i].type == OP_BUY)
         symbols[idx].buyLots += rows[i].lots;
      else
         symbols[idx].sellLots += rows[i].lots;

      symbols[idx].netLots = symbols[idx].buyLots - symbols[idx].sellLots;

      if(rows[i].pain > symbols[idx].worstPain)
         symbols[idx].worstPain = rows[i].pain;
   }

   for(int j = 0; j < ArraySize(symbols); j++)
   {
      double eq = MathMax(1.0, AccountEquity());
      double lossPct = (symbols[j].money < 0) ? MathAbs(symbols[j].money) / eq * 100.0 : 0.0;
      double lossScore = Clamp(lossPct * LossPctMultiplier, 0, 100);
      double volScore = Clamp(symbols[j].volPct * VolatilityPctMultiplier, 0, 100);
      double exposureLots = MathAbs(symbols[j].netLots);
      double lotScore = Clamp((exposureLots / MathMax(0.01, MaxLotsForScore)) * 100.0, 0, 100);

      // v4.4 fix: same direction gate as CalculatePainScore -- don't let a
      // net-profitable symbol basket score high "pain" purely from being
      // volatile or large. worstPain already carries the discount from the
      // per-position score above, so only volScore/lotScore need it here.
      double symDirectionFactor = (symbols[j].money < 0.0) ? 1.0 : Clamp(FavorableMoveDiscount, 0.0, 1.0);
      volScore *= symDirectionFactor;
      lotScore *= symDirectionFactor;

      symbols[j].symbolPain = (lossScore * 0.50) + (symbols[j].worstPain * 0.30) + (volScore * 0.10) + (lotScore * 0.10);
   }
}

int FindSymbolRow(SymbolRow &symbols[], string sym)
{
   for(int i = 0; i < ArraySize(symbols); i++)
   {
      if(symbols[i].symbol == sym)
         return(i);
   }

   return(-1);
}

//+------------------------------------------------------------------+
//| Pain score                                                       |
//+------------------------------------------------------------------+
double CalculatePainScore(PositionRow &r)
{
   double lossScore = Clamp(r.lossPct * LossPctMultiplier, 0, 100);

   double atrScore = 0.0;
   if(UseATRDistanceInPainScore)
      atrScore = Clamp(r.atrDistance * ATRDistanceMultiplier, 0, 100);

   double volScore = Clamp(r.volPct * VolatilityPctMultiplier, 0, 100);

   double lotScore = Clamp((r.lots / MathMax(0.01, MaxLotsForScore)) * 100.0, 0, 100);

   // v4.4 fix: atrScore/volScore/lotScore previously fired the same whether the
   // trade was winning or losing, because atrDistance uses MathAbs(pips) and
   // volPct/lotScore don't look at direction at all. That meant a PROFITABLE
   // trade that had moved far in its favor, or that was simply large/on a
   // volatile symbol, could still rack up a high "pain" score and trigger
   // reduce/hedge advice with no actual loss behind it. Discount those three
   // components on trades that are currently breakeven-or-better; only real
   // floating loss (lossScore) drives pain at full weight regardless of
   // direction.
   double directionFactor = (r.money < 0.0) ? 1.0 : Clamp(FavorableMoveDiscount, 0.0, 1.0);
   atrScore *= directionFactor;
   volScore *= directionFactor;
   lotScore *= directionFactor;

   double weightTotal = Weight_LossPct + Weight_ATRDistance + Weight_Volatility + Weight_LotExposure;
   if(weightTotal <= 0)
      weightTotal = 1.0;

   double pain =
      (lossScore * Weight_LossPct +
       atrScore  * Weight_ATRDistance +
       volScore  * Weight_Volatility +
       lotScore  * Weight_LotExposure) / weightTotal;

   return(Clamp(pain, 0, 100));
}

//+------------------------------------------------------------------+
//| Sorting                                                          |
//+------------------------------------------------------------------+
void SortPositionsByPain(PositionRow &rows[])
{
   int n = ArraySize(rows);

   for(int i = 0; i < n - 1; i++)
   {
      for(int j = i + 1; j < n; j++)
      {
         if(rows[j].pain > rows[i].pain)
         {
            PositionRow temp = rows[i];
            rows[i] = rows[j];
            rows[j] = temp;
         }
      }
   }
}

void SortSymbolsByPain(SymbolRow &symbols[])
{
   int n = ArraySize(symbols);

   for(int i = 0; i < n - 1; i++)
   {
      for(int j = i + 1; j < n; j++)
      {
         if(symbols[j].symbolPain > symbols[i].symbolPain)
         {
            SymbolRow temp = symbols[i];
            symbols[i] = symbols[j];
            symbols[j] = temp;
         }
      }
   }
}

//+------------------------------------------------------------------+
//| Dashboard                                                        |
//+------------------------------------------------------------------+
int ClampInt(int v, int minV, int maxV)
{
   if(v < minV) return(minV);
   if(v > maxV) return(maxV);
   return(v);
}

void ApplyBlankChartStyle()
{
   if(!CleanBlankChartMode)
      return;

   ChartSetInteger(0, CHART_COLOR_BACKGROUND, clrBlack);
   ChartSetInteger(0, CHART_COLOR_FOREGROUND, clrSilver);
   ChartSetInteger(0, CHART_COLOR_GRID, clrBlack);
   ChartSetInteger(0, CHART_SHOW_GRID, false);
   ChartSetInteger(0, CHART_SHOW_VOLUMES, false);
   ChartSetInteger(0, CHART_SHIFT, true);
}

string ShortText(string text, int maxLen)
{
   if(maxLen <= 0)
      return("");

   if(StringLen(text) <= maxLen)
      return(text);

   if(maxLen <= 3)
      return(StringSubstr(text, 0, maxLen));

   return(StringSubstr(text, 0, maxLen - 1) + ".");
}

void DrawBox(string key, int x, int y, int w, int h, color bg, color border)
{
   string name = PREFIX + "BOX_" + key;

   if(ObjectFind(0, name) < 0)
      ObjectCreate(0, name, OBJ_RECTANGLE_LABEL, 0, 0, 0);

   ObjectSetInteger(0, name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, name, OBJPROP_XSIZE, MathMax(1, w));
   ObjectSetInteger(0, name, OBJPROP_YSIZE, MathMax(1, h));
   ObjectSetInteger(0, name, OBJPROP_BGCOLOR, bg);
   ObjectSetInteger(0, name, OBJPROP_BORDER_COLOR, border);
   ObjectSetInteger(0, name, OBJPROP_STYLE, STYLE_SOLID);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, 1);
   ObjectSetInteger(0, name, OBJPROP_BACK, true);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
}

void DrawTextPx(string key, string text, int x, int y, color clr, int size, string font)
{
   string name = PREFIX + "TXT_" + key;

   if(ObjectFind(0, name) < 0)
      ObjectCreate(0, name, OBJ_LABEL, 0, 0, 0);

   ObjectSetInteger(0, name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, size);
   ObjectSetString(0, name, OBJPROP_FONT, font);
   ObjectSetString(0, name, OBJPROP_TEXT, text);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
   ObjectSetInteger(0, name, OBJPROP_BACK, false);
}

void DrawMetricCard(string key, string label, string value, int x, int y, int w, int h, color valueColor, int labelSize, int valueSize)
{
   DrawBox("CARD_" + key, x, y, w, h, CardBGColor, PanelBorderColor);
   DrawTextPx("CARD_L_" + key, label, x + 10, y + 8, NormalColor, labelSize, "Arial");
   DrawTextPx("CARD_V_" + key, value, x + 10, y + 28, valueColor, valueSize, "Arial Bold");
}

string DashboardActionSummary(PositionRow &rows[], SymbolRow &symbols[])
{
   if(ArraySize(rows) <= 0)
      return("No open risk detected.");

   string posAction = PositionAction(rows[0]);
   string symAction = "";
   string sym = "-";

   if(ArraySize(symbols) > 0)
   {
      sym = symbols[0].symbol;
      symAction = SymbolAction(symbols[0]);
   }

   return("Worst: " + rows[0].symbol + " " + ((rows[0].type == OP_BUY) ? "BUY" : "SELL") +
          " | Pain " + DoubleToString(rows[0].pain, 0) +
          " | " + posAction +
          "     Main DD: " + sym + " | " + symAction);
}

void DrawDashboard(PositionRow &rows[], SymbolRow &symbols[])
{
   ClearObjects();
   ApplyBlankChartStyle();

   // Fallback to original compact line dashboard if full screen mode is disabled.
   if(!FullscreenDashboard)
   {
      int line = 0;
      DrawLine(line++, "LPH OPEN POSITION PAIN / RISK DASHBOARD", HeaderColor);
      DrawLine(line++, "Equity: " + MoneyStr(AccountEquity()) +
                       " | Balance: " + MoneyStr(AccountBalance()) +
                       " | Floating: " + MoneyStr(AccountProfit()), NormalColor);
      DrawLine(line++, "ATR TF: " + TFToString(ATR_Timeframe) +
                       " | Refresh: " + IntegerToString(RefreshSeconds) + "s" +
                       " | Open positions: " + IntegerToString(ArraySize(rows)), NormalColor);
      DrawLine(line++, "Use FullscreenDashboard=true for the v3 dedicated blank-chart interface.", WarningColor);
      return;
   }

   int chartW = (int)ChartGetInteger(0, CHART_WIDTH_IN_PIXELS, 0);
   int chartH = (int)ChartGetInteger(0, CHART_HEIGHT_IN_PIXELS, 0);

   if(chartW <= 0) chartW = 1280;
   if(chartH <= 0) chartH = 720;

   int margin = DashboardMargin;
   if(margin < 5) margin = 5;

   int pad = PanelPadding;
   if(pad < 6) pad = 6;

   int titleSize = 20;
   int subSize   = 10;
   int bodySize  = 9;
   int monoSize  = 9;
   int rowH      = 18;

   if(AutoScaleInterface)
   {
      titleSize = ClampInt(chartW / 58, 16, 30);
      subSize   = ClampInt(chartW / 125, 8, 12);
      bodySize  = ClampInt(chartW / 118, 8, 13);
      monoSize  = ClampInt(chartW / 145, 8, 12);
      rowH      = ClampInt(chartH / 40, 16, 23);
   }
   else
   {
      bodySize = MathMax(8, FontSize);
      monoSize = bodySize;
      rowH = MathMax(14, LineSpacing);
      titleSize = bodySize + 8;
      subSize = bodySize;
   }

   int W = chartW - (margin * 2);
   int H = chartH - (margin * 2);

   DrawBox("BG_MAIN", 0, 0, chartW, chartH, clrBlack, clrBlack);

   // Header
   int headerH = ClampInt(chartH / 8, 78, 118);
   DrawBox("HEADER", margin, margin, W, headerH, PanelBGColor, PanelBorderColor);

   DrawTextPx("TITLE", "LPH OPEN POSITIONS PAIN DASHBOARD", margin + pad, margin + 12, HeaderColor, titleSize, "Arial Bold");
   DrawTextPx("SUBTITLE", "Account-wide risk control  |  Pain Score  |  Hedge Plan  |  Recovery Guide", margin + pad, margin + 42, AccentColor, subSize, "Arial");

   string timeText = "Last update: " + TimeToString(TimeLocal(), TIME_DATE|TIME_SECONDS) +
                     "  |  ATR TF: " + TFToString(ATR_Timeframe) +
                     "  |  Refresh: " + IntegerToString(RefreshSeconds) + "s";
   DrawTextPx("TIME", timeText, margin + pad, margin + headerH - 24, NormalColor, subSize, "Arial");

   // Metric cards
   int cardGap = 10;
   int cardY = margin + headerH + 12;
   int cardH = ClampInt(chartH / 11, 56, 78);
   int cardW = (W - (cardGap * 4)) / 5;

   double floating = AccountProfit();
   color floatingColor = floating < 0 ? LossColor : ProfitColor;

   string worstPain = "-";
   color worstColor = NormalColor;
   if(ArraySize(rows) > 0)
   {
      worstPain = DoubleToString(rows[0].pain, 0);
      worstColor = PainColor(rows[0].pain, rows[0].money);
   }

   string mainRisk = "-";
   if(ArraySize(symbols) > 0)
      mainRisk = ShortText(symbols[0].symbol, 12);

   DrawMetricCard("EQ", "Equity", MoneyStr(AccountEquity()), margin, cardY, cardW, cardH, ProfitColor, subSize, bodySize + 2);
   DrawMetricCard("BAL", "Balance", MoneyStr(AccountBalance()), margin + (cardW + cardGap) * 1, cardY, cardW, cardH, NormalColor, subSize, bodySize + 2);
   DrawMetricCard("FLT", "Floating", MoneyStr(floating), margin + (cardW + cardGap) * 2, cardY, cardW, cardH, floatingColor, subSize, bodySize + 2);
   DrawMetricCard("OPEN", "Open positions", IntegerToString(ArraySize(rows)), margin + (cardW + cardGap) * 3, cardY, cardW, cardH, HeaderColor, subSize, bodySize + 2);
   DrawMetricCard("PAIN", "Worst pain / main risk", worstPain + " / " + mainRisk, margin + (cardW + cardGap) * 4, cardY, cardW, cardH, worstColor, subSize, bodySize + 2);

   // Main panels
   int panelTop = cardY + cardH + 12;
   int bottomH = Show_Recovery_Guide ? ClampInt(chartH / 4, 170, 240) : ClampInt(chartH / 9, 62, 92);
   int panelH = chartH - panelTop - bottomH - margin - 12;

   int gap = 14;
   bool twoCol = TwoColumnLayout && chartW >= 900;

   int leftX = margin;
   int leftY = panelTop;
   int leftW = twoCol ? (W - gap) / 2 : W;
   int leftH = twoCol ? panelH : (panelH - gap) / 2;

   int rightX = twoCol ? (margin + leftW + gap) : margin;
   int rightY = twoCol ? panelTop : (leftY + leftH + gap);
   int rightW = twoCol ? leftW : W;
   int rightH = twoCol ? panelH : leftH;

   // Left panel: worst positions
   DrawBox("PANEL_POS", leftX, leftY, leftW, leftH, PanelBGColor, PanelBorderColor);
   DrawTextPx("POS_HEAD", "WORST POSITIONS BY PAIN SCORE", leftX + pad, leftY + 10, HeaderColor, bodySize + 2, "Arial Bold");
   DrawTextPx("POS_SUB", "Highest account pressure first", leftX + pad, leftY + 32, NormalColor, subSize, "Arial");

   int tableY = leftY + 56;
   string posHeader = "Pain Symbol       Side Lot      P/L      Pips   ATRx  Action";
   DrawTextPx("POS_COLS", posHeader, leftX + pad, tableY, NormalColor, monoSize, FontName);
   tableY += rowH;

   int maxPosRows = MathMax(1, (leftH - 74) / rowH);
   int posMax = MathMin(TopPositionsToShow, MathMin(ArraySize(rows), maxPosRows));

   for(int i = 0; i < posMax; i++)
   {
      color c = PainColor(rows[i].pain, rows[i].money);
      string dir = (rows[i].type == OP_BUY) ? "BUY " : "SELL";
      string action = Show_Action_Column ? PositionAction(rows[i]) : "";

      string lineTxt =
         PadLeft(DoubleToString(rows[i].pain, 0), 4) + " " +
         PadRight(ShortText(rows[i].symbol, 12), 12) + " " +
         dir + " " +
         PadLeft(DoubleToString(rows[i].lots, 2), 4) + " " +
         PadLeft(MoneyStr(rows[i].money), 9) + " " +
         PadLeft(DoubleToString(rows[i].pips, 1), 8) + " " +
         PadLeft(DoubleToString(rows[i].atrDistance, 2), 6) + "  " +
         action;

      DrawTextPx("POS_ROW_" + IntegerToString(i), lineTxt, leftX + pad, tableY + (i * rowH), c, monoSize, FontName);
   }

   if(ArraySize(rows) <= 0)
      DrawTextPx("NO_POS", "No open market positions found.", leftX + pad, tableY, NormalColor, bodySize, "Arial Bold");

   // Right panel: exposure summary
   DrawBox("PANEL_SYM", rightX, rightY, rightW, rightH, PanelBGColor, PanelBorderColor);
   DrawTextPx("SYM_HEAD", "SYMBOL EXPOSURE SUMMARY", rightX + pad, rightY + 10, HeaderColor, bodySize + 2, "Arial Bold");
   DrawTextPx("SYM_SUB", "Shows which asset is driving total account pressure", rightX + pad, rightY + 32, NormalColor, subSize, "Arial");

   int symY = rightY + 56;
   string symHeader = "Pain Symbol       Cnt  Buy   Sell   Net       P/L  Action";
   DrawTextPx("SYM_COLS", symHeader, rightX + pad, symY, NormalColor, monoSize, FontName);
   symY += rowH;

   int maxSymRows = MathMax(1, (rightH - 74) / rowH);
   int symMax = MathMin(TopSymbolsToShow, MathMin(ArraySize(symbols), maxSymRows));

   for(int s = 0; s < symMax; s++)
   {
      color sc = PainColor(symbols[s].symbolPain, symbols[s].money);
      string sAction = Show_Action_Column ? SymbolAction(symbols[s]) : "";

      string stxt =
         PadLeft(DoubleToString(symbols[s].symbolPain, 0), 4) + " " +
         PadRight(ShortText(symbols[s].symbol, 12), 12) + " " +
         PadLeft(IntegerToString(symbols[s].count), 3) + " " +
         PadLeft(DoubleToString(symbols[s].buyLots, 2), 5) + " " +
         PadLeft(DoubleToString(symbols[s].sellLots, 2), 6) + " " +
         PadLeft(DoubleToString(symbols[s].netLots, 2), 6) + " " +
         PadLeft(MoneyStr(symbols[s].money), 9) + "  " +
         sAction;

      DrawTextPx("SYM_ROW_" + IntegerToString(s), stxt, rightX + pad, symY + (s * rowH), sc, monoSize, FontName);
   }

   // Bottom action strip
   int bottomY = chartH - margin - bottomH;
   DrawBox("BOTTOM", margin, bottomY, W, bottomH, CardBGColor, PanelBorderColor);

   string summary = DashboardActionSummary(rows, symbols);
   DrawTextPx("ACTION_TITLE", "ACTION / RECOVERY GUIDE", margin + pad, bottomY + 10, HeaderColor, bodySize + 2, "Arial Bold");
   DrawTextPx("ACTION_SUMMARY", summary, margin + pad, bottomY + 34, WarningColor, bodySize, "Arial Bold");

   if(Show_Recovery_Guide)
   {
      DrawTextPx("HEDGE_GUIDE", HedgePlan(rows, symbols), margin + pad, bottomY + 56, AccentColor, bodySize, "Arial Bold");
      DrawTextPx("SLTP_HEDGE", SLTPHedgeLine(rows), margin + pad, bottomY + 78, NormalColor, subSize + 1, "Arial");
      DrawTextPx("SLTP_CURRENT", CurrentPositionLine(rows), margin + pad, bottomY + 98, NormalColor, subSize + 1, "Arial");
      DrawTextPx("RECOVERY_GUIDE", BreakevenPlan(rows, symbols), margin + pad, bottomY + 118, ProfitColor, subSize + 1, "Arial");
   }

   DrawTextPx("ACTION_NOTE", "Risk triage only. No auto-close or auto-trade. ATR levels are planning guides.",
              margin + pad, bottomY + bottomH - 24, NormalColor, subSize, "Arial");
}

// Original compact label drawer kept for fallback mode.
void DrawLine(int line, string text, color clr)
{
   string name = PREFIX + "LINE_" + IntegerToString(line);

   if(ObjectFind(0, name) < 0)
      ObjectCreate(0, name, OBJ_LABEL, 0, 0, 0);

   ObjectSetInteger(0, name, OBJPROP_CORNER, PanelCorner);
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE, PanelX);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE, PanelY + (line * LineSpacing));
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, FontSize);
   ObjectSetString(0, name, OBJPROP_FONT, FontName);
   ObjectSetString(0, name, OBJPROP_TEXT, text);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
}

void ClearObjects()
{
   // Old-build compatible object scan.
   int total = ObjectsTotal();

   for(int i = total - 1; i >= 0; i--)
   {
      string name = ObjectName(i);

      if(StringFind(name, PREFIX) == 0)
         ObjectDelete(name);
   }
}

//+------------------------------------------------------------------+
//| Recommended action guide                                         |
//+------------------------------------------------------------------+
string PositionAction(PositionRow &r)
{
   // Conservative risk-triage label only. This does not execute trades.
   if(r.money < 0.0)
   {
      if(r.pain >= CloseWorstPainLevel)
         return("CLOSE/REDUCE");

      if(r.pain >= ReducePainLevel)
         return("REDUCE");

      if(r.pain >= HedgeWatchPainLevel)
         return("HEDGE WATCH");

      if(UseATRDistanceInPainScore && r.atrDistance >= HighATRDistance)
         return("ATR STRETCHED");

      return("MONITOR LOSS");
   }

   if(r.volPct >= HighVolatilityPercent && r.pain >= HedgeWatchPainLevel)
      return("VOLATILE OK");

   if(r.pain >= HedgeWatchPainLevel)
      return("RISK WATCH");

   return("OK");
}

string SymbolAction(SymbolRow &s)
{
   double grossLots = s.buyLots + s.sellLots;
   bool mixedBook = (s.buyLots > 0.0 && s.sellLots > 0.0);
   bool mostlyHedged = false;

   if(grossLots > 0.0)
      mostlyHedged = (MathAbs(s.netLots) / grossLots <= HedgedExposureRatio);

   if(mixedBook && mostlyHedged)
   {
      if(s.money < 0.0)
         return("HEDGED DD");

      return("MIXED/HEDGED");
   }

   if(s.money < 0.0)
   {
      if(s.symbolPain >= MainDDSymbolPainLevel)
         return("MAIN DD DRIVER");

      if(s.symbolPain >= HedgeWatchPainLevel)
         return("REDUCE EXP");

      return("WATCH DD");
   }

   if(s.volPct >= HighVolatilityPercent)
      return("VOLATILE OK");

   if(s.symbolPain >= HedgeWatchPainLevel)
      return("EXPOSURE WATCH");

   return("OK");
}


//+------------------------------------------------------------------+
//| Hedge / recovery guide                                           |
//+------------------------------------------------------------------+
string OrderSideText(int type)
{
   return((type == OP_BUY) ? "BUY" : "SELL");
}

string OppositeSideText(int type)
{
   return((type == OP_BUY) ? "SELL" : "BUY");
}

double SymbolPointValue(string sym)
{
   double point = MarketInfo(sym, MODE_POINT);
   if(point <= 0.0)
      point = Point;
   return(point);
}

string PriceStr(string sym, double price)
{
   int digits = (int)MarketInfo(sym, MODE_DIGITS);
   if(digits < 0 || digits > 8)
      digits = Digits;
   return(DoubleToString(price, digits));
}

//+------------------------------------------------------------------+
//| v4.4 patch: severity-scaled reduce % + deposit-to-hedge guard     |
//| Added because ReducePercentSuggestion was a single fixed number   |
//| (50%) applied no matter how mild or severe the drawdown was.      |
//+------------------------------------------------------------------+
double ComputeReducePercent(double pain)
{
   double over = MathMax(0.0, pain - ReducePainLevel);
   double pct = MinReducePercent + over * ReduceScalePerPainPoint;
   return(Clamp(pct, MinReducePercent, MaxReducePercent));
}

double MarginPerLotDash(string sym)
{
   double m = MarketInfo(sym, MODE_MARGINREQUIRED);
   if(m > 0.0) return(m);

   double contractSize = MarketInfo(sym, MODE_LOTSIZE);
   if(contractSize <= 0.0) contractSize = 100000.0;

   double price = MarketInfo(sym, MODE_BID);
   double leverage = AccountLeverage();
   if(leverage <= 0.0) leverage = 100.0;
   if(price <= 0.0) return(0.0);

   return((contractSize * price) / leverage);
}

// Margin needed to place `lots` of hedge (plus safety buffer), and the extra
// deposit required if current free margin doesn't already cover it.
void ComputeDepositGuardDash(string sym, double lots, double &marginNeeded, double &depositShortfall)
{
   marginNeeded = MarginPerLotDash(sym) * lots * (1.0 + ReduceDepositMarginBuffer / 100.0);
   double freeMargin = AccountFreeMargin();
   depositShortfall = MathMax(0.0, marginNeeded - freeMargin);
}

double SuggestedHedgeLots(PositionRow &worst, SymbolRow &mainSym)
{
   double lots = worst.lots;

   if(mainSym.symbol == worst.symbol && MathAbs(mainSym.netLots) > 0.0)
      lots = MathAbs(mainSym.netLots);

   lots = lots * MathMax(0.10, HedgeLotMultiplier);

   double minLot = MarketInfo(worst.symbol, MODE_MINLOT);
   double lotStep = MarketInfo(worst.symbol, MODE_LOTSTEP);

   if(minLot <= 0.0) minLot = 0.01;
   if(lotStep <= 0.0) lotStep = 0.01;

   lots = MathMax(minLot, lots);
   lots = MathFloor(lots / lotStep) * lotStep;

   return(NormalizeDouble(lots, 2));
}

bool IsFXCore(string sym, string &base, string &quote)
{
   string upper = StringUpperCustom(sym);
   string clean = "";

   for(int i = 0; i < StringLen(upper); i++)
   {
      int c = StringGetChar(upper, i);
      if(c >= 65 && c <= 90)
         clean = clean + StringSubstr(upper, i, 1);
   }

   if(StringLen(clean) < 6)
      return(false);

   base = StringSubstr(clean, 0, 3);
   quote = StringSubstr(clean, 3, 3);

   // Avoid treating common non-FX CFD/metal/crypto prefixes as normal FX pairs.
   if(base == "XAU" || base == "XAG" || base == "BTC" || base == "ETH" || base == "NAS" || base == "US3" || base == "SPX")
      return(false);

   return(true);
}

string CrossHedgeCandidate(SymbolRow &mainSym, SymbolRow &symbols[])
{
   string base = "";
   string quote = "";

   if(!IsFXCore(mainSym.symbol, base, quote))
      return("Cross: same-symbol hedge preferred for CFD/metals/indices.");

   double net = mainSym.netLots;
   if(MathAbs(net) <= 0.0)
      return("Cross: exposure already mixed; reduce bad legs first.");

   string needCurrency = "";
   string needAction = "";

   if(net > 0.0)
   {
      needCurrency = base;
      needAction = "short " + base;
   }
   else
   {
      needCurrency = quote;
      needAction = "short " + quote;
   }

   for(int i = 0; i < ArraySize(symbols); i++)
   {
      if(symbols[i].symbol == mainSym.symbol)
         continue;

      string b = "";
      string q = "";
      if(!IsFXCore(symbols[i].symbol, b, q))
         continue;

      string side = "";

      if(needCurrency == b)
         side = "SELL";
      else if(needCurrency == q)
         side = "BUY";
      else
         continue;

      return("Alt cross: " + side + " " + symbols[i].symbol + " to offset " + needAction + " exposure.");
   }

   return("Alt cross: none from current open symbols; same-symbol hedge is cleaner.");
}

string HedgePlan(PositionRow &rows[], SymbolRow &symbols[])
{
   if(ArraySize(rows) <= 0)
      return("Hedge: no open positions.");

   PositionRow worst = rows[0];

   if(worst.pain < HedgeTriggerPainLevel && worst.money >= 0.0)
      return("Hedge: not needed yet. Risk is below hedge trigger.");

   SymbolRow mainSym;
   bool hasSym = false;

   if(ArraySize(symbols) > 0)
   {
      mainSym = symbols[0];
      hasSym = true;
   }

   string hedgeSymbol = worst.symbol;
   int protectType = (worst.type == OP_BUY) ? OP_SELL : OP_BUY; // protection for worst losing trade
   double hedgeLots = worst.lots;

   if(hasSym && mainSym.symbol == worst.symbol)
   {
      double grossLots = mainSym.buyLots + mainSym.sellLots;
      bool alreadyHedged = (mainSym.buyLots > 0.0 && mainSym.sellLots > 0.0);

      if(alreadyHedged)
      {
         double reducePct = ComputeReducePercent(worst.pain);
         double reduceLots = worst.lots * reducePct / 100.0;
         return("Hedge: already hedged on " + hedgeSymbol +
                " | reduce worst " + OrderSideText(worst.type) +
                " by ~" + DoubleToString(reduceLots, 2) +
                " lots (" + DoubleToString(reducePct, 0) + "%, scaled to pain " + DoubleToString(worst.pain, 0) +
                ") first. If risk continues: " +
                OrderSideText(protectType) + ".");
      }

      if(MathAbs(mainSym.netLots) > 0.0)
         hedgeLots = SuggestedHedgeLots(worst, mainSym);
   }
   else if(hasSym)
   {
      hedgeLots = SuggestedHedgeLots(worst, mainSym);
   }

   string why = PreferSameSymbolHedge ? "protects worst trade" : "offsets exposure";
   string cross = hasSym ? CrossHedgeCandidate(mainSym, symbols) : "";

   double marginNeeded = 0.0, depositShortfall = 0.0;
   ComputeDepositGuardDash(hedgeSymbol, hedgeLots, marginNeeded, depositShortfall);
   string depositNote = (depositShortfall > 0.0) ?
      (" | margin needed ~" + DoubleToString(marginNeeded, 2) + ", deposit ~" + DoubleToString(depositShortfall, 2) + " more.") :
      (" | margin needed ~" + DoubleToString(marginNeeded, 2) + ", already covered by free margin.");

   return("Hedge: consider " + OrderSideText(protectType) + " " + hedgeSymbol +
          " " + DoubleToString(hedgeLots, 2) + " lots | " + why + ". " + cross + depositNote);
}

string SLTPHedgeLine(PositionRow &rows[])
{
   if(ArraySize(rows) <= 0)
      return("Hedge SL/TP: no open positions.");

   PositionRow r = rows[0];

   double pip = PipSize(r.symbol);
   if(pip <= 0.0)
      pip = SymbolPointValue(r.symbol);

   double atrPrice = r.atrPips * pip;
   if(atrPrice <= 0.0)
      atrPrice = MathAbs(r.current - r.entry);

   int hedgeType = (r.type == OP_BUY) ? OP_SELL : OP_BUY;

   double hedgeEntry = r.current;
   double hedgeSL = hedgeEntry;
   double hedgeTP = hedgeEntry;

   if(hedgeType == OP_SELL)
   {
      hedgeSL = hedgeEntry + (atrPrice * HedgeSL_ATR_Multiple);
      hedgeTP = hedgeEntry - (atrPrice * HedgeTP_ATR_Multiple);
   }
   else
   {
      hedgeSL = hedgeEntry - (atrPrice * HedgeSL_ATR_Multiple);
      hedgeTP = hedgeEntry + (atrPrice * HedgeTP_ATR_Multiple);
   }

   return("Hedge SL/TP: " + OrderSideText(hedgeType) +
          " | SL " + PriceStr(r.symbol, hedgeSL) +
          " | TP " + PriceStr(r.symbol, hedgeTP));
}

string CurrentPositionLine(PositionRow &rows[])
{
   if(ArraySize(rows) <= 0)
      return("Current position: no open positions.");

   PositionRow r = rows[0];

   double pip = PipSize(r.symbol);
   if(pip <= 0.0)
      pip = SymbolPointValue(r.symbol);

   double atrPrice = r.atrPips * pip;
   if(atrPrice <= 0.0)
      atrPrice = MathAbs(r.current - r.entry);

   double guardSL = r.current;
   if(r.type == OP_BUY)
      guardSL = r.current - (atrPrice * CurrentGuardSL_ATR_Multiple);
   else
      guardSL = r.current + (atrPrice * CurrentGuardSL_ATR_Multiple);

   return("Worst trade: " + OrderSideText(r.type) +
          " guard SL " + PriceStr(r.symbol, guardSL) +
          " | BE target " + PriceStr(r.symbol, r.entry));
}


string BreakevenPlan(PositionRow &rows[], SymbolRow &symbols[])
{
   if(ArraySize(rows) <= 0)
      return("Plan: no open risk.");

   string plan = "Plan: ";

   if(ArraySize(symbols) > 0 && symbols[0].symbolPain >= MainDDSymbolPainLevel)
      plan = plan + "stabilize " + symbols[0].symbol + " first; ";

   if(rows[0].pain >= ReducePainLevel)
   {
      bool sameSymHedged = false;
      if(ArraySize(symbols) > 0 && symbols[0].symbol == rows[0].symbol && symbols[0].buyLots > 0.0 && symbols[0].sellLots > 0.0)
         sameSymHedged = true;

      double reducePct = ComputeReducePercent(rows[0].pain);

      if(sameSymHedged)
         plan = plan + "reduce worst by ~" + DoubleToString(reducePct, 0) + "% (scaled to pain " + DoubleToString(rows[0].pain, 0) + "), balance existing hedge, no new add-ons until pain < " + DoubleToString(HedgeTriggerPainLevel, 0) + ".";
      else
         plan = plan + "reduce worst by ~" + DoubleToString(reducePct, 0) + "% (scaled to pain " + DoubleToString(rows[0].pain, 0) + "), hedge remaining net, no new add-ons until pain < " + DoubleToString(HedgeTriggerPainLevel, 0) + ".";
   }
   else if(rows[0].pain >= HedgeTriggerPainLevel)
      plan = plan + "prepare hedge or partial close; wait for relief toward entry/BE.";
   else
      plan = plan + "monitor only; avoid adding into drawdown without fresh confirmation.";

   return(plan);
}

//+------------------------------------------------------------------+
//| Alerts                                                           |
//+------------------------------------------------------------------+
void ProcessRiskAlerts(PositionRow &rows[], SymbolRow &symbols[])
{
   if(ArraySize(rows) <= 0)
      return;

   datetime now = TimeCurrent();

   if(AlertCooldownMinutes > 0 && LastAlertTime > 0)
   {
      if((now - LastAlertTime) < AlertCooldownMinutes * 60)
         return;
   }

   string alertMsg = "";
   string alertKey = "";

   for(int i = 0; i < ArraySize(rows); i++)
   {
      bool hit = false;

      if(rows[i].pain >= PainAlertLevel)
         hit = true;

      if(PositionLossAlertMoney > 0 && rows[i].money <= -MathAbs(PositionLossAlertMoney))
         hit = true;

      if(hit)
      {
         alertKey = "POS_" + IntegerToString(rows[i].ticket) + "_" + DoubleToString(rows[i].pain, 0);

         alertMsg =
            "LPH Risk Alert | Worst open position: " +
            rows[i].symbol + " " + ((rows[i].type == OP_BUY) ? "BUY" : "SELL") +
            " | P/L " + MoneyStr(rows[i].money) +
            " | Pips " + DoubleToString(rows[i].pips, 1) +
            " | Pain " + DoubleToString(rows[i].pain, 0) +
            " | ATRx " + DoubleToString(rows[i].atrDistance, 2) +
            " | Action: " + PositionAction(rows[i]);

         break;
      }
   }

   if(alertMsg == "" && SymbolLossAlertMoney > 0)
   {
      for(int s = 0; s < ArraySize(symbols); s++)
      {
         if(symbols[s].money <= -MathAbs(SymbolLossAlertMoney))
         {
            alertKey = "SYM_" + symbols[s].symbol + "_" + DoubleToString(symbols[s].money, 0);
            alertMsg =
               "LPH Symbol Risk Alert | " + symbols[s].symbol +
               " total P/L " + MoneyStr(symbols[s].money) +
               " | Net lots " + DoubleToString(symbols[s].netLots, 2) +
               " | Pain " + DoubleToString(symbols[s].symbolPain, 0) +
               " | Action: " + SymbolAction(symbols[s]);
            break;
         }
      }
   }

   if(alertMsg == "")
      return;

   if(alertKey == LastAlertKey)
      return;

   LastAlertKey = alertKey;
   LastAlertTime = now;

   if(PopupAlert)
      Alert(alertMsg);

   if(PushNotification)
      SendNotification(alertMsg);

   if(EmailAlert)
      SendMail("LPH Open Position Risk Alert", alertMsg);

   if(PrintToExperts)
      Print(alertMsg);
}

//+------------------------------------------------------------------+
//| Utilities                                                        |
//+------------------------------------------------------------------+
double PipSize(string sym)
{
   double point = MarketInfo(sym, MODE_POINT);
   int digits = (int)MarketInfo(sym, MODE_DIGITS);

   if(point <= 0)
      return(Point);

   string upper = StringUpperCustom(sym);

   if(StringFind(upper, "XAU") >= 0 || StringFind(upper, "GOLD") >= 0)
   {
      if(GoldPipIsTenPoints)
         return(point * 10.0);

      return(point);
   }

   if(digits == 3 || digits == 5)
      return(point * 10.0);

   return(point);
}

string StringUpperCustom(string s)
{
   string out = s;
   StringToUpper(out);
   return(out);
}

double Clamp(double v, double minV, double maxV)
{
   if(v < minV)
      return(minV);

   if(v > maxV)
      return(maxV);

   return(v);
}

color PainColor(double pain, double money)
{
   if(pain >= 85)
      return(DangerColor);

   if(pain >= 70)
      return(WarningColor);

   if(money < 0)
      return(LossColor);

   if(money > 0)
      return(ProfitColor);

   return(NormalColor);
}

string MoneyStr(double value)
{
   string sign = "";

   if(value > 0)
      sign = "+";

   return(sign + DoubleToString(value, 2));
}

string PadLeft(string text, int width)
{
   while(StringLen(text) < width)
      text = " " + text;

   return(text);
}

string PadRight(string text, int width)
{
   while(StringLen(text) < width)
      text = text + " ";

   return(text);
}

string TFToString(int tf)
{
   switch(tf)
   {
      case PERIOD_M1:  return("M1");
      case PERIOD_M5:  return("M5");
      case PERIOD_M15: return("M15");
      case PERIOD_M30: return("M30");
      case PERIOD_H1:  return("H1");
      case PERIOD_H4:  return("H4");
      case PERIOD_D1:  return("D1");
      case PERIOD_W1:  return("W1");
      case PERIOD_MN1: return("MN1");
      default:         return(IntegerToString(tf));
   }
}
//+------------------------------------------------------------------+
