//+------------------------------------------------------------------+
//|                  Limitless_Dynamic_PL_Audit_Patch1_1.mq4         |
//|                  Limitless PH Dynamic P&L Auditing Engine        |
//|                  Patch 1.2 - Split price/fee flag alerts           |
//+------------------------------------------------------------------+
#property copyright "Limitless"
#property version   "2.11"
#property strict

// --- Input Parameters
input int             AtrPeriod              = 14;
input double          AtrMultiplier          = 0.15;
input ENUM_TIMEFRAMES AuditTimeframe         = PERIOD_CURRENT;
input double          MinimumCashTolerance   = 0.02;
input double          SystemToleranceFactor  = 1.00;
input bool            IncludeSwapCommission  = true;
input int             MaxRowsOnChart         = 30;
input bool            EnableTimerRefresh     = true;
input int             TimerRefreshSeconds    = 2;
input bool            ClearCommentOnRemove   = true;
input bool            UseAtrTolerance        = false;
input double          RateDriftPercent       = 0.20;
input double          MaxCommissionPerLot    = 8.0;
input double          MaxSwapPerLotPerDay    = 25.0;

// --- Conversion route cache (parallel arrays, keyed profitCurr+">"+accountCurr)
string g_convCacheKey[];
string g_convCacheSymbol[];
bool   g_convCacheInverse[];

//+------------------------------------------------------------------+
//| Expert initialization                                            |
//+------------------------------------------------------------------+
int OnInit()
{
   if(EnableTimerRefresh)
      EventSetTimer(MathMax(1, TimerRefreshSeconds));

   Comment(
      "=== LIMITLESS DYNAMIC P&L AUDITING ENGINE PATCH 1.2 ===\n",
      "Status: Initializing...\n",
      "Timer Mode: ", (EnableTimerRefresh ? "Active" : "Disabled"), "\n",
      "Waiting for audit cycle..."
   );

   Print("Limitless Dynamic P&L Auditing Engine Patch 1.2 initialized.");

   RunDynamicAuditEngine();

   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
//| Expert deinitialization                                          |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   EventKillTimer();

   if(ClearCommentOnRemove)
      Comment("");

   Print("Limitless Dynamic P&L Auditing Engine Patch 1.2 deinitialized. Reason: ", reason);
}

//+------------------------------------------------------------------+
//| Expert tick                                                      |
//+------------------------------------------------------------------+
void OnTick()
{
   static datetime lastEngineRun = 0;

   if(TimeCurrent() - lastEngineRun < 1)
      return;

   lastEngineRun = TimeCurrent();

   RunDynamicAuditEngine();
}

//+------------------------------------------------------------------+
//| Weekend / no-tick refresh                                        |
//+------------------------------------------------------------------+
void OnTimer()
{
   RunDynamicAuditEngine();
}

//+------------------------------------------------------------------+
//| Core Dynamic Auditing Engine                                     |
//+------------------------------------------------------------------+
void RunDynamicAuditEngine()
{
   ResetLastError();
   RefreshRates();

   double totalBrokerProfit       = 0.0;
   double totalTheoreticalProfit  = 0.0;
   double totalDynamicTolerance   = 0.0;
   double totalSwapCommission     = 0.0;

   int monitoredTrades   = 0;
   int skippedTrades     = 0;
   int flaggedTrades     = 0;
   int priceFlaggedTrades = 0;   // |tradeDelta| > tolerance or conversion failure
   int feeFlaggedTrades   = 0;   // swap/commission band breaches
   int displayedRows     = 0;

   string accountCurrency = AccountInfoString(ACCOUNT_CURRENCY);

   string report = "";
   report += "=== LIMITLESS DYNAMIC P&L AUDITING ENGINE PATCH 1.2 ===\n";
   report += "Status: Real-Time Backend P&L Verification Active\n";
   report += "Timer Refresh: " + (EnableTimerRefresh ? "ON" : "OFF") + "\n";
   report += "Last Update: " + TimeToString(TimeLocal(), TIME_DATE | TIME_SECONDS) + "\n";
   report += "Account Currency: " + accountCurrency + "\n\n";
   report += "TICKET | SYMBOL | BROKER P&L | CALC P&L | DELTA | SWAP | COMM | DYN THRESHOLD | ROUTE\n";
   report += "--------------------------------------------------------------------------------\n";

   for(int i = 0; i < OrdersTotal(); i++)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
      {
         skippedTrades++;
         continue;
      }

      int type = OrderType();

      if(type != OP_BUY && type != OP_SELL)
         continue;

      string sym       = OrderSymbol();
      double openPrice = OrderOpenPrice();
      double lots      = OrderLots();

      SymbolSelect(sym, true);

      double bid = MarketInfo(sym, MODE_BID);
      double ask = MarketInfo(sym, MODE_ASK);

      if(bid <= 0 || ask <= 0 || lots <= 0 || openPrice <= 0)
      {
         skippedTrades++;

         if(displayedRows < MaxRowsOnChart)
         {
            report += StringFormat(
               "#%d | %s | SKIPPED | Missing Bid/Ask/Lot/OpenPrice | Bid %.5f Ask %.5f\n",
               OrderTicket(),
               sym,
               bid,
               ask
            );
            displayedRows++;
         }

         continue;
      }

      double contractSize = MarketInfo(sym, MODE_LOTSIZE);

      if(contractSize <= 0)
         contractSize = 100000.0;

      double currentPrice = 0.0;
      double rawTheoreticalProfit = 0.0;

      if(type == OP_BUY)
      {
         currentPrice = bid;
         rawTheoreticalProfit = (currentPrice - openPrice) * lots * contractSize;
      }
      else if(type == OP_SELL)
      {
         currentPrice = ask;
         rawTheoreticalProfit = (openPrice - currentPrice) * lots * contractSize;
      }

      bool profitCurrencyResolved = true;
      string profitCurrency = GetProfitCurrencySafe(sym, profitCurrencyResolved);

      bool conversionOk = true;
      string conversionRoute = "";

      double conversionRate = GetDynamicConversionRate(
         profitCurrency,
         accountCurrency,
         rawTheoreticalProfit,
         conversionOk,
         conversionRoute
      );

      if(!profitCurrencyResolved)
      {
         conversionOk = false;
         conversionRoute = "ASSUMED 1:1";
      }

      double swapCommission = 0.0;

      if(IncludeSwapCommission)
         swapCommission = OrderSwap() + OrderCommission();

      // Broker figure includes swap+commission for aggregate display only.
      double brokerReportedProfit = OrderProfit() + swapCommission;

      // Delta compares pure price P&L against pure arithmetic — no swap/commission.
      double normalizedTheoreticalProfit = rawTheoreticalProfit * conversionRate;

      double tradeDelta = OrderProfit() - normalizedTheoreticalProfit;

      double orderSwap       = OrderSwap();
      double orderCommission = OrderCommission();

      double daysHeld = (double)(TimeCurrent() - OrderOpenTime()) / 86400.0;

      if(daysHeld < 1.0)
         daysHeld = 1.0;

      bool costFlagged = false;

      if(MathAbs(orderCommission) / lots > MaxCommissionPerLot)
         costFlagged = true;

      if(MathAbs(orderSwap) / (lots * daysHeld) > MaxSwapPerLotPerDay)
         costFlagged = true;

      bool atrUnavailable = false;
      double dynamicAllowedVariance = 0.0;

      if(UseAtrTolerance)
      {
         double symAtr = iATR(sym, AuditTimeframe, AtrPeriod, 0);

         if(symAtr <= 0)
         {
            atrUnavailable = true;
            dynamicAllowedVariance = MinimumCashTolerance;
         }
         else
         {
            dynamicAllowedVariance =
               symAtr * AtrMultiplier * lots * contractSize * MathAbs(conversionRate);

            if(dynamicAllowedVariance < MinimumCashTolerance)
               dynamicAllowedVariance = MinimumCashTolerance;
         }
      }
      else
      {
         dynamicAllowedVariance =
            MinimumCashTolerance +
            MathAbs(rawTheoreticalProfit * conversionRate) * RateDriftPercent / 100.0;
      }

      totalBrokerProfit      += brokerReportedProfit;
      totalTheoreticalProfit += normalizedTheoreticalProfit;
      totalDynamicTolerance  += dynamicAllowedVariance;
      totalSwapCommission    += swapCommission;

      monitoredTrades++;

      bool priceFlagged = false;

      if(!conversionOk)
         priceFlagged = true;

      if(!atrUnavailable && MathAbs(tradeDelta) > dynamicAllowedVariance)
         priceFlagged = true;

      bool tradeIsFlagged = (priceFlagged || costFlagged);

      if(priceFlagged)
         priceFlaggedTrades++;

      if(costFlagged)
         feeFlaggedTrades++;

      if(tradeIsFlagged)
         flaggedTrades++;

      if(displayedRows < MaxRowsOnChart)
      {
         string flagText = "";

         if(priceFlagged)
            flagText = " [FLAG]";

         if(!conversionOk)
            flagText = " [FX ROUTE MISSING]";

         if(costFlagged)
            flagText += " [FEE BAND]";

         if(atrUnavailable)
            flagText += " ATR N/A";

         report += StringFormat(
            "#%d | %s | %.2f | %.2f | D: %.2f | S: %.2f | C: %.2f | +/-$%.2f | %s%s\n",
            OrderTicket(),
            sym,
            brokerReportedProfit,
            normalizedTheoreticalProfit,
            tradeDelta,
            orderSwap,
            orderCommission,
            dynamicAllowedVariance,
            conversionRoute,
            flagText
         );

         displayedRows++;
      }
   }

   // Skew nets out swap+commission so it equals the sum of per-trade deltas.
   double netSystemicSkew = totalBrokerProfit - totalSwapCommission - totalTheoreticalProfit;

   double systemWideTolerance = totalDynamicTolerance * SystemToleranceFactor;

   if(systemWideTolerance < MinimumCashTolerance)
      systemWideTolerance = MinimumCashTolerance;

   report += "--------------------------------------------------------------------------------\n";
   report += StringFormat("Total Open Trades Monitored: %d\n", monitoredTrades);
   report += StringFormat("Skipped Trades: %d\n", skippedTrades);
   report += StringFormat("Flagged Deviations: %d\n", flaggedTrades);

   if(monitoredTrades + skippedTrades > MaxRowsOnChart)
      report += StringFormat("Displayed Rows Limited To: %d\n", MaxRowsOnChart);

   report += "\n";
   report += StringFormat("Aggregate Broker Reporting:   $%.2f\n", totalBrokerProfit);
   report += StringFormat("Aggregate Pure Arithmetic:    $%.2f\n", totalTheoreticalProfit);
   report += StringFormat("Aggregate Swap+Commission:    $%.2f\n", totalSwapCommission);
   report += StringFormat("NET SYSTEMIC DRIFT / SKEW:    $%.2f\n", netSystemicSkew);
   report += StringFormat("System-Wide Dynamic Tolerance:$%.2f\n", systemWideTolerance);
   report += "--------------------------------------------------------------------------------\n";

   if(monitoredTrades <= 0 && skippedTrades <= 0)
   {
      report += "STATUS: EA LOADED, BUT NO OPEN MARKET TRADES TO AUDIT\n";
      report += "NOTE: This can still display during weekends because timer refresh is enabled.\n";
   }
   else if(monitoredTrades <= 0 && skippedTrades > 0)
   {
      report += "STATUS: OPEN TRADES FOUND, BUT ALL WERE SKIPPED DUE TO MISSING PRICE DATA\n";
      report += "ACTION: Check Market Watch symbols, suffixes, and broker feed availability.\n";
   }
   else
   {
      bool priceIntegrityAlert = (MathAbs(netSystemicSkew) > systemWideTolerance || priceFlaggedTrades > 0);
      bool feeAlert            = (feeFlaggedTrades > 0);

      if(priceIntegrityAlert)
         report += StringFormat("CRITICAL ALERT: P&L INTEGRITY DEVIATION DETECTED (%d trades)\n", priceFlaggedTrades);

      if(feeAlert)
         report += StringFormat("WARNING: CARRY COST ACCUMULATION - %d POSITIONS EXCEED FEE BANDS\n", feeFlaggedTrades);

      if(!priceIntegrityAlert && !feeAlert)
         report += "SYSTEM INTEGRITY: VALIDATED\n";
   }

   if(StringLen(report) <= 0)
   {
      report = "=== LIMITLESS DYNAMIC P&L AUDITING ENGINE PATCH 1.2 ===\n";
      report += "Status: EA loaded, but no audit report generated.\n";
      report += "Check Experts tab for compile/runtime errors.\n";
   }

   Comment(report);
}

//+------------------------------------------------------------------+
//| Get symbol profit currency safely                                |
//+------------------------------------------------------------------+
string GetProfitCurrencySafe(string sym, bool &currencyResolved)
{
   currencyResolved = true;

   string profitCurrency = SymbolInfoString(sym, SYMBOL_CURRENCY_PROFIT);

   if(StringLen(profitCurrency) == 3)
      return profitCurrency;

   string core = ExtractFXCore(sym);

   if(StringLen(core) == 6)
      return StringSubstr(core, 3, 3);

   // Exotic/unknown symbol: fall back to account currency, but tell the
   // caller the 1:1 assumption is unverified.
   currencyResolved = false;

   return AccountInfoString(ACCOUNT_CURRENCY);
}

//+------------------------------------------------------------------+
//| Extract FX core from broker symbol with suffix/prefix            |
//| Example: AUDNZDZero -> AUDNZD                                    |
//+------------------------------------------------------------------+
string ExtractFXCore(string sym)
{
   string currencies[10] = {"USD", "EUR", "GBP", "JPY", "AUD", "NZD", "CAD", "CHF", "XAU", "XAG"};

   for(int i = 0; i < 10; i++)
   {
      for(int j = 0; j < 10; j++)
      {
         if(i == j)
            continue;

         string pair = currencies[i] + currencies[j];

         if(StringFind(sym, pair) >= 0)
            return pair;
      }
   }

   return "";
}

//+------------------------------------------------------------------+
//| Dynamic conversion rate with suffix-aware symbol discovery       |
//+------------------------------------------------------------------+
double GetDynamicConversionRate(
   string profitCurr,
   string accountCurr,
   double amountInProfitCurrency,
   bool &rateOk,
   string &route
)
{
   rateOk = true;
   route  = "";

   if(profitCurr == accountCurr)
   {
      route = "1:1";
      return 1.0;
   }

   string cacheKey = profitCurr + ">" + accountCurr;

   // Cache hit: only read MarketInfo, no symbol scan.
   int cacheIdx = FindConversionCacheIndex(cacheKey);

   if(cacheIdx >= 0)
   {
      string cachedSym = g_convCacheSymbol[cacheIdx];

      double cBid = MarketInfo(cachedSym, MODE_BID);
      double cAsk = MarketInfo(cachedSym, MODE_ASK);

      if(cBid > 0 && cAsk > 0)
      {
         if(!g_convCacheInverse[cacheIdx])
         {
            if(amountInProfitCurrency >= 0)
            {
               route = cachedSym + " BID";
               return cBid;
            }

            route = cachedSym + " ASK";
            return cAsk;
         }
         else
         {
            if(amountInProfitCurrency >= 0)
            {
               route = cachedSym + " 1/ASK";
               return 1.0 / cAsk;
            }

            route = cachedSym + " 1/BID";
            return 1.0 / cBid;
         }
      }

      // Cached symbol stale (no live price) -> fall through to full scan.
   }

   // Direct pair: profit currency / account currency
   // Example: NZDUSD converts NZD profit into USD account.
   string directPair = FindBrokerSymbol(profitCurr, accountCurr);

   if(StringLen(directPair) > 0)
   {
      double bid = MarketInfo(directPair, MODE_BID);
      double ask = MarketInfo(directPair, MODE_ASK);

      if(bid > 0 && ask > 0)
      {
         StoreConversionCache(cacheKey, directPair, false);

         if(amountInProfitCurrency >= 0)
         {
            route = directPair + " BID";
            return bid;
         }
         else
         {
            route = directPair + " ASK";
            return ask;
         }
      }
   }

   // Inverse pair: account currency / profit currency
   // Example: USDJPY converts JPY profit into USD account by inverse price.
   string inversePair = FindBrokerSymbol(accountCurr, profitCurr);

   if(StringLen(inversePair) > 0)
   {
      double bid = MarketInfo(inversePair, MODE_BID);
      double ask = MarketInfo(inversePair, MODE_ASK);

      if(bid > 0 && ask > 0)
      {
         StoreConversionCache(cacheKey, inversePair, true);

         if(amountInProfitCurrency >= 0)
         {
            route = inversePair + " 1/ASK";
            return 1.0 / ask;
         }
         else
         {
            route = inversePair + " 1/BID";
            return 1.0 / bid;
         }
      }
   }

   rateOk = false;
   route = "MISSING " + profitCurr + ">" + accountCurr;

   return 1.0;
}

//+------------------------------------------------------------------+
//| Conversion route cache helpers                                    |
//+------------------------------------------------------------------+
int FindConversionCacheIndex(string key)
{
   int total = ArraySize(g_convCacheKey);

   for(int i = 0; i < total; i++)
   {
      if(g_convCacheKey[i] == key)
         return i;
   }

   return -1;
}

void StoreConversionCache(string key, string sym, bool inverse)
{
   int idx = FindConversionCacheIndex(key);

   if(idx < 0)
   {
      idx = ArraySize(g_convCacheKey);
      ArrayResize(g_convCacheKey, idx + 1);
      ArrayResize(g_convCacheSymbol, idx + 1);
      ArrayResize(g_convCacheInverse, idx + 1);
   }

   g_convCacheKey[idx]     = key;
   g_convCacheSymbol[idx]  = sym;
   g_convCacheInverse[idx] = inverse;
}

//+------------------------------------------------------------------+
//| Find broker symbol even with suffix/prefix                       |
//| Example needed: NZDUSD                                           |
//| Broker has: NZDUSDZero                                           |
//+------------------------------------------------------------------+
string FindBrokerSymbol(string baseCurr, string quoteCurr)
{
   string exact = baseCurr + quoteCurr;

   if(IsUsableSymbol(exact))
      return exact;

   int totalSymbols = SymbolsTotal(false);

   // First pass: use broker metadata.
   for(int i = 0; i < totalSymbols; i++)
   {
      string sym = SymbolName(i, false);

      string base   = SymbolInfoString(sym, SYMBOL_CURRENCY_BASE);
      string profit = SymbolInfoString(sym, SYMBOL_CURRENCY_PROFIT);

      if(base == baseCurr && profit == quoteCurr)
      {
         if(IsUsableSymbol(sym))
            return sym;
      }
   }

   // Second pass: fallback by symbol-name detection.
   for(int j = 0; j < totalSymbols; j++)
   {
      string sym2 = SymbolName(j, false);

      if(StringFind(sym2, exact) >= 0)
      {
         if(IsUsableSymbol(sym2))
            return sym2;
      }
   }

   return "";
}

//+------------------------------------------------------------------+
//| Verify symbol exists and has live Bid/Ask                        |
//+------------------------------------------------------------------+
bool IsUsableSymbol(string sym)
{
   if(StringLen(sym) <= 0)
      return false;

   SymbolSelect(sym, true);

   double bid = MarketInfo(sym, MODE_BID);
   double ask = MarketInfo(sym, MODE_ASK);

   if(bid > 0 && ask > 0)
      return true;

   return false;
}
//+------------------------------------------------------------------+
