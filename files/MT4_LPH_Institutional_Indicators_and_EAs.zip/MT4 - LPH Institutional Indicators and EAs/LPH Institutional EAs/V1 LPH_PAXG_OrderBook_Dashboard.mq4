#property strict
#property indicator_chart_window

input int RefreshSeconds = 5;
input int PanelX = 20;
input int PanelY = 20;
input int PanelWidth = 320;
input int PanelHeight = 230;
input string FontName = "Arial";
input int TitleSize = 12;
input int TextSize = 11;

datetime lastReadTime = 0;

// Binance-like colors
color BG_COLOR       = C'18,22,28';
color BORDER_COLOR   = C'45,55,72';
color TITLE_COLOR    = clrWhite;
color LABEL_COLOR    = C'170,180,195';
color GREEN_COLOR    = C'14,203,129';
color RED_COLOR      = C'246,70,93';
color ACCENT_COLOR   = C'240,185,11';   // Binance yellow
color FOOTER_COLOR   = C'120,130,145';

string prefix = "PAXG_OB_";

//-----------------------------------
// Create or update text label
void SetLabel(string name, string text, int x, int y, color clr, int size, string font="Arial")
{
   string obj = prefix + name;

   if(ObjectFind(0, obj) < 0)
      ObjectCreate(0, obj, OBJ_LABEL, 0, 0, 0);

   ObjectSetInteger(0, obj, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, obj, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, obj, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, obj, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, obj, OBJPROP_FONTSIZE, size);
   ObjectSetString(0, obj, OBJPROP_FONT, font);
   ObjectSetString(0, obj, OBJPROP_TEXT, text);
}

//-----------------------------------
// Create or update panel background
void SetPanel()
{
   string obj = prefix + "BG";

   if(ObjectFind(0, obj) < 0)
      ObjectCreate(0, obj, OBJ_RECTANGLE_LABEL, 0, 0, 0);

   ObjectSetInteger(0, obj, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, obj, OBJPROP_XDISTANCE, PanelX);
   ObjectSetInteger(0, obj, OBJPROP_YDISTANCE, PanelY);
   ObjectSetInteger(0, obj, OBJPROP_XSIZE, PanelWidth);
   ObjectSetInteger(0, obj, OBJPROP_YSIZE, PanelHeight);
   ObjectSetInteger(0, obj, OBJPROP_BGCOLOR, BG_COLOR);
   ObjectSetInteger(0, obj, OBJPROP_BORDER_COLOR, BORDER_COLOR);
   ObjectSetInteger(0, obj, OBJPROP_STYLE, STYLE_SOLID);
   ObjectSetInteger(0, obj, OBJPROP_WIDTH, 1);
   ObjectSetInteger(0, obj, OBJPROP_BACK, false);
   ObjectSetInteger(0, obj, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, obj, OBJPROP_HIDDEN, true);
}

//-----------------------------------
void DrawDashboard(string bidVol, string askVol, string delta, string largestBid, string largestAsk, string bias)
{
   SetPanel();

   double dDelta = StrToDouble(delta);
   color deltaColor = (dDelta >= 0 ? GREEN_COLOR : RED_COLOR);
   string biasUpper = bias;
StringToUpper(biasUpper);

color biasColor = (StringFind(biasUpper, "BULL") >= 0 ? GREEN_COLOR : RED_COLOR);

   int x1 = PanelX + 12;
   int x2 = PanelX + 165;
   int y  = PanelY + 12;
   int gap = 24;

   // Title
   SetLabel("TITLE", "BINANCE PAXG ORDER BOOK", x1, y, TITLE_COLOR, TitleSize, "Arial Bold");
   y += gap;

   SetLabel("LINE1", "------------------------------", x1, y, BORDER_COLOR, TextSize, FontName);
   y += gap;

   // Bid Volume
   SetLabel("LBL_BID", "Bid Volume", x1, y, LABEL_COLOR, TextSize, FontName);
   SetLabel("VAL_BID", bidVol, x2, y, GREEN_COLOR, TextSize, "Arial Bold");
   y += gap;

   // Ask Volume
   SetLabel("LBL_ASK", "Ask Volume", x1, y, LABEL_COLOR, TextSize, FontName);
   SetLabel("VAL_ASK", askVol, x2, y, RED_COLOR, TextSize, "Arial Bold");
   y += gap;

   // Delta
   SetLabel("LBL_DELTA", "Delta", x1, y, LABEL_COLOR, TextSize, FontName);
   SetLabel("VAL_DELTA", delta, x2, y, deltaColor, TextSize, "Arial Bold");
   y += gap + 4;

   // Largest Bid
   SetLabel("LBL_LBID", "Largest Bid Wall", x1, y, LABEL_COLOR, TextSize, FontName);
   SetLabel("VAL_LBID", largestBid, x2, y, GREEN_COLOR, TextSize, "Arial Bold");
   y += gap;

   // Largest Ask
   SetLabel("LBL_LASK", "Largest Ask Wall", x1, y, LABEL_COLOR, TextSize, FontName);
   SetLabel("VAL_LASK", largestAsk, x2, y, RED_COLOR, TextSize, "Arial Bold");
   y += gap + 4;

   // Bias
   SetLabel("LBL_BIAS", "Liquidity Bias", x1, y, ACCENT_COLOR, TextSize, FontName);
   SetLabel("VAL_BIAS", bias, x2, y, biasColor, TextSize + 1, "Arial Bold");
   y += gap + 6;

   // Footer
   SetLabel("FOOT", "Updated every " + IntegerToString(RefreshSeconds) + " seconds", x1, y, FOOTER_COLOR, 9, FontName);
}

//-----------------------------------
void DrawError(string msg)
{
   SetPanel();
   SetLabel("TITLE", "BINANCE PAXG ORDER BOOK", PanelX + 12, PanelY + 12, TITLE_COLOR, TitleSize, "Arial Bold");
   SetLabel("ERR", msg, PanelX + 12, PanelY + 50, RED_COLOR, TextSize, "Arial Bold");
}

//-----------------------------------
void DeleteDashboard()
{
   string names[] =
   {
      "BG","TITLE","LINE1","LBL_BID","VAL_BID","LBL_ASK","VAL_ASK",
      "LBL_DELTA","VAL_DELTA","LBL_LBID","VAL_LBID","LBL_LASK","VAL_LASK",
      "LBL_BIAS","VAL_BIAS","FOOT","ERR"
   };

   for(int i=0; i<ArraySize(names); i++)
      ObjectDelete(0, prefix + names[i]);
}

//-----------------------------------
int OnInit()
{
   SetPanel();
   return(INIT_SUCCEEDED);
}

//-----------------------------------
void OnDeinit(const int reason)
{
   DeleteDashboard();
}

//-----------------------------------
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
   if(TimeCurrent() - lastReadTime < RefreshSeconds)
      return(rates_total);

   lastReadTime = TimeCurrent();

   int handle = FileOpen("paxg_data.csv", FILE_READ | FILE_CSV | FILE_COMMON, ',');

   if(handle == INVALID_HANDLE)
   {
      DrawError("Cannot find paxg_data.csv");
      return(rates_total);
   }

   string bidVol     = FileReadString(handle);
   string askVol     = FileReadString(handle);
   string delta      = FileReadString(handle);
   string largestBid = FileReadString(handle);
   string largestAsk = FileReadString(handle);
   string bias       = FileReadString(handle);

   FileClose(handle);

   DrawDashboard(bidVol, askVol, delta, largestBid, largestAsk, bias);

   return(rates_total);
}