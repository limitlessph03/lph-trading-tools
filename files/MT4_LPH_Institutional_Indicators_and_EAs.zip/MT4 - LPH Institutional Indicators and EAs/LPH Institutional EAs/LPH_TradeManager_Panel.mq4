//+------------------------------------------------------------------+
//|                                      LPH_TradeManagerPanel.mq4   |
//|            LimitlessPH - MT4 convenience panel (MT5 parity)      |
//|  Manages EXISTING positions only. Does not open trades.          |
//+------------------------------------------------------------------+
#property copyright "LimitlessPH"
#property version   "1.10"
#property strict

//--- Trade permission (kept for audit parity; panel cannot open trades)
extern bool   InpAllowTrading      = true;   // Master switch for modify/close actions
extern bool   InpCurrentSymbolOnly = true;   // Restrict actions to chart symbol
extern int    InpMagicFilter       = -1;     // -1 = all magics, else only this magic
extern int    InpSlippagePoints    = 30;     // Slippage for close ops (points)
extern double InpMaxSpreadPoints   = 50;     // Reject close/modify if spread wider (0=off)
extern int    InpDefaultSLPips     = 200;    // Default SL pips in input box
extern int    InpDefaultTPPips     = 400;    // Default TP pips in input box
extern double InpPartialPercent    = 50.0;   // Default partial close percent
extern double InpBEOffsetPips      = 0.0;    // BE offset: + = lock profit, - = tighter SL
extern bool   InpBECoverCosts      = true;   // Auto-add spread+commission to BE offset
extern int    InpPanelX            = 10;     // Panel X offset
extern int    InpPanelY            = 20;     // Panel Y offset
extern color  InpPanelBg           = C'25,25,25';
extern color  InpTextColor         = clrWhite;

#define PFX "LPHTMP_"

//--- runtime state
double g_pip       = 0.0;   // pip size in price terms
int    g_pipDigits = 0;

//+------------------------------------------------------------------+
//| Resolve pip size (handles 3/5-digit brokers and metals)          |
//+------------------------------------------------------------------+
void ResolvePipSize()
{
   int    dg  = (int)MarketInfo(Symbol(), MODE_DIGITS);
   double pt  = MarketInfo(Symbol(), MODE_POINT);

   if(pt <= 0.0) pt = Point;
   if(dg <= 0)   dg = Digits;

   // 3 and 5 digit quotes: 1 pip = 10 points. Otherwise 1 pip = 1 point.
   if(dg == 3 || dg == 5) g_pip = pt * 10.0;
   else                   g_pip = pt;

   g_pipDigits = dg;
}

//+------------------------------------------------------------------+
//| Spread guard                                                     |
//+------------------------------------------------------------------+
bool SpreadOK(string sym)
{
   if(InpMaxSpreadPoints <= 0.0) return(true);
   double pt = MarketInfo(sym, MODE_POINT);
   if(pt <= 0.0) return(true);
   double spr = (MarketInfo(sym, MODE_ASK) - MarketInfo(sym, MODE_BID)) / pt;
   if(spr > InpMaxSpreadPoints)
   {
      Print("[LPH Panel] Blocked: spread ", DoubleToString(spr,1),
            " pts > max ", DoubleToString(InpMaxSpreadPoints,1), " on ", sym);
      return(false);
   }
   return(true);
}

//+------------------------------------------------------------------+
//| Order passes filters?                                            |
//+------------------------------------------------------------------+
bool OrderInScope()
{
   if(InpCurrentSymbolOnly && OrderSymbol() != Symbol()) return(false);
   if(InpMagicFilter >= 0 && OrderMagicNumber() != InpMagicFilter) return(false);
   return(true);
}

//+------------------------------------------------------------------+
//| UI helpers                                                       |
//+------------------------------------------------------------------+
void MakeLabel(string name, string text, int x, int y, color clr, int size=8)
{
   string n = PFX + name;
   if(ObjectFind(0, n) < 0) ObjectCreate(0, n, OBJ_LABEL, 0, 0, 0);
   ObjectSetInteger(0, n, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, n, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, n, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, n, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, n, OBJPROP_FONTSIZE, size);
   ObjectSetInteger(0, n, OBJPROP_SELECTABLE, false);
   ObjectSetString (0, n, OBJPROP_TEXT, text);
   ObjectSetString (0, n, OBJPROP_FONT, "Tahoma");
}

void MakeButton(string name, string text, int x, int y, int w, int h, color bg)
{
   string n = PFX + name;
   if(ObjectFind(0, n) < 0) ObjectCreate(0, n, OBJ_BUTTON, 0, 0, 0);
   ObjectSetInteger(0, n, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, n, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, n, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, n, OBJPROP_XSIZE, w);
   ObjectSetInteger(0, n, OBJPROP_YSIZE, h);
   ObjectSetInteger(0, n, OBJPROP_BGCOLOR, bg);
   ObjectSetInteger(0, n, OBJPROP_COLOR, clrWhite);
   ObjectSetInteger(0, n, OBJPROP_FONTSIZE, 8);
   ObjectSetInteger(0, n, OBJPROP_BORDER_COLOR, clrDimGray);
   ObjectSetInteger(0, n, OBJPROP_STATE, false);
   ObjectSetString (0, n, OBJPROP_TEXT, text);
   ObjectSetString (0, n, OBJPROP_FONT, "Tahoma");
}

void MakeEdit(string name, string text, int x, int y, int w, int h)
{
   string n = PFX + name;
   if(ObjectFind(0, n) < 0) ObjectCreate(0, n, OBJ_EDIT, 0, 0, 0);
   ObjectSetInteger(0, n, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, n, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, n, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, n, OBJPROP_XSIZE, w);
   ObjectSetInteger(0, n, OBJPROP_YSIZE, h);
   ObjectSetInteger(0, n, OBJPROP_BGCOLOR, clrBlack);
   ObjectSetInteger(0, n, OBJPROP_COLOR, clrWhite);
   ObjectSetInteger(0, n, OBJPROP_ALIGN, ALIGN_CENTER);
   ObjectSetInteger(0, n, OBJPROP_FONTSIZE, 8);
   ObjectSetString (0, n, OBJPROP_TEXT, text);
}

void MakeRect(string name, int x, int y, int w, int h, color bg)
{
   string n = PFX + name;
   if(ObjectFind(0, n) < 0) ObjectCreate(0, n, OBJ_RECTANGLE_LABEL, 0, 0, 0);
   ObjectSetInteger(0, n, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, n, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, n, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, n, OBJPROP_XSIZE, w);
   ObjectSetInteger(0, n, OBJPROP_YSIZE, h);
   ObjectSetInteger(0, n, OBJPROP_BGCOLOR, bg);
   ObjectSetInteger(0, n, OBJPROP_BORDER_TYPE, BORDER_FLAT);
   ObjectSetInteger(0, n, OBJPROP_COLOR, clrDimGray);
   ObjectSetInteger(0, n, OBJPROP_BACK, false);
   ObjectSetInteger(0, n, OBJPROP_SELECTABLE, false);
}

string EditVal(string name)
{
   return(ObjectGetString(0, PFX + name, OBJPROP_TEXT));
}

void ResetButton(string name)
{
   ObjectSetInteger(0, PFX + name, OBJPROP_STATE, false);
}

//+------------------------------------------------------------------+
//| Build panel                                                      |
//+------------------------------------------------------------------+
void BuildPanel()
{
   int x = InpPanelX, y = InpPanelY;
   MakeRect("bg", x-5, y-5, 250, 266, InpPanelBg);

   MakeLabel("title", "LPH TRADE MANAGER", x, y, clrGold, 9);
   y += 20;
   MakeLabel("pipinfo", "1 pip = " + DoubleToString(g_pip, Digits) +
             "   (" + Symbol() + ")", x, y, clrSilver, 7);

   //--- SL/TP section
   y += 18;
   MakeLabel("lblsl", "SL (pips)", x, y+3, InpTextColor, 8);
   MakeEdit ("edsl", IntegerToString(InpDefaultSLPips), x+60, y, 55, 18);
   MakeLabel("lbltp", "TP (pips)", x+125, y+3, InpTextColor, 8);
   MakeEdit ("edtp", IntegerToString(InpDefaultTPPips), x+185, y, 55, 18);

   y += 24;
   MakeButton("btnsltp", "Apply SL/TP", x, y, 118, 22, C'20,80,140');
   MakeButton("btnclrsltp", "Clear SL/TP", x+122, y, 118, 22, C'70,70,70');

   //--- Partial close section
   y += 30;
   MakeLabel("lblpc", "Partial %", x, y+3, InpTextColor, 8);
   MakeEdit ("edpc", DoubleToString(InpPartialPercent,1), x+60, y, 55, 18);
   MakeButton("btnpc", "Partial Close", x+122, y-2, 118, 22, C'150,110,20');

   //--- Breakeven section
   y += 30;
   MakeLabel("lblbe", "BE offset", x, y+3, InpTextColor, 8);
   MakeEdit ("edbe", DoubleToString(InpBEOffsetPips,1), x+60, y, 55, 18);
   MakeButton("btnbe", "Move to BE", x+122, y-2, 118, 22, C'30,110,110');

   //--- Close section
   y += 30;
   MakeButton("btnclosesym", "Close Symbol", x, y, 118, 22, C'120,40,40');
   MakeButton("btncloseall", "Close ALL", x+122, y, 118, 22, C'160,30,30');

   y += 26;
   MakeButton("btnprofit", "Close Profitable", x, y, 118, 22, C'30,110,50');
   MakeButton("btnloss", "Close Losing", x+122, y, 118, 22, C'110,60,30');

   y += 26;
   MakeButton("btnpend", "Delete Pendings", x, y, 240, 22, C'70,70,90');

   y += 26;
   MakeLabel("status", "Ready.", x, y, clrSilver, 8);

   ChartRedraw();
}

//+------------------------------------------------------------------+
void SetStatus(string s, color c = clrSilver)
{
   ObjectSetString (0, PFX+"status", OBJPROP_TEXT, s);
   ObjectSetInteger(0, PFX+"status", OBJPROP_COLOR, c);
   ChartRedraw();
}

//+------------------------------------------------------------------+
int OnInit()
{
   ResolvePipSize();
   BuildPanel();
   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason)
{
   ObjectsDeleteAll(0, PFX);
   ChartRedraw();
}

void OnTick()
{
   // Panel is event-driven; nothing required per tick.
}

//+------------------------------------------------------------------+
//| Apply SL/TP in pips to all in-scope market orders                |
//+------------------------------------------------------------------+
void ApplySLTP(bool clearInstead)
{
   double slPips = clearInstead ? 0 : StringToDouble(EditVal("edsl"));
   double tpPips = clearInstead ? 0 : StringToDouble(EditVal("edtp"));

   if(!clearInstead && slPips <= 0 && tpPips <= 0)
   { SetStatus("Nothing to apply (SL and TP both 0).", clrOrange); return; }

   int done = 0, failed = 0, skipped = 0;

   for(int i = OrdersTotal()-1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      if(OrderType() != OP_BUY && OrderType() != OP_SELL) continue;
      if(!OrderInScope()) continue;

      string sym = OrderSymbol();
      if(!SpreadOK(sym)) { skipped++; continue; }

      int    dg   = (int)MarketInfo(sym, MODE_DIGITS);
      double pt   = MarketInfo(sym, MODE_POINT);
      double pip  = (dg == 3 || dg == 5) ? pt*10.0 : pt;
      double stopLvl = MarketInfo(sym, MODE_STOPLEVEL) * pt;
      double bid  = MarketInfo(sym, MODE_BID);
      double ask  = MarketInfo(sym, MODE_ASK);
      double open = OrderOpenPrice();

      double newSL = 0.0, newTP = 0.0;

      if(!clearInstead)
      {
         if(OrderType() == OP_BUY)
         {
            if(slPips > 0) newSL = NormalizeDouble(open - slPips*pip, dg);
            if(tpPips > 0) newTP = NormalizeDouble(open + tpPips*pip, dg);
            // Broker stop-level validation
            if(newSL > 0 && newSL > bid - stopLvl)
            { Print("[LPH Panel] SL too close for #", OrderTicket()); failed++; continue; }
            if(newTP > 0 && newTP < ask + stopLvl)
            { Print("[LPH Panel] TP too close for #", OrderTicket()); failed++; continue; }
         }
         else // OP_SELL
         {
            if(slPips > 0) newSL = NormalizeDouble(open + slPips*pip, dg);
            if(tpPips > 0) newTP = NormalizeDouble(open - tpPips*pip, dg);
            if(newSL > 0 && newSL < ask + stopLvl)
            { Print("[LPH Panel] SL too close for #", OrderTicket()); failed++; continue; }
            if(newTP > 0 && newTP > bid - stopLvl)
            { Print("[LPH Panel] TP too close for #", OrderTicket()); failed++; continue; }
         }

         // Preserve existing level if that side left blank
         if(slPips <= 0) newSL = OrderStopLoss();
         if(tpPips <= 0) newTP = OrderTakeProfit();
      }

      // Skip if no actual change
      if(MathAbs(newSL - OrderStopLoss())   < pt*0.5 &&
         MathAbs(newTP - OrderTakeProfit()) < pt*0.5)
      { skipped++; continue; }

      if(OrderModify(OrderTicket(), open, newSL, newTP, 0, clrNONE)) done++;
      else { Print("[LPH Panel] OrderModify failed #", OrderTicket(),
                   " err=", GetLastError()); failed++; }
   }

   SetStatus(StringFormat("SL/TP: %d ok, %d fail, %d skip", done, failed, skipped),
             failed > 0 ? clrOrange : clrLime);
}

//+------------------------------------------------------------------+
//| Move SL to breakeven +/- offset (direction-aware)                |
//| offsetPips: positive = lock profit, negative = leave risk on     |
//+------------------------------------------------------------------+
void ApplyBreakeven()
{
   double offPips = StringToDouble(EditVal("edbe"));
   int done = 0, failed = 0, skipped = 0;

   for(int i = OrdersTotal()-1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      if(OrderType() != OP_BUY && OrderType() != OP_SELL) continue;
      if(!OrderInScope()) continue;

      string sym = OrderSymbol();
      if(!SpreadOK(sym)) { skipped++; continue; }

      int    dg  = (int)MarketInfo(sym, MODE_DIGITS);
      double pt  = MarketInfo(sym, MODE_POINT);
      double pip = (dg == 3 || dg == 5) ? pt*10.0 : pt;
      double stopLvl = MarketInfo(sym, MODE_STOPLEVEL) * pt;
      double bid = MarketInfo(sym, MODE_BID);
      double ask = MarketInfo(sym, MODE_ASK);
      double open = OrderOpenPrice();

      //--- Cost cushion so BE is a real BE, not a small loss
      double cushionPips = 0.0;
      if(InpBECoverCosts)
      {
         double sprPips = ((ask - bid) / pip);

         // Commission + swap expressed in pips for THIS ticket
         double tickVal = MarketInfo(sym, MODE_TICKVALUE);
         double tickSz  = MarketInfo(sym, MODE_TICKSIZE);
         if(tickSz <= 0) tickSz = pt;
         double pipValue = tickVal * (pip / tickSz) * OrderLots();  // $ per pip

         double costMoney = MathAbs(OrderCommission()) + MathAbs(OrderSwap());
         double costPips  = (pipValue > 0.0) ? (costMoney / pipValue) : 0.0;

         cushionPips = sprPips + costPips;
      }

      double totalOffset = offPips + cushionPips;
      double newSL = 0.0;

      if(OrderType() == OP_BUY)
      {
         newSL = NormalizeDouble(open + totalOffset*pip, dg);

         if(newSL > bid - stopLvl)
         {
            Print("[LPH BE] #", OrderTicket(), " not enough room. Need bid >= ",
                  DoubleToString(newSL + stopLvl, dg), ", have ", DoubleToString(bid, dg));
            skipped++; continue;
         }
         // Never loosen an existing protective stop
         if(OrderStopLoss() > 0 && newSL <= OrderStopLoss())
         { skipped++; continue; }
      }
      else // OP_SELL
      {
         newSL = NormalizeDouble(open - totalOffset*pip, dg);

         if(newSL < ask + stopLvl)
         {
            Print("[LPH BE] #", OrderTicket(), " not enough room. Need ask <= ",
                  DoubleToString(newSL - stopLvl, dg), ", have ", DoubleToString(ask, dg));
            skipped++; continue;
         }
         if(OrderStopLoss() > 0 && newSL >= OrderStopLoss())
         { skipped++; continue; }
      }

      if(MathAbs(newSL - OrderStopLoss()) < pt*0.5) { skipped++; continue; }

      if(OrderModify(OrderTicket(), open, newSL, OrderTakeProfit(), 0, clrNONE))
      {
         done++;
         Print("[LPH BE] #", OrderTicket(), " SL -> ", DoubleToString(newSL, dg),
               " (offset ", DoubleToString(offPips,1),
               " + cushion ", DoubleToString(cushionPips,1), " pips)");
      }
      else
      { Print("[LPH BE] OrderModify failed #", OrderTicket(),
              " err=", GetLastError()); failed++; }
   }

   SetStatus(StringFormat("BE: %d ok, %d fail, %d skip", done, failed, skipped),
             failed > 0 ? clrOrange : clrLime);
}

//+------------------------------------------------------------------+
//| Partial close by percentage                                      |
//+------------------------------------------------------------------+
void DoPartialClose()
{
   double pct = StringToDouble(EditVal("edpc"));
   if(pct <= 0.0 || pct >= 100.0)
   { SetStatus("Partial % must be between 0 and 100.", clrOrange); return; }

   int done = 0, failed = 0, skipped = 0;

   for(int i = OrdersTotal()-1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      if(OrderType() != OP_BUY && OrderType() != OP_SELL) continue;
      if(!OrderInScope()) continue;

      string sym = OrderSymbol();
      if(!SpreadOK(sym)) { skipped++; continue; }

      double lotStep = MarketInfo(sym, MODE_LOTSTEP);
      double lotMin  = MarketInfo(sym, MODE_MINLOT);
      if(lotStep <= 0) lotStep = 0.01;
      if(lotMin  <= 0) lotMin  = 0.01;

      double closeLots = OrderLots() * pct / 100.0;
      // Round DOWN to lot step so remainder stays valid
      closeLots = MathFloor(closeLots / lotStep) * lotStep;
      closeLots = NormalizeDouble(closeLots, 2);

      double remainder = NormalizeDouble(OrderLots() - closeLots, 2);

      if(closeLots < lotMin)
      { Print("[LPH Panel] Partial too small for #", OrderTicket(),
              " (", DoubleToString(closeLots,2), " < minlot)"); skipped++; continue; }

      if(remainder > 0.0 && remainder < lotMin)
      { Print("[LPH Panel] Remainder below minlot for #", OrderTicket(),
              " - skipped to avoid invalid volume"); skipped++; continue; }

      double px = (OrderType() == OP_BUY) ? MarketInfo(sym, MODE_BID)
                                          : MarketInfo(sym, MODE_ASK);
      px = NormalizeDouble(px, (int)MarketInfo(sym, MODE_DIGITS));

      if(OrderClose(OrderTicket(), closeLots, px, InpSlippagePoints, clrNONE)) done++;
      else { Print("[LPH Panel] Partial close failed #", OrderTicket(),
                   " err=", GetLastError()); failed++; }
   }

   SetStatus(StringFormat("Partial: %d ok, %d fail, %d skip", done, failed, skipped),
             failed > 0 ? clrOrange : clrLime);
}

//+------------------------------------------------------------------+
//| Bulk close. mode: 0=all, 1=profitable, 2=losing                  |
//+------------------------------------------------------------------+
void DoBulkClose(int mode)
{
   int done = 0, failed = 0, skipped = 0;

   for(int pass = 0; pass < 3; pass++)   // retry passes for requotes
   {
      for(int i = OrdersTotal()-1; i >= 0; i--)
      {
         if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
         if(OrderType() != OP_BUY && OrderType() != OP_SELL) continue;
         if(!OrderInScope()) continue;

         double net = OrderProfit() + OrderSwap() + OrderCommission();
         if(mode == 1 && net <= 0.0) continue;
         if(mode == 2 && net >= 0.0) continue;

         string sym = OrderSymbol();
         if(!SpreadOK(sym)) { if(pass==0) skipped++; continue; }

         RefreshRates();
         double px = (OrderType() == OP_BUY) ? MarketInfo(sym, MODE_BID)
                                             : MarketInfo(sym, MODE_ASK);
         px = NormalizeDouble(px, (int)MarketInfo(sym, MODE_DIGITS));

         if(OrderClose(OrderTicket(), OrderLots(), px, InpSlippagePoints, clrNONE))
            done++;
         else
         {
            int err = GetLastError();
            Print("[LPH Panel] Close failed #", OrderTicket(), " err=", err);
            if(pass == 2) failed++;
            Sleep(200);
         }
      }
   }

   SetStatus(StringFormat("Close: %d ok, %d fail, %d skip", done, failed, skipped),
             failed > 0 ? clrOrange : clrLime);
}

//+------------------------------------------------------------------+
//| Delete pending orders                                            |
//+------------------------------------------------------------------+
void DeletePendings()
{
   int done = 0, failed = 0;
   for(int i = OrdersTotal()-1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      if(OrderType() == OP_BUY || OrderType() == OP_SELL) continue;
      if(!OrderInScope()) continue;

      if(OrderDelete(OrderTicket(), clrNONE)) done++;
      else { Print("[LPH Panel] OrderDelete failed #", OrderTicket(),
                   " err=", GetLastError()); failed++; }
   }
   SetStatus(StringFormat("Pendings: %d deleted, %d failed", done, failed),
             failed > 0 ? clrOrange : clrLime);
}

//+------------------------------------------------------------------+
//| Chart events                                                     |
//+------------------------------------------------------------------+
void OnChartEvent(const int id, const long &lparam, const double &dparam,
                  const string &sparam)
{
   if(id != CHARTEVENT_OBJECT_CLICK) return;
   if(StringSubstr(sparam, 0, StringLen(PFX)) != PFX) return;

   string btn = StringSubstr(sparam, StringLen(PFX));
   ResetButton(btn);

   if(!InpAllowTrading)
   { SetStatus("BLOCKED: InpAllowTrading = false.", clrRed); return; }

   if(!IsTradeAllowed())
   { SetStatus("BLOCKED: Terminal AutoTrading is off.", clrRed); return; }

   if(IsTradeContextBusy())
   { SetStatus("Trade context busy - try again.", clrOrange); return; }

   if(btn == "btnsltp")          ApplySLTP(false);
   else if(btn == "btnclrsltp")  ApplySLTP(true);
   else if(btn == "btnbe")       ApplyBreakeven();
   else if(btn == "btnpc")       DoPartialClose();
   else if(btn == "btnclosesym") { bool s=InpCurrentSymbolOnly; InpCurrentSymbolOnly=true;
                                   DoBulkClose(0); InpCurrentSymbolOnly=s; }
   else if(btn == "btncloseall") { bool s2=InpCurrentSymbolOnly; InpCurrentSymbolOnly=false;
                                   DoBulkClose(0); InpCurrentSymbolOnly=s2; }
   else if(btn == "btnprofit")   DoBulkClose(1);
   else if(btn == "btnloss")     DoBulkClose(2);
   else if(btn == "btnpend")     DeletePendings();

   ChartRedraw();
}
//+------------------------------------------------------------------+