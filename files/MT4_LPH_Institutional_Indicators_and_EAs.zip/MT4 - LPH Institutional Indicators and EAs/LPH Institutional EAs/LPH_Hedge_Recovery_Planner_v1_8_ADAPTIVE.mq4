//+------------------------------------------------------------------+
//| LPH_Hedge_Recovery_Planner_v1_8_ADAPTIVE.mq4                      |
//| One-symbol hedge/recovery planner for Limitless PH / Coach T      |
//| v1.8: replaces the fixed "reduce worst 50%" fallback with a       |
//| severity-scaled % and adds account-aware deposit/survival math    |
//| (margin needed to hedge, deposit shortfall, ATR/money buffer to   |
//| stop-out). Reviewed by Claude, authored as a patch on Coach T's   |
//| v1.7.1 base. Recommend an independent Codex/ChatGPT pass before   |
//| trusting this on a live account -- see patch notes at bottom.     |
//+------------------------------------------------------------------+
#property strict
#property version   "1.80"

// Dashboard EA only. It DOES NOT open, close, or manage trades.
// Attach to ONE chart symbol. It scans open trades for that symbol only.

input string Section_Scan               = "----- SCAN SETTINGS -----";
input bool   UseOnlyLosingTrades        = true;     // true = average losing trades only
input bool   CloseAllUsesAllSymbolTrades = true;     // true = close-all projection includes winning/open trades too
input int    MagicNumberFilter          = -1;       // -1 = all magic numbers
input bool   IncludeManualTrades        = true;     // include magic number 0
input int    RefreshSeconds             = 5;

input string Section_Recovery           = "----- RECOVERY / HEDGE SETTINGS -----";
input double ProfitBufferMoney          = 5.0;      // target close-all profit after recovery
input bool   UseBasketBasedTPSL       = true;     // true = TP/SL based on close-all basket P/L, not pure ATR
input double HedgeSL_CloseAllLossMoney = -100.0;   // close-all loss target if hedge fails at SL
input double MaxBasketTargetATR       = 4.00;     // flag target as too far if BE/profit target is beyond this ATR distance
input int    ATRTimeframe               = PERIOD_H1;
input int    ATRPeriod                  = 14;
input double ConservativeTargetATR      = 0.50;
input double BalancedTargetATR          = 1.00;
input double ExtendedTargetATR          = 1.50;
input double HedgeSL_ATR_Multiple       = 0.75;
input double WorstGuardSL_ATR_Multiple  = 0.50;
input double ReduceFirstPercent         = 50.0;    // DEPRECATED v1.8: no longer used for the fallback message. Kept only so existing saved input sets don't break. See Section_DynamicReduce below.
input double MaxHedgeToNetMultiplier    = 1.50;

input string Section_Lots               = "----- LOT CONTROL -----";
input double MinManualHedgeLot          = 0.01;
input double MaxRecommendedHedgeLot     = 5.00;
input bool   RoundLotUp                 = true;

input string Section_Display            = "----- DISPLAY -----";
input bool   ShowDashboard              = true;
input bool   DrawRecoveryLines          = true;
input bool   AlertsEnabled              = false;
input double AlertLossMoney             = -100.0;
input int    PanelX                     = 10;
input int    PanelY                     = 20;
input int    PanelWidth                 = 860;     // widened in v1.8 for the new deposit/survive lines
input int    PanelHeight                = 520;      // heightened in v1.8 for the new deposit/survive lines
input string FontName                   = "Consolas";
input int    TitleSize                  = 13;
input int    TextSize                   = 10;

input string Section_Account            = "----- ACCOUNT / DEPOSIT GUARD (new in v1.8) -----";
input double MarginSafetyBufferPercent  = 20.0;     // extra cushion on top of bare hedge margin requirement
input double StopOutLevelPercent        = 20.0;     // YOUR broker's stop-out level %. Confirm with ACY Securities, do not assume.
input double SurviveTargetATR           = 2.00;     // how many extra ATR of adverse move you want to be able to survive

input string Section_DynamicReduce      = "----- DYNAMIC REDUCE SCALING (new in v1.8, replaces fixed %) -----";
input double MinReducePercent           = 15.0;     // smallest reduction ever suggested
input double MaxReducePercent           = 90.0;     // largest reduction ever suggested
input double ReduceOverCapWeight        = 20.0;     // % added per full multiple the hedge lot is over the safe cap
input double ReduceLossToEquityWeight   = 2.0;      // % added per 1% of equity lost on this basket

input string Section_Safety             = "----- EXECUTION SAFETY -----";
input bool   AllowAutoTrading           = false;    // intentionally unused; no execution in this EA

color BG_COLOR       = C'11,14,20';
color BORDER_COLOR   = C'75,85,105';
color TITLE_COLOR    = clrGold;
color TEXT_COLOR     = C'225,230,240';
color MUTED_COLOR    = C'160,170,185';
color GREEN_COLOR    = C'20,220,120';
color RED_COLOR      = C'255,70,80';
color CYAN_COLOR     = C'0,220,255';
color ORANGE_COLOR   = C'255,170,40';
color WarningColor   = C'255,70,80';
color BLUE_COLOR     = C'80,150,255';

string prefix = "LPH_HEDGE_RECOVERY_";
datetime lastAlertTime = 0;

struct BasketStats
{
   int totalTrades;
   int selectedTrades;
   int losingTrades;
   int buyCount;
   int sellCount;
   double buyLots;
   double sellLots;
   double netLots;
   double selectedLots;
   double pnlAll;
   double pnlSelected;
   double swapCommSelected;
   double avgEntryAllSelected;
   double avgBuyEntry;
   double avgSellEntry;
   double signedLotSum;
   double signedEntrySum;
   int worstTicket;
   int worstType;
   double worstLots;
   double worstEntry;
   double worstCurrent;
   double worstPL;
};

struct Plan
{
   string name;
   int hedgeType;
   double targetPrice;
   double requiredLots;       // allowed/capped lot used in projection
   double rawRequiredLots;    // mathematical lot needed to reach ProfitBufferMoney
   bool cappedByMaxLot;       // true when MaxRecommendedHedgeLot prevents full recovery
   bool reachesProfitTarget;  // true when TP close-all reaches ProfitBufferMoney
   double hedgeEntry;
   double hedgeSL;
   double projectedExisting;
   double projectedHedge;
   double projectedTotal;      // close-all estimate at hedge TP
   double projectedExistingSL;
   double projectedHedgeSL;
   double projectedTotalSL;    // close-all estimate at hedge SL
   double targetATRDistance;   // TP distance from hedge entry in ATR units
   double slATRDistance;       // SL distance from hedge entry in ATR units
   bool targetTooFar;          // true when basket-based target is too far to call clean recovery
   bool valid;
   string note;
   double marginNeeded;        // margin required to open requiredLots of hedge, plus safety buffer
   double depositShortfall;    // extra deposit needed if current free margin can't cover marginNeeded
};

string SideText(int type)
{
   if(type == OP_BUY)  return "BUY";
   if(type == OP_SELL) return "SELL";
   return "N/A";
}

double PointValue(string sym)
{
   double p = MarketInfo(sym, MODE_POINT);
   if(p <= 0.0) p = Point;
   return p;
}

double TickSizeValue(string sym)
{
   double ts = MarketInfo(sym, MODE_TICKSIZE);
   if(ts <= 0.0) ts = PointValue(sym);
   return ts;
}

double TickValuePerLot(string sym)
{
   double tv = MarketInfo(sym, MODE_TICKVALUE);
   if(tv <= 0.0) tv = 1.0;
   return tv;
}

double MoneyPerPriceUnitPerLot(string sym)
{
   double ts = TickSizeValue(sym);
   double tv = TickValuePerLot(sym);
   if(ts <= 0.0) ts = PointValue(sym);
   return tv / ts;
}

int PriceDigits(string sym)
{
   int d = (int)MarketInfo(sym, MODE_DIGITS);
   if(d < 0) d = Digits;
   return d;
}

string PriceStr(string sym, double price)
{
   return DoubleToString(price, PriceDigits(sym));
}

string MoneyStr(double v)
{
   string sign = "";
   if(v > 0.0) sign = "+";
   return sign + DoubleToString(v, 2);
}

string LotStr(double v)
{
   return DoubleToString(v, 2);
}

double NormalizeLot(string sym, double lots)
{
   double minLot = MarketInfo(sym, MODE_MINLOT);
   double maxLot = MarketInfo(sym, MODE_MAXLOT);
   double step   = MarketInfo(sym, MODE_LOTSTEP);

   if(minLot <= 0.0) minLot = MinManualHedgeLot;
   if(step <= 0.0) step = 0.01;
   if(maxLot <= 0.0) maxLot = MaxRecommendedHedgeLot;

   lots = MathMax(lots, MinManualHedgeLot);
   lots = MathMax(lots, minLot);
   lots = MathMin(lots, maxLot);
   lots = MathMin(lots, MaxRecommendedHedgeLot);

   double steps = lots / step;
   if(RoundLotUp)
      lots = MathCeil(steps) * step;
   else
      lots = MathFloor(steps) * step;

   lots = NormalizeDouble(lots, 2);
   if(lots < minLot) lots = minLot;
   return lots;
}

bool ShouldIncludeOrder(string sym)
{
   if(OrderSymbol() != sym) return false;
   if(OrderType() != OP_BUY && OrderType() != OP_SELL) return false;

   int magic = OrderMagicNumber();
   if(!IncludeManualTrades && magic == 0) return false;
   if(MagicNumberFilter >= 0 && magic != MagicNumberFilter) return false;

   return true;
}

double CurrentPriceForType(string sym, int type)
{
   RefreshRates();
   if(type == OP_BUY)  return MarketInfo(sym, MODE_BID);
   if(type == OP_SELL) return MarketInfo(sym, MODE_ASK);
   return MarketInfo(sym, MODE_BID);
}

double EntryPriceForNewOrder(string sym, int type)
{
   RefreshRates();
   if(type == OP_BUY)  return MarketInfo(sym, MODE_ASK);
   if(type == OP_SELL) return MarketInfo(sym, MODE_BID);
   return MarketInfo(sym, MODE_BID);
}

void DeleteByPrefix(string pfx)
{
   int total = ObjectsTotal();
   for(int i = total - 1; i >= 0; i--)
   {
      string name = ObjectName(i);
      if(StringFind(name, pfx) == 0)
         ObjectDelete(name);
   }
}

void SetRect(string name, int x, int y, int w, int h, color bg, color border)
{
   string obj = prefix + name;
   if(ObjectFind(0, obj) < 0)
      ObjectCreate(0, obj, OBJ_RECTANGLE_LABEL, 0, 0, 0);

   ObjectSetInteger(0, obj, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, obj, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, obj, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, obj, OBJPROP_XSIZE, w);
   ObjectSetInteger(0, obj, OBJPROP_YSIZE, h);
   ObjectSetInteger(0, obj, OBJPROP_BGCOLOR, bg);
   ObjectSetInteger(0, obj, OBJPROP_BORDER_COLOR, border);
   ObjectSetInteger(0, obj, OBJPROP_BACK, false);
   ObjectSetInteger(0, obj, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, obj, OBJPROP_HIDDEN, true);
}

void SetLabel(string name, string text, int x, int y, color clr, int size, string font="")
{
   string obj = prefix + name;
   if(font == "") font = FontName;

   if(ObjectFind(0, obj) < 0)
      ObjectCreate(0, obj, OBJ_LABEL, 0, 0, 0);

   ObjectSetInteger(0, obj, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, obj, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, obj, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, obj, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, obj, OBJPROP_FONTSIZE, size);
   ObjectSetString(0, obj, OBJPROP_FONT, font);
   ObjectSetString(0, obj, OBJPROP_TEXT, text);
   ObjectSetInteger(0, obj, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, obj, OBJPROP_HIDDEN, true);
}

void DrawHLine(string name, double price, color clr, int style, int width, string label)
{
   if(!DrawRecoveryLines || price <= 0.0) return;

   string line = prefix + "LINE_" + name;
   if(ObjectFind(0, line) < 0)
      ObjectCreate(0, line, OBJ_HLINE, 0, 0, price);

   ObjectSetDouble(0, line, OBJPROP_PRICE1, price);
   ObjectSetInteger(0, line, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, line, OBJPROP_STYLE, style);
   ObjectSetInteger(0, line, OBJPROP_WIDTH, width);
   ObjectSetInteger(0, line, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, line, OBJPROP_HIDDEN, true);

   string txt = prefix + "TXT_" + name;
   datetime t = Time[0] + PeriodSeconds() * 8;

   if(ObjectFind(0, txt) < 0)
      ObjectCreate(0, txt, OBJ_TEXT, 0, t, price);

   ObjectSetInteger(0, txt, OBJPROP_TIME1, t);
   ObjectSetDouble(0, txt, OBJPROP_PRICE1, price);
   ObjectSetString(0, txt, OBJPROP_TEXT, label + " " + PriceStr(Symbol(), price));
   ObjectSetInteger(0, txt, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, txt, OBJPROP_FONTSIZE, 9);
   ObjectSetString(0, txt, OBJPROP_FONT, "Arial Bold");
   ObjectSetInteger(0, txt, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, txt, OBJPROP_HIDDEN, true);
}

void ResetStats(BasketStats &s)
{
   s.totalTrades = 0;
   s.selectedTrades = 0;
   s.losingTrades = 0;
   s.buyCount = 0;
   s.sellCount = 0;
   s.buyLots = 0.0;
   s.sellLots = 0.0;
   s.netLots = 0.0;
   s.selectedLots = 0.0;
   s.pnlAll = 0.0;
   s.pnlSelected = 0.0;
   s.swapCommSelected = 0.0;
   s.avgEntryAllSelected = 0.0;
   s.avgBuyEntry = 0.0;
   s.avgSellEntry = 0.0;
   s.signedLotSum = 0.0;
   s.signedEntrySum = 0.0;
   s.worstTicket = -1;
   s.worstType = -1;
   s.worstLots = 0.0;
   s.worstEntry = 0.0;
   s.worstCurrent = 0.0;
   s.worstPL = 0.0;
}

bool ScanBasket(string sym, BasketStats &s)
{
   ResetStats(s);

   double sumEntryLots = 0.0;
   double sumBuyEntryLots = 0.0;
   double sumSellEntryLots = 0.0;

   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      if(!ShouldIncludeOrder(sym)) continue;

      double pl = OrderProfit() + OrderSwap() + OrderCommission();

      s.totalTrades++;
      s.pnlAll += pl;

      bool selected = true;
      if(UseOnlyLosingTrades && pl >= 0.0)
         selected = false;

      if(!selected) continue;

      s.selectedTrades++;
      s.selectedLots += OrderLots();
      s.pnlSelected += pl;
      s.swapCommSelected += (OrderSwap() + OrderCommission());
      if(pl < 0.0) s.losingTrades++;

      if(s.worstTicket < 0 || pl < s.worstPL)
      {
         s.worstTicket = OrderTicket();
         s.worstType = OrderType();
         s.worstLots = OrderLots();
         s.worstEntry = OrderOpenPrice();
         s.worstCurrent = CurrentPriceForType(sym, OrderType());
         s.worstPL = pl;
      }

      int sign = (OrderType() == OP_BUY) ? 1 : -1;
      s.signedLotSum += sign * OrderLots();
      s.signedEntrySum += sign * OrderLots() * OrderOpenPrice();
      sumEntryLots += OrderLots() * OrderOpenPrice();

      if(OrderType() == OP_BUY)
      {
         s.buyCount++;
         s.buyLots += OrderLots();
         sumBuyEntryLots += OrderLots() * OrderOpenPrice();
      }
      else if(OrderType() == OP_SELL)
      {
         s.sellCount++;
         s.sellLots += OrderLots();
         sumSellEntryLots += OrderLots() * OrderOpenPrice();
      }
   }

   s.netLots = s.buyLots - s.sellLots;

   if(s.selectedLots > 0.0) s.avgEntryAllSelected = sumEntryLots / s.selectedLots;
   if(s.buyLots > 0.0) s.avgBuyEntry = sumBuyEntryLots / s.buyLots;
   if(s.sellLots > 0.0) s.avgSellEntry = sumSellEntryLots / s.sellLots;

   return (s.selectedTrades > 0);
}

double ProjectSelectedBasketAtPrice(string sym, double targetPrice)
{
   double mp = MoneyPerPriceUnitPerLot(sym);
   double projected = 0.0;

   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      if(!ShouldIncludeOrder(sym)) continue;

      double nowPL = OrderProfit() + OrderSwap() + OrderCommission();

      // v1.4 fix:
      // If CloseAllUsesAllSymbolTrades=true, projected close-all includes ALL open symbol trades,
      // including currently winning trades. This matches a true manual "close all" basket exit.
      if(!CloseAllUsesAllSymbolTrades)
      {
         if(UseOnlyLosingTrades && nowPL >= 0.0) continue;
      }

      int sign = (OrderType() == OP_BUY) ? 1 : -1;
      projected += sign * (targetPrice - OrderOpenPrice()) * mp * OrderLots();
      projected += OrderSwap() + OrderCommission();
   }

   return projected;
}

double BasketBEPriceProjected(string sym, double targetProfit)
{
   double mp = MoneyPerPriceUnitPerLot(sym);
   if(mp <= 0.0) return 0.0;

   double signedLotSum = 0.0;
   double signedEntrySum = 0.0;
   double swapComm = 0.0;

   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      if(!ShouldIncludeOrder(sym)) continue;

      double nowPL = OrderProfit() + OrderSwap() + OrderCommission();

      if(!CloseAllUsesAllSymbolTrades)
      {
         if(UseOnlyLosingTrades && nowPL >= 0.0) continue;
      }

      int sign = (OrderType() == OP_BUY) ? 1 : -1;
      signedLotSum += sign * OrderLots();
      signedEntrySum += sign * OrderLots() * OrderOpenPrice();
      swapComm += OrderSwap() + OrderCommission();
   }

   if(MathAbs(signedLotSum) < 0.0000001) return 0.0;

   return (targetProfit - swapComm + mp * signedEntrySum) / (mp * signedLotSum);
}


double BasketBEPrice(string sym, BasketStats &s, double targetProfit)
{
   if(MathAbs(s.signedLotSum) < 0.0000001) return 0.0;
   double mp = MoneyPerPriceUnitPerLot(sym);
   if(mp <= 0.0) return 0.0;
   double p = (targetProfit - s.swapCommSelected + mp * s.signedEntrySum) / (mp * s.signedLotSum);
   return p;
}


double ProjectCloseAllWithHedgeAtPrice(string sym, double targetPrice, int hedgeType, double hedgeEntry, double hedgeLots)
{
   double mp = MoneyPerPriceUnitPerLot(sym);
   int hedgeSign = (hedgeType == OP_BUY) ? 1 : -1;

   double basketPL = ProjectSelectedBasketAtPrice(sym, targetPrice);
   double hedgePL = hedgeSign * (targetPrice - hedgeEntry) * mp * hedgeLots;

   return basketPL + hedgePL;
}

bool SolveCloseAllPriceWithHedge(string sym,
                                  int hedgeType,
                                  double hedgeLots,
                                  double hedgeEntry,
                                  double targetPL,
                                  double &outPrice)
{
   double mp = MoneyPerPriceUnitPerLot(sym);
   if(mp <= 0.0 || hedgeLots <= 0.0)
      return false;

   double signedLotSum = 0.0;
   double signedEntrySum = 0.0;
   double swapComm = 0.0;

   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      if(!ShouldIncludeOrder(sym)) continue;

      double nowPL = OrderProfit() + OrderSwap() + OrderCommission();

      if(!CloseAllUsesAllSymbolTrades)
      {
         if(UseOnlyLosingTrades && nowPL >= 0.0) continue;
      }

      int sign = (OrderType() == OP_BUY) ? 1 : -1;
      signedLotSum += sign * OrderLots();
      signedEntrySum += sign * OrderLots() * OrderOpenPrice();
      swapComm += OrderSwap() + OrderCommission();
   }

   int hedgeSign = (hedgeType == OP_BUY) ? 1 : -1;
   signedLotSum += hedgeSign * hedgeLots;
   signedEntrySum += hedgeSign * hedgeLots * hedgeEntry;

   if(MathAbs(signedLotSum) < 0.0000001)
      return false;

   outPrice = (targetPL - swapComm + mp * signedEntrySum) / (mp * signedLotSum);
   return (outPrice > 0.0);
}

bool IsTargetInHedgeDirection(int hedgeType, double entry, double price)
{
   if(hedgeType == OP_BUY)  return (price > entry);
   if(hedgeType == OP_SELL) return (price < entry);
   return false;
}

bool IsSLAgainstHedge(int hedgeType, double entry, double price)
{
   if(hedgeType == OP_BUY)  return (price < entry);
   if(hedgeType == OP_SELL) return (price > entry);
   return false;
}


//+------------------------------------------------------------------+
//| v1.8 patch: account-aware deposit / survival guard                |
//| Added because the fixed 50% "reduce" fallback gave the same       |
//| generic answer regardless of account size, margin used, or how    |
//| far the basket actually was from recoverable. These functions     |
//| turn that into concrete, checkable numbers: how much margin a     |
//| hedge actually costs, how much deposit closes the gap, and how    |
//| far price can move before the account risks a stop-out.           |
//+------------------------------------------------------------------+
double Clamp2(double v, double lo, double hi)
{
   if(v < lo) return lo;
   if(v > hi) return hi;
   return v;
}

double MarginPerLot(string sym)
{
   // Prefer the broker-reported per-lot margin requirement.
   double m = MarketInfo(sym, MODE_MARGINREQUIRED);
   if(m > 0.0) return m;

   // Fallback approximation if the broker/symbol doesn't report it directly:
   // contract_size * price / leverage. This is an estimate -- always confirm
   // the real figure in the terminal's Market Watch / order ticket before sizing.
   double contractSize = MarketInfo(sym, MODE_LOTSIZE);
   if(contractSize <= 0.0) contractSize = 100000.0;

   double price = MarketInfo(sym, MODE_BID);
   double leverage = AccountLeverage();
   if(leverage <= 0.0) leverage = 100.0;
   if(price <= 0.0) return 0.0;

   return (contractSize * price) / leverage;
}

double RequiredMarginForLots(string sym, double lots)
{
   if(lots <= 0.0) return 0.0;
   return MarginPerLot(sym) * lots;
}

// Margin needed to actually place `lots` of hedge (plus a safety buffer), and the
// extra deposit required if current free margin doesn't already cover it.
void ComputeDepositGuard(string sym, double lots, double &marginNeeded, double &depositShortfall)
{
   marginNeeded = RequiredMarginForLots(sym, lots) * (1.0 + MarginSafetyBufferPercent / 100.0);
   double freeMargin = AccountFreeMargin();
   depositShortfall = MathMax(0.0, marginNeeded - freeMargin);
}

// How much further (money and ATR) this symbol's NET exposure can move against the
// account, using CURRENT account-wide margin/equity, before hitting the broker's
// stop-out level.
// APPROXIMATION: assumes every other open position on the account stays exactly
// where it is right now. This EA only scans one symbol, but stop-out is account-wide
// -- if other symbols are also moving against you, real survival room is smaller
// than this number. Treat it as an upper bound, not a guarantee.
bool ComputeSurvivalDistance(string sym, double netLots, double atr,
                              double &moneyBuffer, double &atrBuffer, bool &alreadyAtRisk)
{
   moneyBuffer = 0.0;
   atrBuffer = 0.0;
   alreadyAtRisk = false;

   double equity = AccountEquity();
   double usedMargin = AccountMargin();
   if(usedMargin <= 0.0) return false; // no margin in use -> can't estimate a stop-out distance

   double stopoutEquity = usedMargin * (StopOutLevelPercent / 100.0);
   moneyBuffer = equity - stopoutEquity;

   if(moneyBuffer <= 0.0)
   {
      alreadyAtRisk = true;
      return true;
   }

   double netExposure = MathAbs(netLots);
   if(netExposure <= 0.0000001) return false; // flat net exposure here; this symbol alone can't drive stop-out further

   double mp = MoneyPerPriceUnitPerLot(sym);
   if(mp <= 0.0) return false;

   double priceDistance = moneyBuffer / (mp * netExposure);
   if(atr > 0.0) atrBuffer = priceDistance / atr;

   return true;
}

// Deposit required so the account could absorb SurviveTargetATR of further adverse
// move on this symbol's current net exposure before hitting stop-out.
double DepositToSurviveTargetATR(string sym, double netLots, double atr, double currentMoneyBuffer)
{
   double netExposure = MathAbs(netLots);
   if(netExposure <= 0.0000001 || atr <= 0.0) return 0.0;

   double mp = MoneyPerPriceUnitPerLot(sym);
   if(mp <= 0.0) return 0.0;

   double neededBuffer = mp * netExposure * (SurviveTargetATR * atr);
   return MathMax(0.0, neededBuffer - currentMoneyBuffer);
}

// v1.8 patch: replaces the old fixed ReduceFirstPercent constant. Scales with
// (a) how far over the safe hedge-lot cap the real hedge requirement is, and
// (b) how large the basket loss is relative to account equity. This is a
// transparent, tunable heuristic -- not a solved optimum. Tune the two weight
// inputs (ReduceOverCapWeight, ReduceLossToEquityWeight) to taste, and validate
// against a few real basket examples in visual/demo mode before trusting it.
double ComputeDynamicReducePercent(BasketStats &s, Plan &p1, Plan &p2, Plan &p3)
{
   double netAbs = MathAbs(s.netLots);
   double maxClean = netAbs * MaxHedgeToNetMultiplier;
   if(maxClean <= 0.0) maxClean = 0.0000001;

   double bestRaw = -1.0;
   if(p1.valid && p1.rawRequiredLots > 0.0) bestRaw = p1.rawRequiredLots;
   if(p2.valid && p2.rawRequiredLots > 0.0 && (bestRaw < 0.0 || p2.rawRequiredLots < bestRaw)) bestRaw = p2.rawRequiredLots;
   if(p3.valid && p3.rawRequiredLots > 0.0 && (bestRaw < 0.0 || p3.rawRequiredLots < bestRaw)) bestRaw = p3.rawRequiredLots;

   double overRatio = 0.0;
   if(bestRaw > 0.0)
      overRatio = MathMax(0.0, (bestRaw / maxClean) - 1.0);

   double eq = MathMax(1.0, AccountEquity());
   double lossToEquity = (s.pnlSelected < 0.0) ? (MathAbs(s.pnlSelected) / eq * 100.0) : 0.0;

   double pct = MinReducePercent + (overRatio * ReduceOverCapWeight) + (lossToEquity * ReduceLossToEquityWeight);
   return Clamp2(pct, MinReducePercent, MaxReducePercent);
}

void BuildPlan(string sym, BasketStats &s, string planName, double atrMult, Plan &p)
{
   p.name = planName;
   p.valid = false;
   p.note = "";
   p.requiredLots = 0.0;
   p.rawRequiredLots = 0.0;
   p.cappedByMaxLot = false;
   p.reachesProfitTarget = false;
   p.projectedExisting = 0.0;
   p.projectedHedge = 0.0;
   p.projectedTotal = 0.0;
   p.projectedExistingSL = 0.0;
   p.projectedHedgeSL = 0.0;
   p.projectedTotalSL = 0.0;
   p.targetATRDistance = 0.0;
   p.slATRDistance = 0.0;
   p.targetTooFar = false;
   p.marginNeeded = 0.0;
   p.depositShortfall = 0.0;

   double atr = iATR(sym, ATRTimeframe, ATRPeriod, 0);
   if(atr <= 0.0) atr = MathAbs(MarketInfo(sym, MODE_ASK) - MarketInfo(sym, MODE_BID)) * 10.0;
   if(atr <= 0.0) atr = PointValue(sym) * 100.0;

   if(MathAbs(s.netLots) < 0.000001)
   {
      p.note = "Already hedged/net flat. Reduce worst leg first.";
      return;
   }

   p.hedgeType = (s.netLots > 0.0) ? OP_SELL : OP_BUY;
   p.hedgeEntry = EntryPriceForNewOrder(sym, p.hedgeType);

   // Step 1: ATR is only used to estimate a starting hedge size.
   double trialTarget = p.hedgeEntry;
   double trialSL = p.hedgeEntry;

   if(p.hedgeType == OP_SELL)
   {
      trialTarget = p.hedgeEntry - atr * atrMult;
      trialSL = p.hedgeEntry + atr * HedgeSL_ATR_Multiple;
   }
   else
   {
      trialTarget = p.hedgeEntry + atr * atrMult;
      trialSL = p.hedgeEntry - atr * HedgeSL_ATR_Multiple;
   }

   p.targetPrice = trialTarget;
   p.hedgeSL = trialSL;

   p.projectedExisting = ProjectSelectedBasketAtPrice(sym, trialTarget);

   double mp = MoneyPerPriceUnitPerLot(sym);
   int hedgeSign = (p.hedgeType == OP_BUY) ? 1 : -1;
   double hedgePerLot = hedgeSign * (trialTarget - p.hedgeEntry) * mp;

   if(hedgePerLot <= 0.0)
   {
      p.note = "Invalid hedge target.";
      return;
   }

   double need = ProfitBufferMoney - p.projectedExisting;

   if(need <= 0.0)
   {
      p.requiredLots = 0.0;
      p.rawRequiredLots = 0.0;
      p.cappedByMaxLot = false;
      p.reachesProfitTarget = (p.projectedExisting >= ProfitBufferMoney);
      p.projectedHedge = 0.0;
      p.projectedTotal = p.projectedExisting;
      p.projectedExistingSL = ProjectSelectedBasketAtPrice(sym, p.hedgeSL);
      p.projectedHedgeSL = 0.0;
      p.projectedTotalSL = p.projectedExistingSL;
      p.targetATRDistance = MathAbs(p.targetPrice - p.hedgeEntry) / atr;
      p.slATRDistance = MathAbs(p.hedgeSL - p.hedgeEntry) / atr;
      p.valid = true;
      p.note = "No hedge needed if target is reached.";
      return;
   }

   double rawLots = need / hedgePerLot;
   p.rawRequiredLots = rawLots;
   p.requiredLots = NormalizeLot(sym, rawLots);
   p.cappedByMaxLot = (p.requiredLots + 0.000001 < rawLots);

   // Step 2: if enabled, replace the ATR target with the exact basket close-all TP.
   // This answers: "At what price can I close hedge + basket at BE/small profit?"
   if(UseBasketBasedTPSL && p.requiredLots > 0.0)
   {
      double solvedTP = 0.0;
      if(SolveCloseAllPriceWithHedge(sym, p.hedgeType, p.requiredLots, p.hedgeEntry, ProfitBufferMoney, solvedTP)
         && IsTargetInHedgeDirection(p.hedgeType, p.hedgeEntry, solvedTP))
      {
         p.targetPrice = solvedTP;
      }

      double solvedSL = 0.0;
      if(SolveCloseAllPriceWithHedge(sym, p.hedgeType, p.requiredLots, p.hedgeEntry, HedgeSL_CloseAllLossMoney, solvedSL)
         && IsSLAgainstHedge(p.hedgeType, p.hedgeEntry, solvedSL))
      {
         p.hedgeSL = solvedSL;
      }
      else
      {
         p.hedgeSL = trialSL;
      }
   }

   p.projectedExisting = ProjectSelectedBasketAtPrice(sym, p.targetPrice);
   p.projectedHedge = hedgeSign * (p.targetPrice - p.hedgeEntry) * mp * p.requiredLots;
   p.projectedTotal = p.projectedExisting + p.projectedHedge;
   p.reachesProfitTarget = (p.projectedTotal >= ProfitBufferMoney);

   p.projectedExistingSL = ProjectSelectedBasketAtPrice(sym, p.hedgeSL);
   p.projectedHedgeSL = hedgeSign * (p.hedgeSL - p.hedgeEntry) * mp * p.requiredLots;
   p.projectedTotalSL = p.projectedExistingSL + p.projectedHedgeSL;

   p.targetATRDistance = MathAbs(p.targetPrice - p.hedgeEntry) / atr;
   p.slATRDistance = MathAbs(p.hedgeSL - p.hedgeEntry) / atr;
   p.targetTooFar = (UseBasketBasedTPSL && p.targetATRDistance > MaxBasketTargetATR);

   ComputeDepositGuard(sym, p.requiredLots, p.marginNeeded, p.depositShortfall);

   p.valid = true;

   if(p.targetTooFar)
      p.note = "Basket TP is too far. Reduce first.";
   else if(p.cappedByMaxLot && !p.reachesProfitTarget)
      p.note = "Hedge cap reached. Not enough lot to recover.";
   else if(!p.reachesProfitTarget)
      p.note = "Target not reached. Reduce first.";
   else
      p.note = "Basket-based recovery possible at TP.";
}


string PlanLine(Plan &p, string sym)
{
   if(!p.valid) return p.name + ": " + p.note;

   return p.name + ": " + SideText(p.hedgeType) + " " + LotStr(p.requiredLots) +
          " | TP " + PriceStr(sym, p.targetPrice) + " CA " + MoneyStr(p.projectedTotal) +
          " | SL " + PriceStr(sym, p.hedgeSL) + " CA " + MoneyStr(p.projectedTotalSL);
}

int PickBestPlan(BasketStats &s, Plan &p1, Plan &p2, Plan &p3)
{
   double netAbs = MathAbs(s.netLots);
   double maxClean = netAbs * MaxHedgeToNetMultiplier;

   bool p2ok = (p2.valid && p2.reachesProfitTarget && !p2.targetTooFar && p2.requiredLots > 0.0 && p2.requiredLots <= maxClean);
   bool p1ok = (p1.valid && p1.reachesProfitTarget && !p1.targetTooFar && p1.requiredLots > 0.0 && p1.requiredLots <= maxClean);
   bool p3ok = (p3.valid && p3.reachesProfitTarget && !p3.targetTooFar && p3.requiredLots > 0.0 && p3.requiredLots <= maxClean);

   if(p2ok) return 2;
   if(p1ok) return 1;
   if(p3ok) return 3;

   if(p1.valid && p1.reachesProfitTarget && !p1.targetTooFar && p1.requiredLots <= 0.0) return 1;
   if(p2.valid && p2.reachesProfitTarget && !p2.targetTooFar && p2.requiredLots <= 0.0) return 2;
   if(p3.valid && p3.reachesProfitTarget && !p3.targetTooFar && p3.requiredLots <= 0.0) return 3;

   return 0;
}

string BestPlanText(string sym, BasketStats &s, Plan &p1, Plan &p2, Plan &p3)
{
   int best = PickBestPlan(s, p1, p2, p3);

   if(MathAbs(s.netLots) < 0.000001)
      return "BEST SOLUTION: net exposure is flat. Reduce/close worst leg first; do not add another hedge blindly.";

   Plan p;
   if(best == 1) p = p1;
   if(best == 2) p = p2;
   if(best == 3) p = p3;

   if(best > 0 && p.valid)
   {
      if(p.requiredLots <= 0.0)
         return "BEST SOLUTION: no hedge needed if target is reached. Reduce worst entries.";

      return "BEST SOLUTION: " + SideText(p.hedgeType) + " hedge " + LotStr(p.requiredLots) +
             " lots toward " + PriceStr(sym, p.targetPrice) +
             " then close basket near BE/+" + DoubleToString(ProfitBufferMoney, 2) + ".";
   }

   double dynPct = ComputeDynamicReducePercent(s, p1, p2, p3);
   return "BEST SOLUTION: hedge too heavy for current cap. Reduce worst ~" + DoubleToString(dynPct, 0) +
          "% (severity-scaled, see deposit alternative below), then recompute.";
}

string HedgeReasonText(string sym, BasketStats &s)
{
   if(MathAbs(s.netLots) < 0.000001)
      return "HEDGE REASON: basket is already close to net-flat. Another hedge may trap the account.";

   string side = (s.netLots > 0.0) ? "SELL" : "BUY";
   string exposure = (s.netLots > 0.0) ? "net long" : "net short";

   return "HEDGE REASON: losing basket is " + exposure + " " + LotStr(MathAbs(s.netLots)) +
          " lots; cleanest hedge is " + side + " same symbol.";
}

string CrossHedgeNote(string sym, BasketStats &s)
{
   if(StringLen(sym) < 6) return "ALT HEDGE: same-symbol is recommended; cross hedge needs correlation confirmation.";

   string base = StringSubstr(sym, 0, 3);
   string quote = StringSubstr(sym, 3, 3);

   if(MathAbs(s.netLots) < 0.000001) return "ALT HEDGE: none. Net exposure is already balanced.";

   if(s.netLots > 0.0)
      return "ALT HEDGE LOGIC: sell " + base + " exposure or buy " + quote + " exposure. Same-symbol is cleaner.";
   else
      return "ALT HEDGE LOGIC: buy " + base + " exposure or sell " + quote + " exposure. Same-symbol is cleaner.";
}

double WorstGuardSL(string sym, BasketStats &s)
{
   if(s.worstTicket < 0) return 0.0;

   double atr = iATR(sym, ATRTimeframe, ATRPeriod, 0);
   if(atr <= 0.0) atr = PointValue(sym) * 100.0;

   if(s.worstType == OP_BUY) return CurrentPriceForType(sym, OP_BUY) - atr * WorstGuardSL_ATR_Multiple;
   if(s.worstType == OP_SELL) return CurrentPriceForType(sym, OP_SELL) + atr * WorstGuardSL_ATR_Multiple;
   return 0.0;
}


int MaxCharsForPanel()
{
   int chars = (PanelWidth - 40) / MathMax(6, TextSize);
   if(chars < 70) chars = 70;
   if(chars > 135) chars = 135;
   return chars;
}

int DrawWrappedLabel(string baseName, string text, int x, int y, color clr, int size, int lineHeight, int maxChars, string font="")
{
   if(font == "") font = FontName;

   string remaining = text;
   int lines = 0;

   while(StringLen(remaining) > maxChars && lines < 5)
   {
      int cut = maxChars;

      for(int i = maxChars; i > MathMax(10, maxChars - 30); i--)
      {
         string ch = StringSubstr(remaining, i, 1);
         if(ch == " " || ch == "|" || ch == "." || ch == ";")
         {
            cut = i + 1;
            break;
         }
      }

      string part = StringSubstr(remaining, 0, cut);
      SetLabel(baseName + "_" + IntegerToString(lines), part, x, y + lines * lineHeight, clr, size, font);

      remaining = StringSubstr(remaining, cut);
      while(StringLen(remaining) > 0 && StringSubstr(remaining, 0, 1) == " ")
         remaining = StringSubstr(remaining, 1);

      lines++;
   }

   SetLabel(baseName + "_" + IntegerToString(lines), remaining, x, y + lines * lineHeight, clr, size, font);
   lines++;

   return lines;
}

string ShortPlanLine(Plan &p, string sym)
{
   if(!p.valid)
      return p.name + ": " + p.note;

   return p.name + ": " + SideText(p.hedgeType) + " " + LotStr(p.requiredLots) +
          " | TP CA " + MoneyStr(p.projectedTotal) +
          " | SL CA " + MoneyStr(p.projectedTotalSL);
}

string ShortBestPlanText(string sym, BasketStats &s, Plan &p1, Plan &p2, Plan &p3)
{
   int best = PickBestPlan(s, p1, p2, p3);

   if(MathAbs(s.netLots) < 0.000001)
      return "BEST SOLUTION: net-flat already. Reduce/close worst leg first. Do not add hedge blindly.";

   Plan p;
   if(best == 1) p = p1;
   if(best == 2) p = p2;
   if(best == 3) p = p3;

   if(best > 0 && p.valid)
   {
      if(p.requiredLots <= 0.0)
         return "BEST SOLUTION: no hedge needed if target is reached. Reduce worst entries.";

      return "BEST SOLUTION: " + SideText(p.hedgeType) + " " + LotStr(p.requiredLots) +
             " to TP " + PriceStr(sym, p.targetPrice) +
             " then close basket near BE/+" + DoubleToString(ProfitBufferMoney, 2) + ".";
   }

   double dynPctShort = ComputeDynamicReducePercent(s, p1, p2, p3);
   return "BEST SOLUTION: hedge too heavy. Reduce worst ~" +
          DoubleToString(dynPctShort, 0) + "% (severity-scaled), then recompute.";
}

string ShortCrossHedgeNote(string sym, BasketStats &s)
{
   if(MathAbs(s.netLots) < 0.000001)
      return "ALT HEDGE: none. Net exposure is already balanced.";

   if(StringLen(sym) < 6)
      return "ALT HEDGE: same-symbol preferred. Cross hedge requires correlation confirmation.";

   string base = StringSubstr(sym, 0, 3);
   string quote = StringSubstr(sym, 3, 3);

   if(s.netLots > 0.0)
      return "ALT HEDGE: sell " + base + " exposure or buy " + quote + " exposure. Same-symbol is cleaner.";
   else
      return "ALT HEDGE: buy " + base + " exposure or sell " + quote + " exposure. Same-symbol is cleaner.";
}


void DrawDashboard(string sym, BasketStats &s, Plan &p1, Plan &p2, Plan &p3)
{
   if(!ShowDashboard) return;

   SetRect("BG", PanelX, PanelY, PanelWidth, PanelHeight, BG_COLOR, BORDER_COLOR);

   int x = PanelX + 14;
   int y = PanelY + 12;
   int lh = MathMax(16, TextSize + 8);

   SetLabel("TITLE", "LPH SYMBOL HEDGE / RECOVERY PLANNER", x, y, TITLE_COLOR, TitleSize, "Arial Bold");
   y += 24;

   SetLabel("SUB1", "One-symbol basket recovery math", x, y, CYAN_COLOR, 9, "Arial");
   y += 16;
   SetLabel("SUB2", "Hedge basis: losing trades | TP/SL: basket close-all math", x, y, CYAN_COLOR, 9, "Arial");
   y += 24;

   color pnlClr = s.pnlSelected >= 0.0 ? GREEN_COLOR : RED_COLOR;

   SetLabel("STAT1", "Symbol: " + sym +
                     " | Selected losing: " + IntegerToString(s.selectedTrades) +
                     " | Losing P/L: " + MoneyStr(s.pnlSelected),
            x, y, pnlClr, TextSize, FontName);
   y += lh;

   SetLabel("STAT1B", "All open symbol trades: " + IntegerToString(s.totalTrades) +
                      " | All open P/L: " + MoneyStr(s.pnlAll),
            x, y, TEXT_COLOR, TextSize, FontName);
   y += lh;

   SetLabel("STAT2", "Selected BuyLots: " + LotStr(s.buyLots) +
                     " | SellLots: " + LotStr(s.sellLots) +
                     " | NetLots: " + LotStr(s.netLots),
            x, y, TEXT_COLOR, TextSize, FontName);
   y += lh;

   SetLabel("STAT3", "Avg losing entry: " + PriceStr(sym, s.avgEntryAllSelected),
            x, y, TEXT_COLOR, TextSize, FontName);
   y += lh;

   double be = BasketBEPriceProjected(sym, ProfitBufferMoney);
   string beText = "Projected close-all BE+" + DoubleToString(ProfitBufferMoney, 2) + ": ";
   if(be > 0.0) beText += PriceStr(sym, be);
   else beText += "n/a / net-flat";

   SetLabel("BE", beText, x, y, ORANGE_COLOR, TextSize, FontName);
   y += lh;

   if(s.worstTicket > 0)
   {
      SetLabel("WORST1", "Worst trade: " + SideText(s.worstType) + " " + LotStr(s.worstLots) +
                          " @ " + PriceStr(sym, s.worstEntry),
               x, y, ORANGE_COLOR, TextSize, FontName);
      y += lh;
      SetLabel("WORST2", "Worst P/L: " + MoneyStr(s.worstPL),
               x, y, ORANGE_COLOR, TextSize, FontName);
      y += lh;
   }

   // Short hedge reason, split into safe MT4 label lengths
   string hedgeSide = "NONE";
   if(s.netLots > 0.0) hedgeSide = "SELL";
   if(s.netLots < 0.0) hedgeSide = "BUY";

   if(MathAbs(s.netLots) < 0.000001)
   {
      SetLabel("HEDGE1", "HEDGE: net exposure is already flat", x, y, CYAN_COLOR, TextSize, FontName);
      y += lh;
      SetLabel("HEDGE2", "Action: reduce/close worst leg first", x, y, CYAN_COLOR, TextSize, FontName);
      y += lh;
   }
   else
   {
      SetLabel("HEDGE1", "HEDGE: " + hedgeSide + " same-symbol is the cleanest math",
               x, y, CYAN_COLOR, TextSize, FontName);
      y += lh;
      SetLabel("HEDGE2", "Reason: basket net exposure = " + LotStr(s.netLots) + " lots",
               x, y, CYAN_COLOR, TextSize, FontName);
      y += lh;
   }

   y += 4;
   SetLabel("SECTION_RECOVERY", "RECOVERY SCENARIOS", x, y, TITLE_COLOR, TextSize, "Arial Bold");
   y += lh + 2;

   // Conservative plan
   color p1Clr = (p1.reachesProfitTarget && !p1.targetTooFar) ? TEXT_COLOR : ORANGE_COLOR;
   SetLabel("P1A", p1.name + ": " + SideText(p1.hedgeType) + " allowed " + LotStr(p1.requiredLots) +
                    " | need " + LotStr(p1.rawRequiredLots),
            x, y, p1Clr, TextSize, FontName);
   y += lh;
   SetLabel("P1B", "TP " + PriceStr(sym, p1.targetPrice) + " | CA " + MoneyStr(p1.projectedTotal) +
                   " | " + DoubleToString(p1.targetATRDistance, 1) + " ATR",
            x, y, p1Clr, TextSize, FontName);
   y += lh;
   SetLabel("P1C", "SL " + PriceStr(sym, p1.hedgeSL) + " | CA " + MoneyStr(p1.projectedTotalSL) +
                   " | " + DoubleToString(p1.slATRDistance, 1) + " ATR",
            x, y, RED_COLOR, TextSize, FontName);
   y += lh;

   // Balanced plan
   color p2Clr = (p2.reachesProfitTarget && !p2.targetTooFar) ? TEXT_COLOR : ORANGE_COLOR;
   SetLabel("P2A", p2.name + ": " + SideText(p2.hedgeType) + " allowed " + LotStr(p2.requiredLots) +
                    " | need " + LotStr(p2.rawRequiredLots),
            x, y, p2Clr, TextSize, FontName);
   y += lh;
   SetLabel("P2B", "TP " + PriceStr(sym, p2.targetPrice) + " | CA " + MoneyStr(p2.projectedTotal) +
                   " | " + DoubleToString(p2.targetATRDistance, 1) + " ATR",
            x, y, p2Clr, TextSize, FontName);
   y += lh;
   SetLabel("P2C", "SL " + PriceStr(sym, p2.hedgeSL) + " | CA " + MoneyStr(p2.projectedTotalSL) +
                   " | " + DoubleToString(p2.slATRDistance, 1) + " ATR",
            x, y, RED_COLOR, TextSize, FontName);
   y += lh;

   // Extended plan
   color p3Clr = (p3.reachesProfitTarget && !p3.targetTooFar) ? TEXT_COLOR : ORANGE_COLOR;
   SetLabel("P3A", p3.name + ": " + SideText(p3.hedgeType) + " allowed " + LotStr(p3.requiredLots) +
                    " | need " + LotStr(p3.rawRequiredLots),
            x, y, p3Clr, TextSize, FontName);
   y += lh;
   SetLabel("P3B", "TP " + PriceStr(sym, p3.targetPrice) + " | CA " + MoneyStr(p3.projectedTotal) +
                   " | " + DoubleToString(p3.targetATRDistance, 1) + " ATR",
            x, y, p3Clr, TextSize, FontName);
   y += lh;
   SetLabel("P3C", "SL " + PriceStr(sym, p3.hedgeSL) + " | CA " + MoneyStr(p3.projectedTotalSL) +
                   " | " + DoubleToString(p3.slATRDistance, 1) + " ATR",
            x, y, RED_COLOR, TextSize, FontName);
   y += lh + 4;

   // Best solution, split short
   int best = PickBestPlan(s, p1, p2, p3);
   if(best == 0)
   {
      SetLabel("BEST1", "BEST: NO CLEAN RECOVERY HEDGE at current lot cap.", x, y, WarningColor, TextSize, "Arial Bold");
      y += lh;
      SetLabel("BEST2", "TP is too far, oversized, or still not profitable at that cap.", x, y, WarningColor, TextSize, "Arial Bold");
      y += lh;

      // v1.8: two concrete alternatives instead of one fixed "reduce 50%" line --
      // deposit enough to hedge the real (uncapped) size, OR reduce by a
      // severity-scaled percentage that actually reflects how oversized this basket is.
      double dynPct = ComputeDynamicReducePercent(s, p1, p2, p3);
      SetLabel("BEST3", "OPTION A: reduce worst ~" + DoubleToString(dynPct, 0) + "% (scaled to how oversized this is), then recompute.",
               x, y, GREEN_COLOR, TextSize, "Arial Bold");
      y += lh;

      if(p2.requiredLots > 0.0 && p2.depositShortfall > 0.0)
      {
         SetLabel("BEST4", "OPTION B: deposit ~" + MoneyStr(p2.depositShortfall) + " to margin the full " +
                           LotStr(p2.requiredLots) + " lot hedge (Balanced plan) instead of reducing.",
                  x, y, GREEN_COLOR, TextSize, "Arial Bold");
         y += lh;
      }
      else if(p2.requiredLots > 0.0)
      {
         SetLabel("BEST4", "OPTION B: free margin already covers the full " + LotStr(p2.requiredLots) +
                           " lot Balanced hedge -- cap (MaxHedgeToNetMultiplier) is what's blocking it, not deposit.",
                  x, y, GREEN_COLOR, TextSize, "Arial Bold");
         y += lh;
      }
   }
   else
   {
      Plan bp;
      if(best == 1) bp = p1;
      if(best == 2) bp = p2;
      if(best == 3) bp = p3;

      if(bp.requiredLots <= 0.0)
      {
         SetLabel("BEST1", "BEST: no hedge needed if target is reached.", x, y, GREEN_COLOR, TextSize, "Arial Bold");
         y += lh;
         SetLabel("BEST2", "Reduce worst entries and close basket near BE.", x, y, GREEN_COLOR, TextSize, "Arial Bold");
         y += lh;
      }
      else
      {
         SetLabel("BEST1", "BEST: " + SideText(bp.hedgeType) + " " + LotStr(bp.requiredLots) +
                           " to TP " + PriceStr(sym, bp.targetPrice),
                  x, y, GREEN_COLOR, TextSize, "Arial Bold");
         y += lh;
         SetLabel("BEST2", "Then close basket near BE/+" + DoubleToString(ProfitBufferMoney, 2),
                  x, y, GREEN_COLOR, TextSize, "Arial Bold");
         y += lh;

         if(bp.depositShortfall > 0.0)
            SetLabel("BEST3", "Margin needed for this hedge: " + MoneyStr(bp.marginNeeded) +
                              " | deposit ~" + MoneyStr(bp.depositShortfall) + " more to cover it.",
                     x, y, ORANGE_COLOR, TextSize, FontName);
         else
            SetLabel("BEST3", "Margin needed for this hedge: " + MoneyStr(bp.marginNeeded) +
                              " | already covered by current free margin.",
                     x, y, CYAN_COLOR, TextSize, FontName);
         y += lh;
      }
   }

   // Alt hedge, split short
   if(StringLen(sym) >= 6 && MathAbs(s.netLots) >= 0.000001)
   {
      string base = StringSubstr(sym, 0, 3);
      string quote = StringSubstr(sym, 3, 3);

      if(s.netLots > 0.0)
         SetLabel("ALT1", "ALT: sell " + base + " exposure or buy " + quote + " exposure.", x, y, MUTED_COLOR, TextSize, FontName);
      else
         SetLabel("ALT1", "ALT: buy " + base + " exposure or sell " + quote + " exposure.", x, y, MUTED_COLOR, TextSize, FontName);
      y += lh;

      SetLabel("ALT2", "Same-symbol is cleaner unless correlation confirms.", x, y, MUTED_COLOR, TextSize, FontName);
      y += lh;
   }
   else
   {
      SetLabel("ALT1", "ALT: no cross hedge. Same-symbol preferred.", x, y, MUTED_COLOR, TextSize, FontName);
      y += lh;
   }

   // v1.8: survive-to-stop-out distance, account-wide margin priced by THIS
   // symbol's net exposure only (see ComputeSurvivalDistance notes above).
   y += 4;
   SetLabel("SECTION_SURVIVE", "SURVIVE (account-wide margin, approx -- this symbol's exposure only)", x, y, TITLE_COLOR, TextSize, "Arial Bold");
   y += lh + 2;

   double atrForSurvival = iATR(sym, ATRTimeframe, ATRPeriod, 0);
   if(atrForSurvival <= 0.0) atrForSurvival = PointValue(sym) * 100.0;

   double survMoneyBuffer = 0.0, survATRBuffer = 0.0;
   bool survAtRisk = false;
   bool survOk = ComputeSurvivalDistance(sym, s.netLots, atrForSurvival, survMoneyBuffer, survATRBuffer, survAtRisk);

   if(!survOk)
   {
      SetLabel("SURV1", "Survive buffer: n/a (no margin in use, or net-flat on this symbol).", x, y, MUTED_COLOR, TextSize, FontName);
      y += lh;
   }
   else if(survAtRisk)
   {
      SetLabel("SURV1", "Survive buffer: AT/PAST STOP-OUT RISK ZONE at current StopOutLevelPercent input. Verify live now.",
               x, y, RED_COLOR, TextSize, "Arial Bold");
      y += lh;
   }
   else
   {
      SetLabel("SURV1", "Room before stop-out: ~" + MoneyStr(survMoneyBuffer) + " | ~" +
                        DoubleToString(survATRBuffer, 2) + " ATR of further adverse move on " + sym,
               x, y, (survATRBuffer < 1.0 ? RED_COLOR : ORANGE_COLOR), TextSize, FontName);
      y += lh;

      double depositForSurvive = DepositToSurviveTargetATR(sym, s.netLots, atrForSurvival, survMoneyBuffer);
      if(depositForSurvive > 0.0)
         SetLabel("SURV2", "Deposit ~" + MoneyStr(depositForSurvive) + " to survive " +
                           DoubleToString(SurviveTargetATR, 1) + " ATR further before stop-out.",
                  x, y, ORANGE_COLOR, TextSize, FontName);
      else
         SetLabel("SURV2", "Already covers " + DoubleToString(SurviveTargetATR, 1) + " ATR further before stop-out. No deposit needed for that target.",
                  x, y, CYAN_COLOR, TextSize, FontName);
      y += lh;
   }

   y += 2;
   double guard = WorstGuardSL(sym, s);
   if(guard > 0.0)
      SetLabel("GUARD1", "Worst guard SL: " + PriceStr(sym, guard), x, y, ORANGE_COLOR, TextSize, FontName);
   else
      SetLabel("GUARD1", "Worst guard SL: n/a", x, y, ORANGE_COLOR, TextSize, FontName);
   y += lh;

   SetLabel("GUARD2", "Use guard only as planning level, not auto-exit.", x, y, ORANGE_COLOR, TextSize, FontName);

   SetLabel("NOTE", "Risk triage only. Orange scenario = not a clean recovery hedge. No auto-trade. Survival math assumes other symbols hold still -- see code comments.",
            x, PanelY + PanelHeight - 28, MUTED_COLOR, 9, "Arial");

   if(DrawRecoveryLines)
   {
      if(s.avgEntryAllSelected > 0.0)
         DrawHLine("AVG_ENTRY", s.avgEntryAllSelected, ORANGE_COLOR, STYLE_DOT, 1, "Avg selected entry");

      if(be > 0.0)
         DrawHLine("BASKET_BE", be, CYAN_COLOR, STYLE_DASH, 1, "Basket BE");

      if(p2.valid && p2.targetPrice > 0.0)
         DrawHLine("BALANCED_TP", p2.targetPrice, GREEN_COLOR, STYLE_SOLID, 1, "Hedge TP");

      if(p2.valid && p2.hedgeSL > 0.0)
         DrawHLine("HEDGE_SL", p2.hedgeSL, RED_COLOR, STYLE_DOT, 1, "Hedge SL");

      if(guard > 0.0)
         DrawHLine("WORST_GUARD", guard, BLUE_COLOR, STYLE_DOT, 1, "Worst guard");
   }
}


void DrawNoTrades(string sym)
{
   if(!ShowDashboard) return;
   SetRect("BG", PanelX, PanelY, PanelWidth, 150, BG_COLOR, BORDER_COLOR);
   SetLabel("TITLE", "LPH SYMBOL HEDGE / RECOVERY PLANNER", PanelX + 14, PanelY + 12, TITLE_COLOR, TitleSize, "Arial Bold");
   SetLabel("NONE", "No selected losing/open trades found for " + sym + ".", PanelX + 14, PanelY + 46, TEXT_COLOR, TextSize, FontName);
   SetLabel("INFO", "Attach this EA to the symbol you want to manage. It scans this chart symbol only.", PanelX + 14, PanelY + 70, MUTED_COLOR, TextSize, FontName);
   SetLabel("NOTE", "Dashboard only. No auto-trade execution.", PanelX + 14, PanelY + 104, ORANGE_COLOR, TextSize, FontName);
}

void CheckAlerts(string sym, BasketStats &s)
{
   if(!AlertsEnabled) return;
   if(TimeCurrent() - lastAlertTime < 60) return;

   if(s.pnlSelected <= AlertLossMoney)
   {
      string msg = "LPH Hedge Planner | " + sym + " selected P/L " + MoneyStr(s.pnlSelected) +
                   " | NetLots " + LotStr(s.netLots) + " | recompute hedge plan.";
      Alert(msg);
      SendNotification(msg);
      lastAlertTime = TimeCurrent();
   }
}

void RefreshPlanner()
{
   string sym = Symbol();
   BasketStats s;
   bool ok = ScanBasket(sym, s);

   DeleteByPrefix(prefix);

   if(!ok)
   {
      DrawNoTrades(sym);
      return;
   }

   Plan p1, p2, p3;
   BuildPlan(sym, s, "Conservative " + DoubleToString(ConservativeTargetATR, 2) + " ATR", ConservativeTargetATR, p1);
   BuildPlan(sym, s, "Balanced " + DoubleToString(BalancedTargetATR, 2) + " ATR", BalancedTargetATR, p2);
   BuildPlan(sym, s, "Extended " + DoubleToString(ExtendedTargetATR, 2) + " ATR", ExtendedTargetATR, p3);

   DrawDashboard(sym, s, p1, p2, p3);
   CheckAlerts(sym, s);
}

int OnInit()
{
   if(AllowAutoTrading)
      Print("LPH Hedge Recovery Planner: AllowAutoTrading is true, but this EA intentionally contains no trade execution.");

   int t = RefreshSeconds;
   if(t < 1) t = 1;
   EventSetTimer(t);
   RefreshPlanner();
   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason)
{
   EventKillTimer();
   DeleteByPrefix(prefix);
}

void OnTick()
{
   // no trading logic
}

void OnTimer()
{
   RefreshPlanner();
}
//+------------------------------------------------------------------+
