//+------------------------------------------------------------------+
//|                  LPH_TDI_Basic_Signal_Backtest_EA.mq4           |
//|                                                                  |
//|  This is not a trading EA.                                       |
//|  It does not place orders or call MT4 order functions, and is not |
//|  intended for live trading.                                      |
//|                                                                  |
//|  Purpose: scan historical closed candles for TDI BUY/SELL signals|
//|  and measure how often those states were followed by favorable    |
//|  movement on H1, H4, or D1 Strategy Tester runs.                  |
//|                                                                  |
//|  Reference signal source: Traders_Dynamic_Index_VISUAL_ALERTS.   |
//|  The default mode recreates its Strong Buy and Strong Sell labels |
//|  on closed bars only and counts the first bar of a new state.     |
//+------------------------------------------------------------------+
#property strict

enum TDI_SIGNAL_MODE
{
   SIGNAL_VISUAL_BUY_STATE_ENTRY = 0,
   SIGNAL_BASIC_CROSS_BUY        = 1
};

enum TDI_SIGNAL_SIDE
{
   SIGNAL_BUY_ONLY               = 0,
   SIGNAL_SELL_ONLY              = 1,
   SIGNAL_BUY_AND_SELL           = 2
};

enum TDI_VISUAL_STRENGTH_FILTER
{
   VISUAL_STRONG_ONLY            = 0,
   VISUAL_WEAK_MEDIUM_STRONG     = 1
};

enum TDI_SUCCESS_MODEL
{
   MODEL_FIXED_BARS_FORWARD      = 0,
   MODEL_ATR_TARGET_BEFORE_STOP  = 1,
   MODEL_RR_ATR_STOP_TARGET      = 2
};

enum SAME_BAR_POLICY
{
   SAME_BAR_STOP_FIRST           = 0,
   SAME_BAR_TARGET_FIRST         = 1
};

input string Section_About = "Research scanner only - no trading functions";
input TDI_SIGNAL_MODE InpSignalMode = SIGNAL_VISUAL_BUY_STATE_ENTRY;
input TDI_SIGNAL_SIDE InpSignalSide = SIGNAL_BUY_AND_SELL;
input TDI_VISUAL_STRENGTH_FILTER InpVisualStrengthFilter = VISUAL_STRONG_ONLY;
input bool   InpOnlyCountStateTransitions = true;

input string Section_TDI_Settings = "TDI settings";
input int    RSI_Period = 14;
input int    RSI_Price = 0;
input int    Volatility_Band = 40;
input double Volatility_Band_Multiplier = 1.6185;
input int    RSI_Price_Line = 2;
input int    RSI_Price_Type = 0;
input int    Trade_Signal_Line = 7;
input int    Trade_Signal_Type = 0;
input int    Trade_Signal_Line2 = 50;
input int    Trade_Signal2_Type = 0;

input string Section_Basic_Cross_Filters = "Used when InpSignalMode = SIGNAL_BASIC_CROSS_BUY";
input bool   InpRequireGreenAbove50 = true;
input bool   InpAllowCrossUpThrough50 = true;
input bool   InpRequireBullishSlope = true;
input bool   InpRequireRedRisingOrFlat = false;
input bool   InpAvoidGreenAbove68 = true;

input string Section_Success_Model = "Success model";
input TDI_SUCCESS_MODEL InpSuccessModel = MODEL_FIXED_BARS_FORWARD;
input int    ForwardBars_H1 = 24;
input int    ForwardBars_H4 = 12;
input int    ForwardBars_D1 = 5;
input int    MaxForwardBars = 24;
input int    ATR_Period = 14;
input double TP_ATR = 1.0;
input double SL_ATR = 1.0;
input double TP_R = 1.0;
input SAME_BAR_POLICY InpSameBarPolicy = SAME_BAR_STOP_FIRST;

input string Section_Output = "CSV output";
input bool   InpAppendToExistingCsv = true;
input string InpSignalCsvFile = "LPH_TDI_signal_results.csv";
input string InpSummaryCsvFile = "LPH_TDI_summary_by_timeframe.csv";
input datetime InpStartDate = D'1970.01.01 00:00';
input datetime InpEndDate = D'2099.12.31 23:59';

double g_rsi[];
double g_green[];
double g_red[];
double g_yellow[];
double g_bandUpper[];
double g_bandLower[];

int    g_totalSignals = 0;
int    g_buySignals = 0;
int    g_sellSignals = 0;
int    g_wins = 0;
int    g_losses = 0;
double g_sumFavPips = 0.0;
double g_sumAdvPips = 0.0;
double g_sumResult = 0.0;
bool   g_scanned = false;

//+------------------------------------------------------------------+
struct SignalOutcome
{
   string   successModel;
   double   result;
   string   winLoss;
   double   maxFavorablePips;
   double   maxAdversePips;
   datetime exitTime;
   double   exitPrice;
};

//+------------------------------------------------------------------+
int OnInit()
{
   Print("LPH_TDI_Basic_Signal_Backtest_EA loaded. Scanner only; no trading functions.");
   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
void OnTick()
{
   // Intentionally empty. The scan runs once at tester shutdown so it can
   // evaluate only fully closed historical candles and their forward bars.
}

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   if(reason == REASON_INITFAILED)
      return;

   if(!g_scanned)
      RunScan();
}

//+------------------------------------------------------------------+
void RunScan()
{
   g_scanned = true;
   ResetStats();

   if(Bars < MinimumBarsNeeded())
   {
      Print("LPH_TDI scan skipped: not enough bars. Bars=", Bars,
            " required=", MinimumBarsNeeded());
      return;
   }

   PrepareArrays();
   CalculateTdiBuffers();

   int signalHandle = OpenCsv(InpSignalCsvFile, SignalHeader());
   int summaryHandle = OpenCsv(InpSummaryCsvFile, SummaryHeader());

   if(signalHandle == INVALID_HANDLE || summaryHandle == INVALID_HANDLE)
   {
      Print("LPH_TDI scan failed: could not open CSV output files.");
      if(signalHandle != INVALID_HANDLE) FileClose(signalHandle);
      if(summaryHandle != INVALID_HANDLE) FileClose(summaryHandle);
      return;
   }

   int forwardBars = ForwardBarsForRun();
   int oldestShift = OldestUsableShift();
   int newestSignalShift = forwardBars + 1;

   for(int shift = oldestShift; shift >= newestSignalShift; shift--)
   {
      if(Time[shift] < InpStartDate || Time[shift] > InpEndDate)
         continue;

      string signalType = "";
      int signalDirection = 0;
      if(!IsSignal(shift, signalType, signalDirection))
         continue;

      SignalOutcome outcome;
      EvaluateOutcome(shift, forwardBars, signalDirection, outcome);
      WriteSignalRow(signalHandle, shift, signalType, outcome);
      Accumulate(outcome, signalDirection);
   }

   WriteSummaryRow(summaryHandle);
   FileClose(signalHandle);
   FileClose(summaryHandle);

   PrintSummary();
}

//+------------------------------------------------------------------+
void ResetStats()
{
   g_totalSignals = 0;
   g_buySignals = 0;
   g_sellSignals = 0;
   g_wins = 0;
   g_losses = 0;
   g_sumFavPips = 0.0;
   g_sumAdvPips = 0.0;
   g_sumResult = 0.0;
}

//+------------------------------------------------------------------+
int MinimumBarsNeeded()
{
   int maxTdiPeriod = MathMax(Volatility_Band,
                              MathMax(RSI_Price_Line,
                              MathMax(Trade_Signal_Line, Trade_Signal_Line2)));
   return(maxTdiPeriod + ATR_Period + ForwardBarsForRun() + 20);
}

//+------------------------------------------------------------------+
void PrepareArrays()
{
   ArrayResize(g_rsi, Bars);
   ArrayResize(g_green, Bars);
   ArrayResize(g_red, Bars);
   ArrayResize(g_yellow, Bars);
   ArrayResize(g_bandUpper, Bars);
   ArrayResize(g_bandLower, Bars);

   ArraySetAsSeries(g_rsi, true);
   ArraySetAsSeries(g_green, true);
   ArraySetAsSeries(g_red, true);
   ArraySetAsSeries(g_yellow, true);
   ArraySetAsSeries(g_bandUpper, true);
   ArraySetAsSeries(g_bandLower, true);

   ArrayInitialize(g_rsi, EMPTY_VALUE);
   ArrayInitialize(g_green, EMPTY_VALUE);
   ArrayInitialize(g_red, EMPTY_VALUE);
   ArrayInitialize(g_yellow, EMPTY_VALUE);
   ArrayInitialize(g_bandUpper, EMPTY_VALUE);
   ArrayInitialize(g_bandLower, EMPTY_VALUE);
}

//+------------------------------------------------------------------+
void CalculateTdiBuffers()
{
   for(int shift = Bars - 1; shift >= 0; shift--)
      g_rsi[shift] = iRSI(NULL, 0, RSI_Period, RSI_Price, shift);

   int oldest = OldestCalculationShift();
   for(int i = oldest; i >= 0; i--)
   {
      g_green[i]  = iMAOnArray(g_rsi, 0, RSI_Price_Line,    0, RSI_Price_Type,    i);
      g_red[i]    = iMAOnArray(g_rsi, 0, Trade_Signal_Line, 0, Trade_Signal_Type, i);
      g_yellow[i] = BandMiddle(i);

      double deviation = BandStdDev(i, g_yellow[i]);
      g_bandUpper[i] = g_yellow[i] + (Volatility_Band_Multiplier * deviation);
      g_bandLower[i] = g_yellow[i] - (Volatility_Band_Multiplier * deviation);
   }
}

//+------------------------------------------------------------------+
int OldestCalculationShift()
{
   int maxPeriod = MathMax(Volatility_Band,
                           MathMax(RSI_Price_Line,
                           MathMax(Trade_Signal_Line, Trade_Signal_Line2)));
   return(MathMax(0, Bars - maxPeriod - 2));
}

//+------------------------------------------------------------------+
int OldestUsableShift()
{
   return(MathMax(0, OldestCalculationShift() - 1));
}

//+------------------------------------------------------------------+
double BandMiddle(const int shift)
{
   double sum = 0.0;
   for(int i = shift; i < shift + Volatility_Band; i++)
      sum += g_rsi[i];
   return(sum / MathMax(1, Volatility_Band));
}

//+------------------------------------------------------------------+
double BandStdDev(const int shift, const double mean)
{
   double sumSq = 0.0;
   for(int i = shift; i < shift + Volatility_Band; i++)
      sumSq += MathPow(g_rsi[i] - mean, 2.0);
   return(MathSqrt(sumSq / MathMax(1, Volatility_Band)));
}

//+------------------------------------------------------------------+
bool IsSignal(const int shift, string &signalType, int &signalDirection)
{
   if(InpSignalMode == SIGNAL_VISUAL_BUY_STATE_ENTRY)
   {
      string nowType = VisualSignalState(shift, signalDirection);
      if(nowType == "")
         return(false);
      if(!SignalSideAllowed(signalDirection))
         return(false);
      if(!VisualStrengthAllowed(nowType))
         return(false);

      if(InpOnlyCountStateTransitions)
      {
         int previousDirection = 0;
         string previousType = VisualSignalState(shift + 1, previousDirection);
         if(previousType != "" &&
            previousDirection == signalDirection &&
            VisualStrengthAllowed(previousType))
            return(false);
      }

      signalType = nowType;
      return(true);
   }

   return(IsBasicCrossSignal(shift, signalType, signalDirection));
}

//+------------------------------------------------------------------+
string VisualSignalState(const int shift, int &signalDirection)
{
   signalDirection = 0;
   double green = g_green[shift];
   double red = g_red[shift];
   double yellow = g_yellow[shift];

   if(green <= 32.0 || green >= 68.0)
      return("");

   // Exact closed-bar recreation of Traders_Dynamic_Index_VISUAL_ALERTS
   // Weak/Strong/Medium Buy/Sell label rules, using MdZone as the yellow MBL.
   if(green > red)
   {
      signalDirection = 1;
      if(red < yellow && green < yellow)
         return("Weak Buy");
      if(red > yellow)
         return("Strong Buy");
      if(green > yellow && red < yellow)
         return("Medium Buy");
      return("Buy");
   }

   if(green < red)
   {
      signalDirection = -1;
      if(red > yellow && green > yellow)
         return("Weak Sell");
      if(red < yellow)
         return("Strong Sell");
      if(green < yellow && red > yellow)
         return("Medium Sell");
      return("Sell");
   }

   return("");
}

//+------------------------------------------------------------------+
bool IsBasicCrossSignal(const int shift, string &signalType, int &signalDirection)
{
   double green = g_green[shift];
   double red = g_red[shift];
   double prevGreen = g_green[shift + 1];
   double prevRed = g_red[shift + 1];

   bool crossUp = (green > red && prevGreen <= prevRed);
   bool crossDown = (green < red && prevGreen >= prevRed);
   bool aboveOrCrossing50 = (green > 50.0 || (InpAllowCrossUpThrough50 && prevGreen <= 50.0 && green > prevGreen));
   bool belowOrCrossing50 = (green < 50.0 || (InpAllowCrossUpThrough50 && prevGreen >= 50.0 && green < prevGreen));
   bool bullishSlope = (!InpRequireBullishSlope || green > prevGreen);
   bool bearishSlope = (!InpRequireBullishSlope || green < prevGreen);
   bool redOk = (!InpRequireRedRisingOrFlat || red >= prevRed);
   bool redSellOk = (!InpRequireRedRisingOrFlat || red <= prevRed);
   bool notExhausted = (!InpAvoidGreenAbove68 || green < 68.0);
   bool notOversold = (!InpAvoidGreenAbove68 || green > 32.0);

   if(crossUp && (!InpRequireGreenAbove50 || aboveOrCrossing50) &&
      bullishSlope && redOk && notExhausted && SignalSideAllowed(1))
   {
      signalDirection = 1;
      signalType = "Basic Cross Buy";
      return(true);
   }

   if(crossDown && (!InpRequireGreenAbove50 || belowOrCrossing50) &&
      bearishSlope && redSellOk && notOversold && SignalSideAllowed(-1))
   {
      signalDirection = -1;
      signalType = "Basic Cross Sell";
      return(true);
   }

   return(false);
}

//+------------------------------------------------------------------+
bool SignalSideAllowed(const int signalDirection)
{
   if(signalDirection > 0)
      return(InpSignalSide == SIGNAL_BUY_ONLY || InpSignalSide == SIGNAL_BUY_AND_SELL);
   if(signalDirection < 0)
      return(InpSignalSide == SIGNAL_SELL_ONLY || InpSignalSide == SIGNAL_BUY_AND_SELL);
   return(false);
}

//+------------------------------------------------------------------+
bool VisualStrengthAllowed(const string signalType)
{
   if(InpVisualStrengthFilter == VISUAL_WEAK_MEDIUM_STRONG)
      return(StringFind(signalType, "Buy") >= 0 || StringFind(signalType, "Sell") >= 0);
   return(signalType == "Strong Buy" || signalType == "Strong Sell");
}

//+------------------------------------------------------------------+
void EvaluateOutcome(const int signalShift,
                     const int forwardBars,
                     const int signalDirection,
                     SignalOutcome &outcome)
{
   outcome.successModel = SuccessModelName();
   outcome.result = 0.0;
   outcome.winLoss = "LOSS";
   outcome.maxFavorablePips = 0.0;
   outcome.maxAdversePips = 0.0;
   outcome.exitTime = Time[signalShift];
   outcome.exitPrice = Close[signalShift];

   double entry = Close[signalShift];
   double pip = PipSize();
   int steps = MathMin(forwardBars, signalShift - 1);

   double maxHigh = High[signalShift - 1];
   double minLow = Low[signalShift - 1];
   for(int step = 1; step <= steps; step++)
   {
      int sh = signalShift - step;
      if(High[sh] > maxHigh) maxHigh = High[sh];
      if(Low[sh] < minLow) minLow = Low[sh];
   }

   if(signalDirection > 0)
   {
      outcome.maxFavorablePips = (maxHigh - entry) / pip;
      outcome.maxAdversePips = (entry - minLow) / pip;
   }
   else
   {
      outcome.maxFavorablePips = (entry - minLow) / pip;
      outcome.maxAdversePips = (maxHigh - entry) / pip;
   }

   if(InpSuccessModel == MODEL_FIXED_BARS_FORWARD)
   {
      EvaluateFixedBars(signalShift, steps, signalDirection, entry, outcome);
      return;
   }

   if(InpSuccessModel == MODEL_ATR_TARGET_BEFORE_STOP)
   {
      EvaluateAtrTargetStop(signalShift, steps, signalDirection, entry, outcome);
      return;
   }

   EvaluateRr(signalShift, steps, signalDirection, entry, outcome);
}

//+------------------------------------------------------------------+
void EvaluateFixedBars(const int signalShift,
                       const int steps,
                       const int signalDirection,
                       const double entry,
                       SignalOutcome &outcome)
{
   int exitShift = signalShift - steps;
   double riskPips = AtrRiskPips(signalShift);
   double movePips = signalDirection * (Close[exitShift] - entry) / PipSize();

   outcome.exitTime = Time[exitShift];
   outcome.exitPrice = Close[exitShift];
   outcome.result = SafeDivide(movePips, riskPips);
   outcome.winLoss = (movePips > 0.0 ? "WIN" : "LOSS");
}

//+------------------------------------------------------------------+
void EvaluateAtrTargetStop(const int signalShift,
                           const int steps,
                           const int signalDirection,
                           const double entry,
                           SignalOutcome &outcome)
{
   double atr = iATR(NULL, 0, ATR_Period, signalShift);
   double target = entry + (signalDirection * TP_ATR * atr);
   double stop = entry - (signalDirection * SL_ATR * atr);
   double riskPips = MathMax(MathAbs(entry - stop) / PipSize(), 0.0000001);

   bool hit = false;
   for(int step = 1; step <= steps; step++)
   {
      int sh = signalShift - step;
      bool hitTarget = (signalDirection > 0 ? High[sh] >= target : Low[sh] <= target);
      bool hitStop = (signalDirection > 0 ? Low[sh] <= stop : High[sh] >= stop);

      if(hitTarget && hitStop)
      {
         if(InpSameBarPolicy == SAME_BAR_TARGET_FIRST)
            SetTargetWin(sh, target, TP_ATR / MathMax(SL_ATR, 0.0000001), outcome);
         else
            SetStopLoss(sh, stop, outcome);
         hit = true;
         break;
      }

      if(hitTarget)
      {
         SetTargetWin(sh, target, TP_ATR / MathMax(SL_ATR, 0.0000001), outcome);
         hit = true;
         break;
      }

      if(hitStop)
      {
         SetStopLoss(sh, stop, outcome);
         hit = true;
         break;
      }
   }

   if(!hit)
      SetTimeoutResult(signalShift - steps, signalDirection, entry, riskPips, outcome);
}

//+------------------------------------------------------------------+
void EvaluateRr(const int signalShift,
                const int steps,
                const int signalDirection,
                const double entry,
                SignalOutcome &outcome)
{
   double atr = iATR(NULL, 0, ATR_Period, signalShift);
   double stop = entry - (signalDirection * SL_ATR * atr);
   double target = entry + (signalDirection * TP_R * MathAbs(entry - stop));
   double riskPips = MathMax(MathAbs(entry - stop) / PipSize(), 0.0000001);

   bool hit = false;
   for(int step = 1; step <= steps; step++)
   {
      int sh = signalShift - step;
      bool hitTarget = (signalDirection > 0 ? High[sh] >= target : Low[sh] <= target);
      bool hitStop = (signalDirection > 0 ? Low[sh] <= stop : High[sh] >= stop);

      if(hitTarget && hitStop)
      {
         if(InpSameBarPolicy == SAME_BAR_TARGET_FIRST)
            SetTargetWin(sh, target, TP_R, outcome);
         else
            SetStopLoss(sh, stop, outcome);
         hit = true;
         break;
      }

      if(hitTarget)
      {
         SetTargetWin(sh, target, TP_R, outcome);
         hit = true;
         break;
      }

      if(hitStop)
      {
         SetStopLoss(sh, stop, outcome);
         hit = true;
         break;
      }
   }

   if(!hit)
      SetTimeoutResult(signalShift - steps, signalDirection, entry, riskPips, outcome);
}

//+------------------------------------------------------------------+
void SetTargetWin(const int shift,
                  const double price,
                  const double resultR,
                  SignalOutcome &outcome)
{
   outcome.exitTime = Time[shift];
   outcome.exitPrice = price;
   outcome.result = resultR;
   outcome.winLoss = "WIN";
}

//+------------------------------------------------------------------+
void SetStopLoss(const int shift,
                 const double price,
                 SignalOutcome &outcome)
{
   outcome.exitTime = Time[shift];
   outcome.exitPrice = price;
   outcome.result = -1.0;
   outcome.winLoss = "LOSS";
}

//+------------------------------------------------------------------+
void SetTimeoutResult(const int exitShift,
                      const int signalDirection,
                      const double entry,
                      const double riskPips,
                      SignalOutcome &outcome)
{
   double movePips = signalDirection * (Close[exitShift] - entry) / PipSize();
   outcome.exitTime = Time[exitShift];
   outcome.exitPrice = Close[exitShift];
   outcome.result = SafeDivide(movePips, riskPips);
   outcome.winLoss = (movePips > 0.0 ? "WIN" : "LOSS");
}

//+------------------------------------------------------------------+
double AtrRiskPips(const int shift)
{
   double atr = iATR(NULL, 0, ATR_Period, shift);
   return(MathMax((atr * MathMax(SL_ATR, 0.0000001)) / PipSize(), 0.0000001));
}

//+------------------------------------------------------------------+
void Accumulate(const SignalOutcome &outcome, const int signalDirection)
{
   g_totalSignals++;
   if(signalDirection > 0)
      g_buySignals++;
   if(signalDirection < 0)
      g_sellSignals++;

   if(outcome.winLoss == "WIN")
      g_wins++;
   else
      g_losses++;

   g_sumFavPips += outcome.maxFavorablePips;
   g_sumAdvPips += outcome.maxAdversePips;
   g_sumResult += outcome.result;
}

//+------------------------------------------------------------------+
void WriteSignalRow(const int handle,
                    const int shift,
                    const string signalType,
                    const SignalOutcome &outcome)
{
   FileWrite(handle,
             Symbol(),
             PeriodToString(Period()),
             TimeToString(Time[shift], TIME_DATE | TIME_MINUTES),
             DoubleToString(Close[shift], Digits),
             signalType,
             DoubleToString(g_green[shift], 4),
             DoubleToString(g_red[shift], 4),
             DoubleToString(g_yellow[shift], 4),
             DoubleToString(g_bandUpper[shift], 4),
             DoubleToString(g_bandLower[shift], 4),
             outcome.successModel,
             DoubleToString(outcome.result, 4),
             outcome.winLoss,
             DoubleToString(outcome.maxFavorablePips, 2),
             DoubleToString(outcome.maxAdversePips, 2),
             TimeToString(outcome.exitTime, TIME_DATE | TIME_MINUTES),
             DoubleToString(outcome.exitPrice, Digits));
}

//+------------------------------------------------------------------+
void WriteSummaryRow(const int handle)
{
   double winRate = 0.0;
   double avgFav = 0.0;
   double avgAdv = 0.0;
   double avgResult = 0.0;

   if(g_totalSignals > 0)
   {
      winRate = 100.0 * g_wins / g_totalSignals;
      avgFav = g_sumFavPips / g_totalSignals;
      avgAdv = g_sumAdvPips / g_totalSignals;
      avgResult = g_sumResult / g_totalSignals;
   }

   FileWrite(handle,
             Symbol(),
             PeriodToString(Period()),
             g_totalSignals,
             g_buySignals,
             g_sellSignals,
             g_wins,
             g_losses,
             DoubleToString(winRate, 2),
             DoubleToString(avgFav, 2),
             DoubleToString(avgAdv, 2),
             DoubleToString(avgResult, 4));
}

//+------------------------------------------------------------------+
void PrintSummary()
{
   double winRate = (g_totalSignals > 0 ? 100.0 * g_wins / g_totalSignals : 0.0);
   double avgFav = (g_totalSignals > 0 ? g_sumFavPips / g_totalSignals : 0.0);
   double avgAdv = (g_totalSignals > 0 ? g_sumAdvPips / g_totalSignals : 0.0);
   double avgResult = (g_totalSignals > 0 ? g_sumResult / g_totalSignals : 0.0);

   Print("LPH_TDI_BASIC_SUMMARY",
         " symbol=", Symbol(),
         " timeframe=", PeriodToString(Period()),
         " model=", SuccessModelName(),
         " total_signals=", g_totalSignals,
         " buy_signals=", g_buySignals,
         " sell_signals=", g_sellSignals,
         " wins=", g_wins,
         " losses=", g_losses,
         " win_rate=", DoubleToString(winRate, 2), "%",
         " avg_favorable_pips=", DoubleToString(avgFav, 2),
         " avg_adverse_pips=", DoubleToString(avgAdv, 2),
         " avg_result=", DoubleToString(avgResult, 4));
}

//+------------------------------------------------------------------+
int OpenCsv(const string fileName, const string header)
{
   if(!InpAppendToExistingCsv)
      FileDelete(fileName);

   int handle = FileOpen(fileName, FILE_READ | FILE_WRITE | FILE_CSV | FILE_ANSI, ',');
   if(handle == INVALID_HANDLE)
      handle = FileOpen(fileName, FILE_WRITE | FILE_CSV | FILE_ANSI, ',');

   if(handle == INVALID_HANDLE)
      return(INVALID_HANDLE);

   if(FileSize(handle) <= 0)
      WriteHeader(handle, header);
   else
      FileSeek(handle, 0, SEEK_END);

   return(handle);
}

//+------------------------------------------------------------------+
void WriteHeader(const int handle, const string header)
{
   FileWriteString(handle, header + "\r\n");
}

//+------------------------------------------------------------------+
string SignalHeader()
{
   return("symbol,timeframe,signal_time,signal_price,signal_type,tdi_green,tdi_red,tdi_yellow,tdi_band_upper,tdi_band_lower,success_model,result,win_loss,max_favorable_pips,max_adverse_pips,exit_time,exit_price");
}

//+------------------------------------------------------------------+
string SummaryHeader()
{
   return("symbol,timeframe,total_signals,buy_signals,sell_signals,wins,losses,win_rate,avg_favorable_pips,avg_adverse_pips,avg_result");
}

//+------------------------------------------------------------------+
int ForwardBarsForRun()
{
   if(InpSuccessModel != MODEL_FIXED_BARS_FORWARD)
      return(MathMax(1, MaxForwardBars));

   if(Period() == PERIOD_H1)
      return(MathMax(1, ForwardBars_H1));
   if(Period() == PERIOD_H4)
      return(MathMax(1, ForwardBars_H4));
   if(Period() == PERIOD_D1)
      return(MathMax(1, ForwardBars_D1));

   return(MathMax(1, MaxForwardBars));
}

//+------------------------------------------------------------------+
string SuccessModelName()
{
   if(InpSuccessModel == MODEL_FIXED_BARS_FORWARD)
      return("MODEL_A_FIXED_BARS_FORWARD");
   if(InpSuccessModel == MODEL_ATR_TARGET_BEFORE_STOP)
      return("MODEL_B_ATR_TARGET_BEFORE_STOP");
   return("MODEL_C_RR_ATR_STOP_TARGET");
}

//+------------------------------------------------------------------+
string PeriodToString(const int period)
{
   if(period == PERIOD_M1) return("M1");
   if(period == PERIOD_M5) return("M5");
   if(period == PERIOD_M15) return("M15");
   if(period == PERIOD_M30) return("M30");
   if(period == PERIOD_H1) return("H1");
   if(period == PERIOD_H4) return("H4");
   if(period == PERIOD_D1) return("D1");
   if(period == PERIOD_W1) return("W1");
   if(period == PERIOD_MN1) return("MN1");
   return(IntegerToString(period));
}

//+------------------------------------------------------------------+
double PipSize()
{
   if(Digits == 3 || Digits == 5)
      return(Point * 10.0);
   return(Point);
}

//+------------------------------------------------------------------+
double SafeDivide(const double numerator, const double denominator)
{
   if(MathAbs(denominator) < 0.0000001)
      return(0.0);
   return(numerator / denominator);
}
//+------------------------------------------------------------------+
