//+------------------------------------------------------------------+
//|                                               PAXG_Dashboard.mq4 |
//+------------------------------------------------------------------+
#property strict

// --- Visual inputs for the on-chart line ---
input color  LineColor   = clrGold;        // PAXG price line color
input int    LineWidth   = 1;              // Line thickness
input ENUM_LINE_STYLE LineStyle = STYLE_SOLID; // Line style
input color  LabelColor  = clrGold;        // Label text color
input int    LabelFontSize = 9;            // Label font size

// --- Object names (kept constant so we update instead of duplicate) ---
#define OBJ_LINE  "PAXG_Live_Line"
#define OBJ_LABEL "PAXG_Live_Label"

// OnInit runs once when you drag the EA to the chart
int OnInit()
{
   // Set a timer to fetch the price every 10 seconds.
   // We use 10 seconds to avoid getting IP-banned by Binance for spamming.
   EventSetTimer(10);

   // Run it immediately once on startup so you don't have to wait 10 seconds
   FetchPAXGPrice();

   return(INIT_SUCCEEDED);
}

// OnDeinit runs when you remove the EA from the chart
void OnDeinit(const int reason)
{
   // Clean up the timer, the dashboard text, and the chart objects
   EventKillTimer();
   Comment("");
   ObjectDelete(0, OBJ_LINE);
   ObjectDelete(0, OBJ_LABEL);
}

// OnTimer loops endlessly based on the interval we set in OnInit
void OnTimer()
{
   FetchPAXGPrice();
}

// The core logic to grab the price and display it
void FetchPAXGPrice()
{
   string url = "https://api.binance.com/api/v3/ticker/price?symbol=PAXGUSDT";
   string cookie = "";
   string headers = "User-Agent: Mozilla/5.0\r\n";
   char post[], result[];

   // Execute the WebRequest
   int res = WebRequest("GET", url, cookie, NULL, 5000, post, 0, result, headers);

   if(res == -1) {
      Comment("Error fetching PAXG. Check Tools -> Options -> Expert Advisors.");
      return;
   }

   // Convert response and isolate the price
   string json_response = CharArrayToString(result);
   int price_start = StringFind(json_response, "\"price\":\"");

   if (price_start != -1) {
      price_start += 9;
      int price_end = StringFind(json_response, "\"", price_start);

      if (price_end != -1) {
         string price_str = StringSubstr(json_response, price_start, price_end - price_start);
         double price_val = StringToDouble(price_str);
         string stamp     = TimeToStr(TimeLocal(), TIME_SECONDS);

         // Display the live dashboard on the chart
         Comment("\n--- WEEKEND LIQUIDITY DASHBOARD ---\n\n",
                 "   Live PAXG Price: $", price_str, "\n",
                 "   Last Updated: ", stamp);

         // Draw / update the on-chart line and its label
         DrawPriceLine(price_val, price_str, stamp);
      }
   }
}

// Draws (or moves) a horizontal line at the live PAXG price with a label
void DrawPriceLine(double price_val, string price_str, string stamp)
{
   if(price_val <= 0) return; // guard against bad parse

   // --- Horizontal line ---
   if(ObjectFind(0, OBJ_LINE) < 0)
   {
      ObjectCreate(0, OBJ_LINE, OBJ_HLINE, 0, 0, price_val);
      ObjectSetInteger(0, OBJ_LINE, OBJPROP_BACK, false);
      ObjectSetInteger(0, OBJ_LINE, OBJPROP_SELECTABLE, false);
   }
   ObjectSetDouble (0, OBJ_LINE, OBJPROP_PRICE1, price_val);
   ObjectSetInteger(0, OBJ_LINE, OBJPROP_COLOR, LineColor);
   ObjectSetInteger(0, OBJ_LINE, OBJPROP_WIDTH, LineWidth);
   ObjectSetInteger(0, OBJ_LINE, OBJPROP_STYLE, LineStyle);

   // --- Label anchored at the latest bar, sitting on the line ---
   string txt = "PAXG $" + price_str + "  |  " + stamp;
   datetime anchor = Time[0];

   if(ObjectFind(0, OBJ_LABEL) < 0)
   {
      ObjectCreate(0, OBJ_LABEL, OBJ_TEXT, 0, anchor, price_val);
      ObjectSetInteger(0, OBJ_LABEL, OBJPROP_SELECTABLE, false);
      ObjectSetInteger(0, OBJ_LABEL, OBJPROP_ANCHOR, ANCHOR_LEFT_LOWER);
   }
   ObjectSetInteger(0, OBJ_LABEL, OBJPROP_TIME1, anchor);
   ObjectSetDouble (0, OBJ_LABEL, OBJPROP_PRICE1, price_val);
   ObjectSetString (0, OBJ_LABEL, OBJPROP_TEXT, txt);
   ObjectSetInteger(0, OBJ_LABEL, OBJPROP_COLOR, LabelColor);
   ObjectSetInteger(0, OBJ_LABEL, OBJPROP_FONTSIZE, LabelFontSize);

   ChartRedraw(0);
}
