//+------------------------------------------------------------------+
//| LPH_TDI_Coach_T_Filter_v4_STRICT_D1_50EMA_TDI.mq5                |
//| Native MT5 implementation of the Coach-T TDI filter.             |
//| The calculation uses closed-bar RSI, SMA-smoothed TDI lines,     |
//| volatility bands and optional EMA trend agreement.               |
//+------------------------------------------------------------------+
#property strict
#property indicator_separate_window
#property indicator_minimum 0
#property indicator_maximum 100
#property indicator_buffers 7
#property indicator_plots   5
#property indicator_label1 "TDI Green" 
#property indicator_type1 DRAW_LINE
#property indicator_color1 clrLime
#property indicator_width1 2
#property indicator_label2 "TDI Red"
#property indicator_type2 DRAW_LINE
#property indicator_color2 clrRed
#property indicator_width2 1
#property indicator_label3 "TDI Yellow"
#property indicator_type3 DRAW_LINE
#property indicator_color3 clrGold
#property indicator_width3 2
#property indicator_label4 "TDI Upper Band"
#property indicator_type4 DRAW_LINE
#property indicator_color4 clrDodgerBlue
#property indicator_width4 1
#property indicator_label5 "TDI Lower Band"
#property indicator_type5 DRAW_LINE
#property indicator_color5 clrDodgerBlue
#property indicator_width5 1
#property indicator_level1 32
#property indicator_level2 50
#property indicator_level3 68
#property indicator_levelcolor clrDimGray
#property indicator_levelstyle STYLE_DOT

enum BiasMode { Bias_Neutral=0, Bias_Bullish=1, Bias_Bearish=2 };
input int RSI_Period=14;
input int Volatility_Band_Period=40;
input int RSI_Price_Line_MA=2;
input int Trade_Signal_Line_MA=7;
input int Market_Base_Line_MA=50;
input double Band_Deviation=1.6185;
input BiasMode External_Bias=Bias_Neutral;
input bool Use_EMA_Filter=true;
input int Fast_EMA_Period=50;
input int Slow_EMA_Period=200;
input bool Require_200EMA_Agreement=true;
input int Signal_Shift=1;
input double Slope_Minimum=0.80;
input double Yellow_Flat_Tolerance=0.20;
input double Chop_Zone_Around_50=5.0;
input double Min_Band_Width=10.0;
input bool Show_Status_Label=true;
input bool Enable_Alerts=false;
input bool Restrict_Alerts_To_Timeframe=true;
input ENUM_TIMEFRAMES Alert_Timeframe=PERIOD_D1;

double GreenBuffer[],RedBuffer[],YellowBuffer[],UpperBandBuffer[],LowerBandBuffer[],RsiRawBuffer[],BandBasisBuffer[];
int rsi_handle=INVALID_HANDLE,ema_fast=INVALID_HANDLE,ema_slow=INVALID_HANDLE;
string label_name;
datetime last_alert=0;

int OnInit()
{
   if(RSI_Period<2 || Volatility_Band_Period<2) return(INIT_PARAMETERS_INCORRECT);
   SetIndexBuffer(0,GreenBuffer,INDICATOR_DATA); SetIndexBuffer(1,RedBuffer,INDICATOR_DATA);
   SetIndexBuffer(2,YellowBuffer,INDICATOR_DATA); SetIndexBuffer(3,UpperBandBuffer,INDICATOR_DATA);
   SetIndexBuffer(4,LowerBandBuffer,INDICATOR_DATA); SetIndexBuffer(5,RsiRawBuffer,INDICATOR_CALCULATIONS); SetIndexBuffer(6,BandBasisBuffer,INDICATOR_CALCULATIONS);
   ArraySetAsSeries(GreenBuffer,true); ArraySetAsSeries(RedBuffer,true); ArraySetAsSeries(YellowBuffer,true); ArraySetAsSeries(UpperBandBuffer,true); ArraySetAsSeries(LowerBandBuffer,true); ArraySetAsSeries(RsiRawBuffer,true); ArraySetAsSeries(BandBasisBuffer,true);
   rsi_handle=iRSI(_Symbol,_Period,RSI_Period,PRICE_CLOSE);
   ema_fast=iMA(_Symbol,_Period,Fast_EMA_Period,0,MODE_EMA,PRICE_CLOSE);
   ema_slow=iMA(_Symbol,_Period,Slow_EMA_Period,0,MODE_EMA,PRICE_CLOSE);
   if(rsi_handle==INVALID_HANDLE || ema_fast==INVALID_HANDLE || ema_slow==INVALID_HANDLE) return(INIT_FAILED);
   label_name="LPH_TDI_Status_"+(string)ChartID();
   IndicatorSetString(INDICATOR_SHORTNAME,"LPH TDI Coach T Filter v4");
   return(INIT_SUCCEEDED);
}
void OnDeinit(const int reason){ if(rsi_handle!=INVALID_HANDLE) IndicatorRelease(rsi_handle); if(ema_fast!=INVALID_HANDLE) IndicatorRelease(ema_fast); if(ema_slow!=INVALID_HANDLE) IndicatorRelease(ema_slow); ObjectDelete(0,label_name); }

double SMA(const double &a[],int shift,int period,int total){ if(shift+period>total) return(EMPTY_VALUE); double s=0; for(int k=0;k<period;k++) s+=a[shift+k]; return(s/period); }
double SD(const double &a[],int shift,int period,int total,double mean){ if(mean==EMPTY_VALUE || shift+period>total) return(EMPTY_VALUE); double s=0; for(int k=0;k<period;k++){ double d=a[shift+k]-mean; s+=d*d; } return(MathSqrt(s/period)); }
string Status(int s,const double &emaF[],const double &emaS[],int total)
{
   if(s+2>=total || GreenBuffer[s]==EMPTY_VALUE || RedBuffer[s]==EMPTY_VALUE || YellowBuffer[s]==EMPTY_VALUE) return("WAIT: not enough TDI data");
   bool bull=GreenBuffer[s]>RedBuffer[s] && GreenBuffer[s]>YellowBuffer[s] && GreenBuffer[s]-GreenBuffer[s+1]>=Slope_Minimum;
   bool bear=GreenBuffer[s]<RedBuffer[s] && GreenBuffer[s]<YellowBuffer[s] && GreenBuffer[s+1]-GreenBuffer[s]>=Slope_Minimum;
   bool chop=MathAbs(GreenBuffer[s]-50.0)<=Chop_Zone_Around_50 && MathAbs(RedBuffer[s]-50.0)<=Chop_Zone_Around_50;
   bool emaBull=true,emaBear=true;
   if(Use_EMA_Filter && s<total){ emaBull=emaF[s]>emaS[s]; emaBear=emaF[s]<emaS[s]; if(Require_200EMA_Agreement){ emaBull=emaBull && emaF[s]>50; emaBear=emaBear && emaF[s]<50; } }
   if(chop) return("NO TRADE: TDI chop around 50");
   if(External_Bias==Bias_Bullish) bear=false; if(External_Bias==Bias_Bearish) bull=false;
   if(bull && emaBull) return("BULLISH CONTINUATION");
   if(bear && emaBear) return("BEARISH CONTINUATION");
   if(bull) return("WEAK BUY"); if(bear) return("WEAK SELL"); return("NEUTRAL");
}
void DrawStatus(const string txt)
{
   if(!Show_Status_Label) return;
   if(ObjectFind(0,label_name)<0) ObjectCreate(0,label_name,OBJ_LABEL,0,0,0);
   ObjectSetInteger(0,label_name,OBJPROP_CORNER,CORNER_LEFT_UPPER); ObjectSetInteger(0,label_name,OBJPROP_XDISTANCE,8); ObjectSetInteger(0,label_name,OBJPROP_YDISTANCE,16); ObjectSetInteger(0,label_name,OBJPROP_FONTSIZE,9); ObjectSetInteger(0,label_name,OBJPROP_COLOR,clrWhite); ObjectSetString(0,label_name,OBJPROP_TEXT,txt);
}
int OnCalculate(const int rates_total,const int prev_calculated,const datetime &time[],const double &open[],const double &high[],const double &low[],const double &close[],const long &tick_volume[],const long &volume[],const int &spread[])
{
   int need=MathMax(MathMax(Market_Base_Line_MA,Volatility_Band_Period),MathMax(Slow_EMA_Period,RSI_Period))+5; if(rates_total<need) return(0);
   double rsi[],ef[],es[]; ArraySetAsSeries(rsi,true); ArraySetAsSeries(ef,true); ArraySetAsSeries(es,true);
   if(CopyBuffer(rsi_handle,0,0,rates_total,rsi)<rates_total) return(prev_calculated);
   if(CopyBuffer(ema_fast,0,0,rates_total,ef)<rates_total || CopyBuffer(ema_slow,0,0,rates_total,es)<rates_total) return(prev_calculated);
   for(int i=rates_total-1;i>=0;i--) RsiRawBuffer[i]=rsi[i];
   int first=(prev_calculated==0)?rates_total-need:rates_total-prev_calculated+2; if(first>rates_total-1) first=rates_total-1;
   for(int i=first;i>=0;i--){ GreenBuffer[i]=SMA(RsiRawBuffer,i,RSI_Price_Line_MA,rates_total); RedBuffer[i]=SMA(RsiRawBuffer,i,Trade_Signal_Line_MA,rates_total); YellowBuffer[i]=SMA(RsiRawBuffer,i,Market_Base_Line_MA,rates_total); double b=SMA(GreenBuffer,i,Volatility_Band_Period,rates_total); BandBasisBuffer[i]=b; double d=SD(GreenBuffer,i,Volatility_Band_Period,rates_total,b); UpperBandBuffer[i]=(d==EMPTY_VALUE)?EMPTY_VALUE:b+Band_Deviation*d; LowerBandBuffer[i]=(d==EMPTY_VALUE)?EMPTY_VALUE:b-Band_Deviation*d; }
   int s=MathMax(0,Signal_Shift); string st=Status(s,ef,es,rates_total); DrawStatus(st);
   if(Enable_Alerts && (!Restrict_Alerts_To_Timeframe || _Period==Alert_Timeframe) && time[s]!=last_alert){ if(StringFind(st,"BULLISH")>=0 || StringFind(st,"BEARISH")>=0){ Alert("LPH TDI ",_Symbol," ",st); last_alert=time[s]; } }
   return(rates_total);
}
