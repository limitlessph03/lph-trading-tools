//+------------------------------------------------------------------+
//|                                  LPH_MacroTechnical_Core.mqh      |
//|                       Limitless PH Macro-Technical Alignment      |
//|                                                                  |
//|  Shared, portable logic used by BOTH:                            |
//|    - LPH_MacroBridge_EA.mq4         (writes the macro cache)      |
//|    - LPH_MacroTechnical_Alignment.mq4 (reads cache + technicals) |
//|                                                                  |
//|  Contains: symbol resolution, macro cache read/parse, EMA + TDI  |
//|  math, and macro/technical/alignment classification.             |
//|                                                                  |
//|  Decision support only. Nothing here opens, modifies, or closes  |
//|  any order. No WebRequest and no DLL imports live in this file.   |
//|                                                                  |
//|  MT5 portability note: logic is deliberately kept free of MT4-   |
//|  only order calls. iMA/iRSI/Bars have MT5 equivalents; the CFD   |
//|  mapping and classification functions are pure and reusable.     |
//+------------------------------------------------------------------+
#property strict

#ifndef __LPH_MACROTECHNICAL_CORE_MQH__
#define __LPH_MACROTECHNICAL_CORE_MQH__

//==================================================================
// Versioning & shared constants
//==================================================================
#define LPH_CORE_VERSION        "1.00"
#define LPH_CACHE_MAGIC         "LPHMTC"
#define LPH_CACHE_FORMAT_VER    1
#define LPH_SUPPORTED_SCHEMA    1
#define LPH_CACHE_FILENAME      "LPH_MacroHeatmap_Cache_v1.csv"
#define LPH_CACHE_DELIM         ','
#define LPH_NA_TOKEN            "NA"
#define LPH_MAX_CURRENCIES      64

// Bridge connection states (written into the cache STATUS row, read by panel).
#define LPH_BS_CONNECTED        "CONNECTED"
#define LPH_BS_USING_CACHE      "USING_CACHE"
#define LPH_BS_STALE            "STALE"
#define LPH_BS_AUTH_ERROR       "AUTH_ERROR"
#define LPH_BS_ENDPOINT_ERROR   "ENDPOINT_ERROR"
#define LPH_BS_INVALID          "INVALID_RESPONSE"
#define LPH_BS_STARTING         "STARTING"

//==================================================================
// Enumerations
//==================================================================
enum ENUM_LPH_DIR
  {
   LPH_DIR_BULL = 0,
   LPH_DIR_BEAR,
   LPH_DIR_NEUTRAL,
   LPH_DIR_NA
  };

enum ENUM_LPH_MACRO
  {
   LPH_MACRO_STRONG_BULL = 0,
   LPH_MACRO_BULL,
   LPH_MACRO_MIXED,
   LPH_MACRO_NEUTRAL,
   LPH_MACRO_BEAR,
   LPH_MACRO_STRONG_BEAR,
   LPH_MACRO_PARTIAL,        // e.g. XAU with only USD context available
   LPH_MACRO_UNAVAILABLE     // symbol unresolved / no macro data
  };

enum ENUM_LPH_TECH
  {
   LPH_TECH_STRONG_BUY = 0,
   LPH_TECH_BUY_SETUP,
   LPH_TECH_BUY_WATCH,
   LPH_TECH_STRONG_SELL,
   LPH_TECH_SELL_SETUP,
   LPH_TECH_SELL_WATCH,
   LPH_TECH_MIXED,
   LPH_TECH_WAITING          // insufficient D1/H4 history
  };

enum ENUM_LPH_ALIGN
  {
   LPH_ALIGN_APLUS_BUY = 0,
   LPH_ALIGN_BUY,
   LPH_ALIGN_BUY_WATCH,
   LPH_ALIGN_APLUS_SELL,
   LPH_ALIGN_SELL,
   LPH_ALIGN_SELL_WATCH,
   LPH_ALIGN_CONFLICT,
   LPH_ALIGN_NEUTRAL,
   LPH_ALIGN_STALE_DISABLED,
   LPH_ALIGN_MACRO_UNAVAILABLE
  };

enum ENUM_LPH_FRESH
  {
   LPH_FRESH_LIVE = 0,
   LPH_FRESH_AGING,
   LPH_FRESH_STALE,
   LPH_FRESH_CACHED,
   LPH_FRESH_INVALID,
   LPH_FRESH_MISSING
  };

//==================================================================
// Data structures
//==================================================================
struct LphCurrency
  {
   string            code;
   double            score7d;
   bool              has7d;
   double            score30d;
   bool              has30d;
   double            stableScore;
   bool              hasStable;
   double            compositeScore;
   bool              hasComposite;
   string            bias7d;
   string            bias30d;
   string            status;      // active / partial / standalone / no_data
   string            assetClass;  // fx / metal / index / energy / other
   string            stableLabel;
  };

struct LphCacheMeta
  {
   bool              valid;
   string            invalidReason;
   int               schemaVersion;
   string            generatedAtUtc;
   datetime          generatedEpoch;
   datetime          lastFetchEpoch;
   datetime          lastSuccessEpoch;
   string            bridgeState;
   int               consecutiveFailures;
   int               count;
  };

struct LphSymbolInfo
  {
   bool              resolved;
   bool              isFx;        // true => base/quote FX pair
   string            base;        // FX base OR single-asset code
   string            quote;       // FX quote (empty for single asset)
   string            assetCode;   // resolved macro lookup code
   string            kind;        // FX / METAL / INDEX / ENERGY / SINGLE / UNSUPPORTED
   string            cleaned;
  };

//==================================================================
// Small string helpers
//==================================================================
string LphTrim(string value)
  {
   StringTrimLeft(value);
   StringTrimRight(value);
   return(value);
  }

string LphUpper(string value)
  {
   string v = value;
   StringToUpper(v);
   return(v);
  }

// Remove any occurrence of the cache delimiter from a free-text field so a
// stray comma in a label can never corrupt the CSV column layout.
string LphSanitizeField(string value)
  {
   string out = "";
   int n = StringLen(value);
   for(int i = 0; i < n; i++)
     {
      int ch = StringGetChar(value, i);
      if(ch == (int)LPH_CACHE_DELIM || ch == 10 || ch == 13)
         out += " ";
      else
         out += CharToStr((uchar)ch);
     }
   return(LphTrim(out));
  }

// Keep only A-Z and 0-9 from an upper-cased symbol string.
string LphAlnumUpper(string value)
  {
   string up = LphUpper(value);
   string out = "";
   int n = StringLen(up);
   for(int i = 0; i < n; i++)
     {
      int ch = StringGetChar(up, i);
      if((ch >= 'A' && ch <= 'Z') || (ch >= '0' && ch <= '9'))
         out += CharToStr((uchar)ch);
     }
   return(out);
  }

bool LphIsAlphaChar(int ch)
  {
   return(ch >= 'A' && ch <= 'Z');
  }

//==================================================================
// ISO-8601 UTC timestamp -> datetime (treated as GMT wall-clock).
// Accepts "2026-07-22T06:17:41.713Z" or "2026-07-22T06:17:41Z".
// Returns 0 if the string cannot be parsed into a valid time.
//==================================================================
datetime LphIsoToEpoch(string iso)
  {
   string s = LphTrim(iso);
   if(StringLen(s) < 19)
      return(0);
   // Strip fractional seconds and trailing Z.
   int dot = StringFind(s, ".");
   if(dot >= 0)
      s = StringSubstr(s, 0, dot);
   int zpos = StringFind(s, "Z");
   if(zpos >= 0)
      s = StringSubstr(s, 0, zpos);
   // Convert to MT4 "yyyy.mm.dd hh:mi:ss".
   string out = "";
   int n = StringLen(s);
   for(int i = 0; i < n; i++)
     {
      int ch = StringGetChar(s, i);
      if(ch == '-')
         out += ".";
      else
         if(ch == 'T')
            out += " ";
         else
            out += CharToStr((uchar)ch);
     }
   datetime t = StringToTime(out);
   return(t);
  }

//==================================================================
// Currency universe (extensible). Order is not significant.
//==================================================================
string LphKnownCurrencies[] = {"USD","EUR","GBP","JPY","CHF","CAD","AUD","NZD"};

bool LphIsKnownCurrency(string code)
  {
   for(int i = 0; i < ArraySize(LphKnownCurrencies); i++)
      if(LphKnownCurrencies[i] == code)
         return(true);
   return(false);
  }

//==================================================================
// CFD / single-asset alias table. Each row: alias substring -> macro code.
// Longest / most specific aliases first so partial hits don't shadow them.
//==================================================================
string LphCfdAlias[] =
  {
   "XAUUSD","GOLD","XAU",
   "XAGUSD","SILVER","XAG",
   "NAS100","USTEC","NDX","US100",
   "SPX500","SP500","US500","SPX",
   "US30","DJ30","DOW","WS30",
   "USOIL","WTI","OIL","CL"
  };
string LphCfdCode[] =
  {
   "XAUUSD","XAUUSD","XAUUSD",
   "XAGUSD","XAGUSD","XAGUSD",
   "NAS100","NAS100","NAS100","NAS100",
   "SP500","SP500","SP500","SP500",
   "DJ30","DJ30","DJ30","DJ30",
   "USOIL","USOIL","USOIL","USOIL"
  };

string LphCfdKind(string code)
  {
   if(code == "XAUUSD" || code == "XAGUSD")
      return("METAL");
   if(code == "NAS100" || code == "SP500" || code == "DJ30")
      return("INDEX");
   if(code == "USOIL")
      return("ENERGY");
   return("SINGLE");
  }

//==================================================================
// Resolve a broker symbol to base/quote FX or a single-asset CFD code.
// Handles prefixes/suffixes: EURUSD, EURUSD.a, m.EURUSD, EURUSDzero,
// XAUUSDzero, GBPJPYpro, etc. Manual overrides win when supplied.
//==================================================================
LphSymbolInfo LphResolveSymbol(string rawSymbol, string overrideBase, string overrideQuote)
  {
   LphSymbolInfo info;
   info.resolved  = false;
   info.isFx      = false;
   info.base      = "";
   info.quote     = "";
   info.assetCode = "";
   info.kind      = "UNSUPPORTED";
   info.cleaned   = LphAlnumUpper(rawSymbol);

   string ob = LphUpper(LphTrim(overrideBase));
   string oq = LphUpper(LphTrim(overrideQuote));

   // 1) Manual overrides (highest priority).
   if(ob != "" && oq != "" && LphIsKnownCurrency(ob) && LphIsKnownCurrency(oq) && ob != oq)
     {
      info.resolved  = true;
      info.isFx      = true;
      info.base      = ob;
      info.quote     = oq;
      info.assetCode = ob + oq;
      info.kind      = "FX";
      return(info);
     }
   if(ob != "" && oq == "")
     {
      // Override to a single asset (e.g. force XAUUSD interpretation).
      info.resolved  = true;
      info.isFx      = false;
      info.base      = ob;
      info.quote     = "";
      info.assetCode = ob;
      info.kind      = LphCfdKind(ob);
      return(info);
     }

   string cleaned = info.cleaned;
   int len = StringLen(cleaned);

   // 2) Six-letter FX pair scan (both halves must be known currencies).
   for(int start = 0; start + 6 <= len; start++)
     {
      bool allAlpha = true;
      for(int k = 0; k < 6; k++)
        {
         if(!LphIsAlphaChar(StringGetChar(cleaned, start + k)))
           {
            allAlpha = false;
            break;
           }
        }
      if(!allAlpha)
         continue;
      string base  = StringSubstr(cleaned, start, 3);
      string quote = StringSubstr(cleaned, start + 3, 3);
      if(base != quote && LphIsKnownCurrency(base) && LphIsKnownCurrency(quote))
        {
         info.resolved  = true;
         info.isFx      = true;
         info.base      = base;
         info.quote     = quote;
         info.assetCode = base + quote;
         info.kind      = "FX";
         return(info);
        }
     }

   // 3) CFD / single-asset alias scan.
   for(int a = 0; a < ArraySize(LphCfdAlias); a++)
     {
      if(StringFind(cleaned, LphCfdAlias[a]) >= 0)
        {
         string code    = LphCfdCode[a];
         info.resolved  = true;
         info.isFx      = false;
         info.base      = code;
         info.quote     = "";
         info.assetCode = code;
         info.kind      = LphCfdKind(code);
         return(info);
        }
     }

   return(info);
  }

//==================================================================
// Cache reading & parsing
//==================================================================
// Split a line on the cache delimiter into parts[] (returns count).
int LphSplitLine(string line, string &parts[])
  {
   ushort sep = (ushort)LPH_CACHE_DELIM;
   int count = StringSplit(line, sep, parts);
   return(count);
  }

// Parse a numeric CSV token. "NA"/empty => not available (has=false, value 0).
void LphParseNumber(string token, double &value, bool &has)
  {
   string t = LphTrim(token);
   if(t == "" || t == LPH_NA_TOKEN)
     {
      value = 0.0;
      has   = false;
      return;
     }
   value = StringToDouble(t);
   if(!MathIsValidNumber(value))
     {
      value = 0.0;
      has   = false;
      return;
     }
   has = true;
  }

// Read and parse the shared macro cache from FILE_COMMON.
// Fills meta and the currency array. Never throws; sets meta.valid=false with
// a reason on any problem so callers can preserve their previous good data.
bool LphReadCache(LphCacheMeta &meta, LphCurrency &out[])
  {
   meta.valid              = false;
   meta.invalidReason      = "";
   meta.schemaVersion      = 0;
   meta.generatedAtUtc     = "";
   meta.generatedEpoch     = 0;
   meta.lastFetchEpoch     = 0;
   meta.lastSuccessEpoch   = 0;
   meta.bridgeState        = "";
   meta.consecutiveFailures= 0;
   meta.count              = 0;
   ArrayResize(out, 0);

   if(!FileIsExist(LPH_CACHE_FILENAME, FILE_COMMON))
     {
      meta.invalidReason = "MISSING";
      return(false);
     }

   int handle = FileOpen(LPH_CACHE_FILENAME, FILE_READ | FILE_TXT | FILE_COMMON | FILE_ANSI);
   if(handle == INVALID_HANDLE)
     {
      meta.invalidReason = "OPEN_FAILED";
      return(false);
     }

   bool sawMagic  = false;
   bool sawMeta   = false;
   int  ccyCount  = 0;

   while(!FileIsEnding(handle))
     {
      string line = LphTrim(FileReadString(handle));
      if(line == "")
         continue;

      string parts[];
      int n = LphSplitLine(line, parts);
      if(n <= 0)
         continue;
      string tag = LphTrim(parts[0]);

      if(tag == LPH_CACHE_MAGIC)
        {
         sawMagic = true;
         continue;
        }

      if(tag == "META" && n >= 6)
        {
         meta.schemaVersion    = (int)StringToInteger(LphTrim(parts[1]));
         meta.generatedAtUtc   = LphTrim(parts[2]);
         meta.generatedEpoch   = (datetime)StringToInteger(LphTrim(parts[3]));
         meta.lastFetchEpoch   = (datetime)StringToInteger(LphTrim(parts[4]));
         meta.lastSuccessEpoch = (datetime)StringToInteger(LphTrim(parts[5]));
         sawMeta = true;
         continue;
        }

      if(tag == "STATUS" && n >= 3)
        {
         meta.bridgeState = LphTrim(parts[1]);
         if(n >= 5)
           {
            meta.lastFetchEpoch    = (datetime)StringToInteger(LphTrim(parts[2]));
            meta.lastSuccessEpoch  = (datetime)StringToInteger(LphTrim(parts[3]));
            meta.consecutiveFailures = (int)StringToInteger(LphTrim(parts[4]));
           }
         continue;
        }

      if(tag == "CCY" && n >= 11)
        {
         if(ccyCount >= LPH_MAX_CURRENCIES)
            continue;
         LphCurrency row;
         row.code = LphTrim(parts[1]);
         LphParseNumber(parts[2],  row.score7d,        row.has7d);
         LphParseNumber(parts[3],  row.score30d,       row.has30d);
         LphParseNumber(parts[4],  row.stableScore,    row.hasStable);
         LphParseNumber(parts[5],  row.compositeScore, row.hasComposite);
         row.bias7d      = LphTrim(parts[6]);
         row.bias30d     = LphTrim(parts[7]);
         row.status      = LphTrim(parts[8]);
         row.assetClass  = LphTrim(parts[9]);
         row.stableLabel = LphTrim(parts[10]);
         ArrayResize(out, ccyCount + 1);
         out[ccyCount] = row;
         ccyCount++;
         continue;
        }
     }
   FileClose(handle);

   if(!sawMagic)
     {
      meta.invalidReason = "BAD_MAGIC";
      return(false);
     }
   if(!sawMeta)
     {
      meta.invalidReason = "NO_META";
      return(false);
     }
   if(meta.schemaVersion != LPH_SUPPORTED_SCHEMA)
     {
      meta.invalidReason = "SCHEMA_" + IntegerToString(meta.schemaVersion);
      return(false);
     }
   if(ccyCount <= 0)
     {
      meta.invalidReason = "NO_CURRENCIES";
      return(false);
     }

   meta.count = ccyCount;
   meta.valid = true;
   return(true);
  }

// Look up a currency record by code. Returns index or -1.
int LphFindCurrency(LphCurrency &rows[], string code)
  {
   for(int i = 0; i < ArraySize(rows); i++)
      if(rows[i].code == code)
         return(i);
   return(-1);
  }

//==================================================================
// Freshness classification from the cache meta and thresholds (hours).
//==================================================================
ENUM_LPH_FRESH LphClassifyFreshness(LphCacheMeta &meta, datetime nowGmt,
                                     int staleWarningHours, int disableAfterHours)
  {
   if(!meta.valid)
     {
      if(meta.invalidReason == "MISSING")
         return(LPH_FRESH_MISSING);
      return(LPH_FRESH_INVALID);
     }
   if(meta.generatedEpoch <= 0)
      return(LPH_FRESH_INVALID);

   double ageHours = (double)(nowGmt - meta.generatedEpoch) / 3600.0;
   if(ageHours < 0)
      ageHours = 0;

   ENUM_LPH_FRESH band;
   if(ageHours > (double)disableAfterHours)
      band = LPH_FRESH_STALE;
   else
      if(ageHours > (double)staleWarningHours)
         band = LPH_FRESH_AGING;
      else
         band = LPH_FRESH_LIVE;

   // If the bridge is currently serving from cache (last request failed) but the
   // data is still fresh enough, surface CACHED rather than LIVE.
   if(band == LPH_FRESH_LIVE && meta.bridgeState == LPH_BS_USING_CACHE)
      return(LPH_FRESH_CACHED);

   return(band);
  }

bool LphFreshnessDisablesSignals(ENUM_LPH_FRESH fresh)
  {
   return(fresh == LPH_FRESH_STALE || fresh == LPH_FRESH_INVALID || fresh == LPH_FRESH_MISSING);
  }

//==================================================================
// Macro classification (provisional fallback thresholds, per spec section 4).
// diff7 / diff30 are base-minus-quote differentials for FX, or the single
// asset score fed in on both channels for CFDs.
//==================================================================
ENUM_LPH_MACRO LphClassifyMacro(double diff7, double diff30, double minDiff, double tol)
  {
   bool strongBull = (diff30 >= minDiff && diff7 >= minDiff);
   bool strongBear = (diff30 <= -minDiff && diff7 <= -minDiff);
   if(strongBull)
      return(LPH_MACRO_STRONG_BULL);
   if(strongBear)
      return(LPH_MACRO_STRONG_BEAR);

   // BULLISH: 30D confirms and 7D is not below -tolerance.
   if(diff30 >= minDiff && diff7 >= -tol)
      return(LPH_MACRO_BULL);
   // BEARISH: 30D confirms and 7D is not above +tolerance.
   if(diff30 <= -minDiff && diff7 <= tol)
      return(LPH_MACRO_BEAR);

   // MIXED: 30D regime present but 7D opposes beyond tolerance,
   //        or 7D pressure present while the 30D regime is flat.
   if(diff30 >= minDiff && diff7 < -tol)
      return(LPH_MACRO_MIXED);
   if(diff30 <= -minDiff && diff7 > tol)
      return(LPH_MACRO_MIXED);
   if(MathAbs(diff7) >= minDiff && MathAbs(diff30) < minDiff)
      return(LPH_MACRO_MIXED);

   return(LPH_MACRO_NEUTRAL);
  }

//==================================================================
// EMA (50) direction on a fixed higher timeframe, closed candles only.
//   Compares close[shift1] to EMA[shift1] with an ATR-scaled neutral band.
//==================================================================
ENUM_LPH_DIR LphEmaDirection(string symbol, int timeframe, int emaPeriod,
                             int appliedPrice, double neutralToleranceAtr,
                             double &closeOut, double &emaOut)
  {
   closeOut = iClose(symbol, timeframe, 1);
   emaOut   = iMA(symbol, timeframe, emaPeriod, 0, MODE_EMA, appliedPrice, 1);
   if(closeOut <= 0 || emaOut <= 0)
      return(LPH_DIR_NA);

   double atr = iATR(symbol, timeframe, 14, 1);
   double tol = 0.0;
   if(atr > 0 && neutralToleranceAtr > 0)
      tol = atr * neutralToleranceAtr;

   double diff = closeOut - emaOut;
   if(MathAbs(diff) <= tol)
      return(LPH_DIR_NEUTRAL);
   if(diff > 0)
      return(LPH_DIR_BULL);
   return(LPH_DIR_BEAR);
  }

// Closed-candle EMA reclaim at an arbitrary confirmed shift. For shift=1 this
// compares candle 2 with candle 1 and never reads the forming candle.
bool LphEmaFreshReclaim(string symbol, int timeframe, int emaPeriod,
                        int appliedPrice, int confirmedShift, bool bullish)
  {
   if(confirmedShift < 1 || iBars(symbol, timeframe) < emaPeriod + confirmedShift + 2)
      return(false);
   double closeNow = iClose(symbol, timeframe, confirmedShift);
   double closePrev = iClose(symbol, timeframe, confirmedShift + 1);
   double emaNow = iMA(symbol, timeframe, emaPeriod, 0, MODE_EMA, appliedPrice, confirmedShift);
   double emaPrev = iMA(symbol, timeframe, emaPeriod, 0, MODE_EMA, appliedPrice, confirmedShift + 1);
   if(closeNow <= 0 || closePrev <= 0 || emaNow <= 0 || emaPrev <= 0)
      return(false);
   if(bullish)
      return(closePrev <= emaPrev && closeNow > emaNow);
   return(closePrev >= emaPrev && closeNow < emaNow);
  }

//==================================================================
// TDI (internal). Price Line = SMA(RSI, priceLen); Signal = SMA(PriceLine,
// signalLen); Market Base Line = SMA(RSI, baseLen). Closed candles only.
//==================================================================
double LphTdiRsi(string symbol, int tf, int rsiPeriod, int price, int shift)
  {
   return(iRSI(symbol, tf, rsiPeriod, price, shift));
  }

double LphTdiPriceLine(string symbol, int tf, int rsiPeriod, int price, int priceLen, int shift)
  {
   if(priceLen < 1)
      priceLen = 1;
   double sum = 0.0;
   for(int i = 0; i < priceLen; i++)
      sum += LphTdiRsi(symbol, tf, rsiPeriod, price, shift + i);
   return(sum / priceLen);
  }

double LphTdiSignalLine(string symbol, int tf, int rsiPeriod, int price,
                        int priceLen, int signalLen, int shift)
  {
   if(signalLen < 1)
      signalLen = 1;
   double sum = 0.0;
   for(int i = 0; i < signalLen; i++)
      sum += LphTdiPriceLine(symbol, tf, rsiPeriod, price, priceLen, shift + i);
   return(sum / signalLen);
  }

double LphTdiMarketBase(string symbol, int tf, int rsiPeriod, int price, int baseLen, int shift)
  {
   if(baseLen < 1)
      baseLen = 1;
   double sum = 0.0;
   for(int i = 0; i < baseLen; i++)
      sum += LphTdiRsi(symbol, tf, rsiPeriod, price, shift + i);
   return(sum / baseLen);
  }

// Minimum bars needed for stable TDI values at shift 2.
int LphTdiRequiredBars(int rsiPeriod, int priceLen, int signalLen, int baseLen)
  {
   int deepest = MathMax(baseLen, priceLen + signalLen);
   return(rsiPeriod + deepest + 4);
  }

// Full TDI evaluation for one timeframe. Returns a direction plus fresh-cross
// flags via reference. Sets ok=false when history is insufficient.
ENUM_LPH_DIR LphTdiDirection(string symbol, int tf, int rsiPeriod, int price,
                             int priceLen, int signalLen, int baseLen,
                             bool &freshBullCross, bool &freshBearCross, bool &ok,
                             double &priceLine1Out, double &signalLine1Out, double &baseLine1Out)
  {
   freshBullCross = false;
   freshBearCross = false;
   ok             = false;
   priceLine1Out  = 0;
   signalLine1Out = 0;
   baseLine1Out   = 0;

   int needed = LphTdiRequiredBars(rsiPeriod, priceLen, signalLen, baseLen);
   if(iBars(symbol, tf) < needed)
      return(LPH_DIR_NA);

   double pl1 = LphTdiPriceLine(symbol, tf, rsiPeriod, price, priceLen, 1);
   double pl2 = LphTdiPriceLine(symbol, tf, rsiPeriod, price, priceLen, 2);
   double sl1 = LphTdiSignalLine(symbol, tf, rsiPeriod, price, priceLen, signalLen, 1);
   double sl2 = LphTdiSignalLine(symbol, tf, rsiPeriod, price, priceLen, signalLen, 2);
   double mb1 = LphTdiMarketBase(symbol, tf, rsiPeriod, price, baseLen, 1);

   if(!MathIsValidNumber(pl1) || !MathIsValidNumber(sl1) || !MathIsValidNumber(mb1) ||
      pl1 <= 0 || sl1 <= 0 || mb1 <= 0)
      return(LPH_DIR_NA);

   ok             = true;
   priceLine1Out  = pl1;
   signalLine1Out = sl1;
   baseLine1Out   = mb1;

   // Fresh cross detection (shift 2 -> shift 1).
   if(pl2 <= sl2 && pl1 > sl1)
      freshBullCross = true;
   if(pl2 >= sl2 && pl1 < sl1)
      freshBearCross = true;

   if(pl1 > sl1 && pl1 > mb1 && pl1 > pl2)
      return(LPH_DIR_BULL);
   if(pl1 < sl1 && pl1 < mb1 && pl1 < pl2)
      return(LPH_DIR_BEAR);
   return(LPH_DIR_NEUTRAL);
  }

// Fresh TDI cross at an arbitrary completed candle. This supports bounded
// M15 lookbacks while retaining the same TDI construction as D1/H4.
bool LphTdiFreshCrossAt(string symbol, int tf, int rsiPeriod, int price,
                        int priceLen, int signalLen, int baseLen,
                        int confirmedShift, bool bullish)
  {
   int needed = LphTdiRequiredBars(rsiPeriod, priceLen, signalLen, baseLen);
   if(confirmedShift < 1 || iBars(symbol, tf) < needed + confirmedShift + 1)
      return(false);
   double plNow = LphTdiPriceLine(symbol, tf, rsiPeriod, price, priceLen, confirmedShift);
   double plPrev = LphTdiPriceLine(symbol, tf, rsiPeriod, price, priceLen, confirmedShift + 1);
   double slNow = LphTdiSignalLine(symbol, tf, rsiPeriod, price, priceLen, signalLen, confirmedShift);
   double slPrev = LphTdiSignalLine(symbol, tf, rsiPeriod, price, priceLen, signalLen, confirmedShift + 1);
   if(!MathIsValidNumber(plNow) || !MathIsValidNumber(plPrev) ||
      !MathIsValidNumber(slNow) || !MathIsValidNumber(slPrev))
      return(false);
   if(bullish)
      return(plPrev <= slPrev && plNow > slNow);
   return(plPrev >= slPrev && plNow < slNow);
  }

//==================================================================
// Technical classification (spec section 7).
//==================================================================
ENUM_LPH_TECH LphClassifyTechnical(ENUM_LPH_DIR d1ema, ENUM_LPH_DIR h4ema,
                                   ENUM_LPH_DIR d1tdi, ENUM_LPH_DIR h4tdi,
                                   bool h4FreshBull, bool h4FreshBear, bool historyOk)
  {
   if(!historyOk || d1ema == LPH_DIR_NA || h4ema == LPH_DIR_NA)
      return(LPH_TECH_WAITING);

   bool d1Bull = (d1ema == LPH_DIR_BULL);
   bool d1Bear = (d1ema == LPH_DIR_BEAR);
   bool h4Bull = (h4ema == LPH_DIR_BULL);
   bool h4Bear = (h4ema == LPH_DIR_BEAR);
   bool h4Test = (h4ema == LPH_DIR_BULL || h4ema == LPH_DIR_NEUTRAL);      // "above or testing"
   bool h4TestDn = (h4ema == LPH_DIR_BEAR || h4ema == LPH_DIR_NEUTRAL);

   // ----- BUY family -----
   if(d1Bull && h4Bull && d1tdi == LPH_DIR_BULL && h4tdi == LPH_DIR_BULL)
      return(LPH_TECH_STRONG_BUY);
   if(d1Bull && h4Bull && (d1tdi == LPH_DIR_BULL || d1tdi == LPH_DIR_NEUTRAL) && h4tdi == LPH_DIR_BULL)
      return(LPH_TECH_BUY_SETUP);
   if(d1Bull && h4Test && (h4tdi == LPH_DIR_NEUTRAL || h4FreshBull) && d1tdi != LPH_DIR_BEAR)
      return(LPH_TECH_BUY_WATCH);

   // ----- SELL family -----
   if(d1Bear && h4Bear && d1tdi == LPH_DIR_BEAR && h4tdi == LPH_DIR_BEAR)
      return(LPH_TECH_STRONG_SELL);
   if(d1Bear && h4Bear && (d1tdi == LPH_DIR_BEAR || d1tdi == LPH_DIR_NEUTRAL) && h4tdi == LPH_DIR_BEAR)
      return(LPH_TECH_SELL_SETUP);
   if(d1Bear && h4TestDn && (h4tdi == LPH_DIR_NEUTRAL || h4FreshBear) && d1tdi != LPH_DIR_BULL)
      return(LPH_TECH_SELL_WATCH);

   return(LPH_TECH_MIXED);
  }

//==================================================================
// Final macro-technical alignment (spec section 8).
//==================================================================
bool LphMacroIsBull(ENUM_LPH_MACRO m) { return(m == LPH_MACRO_STRONG_BULL || m == LPH_MACRO_BULL); }
bool LphMacroIsBear(ENUM_LPH_MACRO m) { return(m == LPH_MACRO_STRONG_BEAR || m == LPH_MACRO_BEAR); }
bool LphTechIsBuy(ENUM_LPH_TECH t)    { return(t == LPH_TECH_STRONG_BUY || t == LPH_TECH_BUY_SETUP); }
bool LphTechIsSell(ENUM_LPH_TECH t)   { return(t == LPH_TECH_STRONG_SELL || t == LPH_TECH_SELL_SETUP); }
bool LphTechBuyDir(ENUM_LPH_TECH t)   { return(t == LPH_TECH_STRONG_BUY || t == LPH_TECH_BUY_SETUP || t == LPH_TECH_BUY_WATCH); }
bool LphTechSellDir(ENUM_LPH_TECH t)  { return(t == LPH_TECH_STRONG_SELL || t == LPH_TECH_SELL_SETUP || t == LPH_TECH_SELL_WATCH); }

ENUM_LPH_ALIGN LphClassifyAlignment(ENUM_LPH_MACRO macro, ENUM_LPH_TECH tech,
                                    ENUM_LPH_FRESH fresh)
  {
   // Macro entirely unavailable -> keep technical only.
   if(macro == LPH_MACRO_UNAVAILABLE)
      return(LPH_ALIGN_MACRO_UNAVAILABLE);

   // Stale / invalid macro disables all directional labels.
   if(LphFreshnessDisablesSignals(fresh))
      return(LPH_ALIGN_STALE_DISABLED);

   // A+ tiers.
   if(macro == LPH_MACRO_STRONG_BULL && tech == LPH_TECH_STRONG_BUY)
      return(LPH_ALIGN_APLUS_BUY);
   if(macro == LPH_MACRO_STRONG_BEAR && tech == LPH_TECH_STRONG_SELL)
      return(LPH_ALIGN_APLUS_SELL);

   // Aligned buy / sell.
   if(LphMacroIsBull(macro) && LphTechIsBuy(tech))
      return(LPH_ALIGN_BUY);
   if(LphMacroIsBear(macro) && LphTechIsSell(tech))
      return(LPH_ALIGN_SELL);

   // Watch tiers.
   if(LphMacroIsBull(macro) && tech == LPH_TECH_BUY_WATCH)
      return(LPH_ALIGN_BUY_WATCH);
   if(LphMacroIsBear(macro) && tech == LPH_TECH_SELL_WATCH)
      return(LPH_ALIGN_SELL_WATCH);

   // Conflicts: macro one way, technical the other.
   if(LphMacroIsBull(macro) && LphTechSellDir(tech))
      return(LPH_ALIGN_CONFLICT);
   if(LphMacroIsBear(macro) && LphTechBuyDir(tech))
      return(LPH_ALIGN_CONFLICT);
   if(macro == LPH_MACRO_MIXED && (LphTechBuyDir(tech) || LphTechSellDir(tech)))
      return(LPH_ALIGN_CONFLICT);

   return(LPH_ALIGN_NEUTRAL);
  }

//==================================================================
// Label helpers (text only; colour mapping stays in the caller so it can use
// user-configurable colour inputs).
//==================================================================
string LphDirLabel(ENUM_LPH_DIR d)
  {
   switch(d)
     {
      case LPH_DIR_BULL:    return("BULLISH");
      case LPH_DIR_BEAR:    return("BEARISH");
      case LPH_DIR_NEUTRAL: return("NEUTRAL");
      default:              return("N/A");
     }
  }

string LphMacroLabel(ENUM_LPH_MACRO m)
  {
   switch(m)
     {
      case LPH_MACRO_STRONG_BULL: return("STRONG BULLISH");
      case LPH_MACRO_BULL:        return("BULLISH");
      case LPH_MACRO_MIXED:       return("MIXED");
      case LPH_MACRO_NEUTRAL:     return("NEUTRAL");
      case LPH_MACRO_BEAR:        return("BEARISH");
      case LPH_MACRO_STRONG_BEAR: return("STRONG BEARISH");
      case LPH_MACRO_PARTIAL:     return("PARTIAL");
      default:                    return("UNAVAILABLE");
     }
  }

string LphTechLabel(ENUM_LPH_TECH t)
  {
   switch(t)
     {
      case LPH_TECH_STRONG_BUY:  return("STRONG BUY TECHNICAL");
      case LPH_TECH_BUY_SETUP:   return("BUY SETUP");
      case LPH_TECH_BUY_WATCH:   return("BUY WATCH");
      case LPH_TECH_STRONG_SELL: return("STRONG SELL TECHNICAL");
      case LPH_TECH_SELL_SETUP:  return("SELL SETUP");
      case LPH_TECH_SELL_WATCH:  return("SELL WATCH");
      case LPH_TECH_WAITING:     return("WAITING FOR HISTORY");
      default:                   return("MIXED / NO ALIGNMENT");
     }
  }

string LphAlignLabel(ENUM_LPH_ALIGN a)
  {
   switch(a)
     {
      case LPH_ALIGN_APLUS_BUY:         return("A+ BUY ALIGNMENT");
      case LPH_ALIGN_BUY:               return("BUY ALIGNMENT");
      case LPH_ALIGN_BUY_WATCH:         return("BUY WATCH");
      case LPH_ALIGN_APLUS_SELL:        return("A+ SELL ALIGNMENT");
      case LPH_ALIGN_SELL:              return("SELL ALIGNMENT");
      case LPH_ALIGN_SELL_WATCH:        return("SELL WATCH");
      case LPH_ALIGN_CONFLICT:          return("MACRO-TECHNICAL CONFLICT");
      case LPH_ALIGN_STALE_DISABLED:    return("STALE / SIGNAL DISABLED");
      case LPH_ALIGN_MACRO_UNAVAILABLE: return("MACRO UNAVAILABLE");
      default:                          return("NEUTRAL / NO TRADE");
     }
  }

string LphFreshLabel(ENUM_LPH_FRESH f)
  {
   switch(f)
     {
      case LPH_FRESH_LIVE:    return("LIVE");
      case LPH_FRESH_AGING:   return("AGING");
      case LPH_FRESH_STALE:   return("STALE");
      case LPH_FRESH_CACHED:  return("CACHED");
      case LPH_FRESH_INVALID: return("INVALID");
      default:                return("MISSING");
     }
  }

// Signed number for display, e.g. +49 / -15.
string LphSigned(double value, int digits = 0)
  {
   string s = DoubleToString(value, digits);
   if(value > 0)
      return("+" + s);
   return(s);
  }

#endif // __LPH_MACROTECHNICAL_CORE_MQH__
//+------------------------------------------------------------------+
