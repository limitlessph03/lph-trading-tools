//+------------------------------------------------------------------+
//|            LPH_MacroTechnical_MultiScanner_v2.mq5                |
//|      Limitless PH Multi-Pair Macro-Technical + Fade Context      |
//|               Direct Canonical Duplicate Multi-Scanner           |
//+------------------------------------------------------------------+
#property indicator_chart_window
#property indicator_plots 0
#property copyright "Limitless PH"
#property version   "2.00"
#property description "LPH Multi-Pair Macro-Technical + Fade Context Background Scanner. Direct Duplicate of Canonical v1.20 Indicator Engine."

#include <LPH_MacroTechnical_Core.mqh>

//==================================================================
// Inputs — Scanner & Multi-Pair Config
//==================================================================
input string  Inp_Scanner_Config       = "===== MULTI-PAIR SCANNER CONFIG =====";
input string  Symbol_List              = "EURUSD,GBPUSD,AUDUSD,NZDUSD,USDCAD,USDCHF,USDJPY,XAUUSD";
input int     Scan_Interval_Seconds    = 5;

input string  Inp_Macro                = "----- Macro Settings -----";
input double  MinMacroDifferential     = 20.0;
input double  MacroConflictTolerance   = 10.0;
input int     StaleWarningHours        = 12;
input int     DisableSignalsAfterHours = 36;

input string  Inp_Tech                 = "----- Technical Settings -----";
input int     EMAPeriod                = 50;
input int     TDIRSIPeriod             = 14;
input int     TDIPriceLinePeriod       = 2;
input int     TDISignalLinePeriod      = 7;
input int     TDIMarketBaseLinePeriod  = 40;

input string  Inp_Alerts               = "----- Notifications -----";
input bool    Enable_All_Green_Alerts  = true;
input bool    Enable_All_Red_Alerts    = true;
input bool    Popup_Alert              = true;
input bool    Push_Notification        = true;
input int     Alert_Cooldown_Seconds   = 300;

input string  Inp_Webhook              = "----- Dashboard Webhook -----";
input bool    Enable_Website_Webhook   = true;
input string  Webhook_URL              = "http://127.0.0.1:8080/api/v1/macrotechnical/scan-update";
input int     Webhook_Timeout_MS       = 3000;

//==================================================================
// Globals & Data Structures
//==================================================================
struct SymbolScanResult
{
   string   symbol;
   string   resolved_symbol;
   string   decision;
   string   macro_bias;
   string   d1_regime;
   string   h4_regime;
   string   h1_regime;
   string   m15_regime;
   string   gates_buy;
   string   gates_sell;
   double   tdi_green_h1;
   double   tdi_red_h1;
   double   tdi_yellow_h1;
   bool     all_green;
   bool     all_red;
};

datetime g_lastScanTime = 0;
string   g_parsedSymbols[];
int      g_parsedSymbolCount = 0;
datetime g_lastAlertTimestamps[];
string   g_lastAlertStatuses[];

LphCacheMeta g_meta;
LphCurrency  g_rows[];

//==================================================================
// Lifecycle
//==================================================================
int OnInit()
{
   ParseSymbolList();
   EventSetTimer(Scan_Interval_Seconds);
   Print("[LPH_MACROTECH_SCANNER_v2] Canonical Duplicate Multi-Scanner Initialized. Symbols count: ", g_parsedSymbolCount);
   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason)
{
   EventKillTimer();
}

void OnTimer()
{
   ExecuteMultiPairScan();
}

int OnCalculate(const int rates_total,
                 const int prev_calculated,
                 const int begin,
                 const double &price[])
{
   datetime now = TimeCurrent();
   if(now - g_lastScanTime >= Scan_Interval_Seconds)
   {
      ExecuteMultiPairScan();
   }
   return(rates_total);
}

//==================================================================
// Parse Symbol List
//==================================================================
void ParseSymbolList()
{
   string symbolsStr = Symbol_List;
   StringTrimLeft(symbolsStr);
   StringTrimRight(symbolsStr);
   
   ushort u_sep = StringGetCharacter(",", 0);
   string result[];
   int count = StringSplit(symbolsStr, u_sep, result);
   
   ArrayResize(g_parsedSymbols, count);
   ArrayResize(g_lastAlertTimestamps, count);
   ArrayResize(g_lastAlertStatuses, count);
   g_parsedSymbolCount = 0;
   
   for(int i = 0; i < count; i++)
   {
      string sym = result[i];
      StringTrimLeft(sym);
      StringTrimRight(sym);
      if(StringLen(sym) > 0)
      {
         g_parsedSymbols[g_parsedSymbolCount] = sym;
         g_lastAlertTimestamps[g_parsedSymbolCount] = 0;
         g_lastAlertStatuses[g_parsedSymbolCount] = "";
         g_parsedSymbolCount++;
      }
   }
}

//==================================================================
// Multi-Pair Scan Loop using Duplicate Canonical Engine
//==================================================================
void ExecuteMultiPairScan()
{
   g_lastScanTime = TimeCurrent();
   if(g_parsedSymbolCount <= 0) return;

   LphCacheMeta readMeta;
   LphCurrency readRows[];
   bool cacheOk = LphReadCache(readMeta, readRows);
   if(cacheOk)
   {
      g_meta = readMeta;
      ArrayResize(g_rows, ArraySize(readRows));
      for(int cacheRow = 0; cacheRow < ArraySize(readRows); cacheRow++)
         g_rows[cacheRow] = readRows[cacheRow];
   }
   
   datetime nowGmt = TimeGMT();
   ENUM_LPH_FRESH fresh = LphClassifyFreshness(g_meta, nowGmt, StaleWarningHours, DisableSignalsAfterHours);
   
   SymbolScanResult results[];
   ArrayResize(results, g_parsedSymbolCount);
   string jsonSymbolsPayload = "[";
   
   for(int i = 0; i < g_parsedSymbolCount; i++)
   {
      string baseSym = g_parsedSymbols[i];
      EvaluateCanonicalSymbolContext(baseSym, fresh, results[i]);
      
      CheckAndSendNotifications(i, results[i]);
      
      string symJson = StringFormat(
         "{\"symbol\":\"%s\",\"status\":\"%s\",\"decision\":\"%s\",\"macro_bias\":\"%s\",\"d1_regime\":\"%s\",\"h4_regime\":\"%s\",\"h1_regime\":\"%s\",\"m15_regime\":\"%s\",\"gates_buy\":\"%s\",\"gates_sell\":\"%s\",\"tdi_green\":%.2f,\"tdi_red\":%.2f,\"tdi_yellow\":%.2f,\"all_green\":%s,\"all_red\":%s}",
         results[i].symbol,
         results[i].decision,
         results[i].decision,
         results[i].macro_bias,
         results[i].d1_regime,
         results[i].h4_regime,
         results[i].h1_regime,
         results[i].m15_regime,
         results[i].gates_buy,
         results[i].gates_sell,
         results[i].tdi_green_h1,
         results[i].tdi_red_h1,
         results[i].tdi_yellow_h1,
         results[i].all_green ? "true" : "false",
         results[i].all_red ? "true" : "false"
      );
      
      jsonSymbolsPayload += symJson;
      if(i < g_parsedSymbolCount - 1) jsonSymbolsPayload += ",";
   }
   jsonSymbolsPayload += "]";
   
   if(Enable_Website_Webhook)
   {
      SendScanDataToWebsite(jsonSymbolsPayload);
   }
}

//==================================================================
// Evaluates single symbol using 100% exact canonical core calculations
//==================================================================
void EvaluateCanonicalSymbolContext(string baseSym, ENUM_LPH_FRESH fresh, SymbolScanResult &res)
{
   LphSymbolInfo symInfo = LphResolveSymbol(baseSym, "", "");
   string actualSym = symInfo.resolved ? symInfo.cleaned : baseSym;
   
   if(!SymbolSelect(actualSym, true))
   {
      string suffixes[] = {"zero", "pro", ".a", "m", "c", "i", "_i"};
      for(int s = 0; s < ArraySize(suffixes); s++)
      {
         string testSym = baseSym + suffixes[s];
         if(SymbolSelect(testSym, true)) { actualSym = testSym; break; }
      }
   }
   
   res.symbol = baseSym;
   res.resolved_symbol = actualSym;
   res.decision = "NO TRADE - CONDITIONS CONFLICT";
   res.macro_bias = "NEUTRAL";
   res.d1_regime = "NEUTRAL";
   res.h4_regime = "NEUTRAL";
   res.h1_regime = "NEUTRAL";
   res.m15_regime = "NEUTRAL";
   res.gates_buy = "N/N/N/N";
   res.gates_sell = "N/N/N/N";
   res.tdi_green_h1 = 50.0;
   res.tdi_red_h1 = 50.0;
   res.tdi_yellow_h1 = 50.0;
   res.all_green = false;
   res.all_red = false;
   
   ENUM_LPH_MACRO macroCls = LphClassifyMacro(g_meta, g_rows, symInfo, MinMacroDifferential, MacroConflictTolerance);
   string macroLabel = LphMacroLabel(macroCls);
   res.macro_bias = macroLabel;
   
   double closeD1 = GetCloseOnSymbolTF(actualSym, PERIOD_D1, 0);
   double ema50D1 = GetEMAOnSymbolTF(actualSym, PERIOD_D1, EMAPeriod, 0);
   double gD1 = GetTDIOnSymbolTF(actualSym, PERIOD_D1, TDIPriceLinePeriod, 0);
   double rD1 = GetTDIOnSymbolTF(actualSym, PERIOD_D1, TDISignalLinePeriod, 0);
   
   bool d1Bull = (closeD1 > ema50D1 && gD1 > rD1 && gD1 >= 50.0);
   bool d1Bear = (closeD1 < ema50D1 && gD1 < rD1 && gD1 <= 50.0);
   res.d1_regime = d1Bull ? "BULLISH" : (d1Bear ? "BEARISH" : "NEUTRAL");
   
   double closeH4 = GetCloseOnSymbolTF(actualSym, PERIOD_H4, 0);
   double ema50H4 = GetEMAOnSymbolTF(actualSym, PERIOD_H4, EMAPeriod, 0);
   double gH4 = GetTDIOnSymbolTF(actualSym, PERIOD_H4, TDIPriceLinePeriod, 0);
   double rH4 = GetTDIOnSymbolTF(actualSym, PERIOD_H4, TDISignalLinePeriod, 0);
   
   bool h4Bull = (closeH4 > ema50H4 && gH4 > rH4);
   bool h4Bear = (closeH4 < ema50H4 && gH4 < rH4);
   res.h4_regime = h4Bull ? "BULLISH" : (h4Bear ? "BEARISH" : "NEUTRAL");
   
   double closeH1 = GetCloseOnSymbolTF(actualSym, PERIOD_H1, 0);
   double ema50H1 = GetEMAOnSymbolTF(actualSym, PERIOD_H1, EMAPeriod, 0);
   double gH1 = GetTDIOnSymbolTF(actualSym, PERIOD_H1, TDIPriceLinePeriod, 0);
   double rH1 = GetTDIOnSymbolTF(actualSym, PERIOD_H1, TDISignalLinePeriod, 0);
   double yH1 = GetTDIOnSymbolTF(actualSym, PERIOD_H1, TDIMarketBaseLinePeriod, 0);
   
   res.tdi_green_h1  = NormalizeDouble(gH1, 2);
   res.tdi_red_h1    = NormalizeDouble(rH1, 2);
   res.tdi_yellow_h1 = NormalizeDouble(yH1, 2);
   
   bool h1Bull = (closeH1 > ema50H1 && gH1 > rH1 && gH1 > yH1);
   bool h1Bear = (closeH1 < ema50H1 && gH1 < rH1 && gH1 < yH1);
   res.h1_regime = h1Bull ? "BULLISH" : (h1Bear ? "BEARISH" : "NEUTRAL");
   
   double closeM15 = GetCloseOnSymbolTF(actualSym, PERIOD_M15, 0);
   double ema50M15 = GetEMAOnSymbolTF(actualSym, PERIOD_M15, EMAPeriod, 0);
   double gM15 = GetTDIOnSymbolTF(actualSym, PERIOD_M15, TDIPriceLinePeriod, 0);
   double rM15 = GetTDIOnSymbolTF(actualSym, PERIOD_M15, TDISignalLinePeriod, 0);
   
   bool m15Bull = (closeM15 > ema50M15 && gM15 > rM15);
   bool m15Bear = (closeM15 < ema50M15 && gM15 < rM15);
   res.m15_regime = m15Bull ? "BULLISH" : (m15Bear ? "BEARISH" : "NEUTRAL");
   
   bool macroOkBuy  = (macroCls == LPH_MACRO_STRONG_BULL || macroCls == LPH_MACRO_BULL || macroCls == LPH_MACRO_NEUTRAL);
   bool macroOkSell = (macroCls == LPH_MACRO_STRONG_BEAR || macroCls == LPH_MACRO_BEAR || macroCls == LPH_MACRO_NEUTRAL);
   
   bool buyGateD1    = d1Bull;
   bool buyGateMacro = (macroOkBuy && h4Bull);
   bool buyGateLevel = h1Bull;
   bool buyGateM15   = m15Bull;
   
   bool sellGateD1    = d1Bear;
   bool sellGateMacro = (macroOkSell && h4Bear);
   bool sellGateLevel = h1Bear;
   bool sellGateM15   = m15Bear;
   
   res.gates_buy = StringFormat("%s/%s/%s/%s", 
                                buyGateD1 ? "Y" : "N",
                                buyGateMacro ? "Y" : "N",
                                buyGateLevel ? "Y" : "N",
                                buyGateM15 ? "Y" : "N");
                                
   res.gates_sell = StringFormat("%s/%s/%s/%s", 
                                 sellGateD1 ? "Y" : "N",
                                 sellGateMacro ? "Y" : "N",
                                 sellGateLevel ? "Y" : "N",
                                 sellGateM15 ? "Y" : "N");
                                 
   bool allBuyGatesPassed  = (buyGateD1 && buyGateMacro && buyGateLevel && buyGateM15);
   bool allSellGatesPassed = (sellGateD1 && sellGateMacro && sellGateLevel && sellGateM15);
   
   if(allBuyGatesPassed)
   {
      res.decision = "ALL GREEN TARGET: BUY_READY (GATES Y/Y/Y/Y)";
      res.all_green = true;
   }
   else if(allSellGatesPassed)
   {
      res.decision = "ALL RED TARGET: SELL_READY (GATES Y/Y/Y/Y)";
      res.all_red = true;
   }
   else if(macroCls == LPH_MACRO_STRONG_BEAR && d1Bull)
   {
      res.decision = "NO TRADE - CONDITIONS CONFLICT (MACRO vs TECH)";
   }
   else if(macroCls == LPH_MACRO_STRONG_BULL && d1Bear)
   {
      res.decision = "NO TRADE - CONDITIONS CONFLICT (MACRO vs TECH)";
   }
   else
   {
      res.decision = "NEUTRAL / NO ACTIVE SETUP";
   }
}

double GetCloseOnSymbolTF(string sym, ENUM_TIMEFRAMES tf, int shift)
{
   double arr[];
   ArraySetAsSeries(arr, true);
   if(CopyClose(sym, tf, shift, 1, arr) > 0) return arr[0];
   return 0.0;
}

double GetEMAOnSymbolTF(string sym, ENUM_TIMEFRAMES tf, int period, int shift)
{
   int handle = iMA(sym, tf, period, 0, MODE_EMA, PRICE_CLOSE);
   if(handle == INVALID_HANDLE) return 0.0;
   double arr[];
   ArraySetAsSeries(arr, true);
   double val = 0.0;
   if(CopyBuffer(handle, 0, shift, 1, arr) > 0) val = arr[0];
   IndicatorRelease(handle);
   return val;
}

double GetTDIOnSymbolTF(string sym, ENUM_TIMEFRAMES tf, int maPeriod, int shift)
{
   int rsiHandle = iRSI(sym, tf, TDIRSIPeriod, PRICE_CLOSE);
   if(rsiHandle == INVALID_HANDLE) return 50.0;
   double rsiArr[];
   int lookback = maPeriod + shift + 5;
   ArraySetAsSeries(rsiArr, true);
   if(CopyBuffer(rsiHandle, 0, 0, lookback, rsiArr) < lookback)
   {
      IndicatorRelease(rsiHandle);
      return 50.0;
   }
   
   double sum = 0.0;
   for(int k = 0; k < maPeriod; k++)
   {
      sum += rsiArr[shift + k];
   }
   IndicatorRelease(rsiHandle);
   return (sum / (double)maPeriod);
}

void CheckAndSendNotifications(int symbolIndex, const SymbolScanResult &res)
{
   datetime now = TimeCurrent();
   datetime lastAlert = g_lastAlertTimestamps[symbolIndex];
   
   if(now - lastAlert < Alert_Cooldown_Seconds) return;
   
   bool isNewTarget = (res.decision != g_lastAlertStatuses[symbolIndex]);
   
   if(res.all_green && Enable_All_Green_Alerts && isNewTarget)
   {
      string msg = StringFormat("[LPH MACRO-TECH] ALL GREEN TARGET hit on %s! Decision: %s | Gates BUY: %s",
                                res.symbol, res.decision, res.gates_buy);
                                
      if(Popup_Alert) Alert(msg);
      if(Push_Notification) SendNotification(msg);
      
      g_lastAlertTimestamps[symbolIndex] = now;
      g_lastAlertStatuses[symbolIndex] = res.decision;
   }
   else if(res.all_red && Enable_All_Red_Alerts && isNewTarget)
   {
      string msg = StringFormat("[LPH MACRO-TECH] ALL RED TARGET hit on %s! Decision: %s | Gates SELL: %s",
                                res.symbol, res.decision, res.gates_sell);
                                
      if(Popup_Alert) Alert(msg);
      if(Push_Notification) SendNotification(msg);
      
      g_lastAlertTimestamps[symbolIndex] = now;
      g_lastAlertStatuses[symbolIndex] = res.decision;
   }
}

void SendScanDataToWebsite(string jsonSymbolsPayload)
{
   string headers = "Content-Type: application/json\r\n";
   char postData[];
   char resultData[];
   string resultHeaders;
   
   string fullPayload = StringFormat(
      "{\"scanner_id\":\"LPH_MacroTechnical_MultiScanner_v2\",\"timestamp\":\"%s\",\"pairs_count\":%d,\"symbols\":%s}",
      TimeToString(TimeCurrent(), TIME_DATE|TIME_SECONDS),
      g_parsedSymbolCount,
      jsonSymbolsPayload
   );
   
   StringToCharArray(fullPayload, postData, 0, StringLen(fullPayload), CP_UTF8);
   
   WebRequest("POST", Webhook_URL, headers, Webhook_Timeout_MS, postData, resultData, resultHeaders);
}
//+------------------------------------------------------------------+
