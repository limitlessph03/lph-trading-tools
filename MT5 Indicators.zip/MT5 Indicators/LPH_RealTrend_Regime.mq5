//+------------------------------------------------------------------+
//|                                          LPH_RealTrend_Regime.mq5 |
//|  Evidence-based trend/regime filter for LPH4_lotfix v15          |
//|  Built from losing-trade analysis (2026-08-15):                  |
//|    Finding #1: losers cluster in chop (trend filter fires then   |
//|                reverses). -> Efficiency Ratio + ADX + Choppiness |
//|    Finding #4: loser side = counter-trend side of the range      |
//|                -> signed trend only when regime confirms.        |
//|    Finding #3: Monday-open/gap entries lose out of proportion    |
//|                -> REGIME drops to 0 on 00:00 Monday gap bars.    |
//|  Outputs (separate window):                                      |
//|    TREND  : signed trend strength (0 when regime=chop)           |
//|    REGIME : +1 tradeable bull, -1 tradeable bear, 0 chop/flat    |
//|    ER     : Kaufman efficiency ratio (trend quality 0..1)        |
//|    CHOP   : Choppiness Index (>=61.8 = chop)                    |
//|    ADX    : Wilder ADX trend strength                            |
//+------------------------------------------------------------------+
#property copyright   "MetaTrader Assistant / LPH research"
#property version     "1.00"
#property indicator_separate_window
#property indicator_minimum  -100
#property indicator_maximum   100
#property indicator_buffers    6
#property indicator_plots      5

//--- plot TREND
#property indicator_label1  "TREND"
#property indicator_type1   DRAW_HISTOGRAM
#property indicator_color1  clrDodgerBlue
#property indicator_style1  STYLE_SOLID
#property indicator_width1  2
//--- plot REGIME
#property indicator_label2  "REGIME"
#property indicator_type2   DRAW_COLOR_HISTOGRAM
#property indicator_color2  clrDimGray, clrLimeGreen, clrOrangeRed
#property indicator_width2  3
//--- plot ER
#property indicator_label3  "ER"
#property indicator_type3   DRAW_LINE
#property indicator_color3  clrGold
#property indicator_style3  STYLE_DOT
#property indicator_width3  1
//--- plot CHOP
#property indicator_label4  "CHOP"
#property indicator_type4   DRAW_LINE
#property indicator_color4  clrMagenta
#property indicator_style4  STYLE_DOT
#property indicator_width4  1
//--- plot ADX
#property indicator_label5  "ADX"
#property indicator_type5   DRAW_LINE
#property indicator_color5  clrWhite
#property indicator_style5  STYLE_DOT
#property indicator_width5  1

//--- inputs (evidence-tuned defaults)
input int    InpADXPeriod        = 14;   // ADX period (trend strength)
input double InpADXMin           = 20.0; // ADX min for "real trend" (chop guard)
input int    InpERPeriod         = 10;   // Kaufman efficiency-ratio period
input double InpERMin            = 0.30; // ER min for "real trend" (chop guard)
input int    InpChoppinessPeriod = 14;   // Choppiness Index period
input double InpChopMax          = 61.8; // Choppiness max (above = chop)
input int    InpEMAFast          = 8;    // fast EMA (matches LPH4)
input int    InpEMASlow          = 20;   // slow EMA (matches LPH4)
input int    InpEMAFilter        = 50;   // H4 EMA filter (matches LPH4)
input bool   InpBlockMondayGap   = true; // zero REGIME on 00:00 Monday reopen
input bool   InpShowWordLabel    = true; // show plain-word trend confirmation label on chart

//--- buffers
double B_TREND[];
double B_REGIME[];
double B_REGIME_COLOR[];
double B_ER[];
double B_CHOP[];
double B_ADX[];

int hADX, hEMA8, hEMA20, hEMA50;
string g_lastWord="";
string g_labelName="LPH_RealTrend_Regime_Word";

//+------------------------------------------------------------------+
int OnInit()
  {
   SetIndexBuffer(0,B_TREND,INDICATOR_DATA);
   SetIndexBuffer(1,B_REGIME,INDICATOR_DATA);
   SetIndexBuffer(2,B_REGIME_COLOR,INDICATOR_COLOR_INDEX);
   SetIndexBuffer(3,B_ER,INDICATOR_DATA);
   SetIndexBuffer(4,B_CHOP,INDICATOR_DATA);
   SetIndexBuffer(5,B_ADX,INDICATOR_DATA);

   PlotIndexSetInteger(1,PLOT_COLOR_INDEXES,3);
   PlotIndexSetInteger(1,PLOT_LINE_COLOR,0,clrDimGray);
   PlotIndexSetInteger(1,PLOT_LINE_COLOR,1,clrLimeGreen);
   PlotIndexSetInteger(1,PLOT_LINE_COLOR,2,clrOrangeRed);

   hADX =iADX(_Symbol,_Period,InpADXPeriod);
   hEMA8 =iMA(_Symbol,_Period,InpEMAFast,0,MODE_EMA,PRICE_CLOSE);
   hEMA20=iMA(_Symbol,_Period,InpEMASlow,0,MODE_EMA,PRICE_CLOSE);
   hEMA50=iMA(_Symbol,_Period,InpEMAFilter,0,MODE_EMA,PRICE_CLOSE);

   IndicatorSetInteger(INDICATOR_DIGITS,2);
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
void OnDeinit(const int r)
  {
   if(hADX!=INVALID_HANDLE)  IndicatorRelease(hADX);
   if(hEMA8!=INVALID_HANDLE) IndicatorRelease(hEMA8);
   if(hEMA20!=INVALID_HANDLE)IndicatorRelease(hEMA20);
   if(hEMA50!=INVALID_HANDLE)IndicatorRelease(hEMA50);
   ObjectDelete(0,g_labelName);
  }
//+------------------------------------------------------------------+
double EMA(int handle,int shift)
  {
   if(handle==INVALID_HANDLE) return(0.0);
   double v[1];
   if(CopyBuffer(handle,0,shift,1,v)==1) return(v[0]);
   return(0.0);
  }
//+------------------------------------------------------------------+
//| Kaufman Efficiency Ratio: |net move| / sum(|bar moves|) over N    |
//+------------------------------------------------------------------+
double EfficiencyRatio(int shift,int period)
  {
   int total=period+shift;
   if(total>=Bars(_Symbol,_Period) || total<1) return(0.0);
   double net=MathAbs(iClose(_Symbol,_Period,total)-iClose(_Symbol,_Period,shift));
   double sum=0.0;
   for(int i=shift;i<total;i++)
      sum+=MathAbs(iClose(_Symbol,_Period,i+1)-iClose(_Symbol,_Period,i));
   if(sum<=0.0) return(0.0);
   return(net/sum);
  }
//+------------------------------------------------------------------+
//| Choppiness Index: 100*log10( sum(TR,N) / (HH-LH) ) / log10(N)     |
//+------------------------------------------------------------------+
double ChoppinessIndex(int shift,int period)
  {
   int total=period+shift;
   if(total>=Bars(_Symbol,_Period) || total<1) return(0.0);
   double hh=-DBL_MAX, ll=DBL_MAX, sumTR=0.0;
   for(int i=0;i<period;i++)
     {
      double hi=iHigh(_Symbol,_Period,shift+i);
      double lo=iLow(_Symbol,_Period,shift+i);
      double prev=iClose(_Symbol,_Period,shift+i+1);
      double tr=MathMax(hi-lo,MathMax(MathAbs(hi-prev),MathAbs(lo-prev)));
      sumTR+=tr;
      if(hi>hh) hh=hi;
      if(lo<ll) ll=lo;
     }
   if(hh<=ll || period<=1) return(100.0);
   return(100.0*MathLog10(sumTR/(hh-ll))/MathLog10(period));
  }
//+------------------------------------------------------------------+
//| True if this bar is a Monday 00:00 reopen (weekend gap candle)    |
//+------------------------------------------------------------------+
bool IsMondayGap(int shift)
  {
   datetime t=iTime(_Symbol,_Period,shift);
   datetime p=iTime(_Symbol,_Period,shift+1);
   if(t<=0 || p<=0) return(false);
   MqlDateTime dt;
   TimeToStruct(t,dt);
   if(dt.day_of_week!=1 || dt.hour!=0 || dt.min!=0) return(false);
   return((t-p)>4*3600);
  }
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//| Plain-word confirmation of the current trend regime (manual test) |
//+------------------------------------------------------------------+
string RegimeWord(int sh,double adx,double er,double chop)
  {
   double e8 =EMA(hEMA8,sh);
   double e20=EMA(hEMA20,sh);
   double e50=EMA(hEMA50,sh);
   double e20old=EMA(hEMA20,sh+5);
   double close=iClose(_Symbol,_Period,sh);
   int dir=0;
   if(e8>e20 && close>e50 && e20>e20old) dir=1;
   else if(e8<e20 && close<e50 && e20<e20old) dir=-1;
   if(dir==0) return("NO_DIRECTION");
   if(adx<InpADXMin) return("CHOP_BLOCKED_ADX");
   if(er<InpERMin) return("CHOP_BLOCKED_ER");
   if(chop>InpChopMax) return("CHOP_BLOCKED_CHOP");
   if(InpBlockMondayGap && IsMondayGap(sh)) return("MONDAY_GAP_BLOCKED");
   return(dir==1?"CONFIRMED_BULL":"CONFIRMED_BEAR");
  }
//+------------------------------------------------------------------+
void UpdateWordLabel(int rates_total)
  {
   if(!InpShowWordLabel || rates_total<1) return;
   int sh=0;
   double er=EfficiencyRatio(sh,InpERPeriod);
   double chop=ChoppinessIndex(sh,InpChoppinessPeriod);
   double adx=0.0;
   if(hADX!=INVALID_HANDLE) {double a[1]; if(CopyBuffer(hADX,0,sh,1,a)==1) adx=a[0];}
   string word=RegimeWord(sh,adx,er,chop);
   color col=clrDimGray;
   if(word=="CONFIRMED_BULL") col=clrLimeGreen;
   else if(word=="CONFIRMED_BEAR") col=clrOrangeRed;
   else if(word=="MONDAY_GAP_BLOCKED") col=clrOrange;
   else if(word=="NO_DIRECTION") col=clrSteelBlue;
   string txt="LPH REAL TREND  ("+EnumToString(_Period)+")\nREGIME: "+word+"\nADX "+DoubleToString(adx,1)+" | ER "+DoubleToString(er,2)+" | CHOP "+DoubleToString(chop,1);
   if(!ObjectCreate(0,g_labelName,OBJ_LABEL,0,0,0))
     {
      if(GetLastError()!=4204) return;
     }
   ObjectSetInteger(0,g_labelName,OBJPROP_CORNER,CORNER_LEFT_UPPER);
   ObjectSetInteger(0,g_labelName,OBJPROP_XDISTANCE,10);
   ObjectSetInteger(0,g_labelName,OBJPROP_YDISTANCE,10);
   ObjectSetInteger(0,g_labelName,OBJPROP_FONTSIZE,11);
   ObjectSetString(0,g_labelName,OBJPROP_FONT,"Arial Bold");
   ObjectSetInteger(0,g_labelName,OBJPROP_COLOR,col);
   ObjectSetInteger(0,g_labelName,OBJPROP_BACK,false);
   ObjectSetInteger(0,g_labelName,OBJPROP_SELECTABLE,false);
   ObjectSetInteger(0,g_labelName,OBJPROP_HIDDEN,true);
   ObjectSetString(0,g_labelName,OBJPROP_TEXT,txt);
   ChartRedraw();
   if(word!=g_lastWord)
     {
      g_lastWord=word;
      Print("LPH_REALTREND ",Symbol()," P=",EnumToString(_Period)," REGIME=",word,
            " ADX=",DoubleToString(adx,1)," ER=",DoubleToString(er,2)," CHOP=",DoubleToString(chop,1));
     }
  }
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,const int prev_calculated,
               const int begin,const double &price[])
  {
   int minBars=InpChoppinessPeriod+InpERPeriod+InpEMAFilter+10;
   int start=MathMax(prev_calculated-1,minBars);
   if(start<1) start=1;

   for(int i=start;i<rates_total;i++)
     {
      int sh=rates_total-1-i;                 // shift from current bar
      double er=EfficiencyRatio(sh,InpERPeriod);
      double chop=ChoppinessIndex(sh,InpChoppinessPeriod);
      double adx=0.0;
      if(hADX!=INVALID_HANDLE)
        {
         double a[1];
         if(CopyBuffer(hADX,0,sh,1,a)==1) adx=a[0];
        }
      B_ER[i]=er;
      B_CHOP[i]=chop;
      B_ADX[i]=adx;

      //--- trend direction (LPH4 logic: EMA fast>slow, price>EMA50)
      double e8 =EMA(hEMA8,sh);
      double e20=EMA(hEMA20,sh);
      double e50=EMA(hEMA50,sh);
      double e20old=EMA(hEMA20,sh+5);
      double close=iClose(_Symbol,_Period,sh);

      int dir=0;
      if(e8>e20 && close>e50 && e20>e20old) dir=1;
      else if(e8<e20 && close<e50 && e20<e20old) dir=-1;

      //--- regime: tradeable only if trend quality high (evidence #1)
      bool realTrend=(adx>=InpADXMin && er>=InpERMin && chop<=InpChopMax);
      //--- gap guard (evidence #3): no trade on Monday 00:00 reopen
      if(realTrend && InpBlockMondayGap && IsMondayGap(sh)) realTrend=false;

      double strength=realTrend?MathMin(100.0,adx*(0.5+er)):0.0;
      B_TREND[i]=dir*strength;
      B_REGIME[i]=(dir!=0 && realTrend)?dir:0.0;
      B_REGIME_COLOR[i]=(B_REGIME[i]>0)?1.0:((B_REGIME[i]<0)?2.0:0.0);
     }
   UpdateWordLabel(rates_total);
   return(rates_total);
  }
//+------------------------------------------------------------------+
