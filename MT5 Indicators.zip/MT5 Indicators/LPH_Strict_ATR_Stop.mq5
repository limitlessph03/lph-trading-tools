//+------------------------------------------------------------------+
//| LPH_Strict_ATR_Stop.mq5 - MT5 port of LPH_Strict_ATR_Stop.mq4   |
//+------------------------------------------------------------------+
#property strict
#property indicator_chart_window
#property indicator_buffers 2
#property indicator_plots   2
#property indicator_label1  "Long ATR Stop"
#property indicator_type1   DRAW_LINE
#property indicator_color1  clrDodgerBlue
#property indicator_width1  2
#property indicator_label2  "Short ATR Stop"
#property indicator_type2   DRAW_LINE
#property indicator_color2  clrRed
#property indicator_width2  2

input int ATR_Period=14;
input double ATR_Multiplier=2.5;
double LongStopBuffer[],ShortStopBuffer[];
int atr_handle=INVALID_HANDLE;

int OnInit()
{
   if(ATR_Period<1) return(INIT_PARAMETERS_INCORRECT);
   SetIndexBuffer(0,LongStopBuffer,INDICATOR_DATA);
   SetIndexBuffer(1,ShortStopBuffer,INDICATOR_DATA);
   PlotIndexSetDouble(0,PLOT_EMPTY_VALUE,EMPTY_VALUE);
   PlotIndexSetDouble(1,PLOT_EMPTY_VALUE,EMPTY_VALUE);
   ArraySetAsSeries(LongStopBuffer,true); ArraySetAsSeries(ShortStopBuffer,true);
   atr_handle=iATR(_Symbol,_Period,ATR_Period);
   if(atr_handle==INVALID_HANDLE) return(INIT_FAILED);
   IndicatorSetString(INDICATOR_SHORTNAME,"LPH Strict ATR Stop ("+(string)ATR_Period+", "+DoubleToString(ATR_Multiplier,2)+")");
   return(INIT_SUCCEEDED);
}
void OnDeinit(const int reason){ if(atr_handle!=INVALID_HANDLE) IndicatorRelease(atr_handle); }
int OnCalculate(const int rates_total,const int prev_calculated,const datetime &time[],const double &open[],const double &high[],const double &low[],const double &close[],const long &tick_volume[],const long &volume[],const int &spread[])
{
   if(rates_total<=ATR_Period) return(0);
   double atr[]; ArraySetAsSeries(atr,true);
   if(CopyBuffer(atr_handle,0,0,rates_total,atr)<rates_total) return(prev_calculated);
   ArraySetAsSeries(high,true); ArraySetAsSeries(low,true);
   int first=(prev_calculated==0)?rates_total-ATR_Period-1:rates_total-prev_calculated+1;
   if(first>rates_total-ATR_Period-1) first=rates_total-ATR_Period-1;
   for(int i=first;i>=0;i--)
   {
      int hi=iHighest(_Symbol,_Period,MODE_HIGH,ATR_Period,i);
      int lo=iLowest(_Symbol,_Period,MODE_LOW,ATR_Period,i);
      if(hi<0 || lo<0 || atr[i]==0.0){ LongStopBuffer[i]=EMPTY_VALUE; ShortStopBuffer[i]=EMPTY_VALUE; continue; }
      LongStopBuffer[i]=high[hi]-atr[i]*ATR_Multiplier;
      ShortStopBuffer[i]=low[lo]+atr[i]*ATR_Multiplier;
   }
   return(rates_total);
}
