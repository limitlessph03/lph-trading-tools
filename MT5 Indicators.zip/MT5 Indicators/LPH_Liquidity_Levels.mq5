#include "../Include/LPH_MQL4Compat.mqh"
#property indicator_chart_window
#property indicator_plots 0
// ==========================
// SETTINGS
// ==========================
input ENUM_TIMEFRAMES CalculationTF = PERIOD_M5;
input int RefreshSeconds = 5;
input int LabelBarsAhead = 10;

input bool ShowPreviousDayHighLow = true;
input bool ShowAsiaSession = true;
input bool ShowLondonSession = true;
input bool ShowNewYorkSession = true;
input bool ShowDailyVWAP = true;

// Session times are based on BROKER SERVER TIME
input int AsiaStartHour = 0;
input int AsiaStartMinute = 0;
input int AsiaEndHour = 9;
input int AsiaEndMinute = 0;

input int LondonStartHour = 9;
input int LondonStartMinute = 0;
input int LondonEndHour = 14;
input int LondonEndMinute = 0;

input int NYStartHour = 14;
input int NYStartMinute = 0;
input int NYEndHour = 23;
input int NYEndMinute = 0;

// Colors
input color PrevDayColor = clrDodgerBlue;
input color AsiaColor = clrMediumPurple;
input color LondonColor = clrGold;
input color NYColor = clrTomato;
input color VWAPColor = clrAqua;

input int LineWidth = 1;

string prefix = "XAU_LIQ_";

// ==========================
// UTILITY FUNCTIONS
// ==========================

datetime MakeSessionTime(datetime dayStart, int hour, int minute)
{
   return(dayStart + hour * 3600 + minute * 60);
}

void DeleteOne(string id)
{
   ObjectDelete(0, prefix + id + "_LINE");
   ObjectDelete(0, prefix + id + "_TXT");
}

void DeleteAll()
{
   long chart_id = ChartID();
   int total = ObjectsTotal(chart_id, -1, -1);

   for(int i = total - 1; i >= 0; i--)
   {
      string name = ObjectName(chart_id, i, -1, -1);

      if(StringFind(name, prefix, 0) == 0)
         ObjectDelete(chart_id, name);
   }
}

// ==========================
// DRAW LEVEL FUNCTION
// ==========================

void DrawLevel(string id, double price, color clr, int style, int width, string label)
{
   if(price <= 0 || price == EMPTY_VALUE)
   {
      DeleteOne(id);
      return;
   }

   string lineName = prefix + id + "_LINE";
   string textName = prefix + id + "_TXT";

   if(ObjectFind(0, lineName) < 0)
      ObjectCreate(0, lineName, OBJ_HLINE, 0, 0, price);

   ObjectMove(0, lineName, 0, 0, price);
   ObjectSetInteger(0, lineName, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, lineName, OBJPROP_STYLE, style);
   ObjectSetInteger(0, lineName, OBJPROP_WIDTH, width);
   ObjectSetInteger(0, lineName, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, lineName, OBJPROP_HIDDEN, true);

   datetime currentBarTime = iTime(Symbol(), Period(), 0);
   datetime labelTime = currentBarTime + Period() * 60 * LabelBarsAhead;

   string labelText = label + "  " + DoubleToString(price, Digits);

   if(ObjectFind(0, textName) < 0)
      ObjectCreate(0, textName, OBJ_TEXT, 0, labelTime, price);

   ObjectMove(0, textName, 0, labelTime, price);
   ObjectSetString(0, textName, OBJPROP_TEXT, labelText);
   ObjectSetString(0, textName, OBJPROP_FONT, "Arial Bold");
   ObjectSetInteger(0, textName, OBJPROP_FONTSIZE, 8);
   ObjectSetInteger(0, textName, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, textName, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, textName, OBJPROP_HIDDEN, true);
}

// ==========================
// SESSION HIGH / LOW
// ==========================

bool GetSessionHighLow(datetime sessionStart, datetime sessionEnd, double &sessionHigh, double &sessionLow)
{
   if(sessionEnd <= sessionStart)
      sessionEnd += 86400;

   datetime now = TimeCurrent();

   if(sessionStart > now)
      return(false);

   if(sessionEnd > now)
      sessionEnd = now;

   bool found = false;
   int bars = iBars(Symbol(), CalculationTF);

   for(int i = 0; i < bars; i++)
   {
      datetime barTime = iTime(Symbol(), CalculationTF, i);

      if(barTime < sessionStart)
         break;

      if(barTime >= sessionStart && barTime < sessionEnd)
      {
         double h = iHigh(Symbol(), CalculationTF, i);
         double l = iLow(Symbol(), CalculationTF, i);

         if(!found)
         {
            sessionHigh = h;
            sessionLow = l;
            found = true;
         }
         else
         {
            if(h > sessionHigh) sessionHigh = h;
            if(l < sessionLow) sessionLow = l;
         }
      }
   }

   return(found);
}

// ==========================
// DAILY VWAP
// ==========================

bool CalculateDailyVWAP(double &vwap)
{
   datetime dayStart = iTime(Symbol(), PERIOD_D1, 0);

   if(dayStart <= 0)
      return(false);

   double sumPV = 0;
   double sumVol = 0;

   int bars = iBars(Symbol(), CalculationTF);

   for(int i = 0; i < bars; i++)
   {
      datetime barTime = iTime(Symbol(), CalculationTF, i);

      if(barTime < dayStart)
         break;

      double h = iHigh(Symbol(), CalculationTF, i);
      double l = iLow(Symbol(), CalculationTF, i);
      double c = iClose(Symbol(), CalculationTF, i);
      double vol = (double)iVolume(Symbol(), CalculationTF, i);

      if(vol <= 0)
         continue;

      double typicalPrice = (h + l + c) / 3.0;

      sumPV += typicalPrice * vol;
      sumVol += vol;
   }

   if(sumVol <= 0)
      return(false);

   vwap = sumPV / sumVol;
   return(true);
}

// ==========================
// MAIN DRAW FUNCTION
// ==========================

void DrawAllLevels()
{
   datetime dayStart = iTime(Symbol(), PERIOD_D1, 0);

   if(dayStart <= 0)
      return;

   // Previous Day High / Low
   if(ShowPreviousDayHighLow)
   {
      double pdh = iHigh(Symbol(), PERIOD_D1, 1);
      double pdl = iLow(Symbol(), PERIOD_D1, 1);

      DrawLevel("PDH", pdh, PrevDayColor, STYLE_DOT, LineWidth, "PDH");
      DrawLevel("PDL", pdl, PrevDayColor, STYLE_DOT, LineWidth, "PDL");
   }
   else
   {
      DeleteOne("PDH");
      DeleteOne("PDL");
   }

   // Asia Session
   if(ShowAsiaSession)
   {
      double asiaHigh = 0;
      double asiaLow = 0;

      datetime asiaStart = MakeSessionTime(dayStart, AsiaStartHour, AsiaStartMinute);
      datetime asiaEnd = MakeSessionTime(dayStart, AsiaEndHour, AsiaEndMinute);

      if(GetSessionHighLow(asiaStart, asiaEnd, asiaHigh, asiaLow))
      {
         DrawLevel("ASIA_H", asiaHigh, AsiaColor, STYLE_DOT, LineWidth, "Asia High");
         DrawLevel("ASIA_L", asiaLow, AsiaColor, STYLE_DOT, LineWidth, "Asia Low");
      }
      else
      {
         DeleteOne("ASIA_H");
         DeleteOne("ASIA_L");
      }
   }
   else
   {
      DeleteOne("ASIA_H");
      DeleteOne("ASIA_L");
   }

   // London Session
   if(ShowLondonSession)
   {
      double londonHigh = 0;
      double londonLow = 0;

      datetime londonStart = MakeSessionTime(dayStart, LondonStartHour, LondonStartMinute);
      datetime londonEnd = MakeSessionTime(dayStart, LondonEndHour, LondonEndMinute);

      if(GetSessionHighLow(londonStart, londonEnd, londonHigh, londonLow))
      {
         DrawLevel("LONDON_H", londonHigh, LondonColor, STYLE_DOT, LineWidth, "London High");
         DrawLevel("LONDON_L", londonLow, LondonColor, STYLE_DOT, LineWidth, "London Low");
      }
      else
      {
         DeleteOne("LONDON_H");
         DeleteOne("LONDON_L");
      }
   }
   else
   {
      DeleteOne("LONDON_H");
      DeleteOne("LONDON_L");
   }

   // New York Session
   if(ShowNewYorkSession)
   {
      double nyHigh = 0;
      double nyLow = 0;

      datetime nyStart = MakeSessionTime(dayStart, NYStartHour, NYStartMinute);
      datetime nyEnd = MakeSessionTime(dayStart, NYEndHour, NYEndMinute);

      if(GetSessionHighLow(nyStart, nyEnd, nyHigh, nyLow))
      {
         DrawLevel("NY_H", nyHigh, NYColor, STYLE_DOT, LineWidth, "NY High");
         DrawLevel("NY_L", nyLow, NYColor, STYLE_DOT, LineWidth, "NY Low");
      }
      else
      {
         DeleteOne("NY_H");
         DeleteOne("NY_L");
      }
   }
   else
   {
      DeleteOne("NY_H");
      DeleteOne("NY_L");
   }

   // Daily VWAP
   if(ShowDailyVWAP)
   {
      double vwap = 0;

      if(CalculateDailyVWAP(vwap))
         DrawLevel("DAILY_VWAP", vwap, VWAPColor, STYLE_SOLID, 2, "Daily VWAP");
      else
         DeleteOne("DAILY_VWAP");
   }
   else
   {
      DeleteOne("DAILY_VWAP");
   }

   ChartRedraw();
}

// ==========================
// MT4 EVENTS
// ==========================

int OnInit()
{
   int timerSeconds = RefreshSeconds;

   if(timerSeconds < 1)
      timerSeconds = 1;

   EventSetTimer(timerSeconds);

   DrawAllLevels();

   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason)
{
   EventKillTimer();
   DeleteAll();
}

void OnTimer()
{
   DrawAllLevels();
}

int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
   return(rates_total);
}