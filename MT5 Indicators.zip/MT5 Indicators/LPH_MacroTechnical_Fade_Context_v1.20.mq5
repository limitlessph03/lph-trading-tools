//+------------------------------------------------------------------+
//|                 LPH_MacroTechnical_Fade_Context_v1.20.mq5         |
//|                  Limitless PH Unified Decision Context            |
//|                                                                  |
//|  Faithful 1:1 port of the MT4 indicator. Same inputs, same        |
//|  object names/prefix, same calculations and visual output.        |
//|  Only MT4 -> MT5 API translations were applied.                   |
//|                                                                  |
//|  Reads the shared macro cache written by LPH_MacroBridge_EA and   |
//|  combines the authoritative LPH Macro Heatmap reading with local  |
//|  D1/H4 50-EMA, TDI, session-fade, price-location and position-risk |
//|  gates. Draws one dashboard and raises optional context alerts.    |
//|                                                                  |
//|  Decision support only. NEVER opens, modifies or closes trades.   |
//|  No WebRequest here (the bridge EA owns all network access).      |
//|  No DLLs.                                                         |
//+------------------------------------------------------------------+
#property indicator_chart_window
#property indicator_plots 0
#property copyright "Limitless PH"
#property version   "1.20"
#property description "LPH Macro-Technical + NY Fade Context. Closed-candle decision support only."

#include <LPH_MacroTechnical_Core.mqh>

//==================================================================
// Inputs — Macro
//==================================================================
input string  Inp_Macro                 = "----- Macro -----"; // ---
input double  MinMacroDifferential       = 20.0;   // Provisional: min |differential| for a regime
input double  MacroConflictTolerance     = 10.0;   // Provisional: 7D tolerance vs 30D regime
input string  OverrideBaseCode           = "";     // Force base currency (blank = auto)
input string  OverrideQuoteCode          = "";     // Force quote currency (blank = auto)
input int     StaleWarningHours          = 12;     // AGING threshold
input int     DisableSignalsAfterHours   = 36;     // STALE threshold (disables directional labels)

//==================================================================
// Inputs — Technical
//==================================================================
input string  Inp_Tech                  = "----- Technical -----"; // ---
input int              EMAPeriod         = 50;
input ENUM_APPLIED_PRICE EMAAppliedPrice = PRICE_CLOSE;
input double  EMANeutralToleranceATR     = 0.05;   // ATR-scaled neutral band around the EMA
input int     TDIRSIPeriod               = 14;
input int     TDIPriceLinePeriod         = 2;
input int     TDISignalLinePeriod        = 7;
input int     TDIMarketBaseLinePeriod    = 40;
input ENUM_APPLIED_PRICE TDIPrice        = PRICE_CLOSE;
input int     ExtensionATRPeriod         = 14;     // Provisional research setting
input double  H4PullbackZoneATR          = 0.50;   // Provisional research setting
input double  H4MaxWatchExtensionATR     = 1.25;   // Provisional research setting
input double  H4ExtendedThresholdATR     = 1.50;   // Provisional research setting
input double  H4InvalidationToleranceATR = 0.25;   // Provisional research setting
input bool    EnableExtensionFilter      = true;
input bool    EnableM15TriggerModule     = true;
input int     M15TriggerLookbackBars     = 4;
input string  Inp_RealTrend             = "----- ADX RealTrend (H4 evidence gate) -----"; // ---
input int     RealTrendADXPeriod         = 14;
input double  RealTrendADXMin            = 20.0;
input int     RealTrendERPeriod          = 10;
input double  RealTrendERMin             = 0.30;
input int     RealTrendChopPeriod        = 14;
input double  RealTrendChopMax           = 61.8;
input int     RealTrendEMAFast           = 8;
input int     RealTrendEMASlow           = 20;
input int     RealTrendEMAFilter         = 50;
input bool    RealTrendBlockMondayGap    = true;
input ENUM_TIMEFRAMES RealTrendTimeframe = PERIOD_CURRENT; // PERIOD_CURRENT = follow the chart TF
input bool    ShowRealTrendMetrics       = true;

//==================================================================
// Inputs — NY Fade Context
//==================================================================
input string  Inp_Fade                  = "----- NY Fade Context -----"; // ---
input bool    EnableFadeModule           = true;
input int     DailySlopeLookback         = 5;      // Closed D1 EMA slope lookback
input int     DailySlopeATRPeriod        = 14;
input double  DailySlopeThresholdATR     = 0.15;   // |EMA slope|/D1 ATR per bar
input int     LondonOpenHour             = 7;      // Broker server time
input int     LondonOpenMinute           = 0;
input int     NyOpenHour                 = 13;     // Broker server time
input int     NyOpenMinute               = 0;
input int     NyCloseHour                = 22;     // Broker server time
input int     NyCloseMinute              = 0;
input int     PreNyLeadMinutes           = 120;
input int     FadeTriggerLookbackM15     = 4;
input int     FadeATRPeriodM15           = 14;
input double  FadeLevelToleranceATR      = 0.15;
input double  FadeMaxCloseDistanceATR    = 0.35;
input double  FadeMinWickATR             = 0.10;
input double  FadeH1OversoldRSI          = 32.0;   // Avoid late fresh shorts below this
input double  FadeH1OverboughtRSI        = 68.0;   // Avoid late fresh buys above this
input bool    UseLondonHighLow           = true;
input bool    UsePreviousDayHighLow      = true;
input bool    UseDailyVWAP               = true;
input bool    UseWeeklyVWAP              = true;
input double  ManualDailyPOC             = 0.0;    // 0 = disabled
input double  ManualWeeklyPOC            = 0.0;    // 0 = disabled
input bool    InflationOilShockRegime    = false;  // Manual override: blocks metals/oil fade-short
input bool    MacroFlagMetalsOilOnly     = true;
input bool    RequireMacroNotOpposed     = true;
input bool    RequireM15MomentumTurn     = true;
input bool    ShowFadeDetails            = true;

//==================================================================
// Inputs — Position Risk Guard
//==================================================================
input string  Inp_Risk                  = "----- Position Risk Guard -----"; // ---
input bool    EnablePositionRiskGuard    = true;
input int     PositionMagicFilter        = 0;      // 0 = all magic numbers
input int     StackWarnAt                = 2;
input int     StackBlockAt               = 4;
input double  TradeWarnHours             = 12.0;
input double  TradeStaleHours            = 24.0;
input bool    BlockWhenHedgeLocked       = true;   // Both buy and sell open on chart symbol

//==================================================================
// Inputs — Panel
//==================================================================
input string  Inp_Panel                 = "----- Panel -----"; // ---
input ENUM_BASE_CORNER PanelCorner       = CORNER_LEFT_UPPER;
input int     PanelX                     = 12;
input int     PanelY                     = 25;
input int     PanelWidth                 = 455;
input int     PanelFontSize              = 9;
input string  PanelFont                  = "Consolas";
input color   BackgroundColor            = C'28,28,32';   // dark charcoal
input color   BorderColor                = C'70,70,78';
input color   TextColor                  = clrGainsboro;
input color   StrongBullColor            = C'0,140,70';   // dark green
input color   BullColor                  = C'60,190,110'; // medium green
input color   WatchColor                 = C'230,170,40'; // amber
input color   NeutralColor               = C'150,150,155';// grey
input color   ConflictColor              = C'235,130,40'; // orange
input color   BearColor                  = C'220,70,70';  // red
input color   StaleColor                 = C'150,80,80';  // muted red
input bool    CompactMode                = false;
input bool    ShowRawMacroValues         = true;
input bool    ShowConfidence             = true;
input bool    ShowUpdateTime             = true;
input bool    ShowDebugInfo              = false;

//==================================================================
// Inputs — Alerts
//==================================================================
input string  Inp_Alerts                = "----- Alerts -----"; // ---
input bool    EnableAlerts               = true;
input bool    AlertAPlusOnly             = false;
input bool    EnablePopupAlert           = true;
input bool    EnablePushNotification     = false;
input bool    EnableEmailAlert           = false;
input bool    EnableSoundAlert           = false;
input string  AlertSoundFile             = "alert.wav";
input bool    EnableH1WatchAlerts         = true;
input bool    EnableM15TriggerAlerts      = false;
input bool    EnableAPlusAlerts           = true;
input bool    EnableExtensionWarnings     = true;
input bool    EnableInvalidationAlerts    = true;
input bool    EnableFreshnessAlerts       = false;  // Optional cache stale/recovery notifications
input bool    EnableFadeReadyAlerts       = true;

//==================================================================
// State
//==================================================================
string   g_prefix         = "";
int      g_hRTADX         = INVALID_HANDLE;
int      g_rtTF           = PERIOD_H4;
int      g_lineHeight      = 0;

datetime g_lastH4Time      = 0;
datetime g_lastD1Time      = 0;
datetime g_lastH1Time      = 0;
datetime g_lastM15Time     = 0;
datetime g_lastGenEpoch    = 0;

// last computed snapshot (for redraw + alert gating)
ENUM_LPH_ALIGN g_lastAlign = LPH_ALIGN_NEUTRAL;
ENUM_LPH_FRESH g_lastFresh = LPH_FRESH_MISSING;
datetime       g_lastAlertH4 = 0;
datetime       g_lastAlertH1 = 0;
datetime       g_lastAlertM15 = 0;
datetime       g_lastAlertAPlus = 0;
datetime       g_lastAlertExtension = 0;
datetime       g_lastAlertInvalidation = 0;
bool           g_initialized = false;
string         g_lastWatchKey = "";
string         g_lastTriggerKey = "";
string         g_lastAPlusKey = "";
string         g_lastExtensionKey = "";
string         g_lastInvalidationKey = "";
string         g_lastConflictKey = "";
string         g_lastFadeKey = "";
bool           g_prevExtended = false;
bool           g_prevInvalidated = false;
bool           g_prevFadeReady = false;

// Cache snapshot
LphCacheMeta g_meta;
LphCurrency  g_rows[];
LphSymbolInfo g_sym;

// Macro result
struct LphMacroResult
  {
   ENUM_LPH_MACRO cls;
   bool           hasDiff;
   double         diff7;
   double         diff30;
   string         baseCode;
   string         quoteCode;
   double         baseScore30;
   double         quoteScore30;
   double         baseScore7;
   double         quoteScore7;
   bool           baseHas;
   bool           quoteHas;
   bool           isFx;
   double         assetScore;
   bool           hasAsset;
   double         confidence;
   bool           hasConfidence;
   string         note;
  };

// Technical snapshot
struct LphTechResult
  {
   ENUM_LPH_TECH  cls;
   ENUM_LPH_DIR   d1ema;
   ENUM_LPH_DIR   h4ema;
   ENUM_LPH_DIR   d1tdi;
   ENUM_LPH_DIR   h4tdi;
   ENUM_LPH_DIR   h1ema;
   ENUM_LPH_DIR   h1tdi;
   ENUM_LPH_DIR   m15ema;
   ENUM_LPH_DIR   m15tdi;
   bool           h4FreshBull;
   bool           h4FreshBear;
   bool           d1FreshBull;
   bool           d1FreshBear;
   bool           h1FreshBull;
   bool           h1FreshBear;
   bool           m15FreshBull;
   bool           m15FreshBear;
   bool           h4EmaReclaimBull;
   bool           h4EmaReclaimBear;
   bool           h1EmaReclaimBull;
   bool           h1EmaReclaimBear;
   bool           m15EmaReclaimBull;
   bool           m15EmaReclaimBear;
   bool           m15RecentBull;
   bool           m15RecentBear;
   bool           historyOk;
   bool           h1HistoryOk;
   bool           m15HistoryOk;
   double         d1Close, d1Ema, h4Close, h4Ema, h1Close, h1Ema, m15Close, m15Ema;
   double         h4Atr;
   double         h4ExtensionAtr;
   //--- RealTrend (evidence-based H4 trend-quality gate)
   string         rtWord;
   int            rtDir;
   double         rtAdx;
   double         rtEr;
   double         rtChop;
   bool           rtHistoryOk;
   bool           rtGapBlocked;
  };

enum ENUM_LPH_PRIMARY
  {
   LPH_PRIMARY_NEUTRAL = 0,
   LPH_PRIMARY_CONFLICT,
   LPH_PRIMARY_APLUS_BUY,
   LPH_PRIMARY_APLUS_SELL,
   LPH_PRIMARY_H1_BUY,
   LPH_PRIMARY_H1_SELL,
   LPH_PRIMARY_M15_BUY,
   LPH_PRIMARY_M15_SELL,
   LPH_PRIMARY_EXTENDED_BUY,
   LPH_PRIMARY_EXTENDED_SELL,
   LPH_PRIMARY_EXTENDED_NEUTRAL,
   LPH_PRIMARY_INVALIDATED,
   LPH_PRIMARY_UNAVAILABLE
  };

struct LphSignalResult
  {
   bool macroUsable;
   bool regimeBull;
   bool regimeBear;
   bool h4Pullback;
   bool h4ValidBull;
   bool h4ValidBear;
   bool h4ExtendedBull;
   bool h4ExtendedBear;
   bool h4RawExtended;
   bool h4Invalidated;
   bool h1BuyWatch;
   bool h1SellWatch;
   bool m15BuyTrigger;
   bool m15SellTrigger;
   bool aPlusBuy;
   bool aPlusSell;
   ENUM_LPH_PRIMARY primary;
   string locationLabel;
   string entryQuality;
  };

enum ENUM_LPH_FADE_SESSION
  {
   LPH_FADE_CLOSED = 0,
   LPH_FADE_PRE_NY,
   LPH_FADE_NY
  };

enum ENUM_LPH_FADE_STATE
  {
   LPH_FADE_DISABLED = 0,
   LPH_FADE_BLOCKED,
   LPH_FADE_WAIT,
   LPH_FADE_BUY_WATCH,
   LPH_FADE_SELL_WATCH,
   LPH_FADE_BUY_READY,
   LPH_FADE_SELL_READY,
   LPH_FADE_CONFLICT
  };

struct LphFadeResult
  {
   ENUM_LPH_FADE_SESSION session;
   ENUM_LPH_FADE_STATE   state;
   int      dailyTrend;
   double   dailyEma;
   double   dailySlopeAtr;
   double   m15Atr;
   double   h1Rsi;
   double   dailyVwap;
   double   weeklyVwap;
   double   londonHigh;
   double   londonLow;
   double   previousDayHigh;
   double   previousDayLow;
   double   shortLevel;
   double   buyLevel;
   string   shortLevelName;
   string   buyLevelName;
   bool     shortRegimeOk;
   bool     buyRegimeOk;
   bool     shortMacroOk;
   bool     buyMacroOk;
   bool     shortMomentumOk;
   bool     buyMomentumOk;
   bool     shortLocationOk;
   bool     buyLocationOk;
   bool     shortTrigger;
   bool     buyTrigger;
   int      shortScore;
   int      buyScore;
   int      scoreTotal;
   int      buyDepth;
   int      sellDepth;
   double   buyLots;
   double   sellLots;
   int      warnTrades;
   int      staleTrades;
   double   oldestHours;
   bool     hedgeLocked;
   bool     riskBlocked;
   string   riskReason;
   string   verdict;
   string   reason;
   string   invalidation;
  };

//==================================================================
// MT4 compatibility: TimeDayOfWeek removed in MQL5
//==================================================================
int TimeDayOfWeek(const datetime t)
  {
   MqlDateTime s;
   TimeToStruct(t, s);
   return(s.day_of_week);
  }

//==================================================================
// Lifecycle
//==================================================================
int OnInit()
  {
   g_prefix = "LPHMTC_" + IntegerToString((int)ChartID()) + "_";
   g_lineHeight = (int)MathMax(12, PanelFontSize * 1.9 + 2);
   g_rtTF = (RealTrendTimeframe == PERIOD_CURRENT ? (int)_Period : (int)RealTrendTimeframe);
   g_hRTADX = iADX(_Symbol, (ENUM_TIMEFRAMES)g_rtTF, RealTrendADXPeriod);
   g_initialized = false;
   g_lastH4Time = 0;
   g_lastD1Time = 0;
   g_lastH1Time = 0;
   g_lastM15Time = 0;
   g_lastGenEpoch = 0;

   EventSetTimer(2);
   Recalculate(true);
   return(INIT_SUCCEEDED);
  }

void OnDeinit(const int reason)
  {
   EventKillTimer();
   LphReleaseHandles();
   if(g_hRTADX != INVALID_HANDLE) IndicatorRelease(g_hRTADX);
   ObjectsDeleteAll(0, g_prefix);
  }

int OnCalculate(const int rates_total,
                const int prev_calculated,
                const int begin,
                const double &price[])
  {
   // Cheap new-candle detection; heavy work happens in OnTimer/Recalculate.
   if(NewCandle())
      Recalculate(false);
   return(rates_total);
  }

void OnTimer()
  {
   bool force = NewCandle();
   Recalculate(force);
  }

void OnChartEvent(const int id, const long &lparam, const double &dparam, const string &sparam)
  {
   if(id == CHARTEVENT_CHART_CHANGE)
      Redraw();   // reposition after resize
  }

//==================================================================
// New completed candle detection (D1 / H4 / H1 / M15)
//==================================================================
bool NewCandle()
  {
   bool changed = false;
   datetime h4 = iTime(_Symbol, PERIOD_H4, 0);
   datetime d1 = iTime(_Symbol, PERIOD_D1, 0);
   datetime h1 = iTime(_Symbol, PERIOD_H1, 0);
   datetime m15 = iTime(_Symbol, PERIOD_M15, 0);
   if(h4 != g_lastH4Time && h4 > 0) { g_lastH4Time = h4; changed = true; }
   if(d1 != g_lastD1Time && d1 > 0) { g_lastD1Time = d1; changed = true; }
   if(h1 != g_lastH1Time && h1 > 0) { g_lastH1Time = h1; changed = true; }
   if(m15 != g_lastM15Time && m15 > 0) { g_lastM15Time = m15; changed = true; }
   return(changed);
  }

//==================================================================
// Master recalculation
//==================================================================
void Recalculate(bool force)
  {
   // 1) Load macro cache.
   // Read into a temporary snapshot. A bridge cache replacement has a very
   // short delete/move window; retain the last validated snapshot rather than
   // turning that transient miss into false STALE/RECOVERED alerts.
   LphCacheMeta readMeta;
   LphCurrency readRows[];
   bool cacheOk = LphReadCache(readMeta, readRows);
   if(cacheOk)
     {
      g_meta = readMeta;
      ArrayResize(g_rows, ArraySize(readRows));
      for(int cacheRow = 0; cacheRow < ArraySize(readRows); cacheRow++)
         g_rows[cacheRow] = readRows[cacheRow];
     }
   else if(!g_meta.valid)
     {
      g_meta = readMeta;
      ArrayResize(g_rows, 0);
     }

   datetime nowGmt = TimeGMT();
   ENUM_LPH_FRESH fresh = LphClassifyFreshness(g_meta, nowGmt, StaleWarningHours, DisableSignalsAfterHours);

   bool macroChanged = (g_meta.valid && g_meta.generatedEpoch != g_lastGenEpoch);
   if(g_meta.valid)
      g_lastGenEpoch = g_meta.generatedEpoch;

   // 2) Resolve symbol.
   g_sym = LphResolveSymbol(_Symbol, OverrideBaseCode, OverrideQuoteCode);

   // 3) Build macro + technical.
   LphMacroResult macro = BuildMacro(fresh);
   LphTechResult  tech  = BuildTechnical();

   // 4) Final alignment.
   ENUM_LPH_ALIGN align = LphClassifyAlignment(macro.cls, tech.cls, fresh);
   LphSignalResult signals = BuildSignals(macro, tech, align, fresh);
   LphFadeResult fade = BuildFadeContext(macro, tech, signals, fresh);

   // 5) Alerts (skip on the very first pass to avoid a startup alert).
   if(g_initialized)
      EvaluateAlerts(macro, tech, signals, fade, align, fresh, macroChanged);
   else
     {
      g_lastAlertH1 = iTime(_Symbol, PERIOD_H1, 1);
      g_lastAlertM15 = iTime(_Symbol, PERIOD_M15, 1);
      g_lastAlertAPlus = (datetime)MathMax(iTime(_Symbol, PERIOD_D1, 1), iTime(_Symbol, PERIOD_H4, 1));
      g_lastAlertExtension = iTime(_Symbol, PERIOD_H4, 1);
      g_lastAlertInvalidation = iTime(_Symbol, PERIOD_H4, 1);
      g_prevExtended = signals.h4RawExtended;
      g_prevInvalidated = signals.h4Invalidated;
      g_prevFadeReady = (fade.state == LPH_FADE_BUY_READY || fade.state == LPH_FADE_SELL_READY);
     }

   g_lastAlign = align;
   g_lastFresh = fresh;
   g_initialized = true;

   // 6) Draw.
   RenderPanel(macro, tech, signals, fade, align, fresh);
  }

//==================================================================
// Macro construction
//==================================================================
LphMacroResult BuildMacro(ENUM_LPH_FRESH fresh)
  {
   LphMacroResult r;
   r.cls = LPH_MACRO_UNAVAILABLE;
   r.hasDiff = false; r.diff7 = 0; r.diff30 = 0;
   r.baseCode = ""; r.quoteCode = "";
   r.baseScore30 = 0; r.quoteScore30 = 0; r.baseScore7 = 0; r.quoteScore7 = 0;
   r.baseHas = false; r.quoteHas = false; r.isFx = g_sym.isFx;
   r.assetScore = 0; r.hasAsset = false;
   r.confidence = 0; r.hasConfidence = false;
   r.note = "";

   if(!g_meta.valid)
     {
      r.note = "Macro cache " + LphFreshLabel(fresh) + ".";
      return(r);
     }
   if(!g_sym.resolved)
     {
      r.note = "UNSUPPORTED SYMBOL - MACRO SIGNAL UNAVAILABLE";
      return(r);
     }

   if(g_sym.isFx)
     {
      r.baseCode  = g_sym.base;
      r.quoteCode = g_sym.quote;
      int bi = LphFindCurrency(g_rows, g_sym.base);
      int qi = LphFindCurrency(g_rows, g_sym.quote);
      bool baseOk  = (bi >= 0 && g_rows[bi].has30d && g_rows[bi].has7d);
      bool quoteOk = (qi >= 0 && g_rows[qi].has30d && g_rows[qi].has7d);

      if(bi >= 0) { r.baseScore30 = g_rows[bi].score30d; r.baseScore7 = g_rows[bi].score7d; r.baseHas = baseOk; }
      if(qi >= 0) { r.quoteScore30 = g_rows[qi].score30d; r.quoteScore7 = g_rows[qi].score7d; r.quoteHas = quoteOk; }

      if(baseOk && quoteOk)
        {
         r.diff30 = r.baseScore30 - r.quoteScore30;   // Base 30D - Quote 30D
         r.diff7  = r.baseScore7  - r.quoteScore7;    // Base 7D  - Quote 7D
         r.hasDiff = true;
         r.cls = LphClassifyMacro(r.diff7, r.diff30, MinMacroDifferential, MacroConflictTolerance);
        }
      else
        {
         // One side missing: never fabricate a differential.
         if(g_sym.quote == "USD" && quoteOk)
            r.note = "PARTIAL MACRO DATA - USD CONTEXT ONLY";
         else
            if(g_sym.base == "USD" && baseOk)
               r.note = "PARTIAL MACRO DATA - USD CONTEXT ONLY";
            else
               r.note = "PARTIAL MACRO DATA - MISSING CURRENCY";
         r.cls = LPH_MACRO_PARTIAL;
        }
      return(r);
     }

   // Single-asset CFD (gold / silver / index / oil): use its own score only.
   r.baseCode = g_sym.assetCode;
   int ai = LphFindCurrency(g_rows, g_sym.assetCode);
   if(ai >= 0)
     {
      bool usable = (g_rows[ai].status != "no_data") &&
                    (g_rows[ai].hasComposite || g_rows[ai].hasStable);
      if(usable)
        {
         r.assetScore = g_rows[ai].hasComposite ? g_rows[ai].compositeScore : g_rows[ai].stableScore;
         r.hasAsset = true;
         r.diff30 = r.assetScore;
         r.diff7  = r.assetScore;
         r.hasDiff = true;
         r.cls = LphClassifyMacro(r.assetScore, r.assetScore, MinMacroDifferential, MacroConflictTolerance);
         return(r);
        }
     }

   // No authoritative asset score. Offer USD context if available; never fabricate.
   int ui = LphFindCurrency(g_rows, "USD");
   if(ui >= 0 && g_rows[ui].has30d)
     {
      r.note = "PARTIAL MACRO DATA - USD CONTEXT ONLY";
      r.baseScore30 = g_rows[ui].score30d;
      r.baseScore7  = g_rows[ui].has7d ? g_rows[ui].score7d : 0;
      r.cls = LPH_MACRO_PARTIAL;
     }
   else
     {
      r.note = g_sym.assetCode + " macro score unavailable.";
      r.cls = LPH_MACRO_UNAVAILABLE;
     }
   return(r);
  }

//==================================================================
// Technical construction
//==================================================================
//==================================================================
// RealTrend — evidence-based H4 trend-quality gate
//   Ported from LPH_RealTrend_Regime (loss findings #1/#3/#4):
//   ADX(14)>=20 AND Kaufman ER(10)>=0.30 AND Choppiness(14)<=61.8,
//   EMA8>EMA20 + close>EMA50 + EMA20 rising (bull) / mirror (bear),
//   Monday 00:00 reopen blocked. Closed candles on the chosen TF
//   (RealTrendTimeframe = PERIOD_CURRENT follows the chart timeframe).
//==================================================================
double RealTrendADXValue(int shift)
  {
   if(g_hRTADX == INVALID_HANDLE) return(0.0);
   double buf[];
   ArraySetAsSeries(buf, true);
   if(CopyBuffer(g_hRTADX, 0, shift, 1, buf) < 1) return(0.0);
   return(buf[0]);
  }

double RealTrendKaufmanER(int shift)
  {
   int p = RealTrendERPeriod;
   int total = p + shift;
   if(total >= iBars(_Symbol, (ENUM_TIMEFRAMES)g_rtTF) || total < 1) return(0.0);
   double net = MathAbs(iClose(_Symbol, (ENUM_TIMEFRAMES)g_rtTF, total) - iClose(_Symbol, (ENUM_TIMEFRAMES)g_rtTF, shift));
   double sum = 0.0;
   for(int i = shift; i < total; i++)
      sum += MathAbs(iClose(_Symbol, (ENUM_TIMEFRAMES)g_rtTF, i + 1) - iClose(_Symbol, (ENUM_TIMEFRAMES)g_rtTF, i));
   if(sum <= 0.0) return(0.0);
   return(net / sum);
  }

double RealTrendChoppiness(int shift)
  {
   int p = RealTrendChopPeriod;
   int total = p + shift;
   if(total >= iBars(_Symbol, (ENUM_TIMEFRAMES)g_rtTF) || total < 1) return(100.0);
   double hh = -DBL_MAX, ll = DBL_MAX, sumTR = 0.0;
   for(int i = 0; i < p; i++)
     {
      double hi   = iHigh(_Symbol, (ENUM_TIMEFRAMES)g_rtTF, shift + i);
      double lo   = iLow(_Symbol, (ENUM_TIMEFRAMES)g_rtTF, shift + i);
      double prev = iClose(_Symbol, (ENUM_TIMEFRAMES)g_rtTF, shift + i + 1);
      double tr   = MathMax(hi - lo, MathMax(MathAbs(hi - prev), MathAbs(lo - prev)));
      sumTR += tr;
      if(hi > hh) hh = hi;
      if(lo < ll) ll = lo;
     }
   if(hh <= ll || p <= 1 || sumTR <= 0.0) return(100.0);
   return(100.0 * MathLog10(sumTR / (hh - ll)) / MathLog10(p));
  }

bool RealTrendMondayGap(int shift)
  {
   datetime t = iTime(_Symbol, (ENUM_TIMEFRAMES)g_rtTF, shift);
   datetime p = iTime(_Symbol, (ENUM_TIMEFRAMES)g_rtTF, shift + 1);
   if(t <= 0 || p <= 0) return(false);
   MqlDateTime dt;
   TimeToStruct(t, dt);
   return(dt.day_of_week == 1 && dt.hour == 0 && dt.min == 0 && (t - p) > 4 * 3600);
  }

// +1 bull / -1 bear / 0 chop-or-flat (closed H4 candles).
int RealTrendCompute(int shift, double &adx, double &er, double &chop)
  {
   adx  = RealTrendADXValue(shift);
   er   = RealTrendKaufmanER(shift);
   chop = RealTrendChoppiness(shift);

   double e8     = LphMAValue(_Symbol, (ENUM_TIMEFRAMES)g_rtTF, RealTrendEMAFast, MODE_EMA, PRICE_CLOSE, shift);
   double e20    = LphMAValue(_Symbol, (ENUM_TIMEFRAMES)g_rtTF, RealTrendEMASlow, MODE_EMA, PRICE_CLOSE, shift);
   double e50    = LphMAValue(_Symbol, (ENUM_TIMEFRAMES)g_rtTF, RealTrendEMAFilter, MODE_EMA, PRICE_CLOSE, shift);
   double e20old = LphMAValue(_Symbol, (ENUM_TIMEFRAMES)g_rtTF, RealTrendEMASlow, MODE_EMA, PRICE_CLOSE, shift + 5);
   double close  = iClose(_Symbol, (ENUM_TIMEFRAMES)g_rtTF, shift);

   int dir = 0;
   if(e8 > e20 && close > e50 && e20 > e20old) dir = 1;
   else if(e8 < e20 && close < e50 && e20 < e20old) dir = -1;

   if(dir == 0) return(0);
   if(adx < RealTrendADXMin || er < RealTrendERMin || chop > RealTrendChopMax) return(0);
   if(RealTrendBlockMondayGap && RealTrendMondayGap(shift)) return(0);
   return(dir);
  }

string RealTrendWord(int rtDir)
  {
   if(rtDir > 0) return("BULLISH");
   if(rtDir < 0) return("BEARISH");
   return("CHOP");
  }

string RealTrendTFLabel()
  {
   if(g_rtTF == (int)PERIOD_M1)  return("M1");
   if(g_rtTF == (int)PERIOD_M5)  return("M5");
   if(g_rtTF == (int)PERIOD_M15) return("M15");
   if(g_rtTF == (int)PERIOD_M30) return("M30");
   if(g_rtTF == (int)PERIOD_H1)  return("H1");
   if(g_rtTF == (int)PERIOD_H4)  return("H4");
   if(g_rtTF == (int)PERIOD_D1)  return("D1");
   if(g_rtTF == (int)PERIOD_W1)  return("W1");
   if(g_rtTF == (int)PERIOD_MN1) return("MN1");
   return(IntegerToString(g_rtTF));
  }

color RealTrendColor(int rtDir)
  {
   if(rtDir > 0) return(StrongBullColor);
   if(rtDir < 0) return(BearColor);
   return(WatchColor);
  }

LphTechResult BuildTechnical()
  {
   LphTechResult t;
   t.h4FreshBull = false; t.h4FreshBear = false;
   t.d1FreshBull = false; t.d1FreshBear = false;
   t.h1FreshBull = false; t.h1FreshBear = false;
   t.m15FreshBull = false; t.m15FreshBear = false;
   t.h4EmaReclaimBull = false; t.h4EmaReclaimBear = false;
   t.h1EmaReclaimBull = false; t.h1EmaReclaimBear = false;
   t.m15EmaReclaimBull = false; t.m15EmaReclaimBear = false;
   t.m15RecentBull = false; t.m15RecentBear = false;

   t.d1ema = LphEmaDirection(_Symbol, PERIOD_D1, EMAPeriod, EMAAppliedPrice,
                             EMANeutralToleranceATR, t.d1Close, t.d1Ema);
   t.h4ema = LphEmaDirection(_Symbol, PERIOD_H4, EMAPeriod, EMAAppliedPrice,
                             EMANeutralToleranceATR, t.h4Close, t.h4Ema);
   t.h1ema = LphEmaDirection(_Symbol, PERIOD_H1, EMAPeriod, EMAAppliedPrice,
                             EMANeutralToleranceATR, t.h1Close, t.h1Ema);
   t.m15ema = LphEmaDirection(_Symbol, PERIOD_M15, EMAPeriod, EMAAppliedPrice,
                              EMANeutralToleranceATR, t.m15Close, t.m15Ema);

   bool okD1 = false, okH4 = false, okH1 = false, okM15 = false;
   double pl1, sl1, mb1;
   t.d1tdi = LphTdiDirection(_Symbol, PERIOD_D1, TDIRSIPeriod, TDIPrice,
                             TDIPriceLinePeriod, TDISignalLinePeriod, TDIMarketBaseLinePeriod,
                             t.d1FreshBull, t.d1FreshBear, okD1, pl1, sl1, mb1);
   t.h4tdi = LphTdiDirection(_Symbol, PERIOD_H4, TDIRSIPeriod, TDIPrice,
                             TDIPriceLinePeriod, TDISignalLinePeriod, TDIMarketBaseLinePeriod,
                             t.h4FreshBull, t.h4FreshBear, okH4, pl1, sl1, mb1);
   t.h1tdi = LphTdiDirection(_Symbol, PERIOD_H1, TDIRSIPeriod, TDIPrice,
                             TDIPriceLinePeriod, TDISignalLinePeriod, TDIMarketBaseLinePeriod,
                             t.h1FreshBull, t.h1FreshBear, okH1, pl1, sl1, mb1);
   t.m15tdi = LphTdiDirection(_Symbol, PERIOD_M15, TDIRSIPeriod, TDIPrice,
                              TDIPriceLinePeriod, TDISignalLinePeriod, TDIMarketBaseLinePeriod,
                              t.m15FreshBull, t.m15FreshBear, okM15, pl1, sl1, mb1);

   t.h4EmaReclaimBull = LphEmaFreshReclaim(_Symbol, PERIOD_H4, EMAPeriod, EMAAppliedPrice, 1, true);
   t.h4EmaReclaimBear = LphEmaFreshReclaim(_Symbol, PERIOD_H4, EMAPeriod, EMAAppliedPrice, 1, false);
   t.h1EmaReclaimBull = LphEmaFreshReclaim(_Symbol, PERIOD_H1, EMAPeriod, EMAAppliedPrice, 1, true);
   t.h1EmaReclaimBear = LphEmaFreshReclaim(_Symbol, PERIOD_H1, EMAPeriod, EMAAppliedPrice, 1, false);
   t.m15EmaReclaimBull = LphEmaFreshReclaim(_Symbol, PERIOD_M15, EMAPeriod, EMAAppliedPrice, 1, true);
   t.m15EmaReclaimBear = LphEmaFreshReclaim(_Symbol, PERIOD_M15, EMAPeriod, EMAAppliedPrice, 1, false);

   int lookback = (int)MathMax(1, M15TriggerLookbackBars);
   for(int shift = 1; shift <= lookback; shift++)
     {
      if(LphEmaFreshReclaim(_Symbol, PERIOD_M15, EMAPeriod, EMAAppliedPrice, shift, true) ||
         LphTdiFreshCrossAt(_Symbol, PERIOD_M15, TDIRSIPeriod, TDIPrice,
                            TDIPriceLinePeriod, TDISignalLinePeriod, TDIMarketBaseLinePeriod,
                            shift, true)) t.m15RecentBull = true;
      if(LphEmaFreshReclaim(_Symbol, PERIOD_M15, EMAPeriod, EMAAppliedPrice, shift, false) ||
         LphTdiFreshCrossAt(_Symbol, PERIOD_M15, TDIRSIPeriod, TDIPrice,
                            TDIPriceLinePeriod, TDISignalLinePeriod, TDIMarketBaseLinePeriod,
                            shift, false)) t.m15RecentBear = true;
     }

   t.historyOk = (t.d1ema != LPH_DIR_NA && t.h4ema != LPH_DIR_NA && okD1 && okH4);
   t.h1HistoryOk = (t.h1ema != LPH_DIR_NA && okH1);
   t.m15HistoryOk = (t.m15ema != LPH_DIR_NA && okM15);
   t.h4Atr = LphATRValue(_Symbol, PERIOD_H4, ExtensionATRPeriod, 1);
   t.h4ExtensionAtr = (t.h4Atr > 0 ? MathAbs(t.h4Close - t.h4Ema) / t.h4Atr : 0.0);

   //--- RealTrend: evidence-based H4 trend-quality gate (ADX/ER/Choppiness/Monday-gap)
   double rtAdx = 0.0, rtEr = 0.0, rtChop = 0.0;
   t.rtHistoryOk = (g_hRTADX != INVALID_HANDLE &&
                    iBars(_Symbol, (ENUM_TIMEFRAMES)g_rtTF) >= RealTrendChopPeriod + RealTrendERPeriod + RealTrendEMAFilter + 10);
   t.rtDir = t.rtHistoryOk ? RealTrendCompute(1, rtAdx, rtEr, rtChop) : 0;
   t.rtAdx = rtAdx;
   t.rtEr = rtEr;
   t.rtChop = rtChop;
   t.rtGapBlocked = (t.rtHistoryOk && RealTrendBlockMondayGap && RealTrendMondayGap(1));
   t.rtWord = t.rtHistoryOk ? RealTrendWord(t.rtDir) : "N/A";

   t.cls = LphClassifyTechnical(t.d1ema, t.h4ema, t.d1tdi, t.h4tdi,
                                t.h4FreshBull, t.h4FreshBear, t.historyOk);
   return(t);
  }

LphSignalResult BuildSignals(LphMacroResult &macro, LphTechResult &t,
                             ENUM_LPH_ALIGN align, ENUM_LPH_FRESH fresh)
  {
   LphSignalResult s;
   s.macroUsable = g_meta.valid && !LphFreshnessDisablesSignals(fresh) && macro.hasDiff &&
                   macro.cls != LPH_MACRO_MIXED && macro.cls != LPH_MACRO_NEUTRAL &&
                   macro.cls != LPH_MACRO_PARTIAL && macro.cls != LPH_MACRO_UNAVAILABLE;
   s.regimeBull = s.macroUsable && LphMacroIsBull(macro.cls);
   s.regimeBear = s.macroUsable && LphMacroIsBear(macro.cls);
   s.h4Pullback = (t.h4Atr > 0 && t.h4ExtensionAtr <= H4PullbackZoneATR);
   s.h4RawExtended = EnableExtensionFilter && t.h4Atr > 0 &&
                     t.h4ExtensionAtr >= H4ExtendedThresholdATR;
   s.h4ExtendedBull = EnableExtensionFilter && s.regimeBull && t.h4Atr > 0 &&
                      t.h4Close > t.h4Ema && t.h4ExtensionAtr >= H4ExtendedThresholdATR;
   s.h4ExtendedBear = EnableExtensionFilter && s.regimeBear && t.h4Atr > 0 &&
                      t.h4Close < t.h4Ema && t.h4ExtensionAtr >= H4ExtendedThresholdATR;
   bool invalidBull = s.regimeBull && t.h4Atr > 0 &&
                      t.h4Close < t.h4Ema - H4InvalidationToleranceATR * t.h4Atr &&
                      t.h4tdi == LPH_DIR_BEAR;
   bool invalidBear = s.regimeBear && t.h4Atr > 0 &&
                      t.h4Close > t.h4Ema + H4InvalidationToleranceATR * t.h4Atr &&
                      t.h4tdi == LPH_DIR_BULL;
   s.h4Invalidated = invalidBull || invalidBear;
   s.h4ValidBull = s.regimeBull && !s.h4Invalidated &&
                   (s.h4Pullback || t.h4ema == LPH_DIR_BULL || t.h4FreshBull || t.h4EmaReclaimBull) &&
                   (s.h4Pullback || t.h4ExtensionAtr <= H4MaxWatchExtensionATR || !EnableExtensionFilter);
   s.h4ValidBear = s.regimeBear && !s.h4Invalidated &&
                   (s.h4Pullback || t.h4ema == LPH_DIR_BEAR || t.h4FreshBear || t.h4EmaReclaimBear) &&
                   (s.h4Pullback || t.h4ExtensionAtr <= H4MaxWatchExtensionATR || !EnableExtensionFilter);
   s.h1BuyWatch = s.macroUsable && t.historyOk && t.h1HistoryOk && s.regimeBull &&
                  t.d1Close > t.d1Ema && t.d1tdi != LPH_DIR_BEAR && s.h4ValidBull &&
                  t.h1Close > t.h1Ema && (t.h1tdi == LPH_DIR_BULL || t.h1FreshBull) &&
                  !s.h4ExtendedBull;
   s.h1SellWatch = s.macroUsable && t.historyOk && t.h1HistoryOk && s.regimeBear &&
                   t.d1Close < t.d1Ema && t.d1tdi != LPH_DIR_BULL && s.h4ValidBear &&
                   t.h1Close < t.h1Ema && (t.h1tdi == LPH_DIR_BEAR || t.h1FreshBear) &&
                   !s.h4ExtendedBear;
   s.m15BuyTrigger = EnableM15TriggerModule && t.m15HistoryOk && s.h1BuyWatch &&
                     t.m15Close > t.m15Ema && t.m15tdi == LPH_DIR_BULL && t.m15RecentBull &&
                     !s.h4ExtendedBull && !s.h4Invalidated;
   s.m15SellTrigger = EnableM15TriggerModule && t.m15HistoryOk && s.h1SellWatch &&
                      t.m15Close < t.m15Ema && t.m15tdi == LPH_DIR_BEAR && t.m15RecentBear &&
                      !s.h4ExtendedBear && !s.h4Invalidated;
   s.aPlusBuy = (align == LPH_ALIGN_APLUS_BUY);
   s.aPlusSell = (align == LPH_ALIGN_APLUS_SELL);

   bool macroUnavailable = !g_meta.valid || LphFreshnessDisablesSignals(fresh) ||
                           macro.cls == LPH_MACRO_UNAVAILABLE || macro.cls == LPH_MACRO_PARTIAL;
   if(macroUnavailable) s.primary = LPH_PRIMARY_UNAVAILABLE;
   else if(s.h4Invalidated) s.primary = LPH_PRIMARY_INVALIDATED;
   else if(s.h4ExtendedBull) s.primary = LPH_PRIMARY_EXTENDED_BUY;
   else if(s.h4ExtendedBear) s.primary = LPH_PRIMARY_EXTENDED_SELL;
   else if(s.h4RawExtended) s.primary = LPH_PRIMARY_EXTENDED_NEUTRAL;
   else if(s.m15BuyTrigger) s.primary = LPH_PRIMARY_M15_BUY;
   else if(s.m15SellTrigger) s.primary = LPH_PRIMARY_M15_SELL;
   else if(s.h1BuyWatch) s.primary = LPH_PRIMARY_H1_BUY;
   else if(s.h1SellWatch) s.primary = LPH_PRIMARY_H1_SELL;
   else if(s.aPlusBuy) s.primary = LPH_PRIMARY_APLUS_BUY;
   else if(s.aPlusSell) s.primary = LPH_PRIMARY_APLUS_SELL;
   else if(align == LPH_ALIGN_CONFLICT || macro.cls == LPH_MACRO_MIXED) s.primary = LPH_PRIMARY_CONFLICT;
   else s.primary = LPH_PRIMARY_NEUTRAL;

   string side = t.h4Close >= t.h4Ema ? " ABOVE H4 EMA" : " BELOW H4 EMA";
   s.locationLabel = DoubleToString(t.h4ExtensionAtr, 2) + " ATR" + side;
   if(s.h4Pullback) s.locationLabel = "PULLBACK ZONE - " + s.locationLabel;
   else if(s.h4RawExtended) s.locationLabel = "EXTENDED - " + s.locationLabel;
   else if(s.h4ValidBull || s.h4ValidBear) s.locationLabel = "VALID TREND LOCATION - " + s.locationLabel;
   s.entryQuality = s.h4Invalidated ? "INVALIDATED" :
                    (s.h4RawExtended ? "POOR - DO NOT CHASE" : "VALID, NOT EXTENDED");
   return(s);
  }

//==================================================================
// NY fade context
//==================================================================
string UpperSymbol(string value)
  {
   string result = value;
   StringToUpper(result);
   return(result);
  }

bool IsMetalOrOil(string symbol)
  {
   string upper = UpperSymbol(symbol);
   return(StringFind(upper, "XAU") >= 0 || StringFind(upper, "XAG") >= 0 ||
          StringFind(upper, "GOLD") >= 0 || StringFind(upper, "SILVER") >= 0 ||
          StringFind(upper, "WTI") >= 0 || StringFind(upper, "OIL") >= 0 ||
          StringFind(upper, "BRENT") >= 0);
  }

datetime StartOfServerDay(datetime when)
  {
   MqlDateTime parts;
   TimeToStruct(when, parts);
   parts.hour = 0;
   parts.min = 0;
   parts.sec = 0;
   return(StructToTime(parts));
  }

datetime StartOfServerWeek(datetime when)
  {
   datetime dayStart = StartOfServerDay(when);
   int dayOfWeek = TimeDayOfWeek(dayStart); // Sunday=0
   int daysFromMonday = (dayOfWeek + 6) % 7;
   return(dayStart - daysFromMonday * 86400);
  }

datetime TimeOnServerDay(datetime dayStart, int hourValue, int minuteValue)
  {
   int safeHour = (int)MathMax(0, MathMin(23, hourValue));
   int safeMinute = (int)MathMax(0, MathMin(59, minuteValue));
   return(dayStart + safeHour * 3600 + safeMinute * 60);
  }

ENUM_LPH_FADE_SESSION FadeSession(datetime now)
  {
   datetime dayStart = StartOfServerDay(now);
   datetime nyOpen = TimeOnServerDay(dayStart, NyOpenHour, NyOpenMinute);
   datetime nyClose = TimeOnServerDay(dayStart, NyCloseHour, NyCloseMinute);
   if(nyClose <= nyOpen)
      nyClose += 86400;

   datetime preOpen = nyOpen - (int)MathMax(0, PreNyLeadMinutes) * 60;
   if(now >= preOpen && now < nyOpen) return(LPH_FADE_PRE_NY);
   if(now >= nyOpen && now < nyClose) return(LPH_FADE_NY);
   return(LPH_FADE_CLOSED);
  }

int ClosedDailyTrend(double &emaNow, double &slopeAtr)
  {
   int lookback = (int)MathMax(1, DailySlopeLookback);
   emaNow = LphMAValue(_Symbol, PERIOD_D1, EMAPeriod, MODE_EMA, (int)EMAAppliedPrice, 1);
   double emaBack = LphMAValue(_Symbol, PERIOD_D1, EMAPeriod, MODE_EMA,
                               (int)EMAAppliedPrice, 1 + lookback);
   double atr = LphATRValue(_Symbol, PERIOD_D1, DailySlopeATRPeriod, 1);
   double closeValue = iClose(_Symbol, PERIOD_D1, 1);
   if(atr <= 0 || emaNow <= 0 || emaBack <= 0 || closeValue <= 0)
     {
      slopeAtr = 0;
      return(0);
     }

   slopeAtr = ((emaNow - emaBack) / lookback) / atr;
   if(slopeAtr >= DailySlopeThresholdATR && closeValue > emaNow) return(+1);
   if(slopeAtr <= -DailySlopeThresholdATR && closeValue < emaNow) return(-1);
   return(0);
  }

double AnchoredTickVWAP(datetime fromTime, datetime toTime)
  {
   if(fromTime <= 0 || toTime <= fromTime) return(0);
   int bars = iBars(_Symbol, PERIOD_M15);
   int maxBars = (int)MathMin(bars - 1, 1000);
   double priceVolume = 0;
   double volumeTotal = 0;

   for(int shift = 1; shift <= maxBars; shift++)
     {
      datetime barTime = iTime(_Symbol, PERIOD_M15, shift);
      if(barTime <= 0) break;
      if(barTime < fromTime) break;
      if(barTime >= toTime) continue;

      double typical = (iHigh(_Symbol, PERIOD_M15, shift) +
                        iLow(_Symbol, PERIOD_M15, shift) +
                        iClose(_Symbol, PERIOD_M15, shift)) / 3.0;
      double tickVolume = (double)iVolume(_Symbol, PERIOD_M15, shift);
      if(tickVolume <= 0) continue;
      priceVolume += typical * tickVolume;
      volumeTotal += tickVolume;
     }
   return(volumeTotal > 0 ? priceVolume / volumeTotal : 0);
  }

bool ClosedRange(datetime fromTime, datetime toTime, double &rangeHigh, double &rangeLow)
  {
   rangeHigh = 0;
   rangeLow = 0;
   if(fromTime <= 0 || toTime <= fromTime) return(false);

   int bars = iBars(_Symbol, PERIOD_M15);
   int maxBars = (int)MathMin(bars - 1, 1000);
   bool found = false;
   double highValue = -1.0e100;
   double lowValue = 1.0e100;

   for(int shift = 1; shift <= maxBars; shift++)
     {
      datetime barTime = iTime(_Symbol, PERIOD_M15, shift);
      if(barTime <= 0) break;
      if(barTime < fromTime) break;
      if(barTime >= toTime) continue;
      highValue = MathMax(highValue, iHigh(_Symbol, PERIOD_M15, shift));
      lowValue = MathMin(lowValue, iLow(_Symbol, PERIOD_M15, shift));
      found = true;
     }

   if(found)
     {
      rangeHigh = highValue;
      rangeLow = lowValue;
     }
   return(found);
  }

bool M15ShortRejection(double level, double atr, int &hitShift)
  {
   hitShift = 0;
   if(level <= 0 || atr <= 0) return(false);
   double tolerance = FadeLevelToleranceATR * atr;
   double minWick = FadeMinWickATR * atr;
   int lookback = (int)MathMax(1, FadeTriggerLookbackM15);

   for(int shift = 1; shift <= lookback; shift++)
     {
      double openValue = iOpen(_Symbol, PERIOD_M15, shift);
      double highValue = iHigh(_Symbol, PERIOD_M15, shift);
      double closeValue = iClose(_Symbol, PERIOD_M15, shift);
      double upperWick = highValue - MathMax(openValue, closeValue);
      bool touched = highValue >= level - tolerance;
      bool closedBack = closeValue < level;
      bool stayedNear = MathAbs(closeValue - level) <= FadeMaxCloseDistanceATR * atr;
      if(touched && closedBack && stayedNear && upperWick >= minWick)
        {
         hitShift = shift;
         return(true);
        }
     }
   return(false);
  }

bool M15BuyReclaim(double level, double atr, int &hitShift)
  {
   hitShift = 0;
   if(level <= 0 || atr <= 0) return(false);
   double tolerance = FadeLevelToleranceATR * atr;
   double minWick = FadeMinWickATR * atr;
   int lookback = (int)MathMax(1, FadeTriggerLookbackM15);

   for(int shift = 1; shift <= lookback; shift++)
     {
      double openValue = iOpen(_Symbol, PERIOD_M15, shift);
      double lowValue = iLow(_Symbol, PERIOD_M15, shift);
      double closeValue = iClose(_Symbol, PERIOD_M15, shift);
      double lowerWick = MathMin(openValue, closeValue) - lowValue;
      bool touched = lowValue <= level + tolerance;
      bool closedBack = closeValue > level;
      bool stayedNear = MathAbs(closeValue - level) <= FadeMaxCloseDistanceATR * atr;
      if(touched && closedBack && stayedNear && lowerWick >= minWick)
        {
         hitShift = shift;
         return(true);
        }
     }
   return(false);
  }

void EvaluateShortCandidate(string name, double level, double atr, double closeValue,
                            LphFadeResult &fade, double &bestWatch, double &bestTrigger)
  {
   if(level <= 0 || atr <= 0) return;
   double distance = MathAbs(closeValue - level) / atr;
   int hitShift = 0;
   bool triggered = M15ShortRejection(level, atr, hitShift);
   double triggerRank = hitShift * 10.0 + distance;

   if(triggered && triggerRank < bestTrigger)
     {
      bestTrigger = triggerRank;
      fade.shortTrigger = true;
      fade.shortLocationOk = true;
      fade.shortLevel = level;
      fade.shortLevelName = name;
      return;
     }

   if(bestTrigger >= 1.0e90 && distance <= FadeMaxCloseDistanceATR && distance < bestWatch)
     {
      bestWatch = distance;
      fade.shortLocationOk = true;
      fade.shortLevel = level;
      fade.shortLevelName = name;
     }
  }

void EvaluateBuyCandidate(string name, double level, double atr, double closeValue,
                          LphFadeResult &fade, double &bestWatch, double &bestTrigger)
  {
   if(level <= 0 || atr <= 0) return;
   double distance = MathAbs(closeValue - level) / atr;
   int hitShift = 0;
   bool triggered = M15BuyReclaim(level, atr, hitShift);
   double triggerRank = hitShift * 10.0 + distance;

   if(triggered && triggerRank < bestTrigger)
     {
      bestTrigger = triggerRank;
      fade.buyTrigger = true;
      fade.buyLocationOk = true;
      fade.buyLevel = level;
      fade.buyLevelName = name;
      return;
     }

   if(bestTrigger >= 1.0e90 && distance <= FadeMaxCloseDistanceATR && distance < bestWatch)
     {
      bestWatch = distance;
      fade.buyLocationOk = true;
      fade.buyLevel = level;
      fade.buyLevelName = name;
     }
  }

void ScanPositionRisk(LphFadeResult &fade)
  {
   fade.buyDepth = 0;
   fade.sellDepth = 0;
   fade.buyLots = 0;
   fade.sellLots = 0;
   fade.warnTrades = 0;
   fade.staleTrades = 0;
   fade.oldestHours = 0;

   for(int index = 0; index < PositionsTotal(); index++)
     {
      if(PositionGetTicket(index) == 0) continue;
      if(PositionGetString(POSITION_SYMBOL) != _Symbol) continue;
      if(PositionMagicFilter != 0 && (long)PositionGetInteger(POSITION_MAGIC) != PositionMagicFilter) continue;
      long ptype = PositionGetInteger(POSITION_TYPE);
      if(ptype != POSITION_TYPE_BUY && ptype != POSITION_TYPE_SELL) continue;

      if(ptype == POSITION_TYPE_BUY)
        {
         fade.buyDepth++;
         fade.buyLots += PositionGetDouble(POSITION_VOLUME);
        }
      else
        {
         fade.sellDepth++;
         fade.sellLots += PositionGetDouble(POSITION_VOLUME);
        }

      double ageHours = (double)(TimeCurrent() - (datetime)PositionGetInteger(POSITION_TIME)) / 3600.0;
      fade.oldestHours = MathMax(fade.oldestHours, ageHours);
      if(ageHours >= TradeStaleHours) fade.staleTrades++;
      else if(ageHours >= TradeWarnHours) fade.warnTrades++;
     }

   fade.hedgeLocked = (fade.buyDepth > 0 && fade.sellDepth > 0);
   fade.riskBlocked = false;
   fade.riskReason = "";
   if(!EnablePositionRiskGuard) return;

   if(fade.staleTrades > 0)
     {
      fade.riskBlocked = true;
      fade.riskReason = "STALE POSITION OPEN - RE-JUSTIFY BEFORE ADDING";
     }
   else if(BlockWhenHedgeLocked && fade.hedgeLocked)
     {
      fade.riskBlocked = true;
      fade.riskReason = "HEDGE-LOCKED - RESOLVE EXISTING EXPOSURE FIRST";
     }
   else if(MathMax(fade.buyDepth, fade.sellDepth) >= StackBlockAt)
     {
      fade.riskBlocked = true;
      fade.riskReason = "STACK LIMIT REACHED - DO NOT ADD";
     }
  }

string FadeSessionLabel(ENUM_LPH_FADE_SESSION session)
  {
   if(session == LPH_FADE_PRE_NY) return("PRE-NY");
   if(session == LPH_FADE_NY) return("NY OPEN");
   return("CLOSED");
  }

string FadeStateLabel(ENUM_LPH_FADE_STATE state)
  {
   switch(state)
     {
      case LPH_FADE_DISABLED:   return("DISABLED");
      case LPH_FADE_BLOCKED:    return("NO TRADE - HARD VETO");
      case LPH_FADE_BUY_WATCH:  return("FADE-BUY WATCH");
      case LPH_FADE_SELL_WATCH: return("FADE-SHORT WATCH");
      case LPH_FADE_BUY_READY:  return("BUY READY - FAILED BREAKDOWN");
      case LPH_FADE_SELL_READY: return("SELL READY - FAILED RALLY");
      case LPH_FADE_CONFLICT:   return("NO TRADE - TWO-WAY CONFLICT");
      default:                  return("WAITING FOR LOCATION + TRIGGER");
     }
  }

string YesNo(bool value)
  {
   return(value ? "Y" : "N");
  }

LphFadeResult BuildFadeContext(LphMacroResult &macro, LphTechResult &tech,
                               LphSignalResult &signals, ENUM_LPH_FRESH fresh)
  {
   LphFadeResult fade;
   fade.session = FadeSession(TimeCurrent());
   fade.state = EnableFadeModule ? LPH_FADE_WAIT : LPH_FADE_DISABLED;
   fade.dailyTrend = ClosedDailyTrend(fade.dailyEma, fade.dailySlopeAtr);
   fade.m15Atr = LphATRValue(_Symbol, PERIOD_M15, FadeATRPeriodM15, 1);
   fade.h1Rsi = LphRSIValue(_Symbol, PERIOD_H1, TDIRSIPeriod, (int)TDIPrice, 1);
   fade.dailyVwap = 0;
   fade.weeklyVwap = 0;
   fade.londonHigh = 0;
   fade.londonLow = 0;
   fade.previousDayHigh = iHigh(_Symbol, PERIOD_D1, 1);
   fade.previousDayLow = iLow(_Symbol, PERIOD_D1, 1);
   fade.shortLevel = 0;
   fade.buyLevel = 0;
   fade.shortLevelName = "";
   fade.buyLevelName = "";
   fade.shortRegimeOk = false;
   fade.buyRegimeOk = false;
   fade.shortMacroOk = false;
   fade.buyMacroOk = false;
   fade.shortMomentumOk = false;
   fade.buyMomentumOk = false;
   fade.shortLocationOk = false;
   fade.buyLocationOk = false;
   fade.shortTrigger = false;
   fade.buyTrigger = false;
   fade.shortScore = 0;
   fade.buyScore = 0;
   fade.scoreTotal = 5;
   fade.verdict = "";
   fade.reason = "";
   fade.invalidation = "";

   ScanPositionRisk(fade);
   if(!EnableFadeModule)
     {
      fade.verdict = FadeStateLabel(fade.state);
      fade.reason = "Fade module disabled in inputs.";
      return(fade);
     }

   datetime now = TimeCurrent();
   datetime dayStart = StartOfServerDay(now);
   datetime weekStart = StartOfServerWeek(now);
   datetime londonOpen = TimeOnServerDay(dayStart, LondonOpenHour, LondonOpenMinute);
   datetime nyOpen = TimeOnServerDay(dayStart, NyOpenHour, NyOpenMinute);
   datetime rangeEnd = (now < nyOpen ? now : nyOpen);

   if(UseDailyVWAP) fade.dailyVwap = AnchoredTickVWAP(dayStart, now);
   if(UseWeeklyVWAP) fade.weeklyVwap = AnchoredTickVWAP(weekStart, now);
   if(UseLondonHighLow) ClosedRange(londonOpen, rangeEnd, fade.londonHigh, fade.londonLow);

   bool macroFresh = g_meta.valid && !LphFreshnessDisablesSignals(fresh) &&
                     macro.cls != LPH_MACRO_UNAVAILABLE;
   fade.shortMacroOk = macroFresh;
   fade.buyMacroOk = macroFresh;
   if(RequireMacroNotOpposed)
     {
      fade.shortMacroOk = macroFresh && !LphMacroIsBull(macro.cls);
      fade.buyMacroOk = macroFresh && !LphMacroIsBear(macro.cls);
     }

   bool manualMacroApplies = (!MacroFlagMetalsOilOnly || IsMetalOrOil(_Symbol));
   if(InflationOilShockRegime && manualMacroApplies)
      fade.shortMacroOk = false;

   fade.shortRegimeOk = (fade.dailyTrend != +1);
   fade.buyRegimeOk = (fade.dailyTrend != -1);
   fade.shortMomentumOk = (fade.h1Rsi >= FadeH1OversoldRSI);
   fade.buyMomentumOk = (fade.h1Rsi <= FadeH1OverboughtRSI);
   if(RequireM15MomentumTurn)
     {
      fade.shortMomentumOk = fade.shortMomentumOk && tech.m15HistoryOk &&
                             tech.m15tdi == LPH_DIR_BEAR && tech.m15RecentBear;
      fade.buyMomentumOk = fade.buyMomentumOk && tech.m15HistoryOk &&
                           tech.m15tdi == LPH_DIR_BULL && tech.m15RecentBull;
     }

   double closeM15 = iClose(_Symbol, PERIOD_M15, 1);
   double bestShortWatch = 1.0e100;
   double bestShortTrigger = 1.0e100;
   double bestBuyWatch = 1.0e100;
   double bestBuyTrigger = 1.0e100;

   if(UseLondonHighLow)
     {
      EvaluateShortCandidate("London high", fade.londonHigh, fade.m15Atr, closeM15,
                             fade, bestShortWatch, bestShortTrigger);
      EvaluateBuyCandidate("London low", fade.londonLow, fade.m15Atr, closeM15,
                           fade, bestBuyWatch, bestBuyTrigger);
     }
   if(UsePreviousDayHighLow)
     {
      EvaluateShortCandidate("previous-day high", fade.previousDayHigh, fade.m15Atr, closeM15,
                             fade, bestShortWatch, bestShortTrigger);
      EvaluateBuyCandidate("previous-day low", fade.previousDayLow, fade.m15Atr, closeM15,
                           fade, bestBuyWatch, bestBuyTrigger);
     }
   if(UseDailyVWAP)
     {
      EvaluateShortCandidate("daily VWAP", fade.dailyVwap, fade.m15Atr, closeM15,
                             fade, bestShortWatch, bestShortTrigger);
      EvaluateBuyCandidate("daily VWAP", fade.dailyVwap, fade.m15Atr, closeM15,
                           fade, bestBuyWatch, bestBuyTrigger);
     }
   if(UseWeeklyVWAP)
     {
      EvaluateShortCandidate("weekly VWAP", fade.weeklyVwap, fade.m15Atr, closeM15,
                             fade, bestShortWatch, bestShortTrigger);
      EvaluateBuyCandidate("weekly VWAP", fade.weeklyVwap, fade.m15Atr, closeM15,
                           fade, bestBuyWatch, bestBuyTrigger);
     }
   EvaluateShortCandidate("manual daily POC", ManualDailyPOC, fade.m15Atr, closeM15,
                          fade, bestShortWatch, bestShortTrigger);
   EvaluateBuyCandidate("manual daily POC", ManualDailyPOC, fade.m15Atr, closeM15,
                        fade, bestBuyWatch, bestBuyTrigger);
   EvaluateShortCandidate("manual weekly POC", ManualWeeklyPOC, fade.m15Atr, closeM15,
                          fade, bestShortWatch, bestShortTrigger);
   EvaluateBuyCandidate("manual weekly POC", ManualWeeklyPOC, fade.m15Atr, closeM15,
                        fade, bestBuyWatch, bestBuyTrigger);
   EvaluateShortCandidate("H1 50 EMA", tech.h1Ema, fade.m15Atr, closeM15,
                          fade, bestShortWatch, bestShortTrigger);
   EvaluateBuyCandidate("H1 50 EMA", tech.h1Ema, fade.m15Atr, closeM15,
                        fade, bestBuyWatch, bestBuyTrigger);
   EvaluateShortCandidate("H4 50 EMA", tech.h4Ema, fade.m15Atr, closeM15,
                          fade, bestShortWatch, bestShortTrigger);
   EvaluateBuyCandidate("H4 50 EMA", tech.h4Ema, fade.m15Atr, closeM15,
                        fade, bestBuyWatch, bestBuyTrigger);

   bool shortLate = (tech.h4Atr > 0 && tech.h4Close < tech.h4Ema &&
                     tech.h4ExtensionAtr >= H4ExtendedThresholdATR);
   bool buyLate = (tech.h4Atr > 0 && tech.h4Close > tech.h4Ema &&
                   tech.h4ExtensionAtr >= H4ExtendedThresholdATR);

   if(fade.shortRegimeOk) fade.shortScore++;
   if(fade.shortMacroOk) fade.shortScore++;
   if(fade.shortLocationOk) fade.shortScore++;
   if(fade.shortMomentumOk) fade.shortScore++;
   if(fade.session == LPH_FADE_NY) fade.shortScore++;

   if(fade.buyRegimeOk) fade.buyScore++;
   if(fade.buyMacroOk) fade.buyScore++;
   if(fade.buyLocationOk) fade.buyScore++;
   if(fade.buyMomentumOk) fade.buyScore++;
   if(fade.session == LPH_FADE_NY) fade.buyScore++;

   bool hardDataBlock = !macroFresh || !tech.historyOk || !tech.m15HistoryOk ||
                        signals.h4Invalidated || fade.m15Atr <= 0;
   bool shortReady = fade.session == LPH_FADE_NY && fade.shortRegimeOk &&
                     fade.shortMacroOk && fade.shortLocationOk &&
                     fade.shortTrigger && fade.shortMomentumOk && !shortLate;
   bool buyReady = fade.session == LPH_FADE_NY && fade.buyRegimeOk &&
                   fade.buyMacroOk && fade.buyLocationOk &&
                   fade.buyTrigger && fade.buyMomentumOk && !buyLate;

   if(fade.riskBlocked || hardDataBlock)
     {
      fade.state = LPH_FADE_BLOCKED;
      if(fade.riskBlocked) fade.reason = fade.riskReason;
      else if(!macroFresh) fade.reason = "MACRO DATA NOT USABLE";
      else if(signals.h4Invalidated) fade.reason = "H4 STRUCTURE INVALIDATED";
      else fade.reason = "WAITING FOR CLOSED-CANDLE HISTORY";
     }
   else if(shortReady && buyReady)
     {
      fade.state = LPH_FADE_CONFLICT;
      fade.reason = "Both sides triggered near competing levels.";
     }
   else if(shortReady)
     {
      fade.state = LPH_FADE_SELL_READY;
      fade.reason = "NY failed rally + bearish M15 turn at " + fade.shortLevelName + ".";
      fade.invalidation = "M15 acceptance above " + DoubleToString(fade.shortLevel, _Digits);
     }
   else if(buyReady)
     {
      fade.state = LPH_FADE_BUY_READY;
      fade.reason = "NY failed breakdown + bullish M15 turn at " + fade.buyLevelName + ".";
      fade.invalidation = "M15 acceptance below " + DoubleToString(fade.buyLevel, _Digits);
     }
   else
     {
      bool shortWatch = fade.shortRegimeOk && fade.shortMacroOk &&
                        fade.shortLocationOk && !shortLate;
      bool buyWatch = fade.buyRegimeOk && fade.buyMacroOk &&
                      fade.buyLocationOk && !buyLate;

      if(shortWatch && !buyWatch)
        {
         fade.state = LPH_FADE_SELL_WATCH;
         if(fade.session == LPH_FADE_CLOSED) fade.reason = "Location found; wait for pre-NY/NY window.";
         else if(!fade.shortTrigger) fade.reason = "Wait for M15 rejection at " + fade.shortLevelName + ".";
         else fade.reason = "Wait for bearish M15 momentum confirmation.";
        }
      else if(buyWatch && !shortWatch)
        {
         fade.state = LPH_FADE_BUY_WATCH;
         if(fade.session == LPH_FADE_CLOSED) fade.reason = "Location found; wait for pre-NY/NY window.";
         else if(!fade.buyTrigger) fade.reason = "Wait for M15 reclaim at " + fade.buyLevelName + ".";
         else fade.reason = "Wait for bullish M15 momentum confirmation.";
        }
      else
        {
         fade.state = LPH_FADE_WAIT;
         if(fade.session == LPH_FADE_CLOSED) fade.reason = "Outside pre-NY/NY evaluation window.";
         else if(!fade.shortLocationOk && !fade.buyLocationOk) fade.reason = "Price is between actionable levels.";
         else if(shortLate || buyLate) fade.reason = "Move already extended in entry direction - do not chase.";
         else fade.reason = "Conditions are mixed; wait for one-sided confirmation.";
        }
     }

   fade.verdict = FadeStateLabel(fade.state);
   return(fade);
  }

//==================================================================
// Alerts
//==================================================================
string AlertKey(string alertType, string direction, datetime candleTime)
  {
   return(_Symbol + "|" + alertType + "|" + direction + "|" +
          IntegerToString((int)candleTime) + "|" + IntegerToString((int)g_meta.generatedEpoch));
  }

void FireDedup(string &slot, string key, string message)
  {
   if(key == slot) return;
   slot = key;
   FireAlert(message);
  }

void EvaluateAlerts(LphMacroResult &macro, LphTechResult &t, LphSignalResult &s,
                    LphFadeResult &fade, ENUM_LPH_ALIGN align,
                    ENUM_LPH_FRESH fresh, bool macroChanged)
  {
   if(!EnableAlerts)
      return;

   datetime d1Closed = iTime(_Symbol, PERIOD_D1, 1);
   datetime h4Closed = iTime(_Symbol, PERIOD_H4, 1);
   datetime h1Closed = iTime(_Symbol, PERIOD_H1, 1);
   datetime m15Closed = iTime(_Symbol, PERIOD_M15, 1);

   // Stale transitions.
   bool wasStale = (g_lastFresh == LPH_FRESH_STALE || g_lastFresh == LPH_FRESH_INVALID || g_lastFresh == LPH_FRESH_MISSING);
   bool isStale  = (fresh == LPH_FRESH_STALE || fresh == LPH_FRESH_INVALID || fresh == LPH_FRESH_MISSING);
   if(EnableFreshnessAlerts && isStale && !wasStale)
     {
      FireAlert("MACRO DATA STALE - directional signals disabled");
      return;
     }
   if(EnableFreshnessAlerts && !isStale && wasStale)
      FireAlert("MACRO DATA RECOVERED - " + LphFreshLabel(fresh));

   bool extended = s.h4RawExtended;
   bool alignChanged = (align != g_lastAlign);
   if(AlertAPlusOnly)
     {
      datetime aOnlyTime = (datetime)MathMax(d1Closed, h4Closed);
      if(EnableAPlusAlerts && !extended && (s.aPlusBuy || s.aPlusSell) && alignChanged)
        {
         string dirOnly = s.aPlusBuy ? "BUY" : "SELL";
         string keyOnly = AlertKey("APLUS", dirOnly, aOnlyTime);
         FireDedup(g_lastAPlusKey, keyOnly, "LPH TREND | " + _Symbol + " | A+ " + dirOnly +
                   " TREND CONFIRMATION | Closed D1/H4 candles | Assess chart - not an entry signal");
         g_lastAlertAPlus = aOnlyTime;
        }
      g_prevExtended = extended;
      g_prevInvalidated = s.h4Invalidated;
      return;
     }

   if(EnableInvalidationAlerts && s.h4Invalidated && !g_prevInvalidated)
     {
      string invDir = s.regimeBull ? "Bullish" : "Bearish";
      FireDedup(g_lastInvalidationKey, AlertKey("INVALIDATION", invDir, h4Closed),
                "LPH INVALIDATION | " + _Symbol + " | " + invDir +
                " watch cancelled | H4 structure invalidated");
      g_lastAlertInvalidation = h4Closed;
     }
   else if(EnableInvalidationAlerts && g_prevInvalidated && !s.h4Invalidated)
      FireDedup(g_lastInvalidationKey, AlertKey("INVALIDATION_RECOVERY", "RECOVERED", h4Closed),
                "LPH INVALIDATION | " + _Symbol + " | H4 structure recovered | Reassess chart");

   if(EnableExtensionWarnings && extended && !g_prevExtended)
     {
      string extDir = (t.h4Close >= t.h4Ema ? "UP" : "DOWN");
      string trend = (s.aPlusBuy || s.aPlusSell) ? " | A+ " + extDir + " TREND CONFIRMED" : "";
      FireDedup(g_lastExtensionKey, AlertKey("EXTENDED", extDir, h4Closed),
                "LPH TREND | " + _Symbol + trend + " | EXTENDED " +
                DoubleToString(t.h4ExtensionAtr, 2) + " ATR | DO NOT CHASE");
      g_lastAlertExtension = h4Closed;
     }
   else if(EnableExtensionWarnings && g_prevExtended && !extended)
      FireDedup(g_lastExtensionKey, AlertKey("EXTENSION_EXIT", "RECOVERED", h4Closed),
                "LPH LOCATION | " + _Symbol + " | No longer H4-extended | Reassess chart");

   if(!s.h4Invalidated && !extended)
     {
      if(EnableM15TriggerAlerts && s.m15BuyTrigger && (m15Closed != g_lastAlertM15 || alignChanged))
        {
         FireDedup(g_lastTriggerKey, AlertKey("M15_TRIGGER", "BUY", m15Closed),
                   "LPH TRIGGER | " + _Symbol + " | M15 BUY TRIGGER - CHECK CHART | H1 watch active | M15 EMA + TDI bullish | Check entry, stop and R:R");
         g_lastAlertM15 = m15Closed;
        }
      if(EnableM15TriggerAlerts && s.m15SellTrigger && (m15Closed != g_lastAlertM15 || alignChanged))
        {
         FireDedup(g_lastTriggerKey, AlertKey("M15_TRIGGER", "SELL", m15Closed),
                   "LPH TRIGGER | " + _Symbol + " | M15 SELL TRIGGER - CHECK CHART | H1 watch active | M15 EMA + TDI bearish | Check entry, stop and R:R");
         g_lastAlertM15 = m15Closed;
        }
      if(EnableH1WatchAlerts && s.h1BuyWatch && (h1Closed != g_lastAlertH1 || alignChanged))
        {
         FireDedup(g_lastWatchKey, AlertKey("H1_WATCH", "BUY", h1Closed),
                   "LPH WATCH | " + _Symbol + " | H1 BUY WATCH | Macro bullish | H4 structure valid | H1 EMA + TDI bullish | Inspect chart - no blind entry");
         g_lastAlertH1 = h1Closed;
        }
      if(EnableH1WatchAlerts && s.h1SellWatch && (h1Closed != g_lastAlertH1 || alignChanged))
        {
         FireDedup(g_lastWatchKey, AlertKey("H1_WATCH", "SELL", h1Closed),
                   "LPH WATCH | " + _Symbol + " | H1 SELL WATCH | Macro bearish | H4 structure valid | H1 EMA + TDI bearish | Inspect chart - no blind entry");
         g_lastAlertH1 = h1Closed;
        }
      datetime aTime = (datetime)MathMax(d1Closed, h4Closed);
      if(EnableAPlusAlerts && (s.aPlusBuy || s.aPlusSell) && alignChanged)
        {
         string aDir = s.aPlusBuy ? "BUY" : "SELL";
         FireDedup(g_lastAPlusKey, AlertKey("APLUS", aDir, aTime),
                   "LPH TREND | " + _Symbol + " | A+ " + aDir +
                   " TREND CONFIRMATION | Closed D1/H4 candles | Assess chart - not an entry signal");
         g_lastAlertAPlus = aTime;
        }
     }

   if(align == LPH_ALIGN_CONFLICT && (align != g_lastAlign || macroChanged))
      FireDedup(g_lastConflictKey, AlertKey("CONFLICT", "NONE", h4Closed),
                "LPH CONFLICT | " + _Symbol + " | MACRO-TECHNICAL CONFLICT | No directional alert");

   bool fadeReady = (fade.state == LPH_FADE_BUY_READY || fade.state == LPH_FADE_SELL_READY);
   if(EnableFadeReadyAlerts && fadeReady && !g_prevFadeReady)
     {
      string fadeDir = (fade.state == LPH_FADE_BUY_READY ? "BUY" : "SELL");
      FireDedup(g_lastFadeKey, AlertKey("FADE_READY", fadeDir, m15Closed),
                "LPH FADE | " + _Symbol + " | " + fade.verdict + " | " +
                fade.reason + " | " + fade.invalidation);
     }

   g_prevExtended = extended;
   g_prevInvalidated = s.h4Invalidated;
   g_prevFadeReady = fadeReady;
  }

void FireAlert(string message)
  {
   if(EnablePopupAlert)       Alert(message);
   if(EnablePushNotification) SendNotification(message);
   if(EnableEmailAlert)       SendMail("LPH Macro-Technical + Fade Context", message);
   if(EnableSoundAlert)       PlaySound(AlertSoundFile);
   if(!EnablePopupAlert && !EnablePushNotification && !EnableEmailAlert && !EnableSoundAlert)
      Print("[LPH_Context] " + message);
  }

//==================================================================
// Colour mapping (uses the user colour inputs)
//==================================================================
color DirColor(ENUM_LPH_DIR d)
  {
   switch(d)
     {
      case LPH_DIR_BULL: return(BullColor);
      case LPH_DIR_BEAR: return(BearColor);
      case LPH_DIR_NEUTRAL: return(NeutralColor);
      default: return(NeutralColor);
     }
  }

color MacroColor(ENUM_LPH_MACRO m)
  {
   switch(m)
     {
      case LPH_MACRO_STRONG_BULL: return(StrongBullColor);
      case LPH_MACRO_BULL:        return(BullColor);
      case LPH_MACRO_BEAR:        return(BearColor);
      case LPH_MACRO_STRONG_BEAR: return(BearColor);
      case LPH_MACRO_MIXED:       return(ConflictColor);
      case LPH_MACRO_PARTIAL:     return(WatchColor);
      case LPH_MACRO_NEUTRAL:     return(NeutralColor);
      default:                    return(NeutralColor);
     }
  }

color TechColor(ENUM_LPH_TECH t)
  {
   switch(t)
     {
      case LPH_TECH_STRONG_BUY:  return(StrongBullColor);
      case LPH_TECH_BUY_SETUP:   return(BullColor);
      case LPH_TECH_BUY_WATCH:   return(WatchColor);
      case LPH_TECH_STRONG_SELL: return(BearColor);
      case LPH_TECH_SELL_SETUP:  return(BearColor);
      case LPH_TECH_SELL_WATCH:  return(WatchColor);
      case LPH_TECH_WAITING:     return(NeutralColor);
      default:                   return(ConflictColor);
     }
  }

color AlignColor(ENUM_LPH_ALIGN a)
  {
   switch(a)
     {
      case LPH_ALIGN_APLUS_BUY:  return(StrongBullColor);
      case LPH_ALIGN_BUY:        return(BullColor);
      case LPH_ALIGN_BUY_WATCH:  return(WatchColor);
      case LPH_ALIGN_APLUS_SELL: return(BearColor);
      case LPH_ALIGN_SELL:       return(BearColor);
      case LPH_ALIGN_SELL_WATCH: return(WatchColor);
      case LPH_ALIGN_CONFLICT:   return(ConflictColor);
      case LPH_ALIGN_STALE_DISABLED: return(StaleColor);
      case LPH_ALIGN_MACRO_UNAVAILABLE: return(NeutralColor);
      default:                   return(NeutralColor);
     }
  }

color FreshColor(ENUM_LPH_FRESH f)
  {
   switch(f)
     {
      case LPH_FRESH_LIVE:   return(BullColor);
      case LPH_FRESH_AGING:  return(WatchColor);
      case LPH_FRESH_CACHED: return(WatchColor);
      default:               return(StaleColor);
     }
  }

color FadeColor(ENUM_LPH_FADE_STATE state)
  {
   if(state == LPH_FADE_BUY_READY) return(BullColor);
   if(state == LPH_FADE_SELL_READY) return(BearColor);
   if(state == LPH_FADE_BUY_WATCH || state == LPH_FADE_SELL_WATCH) return(WatchColor);
   if(state == LPH_FADE_BLOCKED) return(StaleColor);
   if(state == LPH_FADE_CONFLICT) return(ConflictColor);
   return(NeutralColor);
  }

string UnifiedDecision(LphSignalResult &signals, LphFadeResult &fade)
  {
   int trendDirection = 0;
   if(signals.m15BuyTrigger) trendDirection = +1;
   if(signals.m15SellTrigger) trendDirection = -1;
   int fadeDirection = 0;
   if(fade.state == LPH_FADE_BUY_READY) fadeDirection = +1;
   if(fade.state == LPH_FADE_SELL_READY) fadeDirection = -1;

   if(fade.riskBlocked || signals.h4Invalidated) return("NO TRADE - HARD VETO");
   if(trendDirection != 0 && fadeDirection != 0 && trendDirection != fadeDirection)
      return("NO TRADE - TREND/FADE CONFLICT");
   if(trendDirection > 0 && fadeDirection > 0) return("BUY READY - TREND + FADE AGREE");
   if(trendDirection < 0 && fadeDirection < 0) return("SELL READY - TREND + FADE AGREE");
   if(fadeDirection > 0) return("BUY READY - FAILED BREAKDOWN");
   if(fadeDirection < 0) return("SELL READY - FAILED RALLY");
   if(trendDirection > 0) return("TREND BUY TRIGGER - CHECK CHART");
   if(trendDirection < 0) return("TREND SELL TRIGGER - CHECK CHART");
   if(signals.h4RawExtended) return("DO NOT CHASE - H4 EXTENDED");
   if(fade.state == LPH_FADE_BUY_WATCH) return("WATCH FOR FAILED BREAKDOWN");
   if(fade.state == LPH_FADE_SELL_WATCH) return("WATCH FOR FAILED RALLY");
   if(signals.h1BuyWatch) return("H1 BUY WATCH - WAIT FOR M15");
   if(signals.h1SellWatch) return("H1 SELL WATCH - WAIT FOR M15");
   if(signals.primary == LPH_PRIMARY_CONFLICT || fade.state == LPH_FADE_CONFLICT)
      return("NO TRADE - CONDITIONS CONFLICT");
   return("WAIT - NO COMPLETE SETUP");
  }

color UnifiedDecisionColor(LphSignalResult &signals, LphFadeResult &fade)
  {
   string decision = UnifiedDecision(signals, fade);
   if(StringFind(decision, "BUY READY") == 0) return(BullColor);
   if(StringFind(decision, "SELL READY") == 0) return(BearColor);
   if(StringFind(decision, "NO TRADE") == 0) return(StaleColor);
   if(StringFind(decision, "DO NOT CHASE") == 0) return(ConflictColor);
   if(StringFind(decision, "WATCH") >= 0 || StringFind(decision, "TRIGGER") >= 0) return(WatchColor);
   return(NeutralColor);
  }

//==================================================================
// Panel rendering
//==================================================================
void RenderPanel(LphMacroResult &macro, LphTechResult &tech, LphSignalResult &signals,
                 LphFadeResult &fade, ENUM_LPH_ALIGN align, ENUM_LPH_FRESH fresh)
  {
   int line = 0;
   int maxLines = 64;
   EnsureBackground(maxLines);

   SetLine(line++, "LPH MACRO-TECHNICAL + FADE CONTEXT", TextColor, true);
   SetLine(line++, "---------------------------------------------------", BorderColor, false);
   SetLine(line++, "Symbol: " + _Symbol + "  [" + g_sym.kind + "]", TextColor, false);
   if(ShowUpdateTime)
      SetLine(line++, "Updated: " + (g_meta.valid ? g_meta.generatedAtUtc : "n/a") +
              "  (" + LphFreshLabel(fresh) + ")", FreshColor(fresh), false);
   SetLine(line++, "DECISION: " + UnifiedDecision(signals, fade),
           UnifiedDecisionColor(signals, fade), true);
   if(fade.reason != "")
      SetLine(line++, "Next: " + fade.reason, FadeColor(fade.state), false);

   // ---- MACRO ----
   SetLine(line++, "MACRO", MacroColor(macro.cls), true);
   if(macro.note != "")
      SetLine(line++, macro.note, MacroColor(macro.cls), false);

   if(g_sym.isFx && ShowRawMacroValues)
     {
      SetLine(line++, "Base 30D: " + macro.baseCode + " " + (macro.baseHas ? LphSigned(macro.baseScore30) : "n/a"), TextColor, false);
      SetLine(line++, "Quote 30D: " + macro.quoteCode + " " + (macro.quoteHas ? LphSigned(macro.quoteScore30) : "n/a"), TextColor, false);
     }
   else
      if(!g_sym.isFx && macro.hasAsset && ShowRawMacroValues)
         SetLine(line++, "Asset: " + macro.baseCode + " " + LphSigned(macro.assetScore), TextColor, false);

   if(macro.hasDiff)
     {
      if(!CompactMode)
        {
         SetLine(line++, "30D Differential: " + LphSigned(macro.diff30), MacroColor(macro.cls), false);
         SetLine(line++, "7D Differential: "  + LphSigned(macro.diff7),  MacroColor(macro.cls), false);
        }
     }
   SetLine(line++, "Macro Bias: " + LphMacroLabel(macro.cls), MacroColor(macro.cls), true);
   if(ShowConfidence)
      SetLine(line++, "Confidence: " + (macro.hasConfidence ? DoubleToString(macro.confidence * 100, 0) + "%" : "n/a"), NeutralColor, false);

   // ---- TECHNICAL REGIME ----
   SetLine(line++, "TECHNICAL REGIME  [" + tech.rtWord + "]", RealTrendColor(tech.rtDir), true);
   if(tech.cls == LPH_TECH_WAITING)
      SetLine(line++, "WAITING FOR HISTORY", WatchColor, false);
   if(ShowRealTrendMetrics)
      SetLine(line++, "RealTrend " + RealTrendTFLabel() + ": ADX " + DoubleToString(tech.rtAdx, 1) +
              " | ER " + DoubleToString(tech.rtEr, 2) +
              " | CHOP " + DoubleToString(tech.rtChop, 1) +
              (tech.rtGapBlocked ? " | MONDAY-GAP BLOCK" : "") +
              (!tech.rtHistoryOk ? " | WAITING FOR HISTORY" : ""), NeutralColor, false);
   SetLine(line++, "D1 50 EMA: " + LphDirLabel(tech.d1ema), DirColor(tech.d1ema), false);
   SetLine(line++, "D1 TDI: " + LphDirLabel(tech.d1tdi) + TdiCrossTag(tech.d1FreshBull, tech.d1FreshBear), DirColor(tech.d1tdi), false);
   SetLine(line++, "H4 50 EMA: " + EmaLabel(tech.h4ema, tech.h4EmaReclaimBull, tech.h4EmaReclaimBear), DirColor(tech.h4ema), false);
   SetLine(line++, "H4 TDI: " + LphDirLabel(tech.h4tdi) + TdiCrossTag(tech.h4FreshBull, tech.h4FreshBear), DirColor(tech.h4tdi), false);
   SetLine(line++, "H4 Location: " + signals.locationLabel,
           (signals.h4Invalidated ? StaleColor : (signals.h4RawExtended ? ConflictColor : NeutralColor)), false);
   SetLine(line++, "H4 Extension: " + (tech.h4Atr > 0 ? DoubleToString(tech.h4ExtensionAtr, 2) + " ATR" : "WAITING FOR HISTORY"), NeutralColor, false);

   if(!CompactMode)
     {
      SetLine(line++, "ENTRY-TIMING", TextColor, true);
      if(!tech.h1HistoryOk)
         SetLine(line++, "H1: WAITING FOR HISTORY", WatchColor, false);
      else
        {
         SetLine(line++, "H1 50 EMA: " + EmaLabel(tech.h1ema, tech.h1EmaReclaimBull, tech.h1EmaReclaimBear), DirColor(tech.h1ema), false);
         SetLine(line++, "H1 TDI: " + LphDirLabel(tech.h1tdi) + TdiCrossTag(tech.h1FreshBull, tech.h1FreshBear), DirColor(tech.h1tdi), false);
         SetLine(line++, "H1 Watch: " + WatchLabel(signals),
                 (signals.h1BuyWatch || signals.h1SellWatch) ? WatchColor : NeutralColor, false);
        }
      if(!tech.m15HistoryOk)
         SetLine(line++, "M15: WAITING FOR HISTORY", WatchColor, false);
      else
        {
         SetLine(line++, "M15 50 EMA: " + EmaLabel(tech.m15ema, tech.m15EmaReclaimBull, tech.m15EmaReclaimBear), DirColor(tech.m15ema), false);
         SetLine(line++, "M15 TDI: " + LphDirLabel(tech.m15tdi) + TdiCrossTag(tech.m15FreshBull, tech.m15FreshBear), DirColor(tech.m15tdi), false);
         SetLine(line++, "M15 Trigger: " + TriggerLabel(signals),
                 (signals.m15BuyTrigger ? BullColor : (signals.m15SellTrigger ? BearColor : NeutralColor)), false);
        }
     }

   // ---- NY FADE CONTEXT ----
   SetLine(line++, "NY FADE CONTEXT", FadeColor(fade.state), true);
   SetLine(line++, "Session: " + FadeSessionLabel(fade.session) +
           " | State: " + fade.verdict, FadeColor(fade.state), true);
   string dailyRegime = (fade.dailyTrend > 0 ? "RISING" : (fade.dailyTrend < 0 ? "FALLING" : "RANGE/MIXED"));
   SetLine(line++, "Closed-D1 regime: " + dailyRegime +
           " | slope " + DoubleToString(fade.dailySlopeAtr, 2) + " ATR/bar",
           (fade.dailyTrend == 0 ? WatchColor : (fade.dailyTrend > 0 ? BullColor : BearColor)), false);
   SetLine(line++, "Fade scores: BUY " + IntegerToString(fade.buyScore) + "/" +
           IntegerToString(fade.scoreTotal) + " | SELL " +
           IntegerToString(fade.shortScore) + "/" + IntegerToString(fade.scoreTotal),
           NeutralColor, false);

   if(ShowFadeDetails)
     {
      string shortLevelText = fade.shortLocationOk ?
                              fade.shortLevelName + " " + DoubleToString(fade.shortLevel, _Digits) :
                              "none nearby";
      string buyLevelText = fade.buyLocationOk ?
                            fade.buyLevelName + " " + DoubleToString(fade.buyLevel, _Digits) :
                            "none nearby";
      SetLine(line++, "Short location: " + shortLevelText +
              " | reject " + (fade.shortTrigger ? "YES" : "no"),
              fade.shortTrigger ? BearColor : NeutralColor, false);
      SetLine(line++, "Buy location: " + buyLevelText +
              " | reclaim " + (fade.buyTrigger ? "YES" : "no"),
              fade.buyTrigger ? BullColor : NeutralColor, false);
      SetLine(line++, "SELL gates D1/Macro/Level/M15: " +
              YesNo(fade.shortRegimeOk) + "/" + YesNo(fade.shortMacroOk) + "/" +
              YesNo(fade.shortLocationOk) + "/" +
              YesNo(fade.shortTrigger && fade.shortMomentumOk),
              NeutralColor, false);
      SetLine(line++, "BUY  gates D1/Macro/Level/M15: " +
              YesNo(fade.buyRegimeOk) + "/" + YesNo(fade.buyMacroOk) + "/" +
              YesNo(fade.buyLocationOk) + "/" +
              YesNo(fade.buyTrigger && fade.buyMomentumOk),
              NeutralColor, false);
      SetLine(line++, "H1 RSI: " + DoubleToString(fade.h1Rsi, 1) +
              " | M15 turn: " +
              (tech.m15RecentBull ? "bull " : "") +
              (tech.m15RecentBear ? "bear" : (!tech.m15RecentBull ? "none" : "")),
              NeutralColor, false);
      if(fade.dailyVwap > 0 || fade.weeklyVwap > 0)
         SetLine(line++, "VWAP D/W: " +
                 (fade.dailyVwap > 0 ? DoubleToString(fade.dailyVwap, _Digits) : "n/a") +
                 " / " +
                 (fade.weeklyVwap > 0 ? DoubleToString(fade.weeklyVwap, _Digits) : "n/a"),
                 NeutralColor, false);
      if(fade.invalidation != "")
         SetLine(line++, "Invalidation: " + fade.invalidation, StaleColor, false);
     }

   if(EnablePositionRiskGuard)
     {
      color riskColor = fade.riskBlocked ? StaleColor :
                        ((MathMax(fade.buyDepth, fade.sellDepth) >= StackWarnAt ||
                          fade.warnTrades > 0) ? WatchColor : BullColor);
      SetLine(line++, "RISK GUARD: BUY x" + IntegerToString(fade.buyDepth) +
              " (" + DoubleToString(fade.buyLots, 2) + ") | SELL x" +
              IntegerToString(fade.sellDepth) + " (" + DoubleToString(fade.sellLots, 2) + ")",
              riskColor, false);
      SetLine(line++, "Aging/stale: " + IntegerToString(fade.warnTrades) + "/" +
              IntegerToString(fade.staleTrades) +
              (fade.hedgeLocked ? " | HEDGE-LOCKED" : ""),
              riskColor, false);
      if(fade.riskReason != "")
         SetLine(line++, fade.riskReason, StaleColor, true);
     }

   // ---- FINAL ----
   SetLine(line++, "FINAL STATUS", TextColor, true);
   SetLine(line++, "Trend State: " + PrimaryLabel(signals.primary), PrimaryColor(signals.primary), true);
   SetLine(line++, "Trend Confirmation: " + TrendLabel(signals),
           signals.aPlusBuy ? StrongBullColor : (signals.aPlusSell ? BearColor : NeutralColor), false);
   SetLine(line++, "Trend Entry Quality: " + signals.entryQuality,
           (signals.h4Invalidated ? StaleColor : (signals.h4RawExtended ? ConflictColor : NeutralColor)), false);

   if(ShowDebugInfo)
     {
      SetLine(line++, "dbg D1 C/E: " + DoubleToString(tech.d1Close, _Digits) + " / " + DoubleToString(tech.d1Ema, _Digits), NeutralColor, false);
      SetLine(line++, "dbg H4 C/E: " + DoubleToString(tech.h4Close, _Digits) + " / " + DoubleToString(tech.h4Ema, _Digits), NeutralColor, false);
      SetLine(line++, "dbg bridge: " + (g_meta.bridgeState == "" ? "?" : g_meta.bridgeState) + "  ccy=" + IntegerToString(g_meta.count), NeutralColor, false);
     }

   SetLine(line++, "Decision support only | Closed candles", NeutralColor, false);

   // Hide any leftover lines from a previous longer render.
   for(int i = line; i < maxLines; i++)
      HideLine(i);

   ResizeBackground(line);
   ChartRedraw();
  }

string TdiCrossTag(bool freshBull, bool freshBear)
  {
   if(freshBull) return(" - FRESH BULLISH CROSS");
   if(freshBear) return(" - FRESH BEARISH CROSS");
   return("");
  }

string EmaLabel(ENUM_LPH_DIR d, bool reclaimBull, bool reclaimBear)
  {
   if(reclaimBull) return("BULLISH RECLAIM");
   if(reclaimBear) return("BEARISH RECLAIM");
   return(LphDirLabel(d));
  }

string WatchLabel(LphSignalResult &s)
  {
   if(s.h1BuyWatch) return("H1 BUY WATCH - ACTIVE");
   if(s.h1SellWatch) return("H1 SELL WATCH - ACTIVE");
   return("WAITING");
  }

string TriggerLabel(LphSignalResult &s)
  {
   if(!EnableM15TriggerModule) return("OFF");
   if(s.m15BuyTrigger) return("M15 BUY TRIGGER - CHECK CHART");
   if(s.m15SellTrigger) return("M15 SELL TRIGGER - CHECK CHART");
   return("WAITING");
  }

string TrendLabel(LphSignalResult &s)
  {
   if(s.aPlusBuy) return("A+ BUY TREND CONFIRMATION");
   if(s.aPlusSell) return("A+ SELL TREND CONFIRMATION");
   return("NONE");
  }

string PrimaryLabel(ENUM_LPH_PRIMARY p)
  {
   switch(p)
     {
      case LPH_PRIMARY_UNAVAILABLE: return("STALE / INVALID / MACRO UNAVAILABLE");
      case LPH_PRIMARY_INVALIDATED: return("H4 STRUCTURE INVALIDATED");
      case LPH_PRIMARY_EXTENDED_BUY: return("EXTENDED - DO NOT CHASE (BULLISH REGIME)");
      case LPH_PRIMARY_EXTENDED_SELL: return("EXTENDED - DO NOT CHASE (BEARISH REGIME)");
      case LPH_PRIMARY_EXTENDED_NEUTRAL: return("EXTENDED - DO NOT CHASE");
      case LPH_PRIMARY_M15_BUY: return("M15 BUY TRIGGER - CHECK CHART");
      case LPH_PRIMARY_M15_SELL: return("M15 SELL TRIGGER - CHECK CHART");
      case LPH_PRIMARY_H1_BUY: return("H1 BUY WATCH - INSPECT CHART");
      case LPH_PRIMARY_H1_SELL: return("H1 SELL WATCH - INSPECT CHART");
      case LPH_PRIMARY_APLUS_BUY: return("A+ BUY TREND CONFIRMATION");
      case LPH_PRIMARY_APLUS_SELL: return("A+ SELL TREND CONFIRMATION");
      case LPH_PRIMARY_CONFLICT: return("MACRO-TECHNICAL CONFLICT");
      default: return("NEUTRAL / NO ACTIVE SETUP");
     }
  }

color PrimaryColor(ENUM_LPH_PRIMARY p)
  {
   if(p == LPH_PRIMARY_M15_BUY) return(BullColor);
   if(p == LPH_PRIMARY_M15_SELL) return(BearColor);
   if(p == LPH_PRIMARY_H1_BUY || p == LPH_PRIMARY_H1_SELL) return(WatchColor);
   if(p == LPH_PRIMARY_APLUS_BUY) return(StrongBullColor);
   if(p == LPH_PRIMARY_APLUS_SELL) return(BearColor);
   if(p == LPH_PRIMARY_EXTENDED_BUY || p == LPH_PRIMARY_EXTENDED_SELL ||
      p == LPH_PRIMARY_EXTENDED_NEUTRAL || p == LPH_PRIMARY_CONFLICT) return(ConflictColor);
   if(p == LPH_PRIMARY_INVALIDATED || p == LPH_PRIMARY_UNAVAILABLE) return(StaleColor);
   return(NeutralColor);
  }

//==================================================================
// Chart object helpers (create once, update thereafter)
//==================================================================
void EnsureBackground(int maxLines)
  {
   string name = g_prefix + "BG";
   if(ObjectFind(0, name) < 0)
     {
      ObjectCreate(0, name, OBJ_RECTANGLE_LABEL, 0, 0, 0);
      ObjectSetInteger(0, name, OBJPROP_CORNER, PanelCorner);
      ObjectSetInteger(0, name, OBJPROP_XDISTANCE, PanelX - 6);
      ObjectSetInteger(0, name, OBJPROP_YDISTANCE, PanelY - 6);
      ObjectSetInteger(0, name, OBJPROP_XSIZE, PanelWidth);
      ObjectSetInteger(0, name, OBJPROP_BGCOLOR, BackgroundColor);
      ObjectSetInteger(0, name, OBJPROP_BORDER_TYPE, BORDER_FLAT);
      ObjectSetInteger(0, name, OBJPROP_COLOR, BorderColor);
      ObjectSetInteger(0, name, OBJPROP_STYLE, STYLE_SOLID);
      ObjectSetInteger(0, name, OBJPROP_WIDTH, 1);
      ObjectSetInteger(0, name, OBJPROP_BACK, false);
      ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
      ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
     }
   ObjectSetInteger(0, name, OBJPROP_YSIZE, (maxLines + 1) * g_lineHeight);
  }

void ResizeBackground(int usedLines)
  {
   string name = g_prefix + "BG";
   if(ObjectFind(0, name) >= 0)
      ObjectSetInteger(0, name, OBJPROP_YSIZE, (usedLines + 1) * g_lineHeight);
  }

void SetLine(int index, string text, color clr, bool bold)
  {
   string name = g_prefix + "L" + IntegerToString(index);
   if(ObjectFind(0, name) < 0)
     {
      ObjectCreate(0, name, OBJ_LABEL, 0, 0, 0);
      ObjectSetInteger(0, name, OBJPROP_CORNER, PanelCorner);
      ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
      ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
      ObjectSetInteger(0, name, OBJPROP_ANCHOR, ANCHOR_LEFT_UPPER);
     }
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE, PanelX);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE, PanelY + index * g_lineHeight);
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, PanelFontSize + (bold ? 1 : 0));
   ObjectSetString(0, name, OBJPROP_FONT, bold ? PanelFont : PanelFont);
   ObjectSetString(0, name, OBJPROP_TEXT, text);
  }

void HideLine(int index)
  {
   string name = g_prefix + "L" + IntegerToString(index);
   if(ObjectFind(0, name) >= 0)
      ObjectSetString(0, name, OBJPROP_TEXT, " ");
  }

void Redraw()
  {
   // Force a full recompute + redraw (used after chart resize).
   Recalculate(false);
  }
//+------------------------------------------------------------------+
