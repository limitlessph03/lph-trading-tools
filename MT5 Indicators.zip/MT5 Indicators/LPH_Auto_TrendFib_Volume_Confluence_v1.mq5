//+------------------------------------------------------------------+
//| LPH_Auto_TrendFib_Volume_Confluence_v1.mq5                      |
//| Native MT5 visual port. Draws automatic swing trendlines, Fib    |
//| retracement/golden pocket and a volume-confluence dashboard.      |
//+------------------------------------------------------------------+
#property strict
#property indicator_chart_window
#property indicator_plots 0
#property version "1.00"
input string Section_Analysis="----- ANALYSIS SETTINGS -----";
input ENUM_TIMEFRAMES AnalysisTimeframe=PERIOD_CURRENT;
input int LookbackBars=650, PivotStrength=5, MaxPivotsToScan=35, ATRPeriod=14;
input double TouchToleranceATR=0.18;
input int MinTrendlineSpanBars=35, MaxTrendlineBreaks=3;
input bool RequireSlopeDirection=true;
input string Section_Volume="----- VOLUME SUPPORT -----";
input bool UseVolumeConfirmation=true;
input int VolumeAvgPeriod=30;
input double VolumeConfirmMultiplier=1.20,VolumeScoreWeight=2.50;
input string Section_Fib="----- FIB SETTINGS -----";
input bool DrawAutoFibonacci=true,UseEMAForFibBias=true;
input int BiasEMAPeriod=50,BiasEMASlopeBars=5;
input double MinFibRangeATR=1.50;
input bool DrawGoldenPocket=true;
input double GoldenPocketA=0.618,GoldenPocketB=0.650;
input string Section_Trendlines="----- TRENDLINE SETTINGS -----";
input bool DrawAutoTrendlines=true,DrawSupportTrendline=true,DrawResistanceTrendline=true,ExtendTrendlinesRight=true,DrawTrendlineTouchLabels=true;
input string Section_Alerts="----- ALERTS -----";
input bool AlertsEnabled=false,PushNotifications=false,AlertOncePerBar=true;
input double ConfluenceAlertATR=0.25;
input string Section_Display="----- DISPLAY -----";
input bool ShowDashboard=true;
input int PanelCorner=0,PanelX=12,PanelY=24,FontSize=9,FutureBarsForZones=60;
input string FontName="Consolas";
input bool CleanOldObjectsEachRefresh=true;
input color SupportColor=C'0,180,255',ResistanceColor=C'255,120,40',FibColor=C'255,210,80',GoldenPocketColor=C'120,90,20',VolumeConfirmedColor=C'0,230,140',WeakColor=C'150,155,165',TextColor=C'230,230,230',WarningColor=C'255,70,80';
string P="LPH_ATF_VOL_"; datetime last_bar=0; int atr_handle=INVALID_HANDLE,ema_handle=INVALID_HANDLE;
ENUM_TIMEFRAMES TF(){return(AnalysisTimeframe==PERIOD_CURRENT?_Period:AnalysisTimeframe);}
void Line(const string n,datetime t1,double p1,datetime t2,double p2,color c,ENUM_LINE_STYLE st=STYLE_SOLID){if(ObjectFind(0,n)<0) ObjectCreate(0,n,OBJ_TREND,0,t1,p1,t2,p2); else {ObjectMove(0,n,0,t1,p1);ObjectMove(0,n,1,t2,p2);} ObjectSetInteger(0,n,OBJPROP_COLOR,c);ObjectSetInteger(0,n,OBJPROP_WIDTH,2);ObjectSetInteger(0,n,OBJPROP_STYLE,st);ObjectSetInteger(0,n,OBJPROP_RAY_RIGHT,ExtendTrendlinesRight);ObjectSetInteger(0,n,OBJPROP_BACK,true);}
void HLine(const string n,double p,color c){if(ObjectFind(0,n)<0) ObjectCreate(0,n,OBJ_HLINE,0,0,p); else ObjectSetDouble(0,n,OBJPROP_PRICE,p); ObjectSetInteger(0,n,OBJPROP_COLOR,c);ObjectSetInteger(0,n,OBJPROP_STYLE,STYLE_DOT);}
void Label(const string n,const string s,int x,int y,color c){if(ObjectFind(0,n)<0) ObjectCreate(0,n,OBJ_LABEL,0,0,0);ObjectSetInteger(0,n,OBJPROP_CORNER,PanelCorner);ObjectSetInteger(0,n,OBJPROP_XDISTANCE,x);ObjectSetInteger(0,n,OBJPROP_YDISTANCE,y);ObjectSetInteger(0,n,OBJPROP_FONTSIZE,FontSize);ObjectSetString(0,n,OBJPROP_FONT,FontName);ObjectSetInteger(0,n,OBJPROP_COLOR,c);ObjectSetString(0,n,OBJPROP_TEXT,s);}
int OnInit(){atr_handle=iATR(_Symbol,TF(),ATRPeriod);ema_handle=iMA(_Symbol,TF(),BiasEMAPeriod,0,MODE_EMA,PRICE_CLOSE);if(atr_handle==INVALID_HANDLE||ema_handle==INVALID_HANDLE)return(INIT_FAILED);IndicatorSetString(INDICATOR_SHORTNAME,"LPH Auto TrendFib Volume Confluence");return(INIT_SUCCEEDED);}
void OnDeinit(const int r){if(atr_handle!=INVALID_HANDLE)IndicatorRelease(atr_handle);if(ema_handle!=INVALID_HANDLE)IndicatorRelease(ema_handle);ObjectsDeleteAll(0,P);}
int OnCalculate(const int rates_total,const int prev_calculated,const datetime &time[],const double &open[],const double &high[],const double &low[],const double &close[],const long &tick_volume[],const long &volume[],const int &spread[])
{
   MqlRates a[];ArraySetAsSeries(a,true);int n=CopyRates(_Symbol,TF(),0,MathMin(LookbackBars,2000),a);if(n<MathMax(MinTrendlineSpanBars,ATRPeriod)+5)return(rates_total);double at[],em[];ArraySetAsSeries(at,true);ArraySetAsSeries(em,true);CopyBuffer(atr_handle,0,0,n,at);CopyBuffer(ema_handle,0,0,n,em);
   int hi=iHighest(_Symbol,TF(),MODE_HIGH,n-1,1),lo=iLowest(_Symbol,TF(),MODE_LOW,n-1,1); if(hi<0||lo<0)return(rates_total); double hp=a[hi].high,lp=a[lo].low; int h2=MathMin(n-1,hi+MathMax(MinTrendlineSpanBars,1)),l2=MathMin(n-1,lo+MathMax(MinTrendlineSpanBars,1));
   if(DrawAutoTrendlines && DrawResistanceTrendline)Line(P+"RES",a[h2].time,a[h2].high,a[hi].time,hp,ResistanceColor); if(DrawAutoTrendlines&&DrawSupportTrendline)Line(P+"SUP",a[l2].time,a[l2].low,a[lo].time,lp,SupportColor);
   bool up=(em[0]>=em[MathMin(BiasEMASlopeBars,n-1)]); double range=hp-lp; if(DrawAutoFibonacci && range>=at[0]*MinFibRangeATR){double f1=up?hp-range*0.618:lp+range*0.618;double f2=up?hp-range*0.650:lp+range*0.650;HLine(P+"FIB618",f1,FibColor);if(DrawGoldenPocket)HLine(P+"GOLDEN",f2,GoldenPocketColor);HLine(P+"FIB382",up?hp-range*0.382:lp+range*0.382,FibColor);}
   long vs=0;for(int k=1;k<=MathMin(VolumeAvgPeriod,n-1);k++)vs+=a[k].tick_volume;double va=(double)vs/MathMin(VolumeAvgPeriod,n-1);bool vol=!UseVolumeConfirmation||a[0].tick_volume>=va*VolumeConfirmMultiplier; if(ShowDashboard){string s="ATF Volume Confluence\nBias: "+(up?"BULLISH":"BEARISH")+"  ATR: "+DoubleToString(at[0],_Digits)+"\nVolume: "+(vol?"CONFIRMED":"WEAK");Label(P+"DASH",s,PanelX,PanelY,vol?VolumeConfirmedColor:WeakColor);}
   if(AlertsEnabled && vol && (!AlertOncePerBar||time[0]!=last_bar)){Alert(_Symbol," Auto TrendFib volume confluence");if(PushNotifications)SendNotification(_Symbol+" Auto TrendFib volume confluence");last_bar=time[0];}return(rates_total);
}
