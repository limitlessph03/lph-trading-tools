//+------------------------------------------------------------------+
//| LPH_Institutional_Zones_Preset_Dark_StaticProfile_Final.mq5     |
//|  Drawing-only institutional zones for MT5.                        |
//|                                                                  |
//|  MT5 static-profile deployment built from the validated Histogram  |
//|  port. Same zone/VWAP engine and compatible profile inputs.         |
//|  object names/prefix, same calculations and visual output.        |
//|  Only MT4 -> MT5 API translations were applied.                   |
//|                                                                  |
//|  No Alert(), SendNotification(), SendMail(), OrderSend(), or      |
//|  trading logic is used. This indicator only draws chart objects   |
//|  and optional VWAP buffers.                                       |
//+------------------------------------------------------------------+
#property indicator_chart_window
#property indicator_buffers 4
#property indicator_plots   4

#property indicator_label1  "Session VWAP"
#property indicator_type1   DRAW_LINE
#property indicator_color1  clrDodgerBlue
#property indicator_width1  2

#property indicator_label2  "VWAP Upper"
#property indicator_type2   DRAW_LINE
#property indicator_color2  clrSlateGray
#property indicator_style2  STYLE_DOT

#property indicator_label3  "VWAP Lower"
#property indicator_type3   DRAW_LINE
#property indicator_color3  clrSlateGray
#property indicator_style3  STYLE_DOT

#property indicator_label4  "EMA 50"
#property indicator_type4   DRAW_LINE
#property indicator_color4  clrDarkGray
#property indicator_width4  1

input string InpSectionGeneral       = "===== General / Performance =====";
input bool   InpDrawVolumeProfiles   = true;
input bool   InpDrawSupportResistance= true;
input bool   InpDrawVWAP             = true;
input bool   InpDrawEMA50            = false;
input int    InpRefreshSeconds       = 30;
input int    InpProjectionBars       = 45;
input int    InpMaxBarsToScan        = 1200;
input int    InpLineLabelOffsetBars  = 4;
input int    InpLineLabelFontSize    = 8;
input bool   InpDrawLabels           = true;

input string InpSectionProfiles      = "===== Volume Profile Zones =====";
input bool   InpDrawDailyProfile     = true;
input bool   InpDrawWeeklyProfile    = true;
input bool   InpDrawMonthlyProfile   = false;
input int    InpProfilePreset        = 0;  // 0 Custom, 1 FX_M30_Clean, 2 FX_M30_Volatile, 3 XAU_Indices_M30
input int    InpProfileBinMode       = 0;  // 0 Fixed, 1 Adaptive, 2 MultiResolution
input int    InpDailyFallbackBars    = 96;
input int    InpWeeklyFallbackBars   = 320;
input int    InpMonthlyFallbackBars  = 1000;
input int    InpProfileBins          = 24;
input int    InpProfileBinsFixed     = 24;
input int    InpMaxHVNZonesEach      = 1;
input int    InpMaxLVNZonesEach      = 1;
input double InpHVNPercentOfPOC      = 0.55;
input double InpLVNPercentOfPOC      = 0.35;
input double InpPOCConsensusATR      = 0.15;
input bool   InpDrawPOCZone          = true;
// ---- Volume Profile histogram (left-side bars) — UI only, does not change calculations ----
input bool   InpShowVolumeHistogram   = false;   // draw real horizontal volume-profile bars from the left edge
input int    InpHistogramMaxBars      = 60;      // performance cap: max histogram bars drawn per profile (D/W/M)
input int    InpHistogramWidthBars    = 30;      // how many chart-bars wide the longest (POC) volume bar extends
input color  InpHistogramColorEdge    = C'18,32,44';   // light shade at thin (low-volume) edges
input color  InpHistogramColorPOC     = C'46,96,132';  // denser shade near POC (high volume)
input int    InpHistogramFillWidth     = 3;             // line thickness to make bars read as a filled profile (raise for more solid fill)
input bool   InpDrawPOCConfidenceLabel = true;
input bool   InpProfileDebug         = false;

input string InpSectionSR            = "===== Support / Resistance =====";
input ENUM_TIMEFRAMES InpSRCalculationTF = PERIOD_H4;
input int    InpSRLookbackBars       = 650;
input int    InpPivotStrength        = 5;
input int    InpMinTouches           = 3;
input int    InpMaxSRZones           = 4;
input double InpMergeATRMultiple     = 0.32;
input double InpZoneATRPadding       = 0.07;
input bool   InpSRExtendToCurrentOnly= true;
input bool   InpDrawSRMidlines       = true;
input bool   InpSRUseVolumeFilter    = true;
input int    InpSRVolumeAverageBars  = 24;
input double InpSRMinVolumeMultiplier= 1.10;
input double InpSRMinScore           = 6.00;

input string InpSectionVWAP          = "===== VWAP =====";
input bool   InpDrawCurvedVWAP       = true;
input int    InpCurvedVWAPMaxTFMin   = 60;
input bool   InpDrawVWAPLevels       = true;
input bool   InpDrawDailyVWAPLevel   = true;
input bool   InpDrawWeeklyVWAPLevel  = false;
input bool   InpDrawMonthlyVWAPLevel = false;
input bool   InpDrawVWAPBands        = false;
input double InpVWAPBandStdev        = 1.5;
input bool   InpVWAPResetDaily       = true;
input ENUM_TIMEFRAMES InpVWAPLevelCalcTF = PERIOD_M5;
input int    InpVWAPLevelMaxBars   = 1500;

input string InpSectionKeyLevels     = "===== Session / Previous Day =====";
input bool   InpDrawAsiaHighLow      = true;
input string InpAsiaSession          = "00:00-06:00";
input bool   InpDrawPrevDayHighLow   = true;
input bool   InpDrawPivotLevels      = true;
input bool   InpDrawFullPivotSet     = false;
input bool   InpDrawPivotShortLines  = true;
input int    InpPivotShortLineBars   = 34;
input ENUM_TIMEFRAMES InpPivotSourceTF = PERIOD_D1;
input int    InpHighLowShortLineBars = 42;

input string InpSectionColors        = "===== Colors =====";
input color  InpEMA50Color           = C'150,150,150';
input color  InpVWAPLineColor        = clrAqua;
input color  InpVWAPLevelColor       = clrAqua;
input color  InpDailyPOCColor        = C'95,165,235';
input color  InpDailyHVNColor        = C'28,64,98';
input color  InpDailyLVNColor        = C'18,44,72';
input color  InpWeeklyPOCColor       = C'225,165,70';
input color  InpWeeklyHVNColor       = C'92,58,18';
input color  InpWeeklyLVNColor       = C'64,42,16';
input color  InpMonthlyPOCColor      = C'40,190,190';
input color  InpMonthlyHVNColor      = C'18,82,86';
input color  InpMonthlyLVNColor      = C'14,56,60';
input color  InpResistanceColor      = C'30,58,105';
input color  InpSupportColor         = C'95,32,32';
input color  InpPrevDayColor         = C'115,115,115';
input color  InpAsiaColor            = C'80,115,110';
input color  InpPivotColor           = C'80,105,145';
input color  InpPivotResistanceColor = C'125,55,55';
input color  InpPivotSupportColor    = C'70,120,70';
input color  InpLabelColor           = C'155,155,155';

double g_vwap[];
double g_vwapUpper[];
double g_vwapLower[];
double g_ema50[];

string   PREFIX = "LPH_IZ_STATIC_PROFILE_";
datetime g_lastDrawTime = 0;
datetime g_lastBarTime  = 0;

// --- MT5 indicator handles (MT4 returned values directly; MT5 uses handles) ---
int             g_ema50Handle = INVALID_HANDLE;
ENUM_TIMEFRAMES g_atrTF[];
int             g_atrPeriod[];
int             g_atrHandle[];

//+------------------------------------------------------------------+
//| MT4 compatibility: date component helpers (removed in MQL5)      |
//+------------------------------------------------------------------+
int TimeYear(const datetime t)      { MqlDateTime s; TimeToStruct(t, s); return(s.year); }
int TimeMonth(const datetime t)     { MqlDateTime s; TimeToStruct(t, s); return(s.mon); }
int TimeDayOfYear(const datetime t) { MqlDateTime s; TimeToStruct(t, s); return(s.day_of_year); }
int TimeDayOfWeek(const datetime t) { MqlDateTime s; TimeToStruct(t, s); return(s.day_of_week); }
int TimeHour(const datetime t)      { MqlDateTime s; TimeToStruct(t, s); return(s.hour); }
int TimeMinute(const datetime t)    { MqlDateTime s; TimeToStruct(t, s); return(s.min); }

//+------------------------------------------------------------------+
//| ATR handle cache (MT5 iATR returns a handle, not a value)        |
//+------------------------------------------------------------------+
int GetATRHandle(const ENUM_TIMEFRAMES tf, const int period)
{
   int total = ArraySize(g_atrHandle);
   for(int i = 0; i < total; i++)
      if(g_atrTF[i] == tf && g_atrPeriod[i] == period)
         return(g_atrHandle[i]);

   int h = iATR(_Symbol, tf, period);
   if(h == INVALID_HANDLE)
      return(INVALID_HANDLE);

   ArrayResize(g_atrTF, total + 1);
   ArrayResize(g_atrPeriod, total + 1);
   ArrayResize(g_atrHandle, total + 1);
   g_atrTF[total]     = tf;
   g_atrPeriod[total] = period;
   g_atrHandle[total] = h;
   return(h);
}

//+------------------------------------------------------------------+
//| Read one ATR value at a given shift (mirrors MT4 iATR(...,shift))|
//+------------------------------------------------------------------+
double GetATRValue(const ENUM_TIMEFRAMES tf, const int period, const int shift)
{
   int h = GetATRHandle(tf, period);
   if(h == INVALID_HANDLE)
      return(0.0);

   double buf[];
   ArraySetAsSeries(buf, true);
   if(CopyBuffer(h, 0, shift, 1, buf) < 1)
      return(0.0);

   return(buf[0]);
}

//+------------------------------------------------------------------+
int OnInit()
{
   IndicatorSetString(INDICATOR_SHORTNAME, "LPH Institutional Zones Dark Solid VWAP SR");

   SetIndexBuffer(0, g_vwap,      INDICATOR_DATA);
   SetIndexBuffer(1, g_vwapUpper, INDICATOR_DATA);
   SetIndexBuffer(2, g_vwapLower, INDICATOR_DATA);
   SetIndexBuffer(3, g_ema50,     INDICATOR_DATA);

   // Match MT4 series indexing (index 0 == current bar) for every buffer.
   ArraySetAsSeries(g_vwap, true);
   ArraySetAsSeries(g_vwapUpper, true);
   ArraySetAsSeries(g_vwapLower, true);
   ArraySetAsSeries(g_ema50, true);

   PlotIndexSetDouble(0, PLOT_EMPTY_VALUE, EMPTY_VALUE);
   PlotIndexSetDouble(1, PLOT_EMPTY_VALUE, EMPTY_VALUE);
   PlotIndexSetDouble(2, PLOT_EMPTY_VALUE, EMPTY_VALUE);
   PlotIndexSetDouble(3, PLOT_EMPTY_VALUE, EMPTY_VALUE);

   PlotIndexSetInteger(0, PLOT_DRAW_TYPE, DRAW_LINE);
   PlotIndexSetInteger(0, PLOT_LINE_STYLE, STYLE_SOLID);
   PlotIndexSetInteger(0, PLOT_LINE_WIDTH, 1);
   PlotIndexSetInteger(0, PLOT_LINE_COLOR, InpVWAPLineColor);

   PlotIndexSetInteger(1, PLOT_DRAW_TYPE, DRAW_LINE);
   PlotIndexSetInteger(1, PLOT_LINE_STYLE, STYLE_DOT);
   PlotIndexSetInteger(1, PLOT_LINE_WIDTH, 1);
   PlotIndexSetInteger(1, PLOT_LINE_COLOR, InpVWAPLevelColor);

   PlotIndexSetInteger(2, PLOT_DRAW_TYPE, DRAW_LINE);
   PlotIndexSetInteger(2, PLOT_LINE_STYLE, STYLE_DOT);
   PlotIndexSetInteger(2, PLOT_LINE_WIDTH, 1);
   PlotIndexSetInteger(2, PLOT_LINE_COLOR, InpVWAPLevelColor);

   PlotIndexSetInteger(3, PLOT_DRAW_TYPE, DRAW_LINE);
   PlotIndexSetInteger(3, PLOT_LINE_STYLE, STYLE_SOLID);
   PlotIndexSetInteger(3, PLOT_LINE_WIDTH, 1);
   PlotIndexSetInteger(3, PLOT_LINE_COLOR, InpEMA50Color);

   // EMA50 handle (chart symbol/timeframe) — created once.
   g_ema50Handle = iMA(_Symbol, _Period, 50, 0, MODE_EMA, PRICE_CLOSE);
   if(g_ema50Handle == INVALID_HANDLE)
      Print("LPH IZ: failed to create EMA50 handle, err=", GetLastError());

   // Warm ATR handles for the timeframes the engine actually uses.
   if(GetATRHandle(PERIOD_M15, 14) == INVALID_HANDLE)
      Print("LPH IZ: failed to create ATR(M15) handle, err=", GetLastError());
   if(GetATRHandle(PERIOD_H1, 14) == INVALID_HANDLE)
      Print("LPH IZ: failed to create ATR(H1) handle, err=", GetLastError());
   if(GetATRHandle(ResolveSRCalculationTF(), 14) == INVALID_HANDLE)
      Print("LPH IZ: failed to create ATR(SR TF) handle, err=", GetLastError());

   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   if(g_ema50Handle != INVALID_HANDLE)
      IndicatorRelease(g_ema50Handle);

   for(int i = 0; i < ArraySize(g_atrHandle); i++)
      if(g_atrHandle[i] != INVALID_HANDLE)
         IndicatorRelease(g_atrHandle[i]);

   DeleteObjectsByPrefix(PREFIX);
}

//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
   if(rates_total < 50)
      return(rates_total);

   // Match MT4 series semantics: index 0 == current bar for all input series.
   ArraySetAsSeries(time, true);
   ArraySetAsSeries(high, true);
   ArraySetAsSeries(low, true);
   ArraySetAsSeries(close, true);
   ArraySetAsSeries(tick_volume, true);

   if(InpDrawEMA50)
      CalculateEMA50(rates_total);
   else
      ClearBuffer(g_ema50, rates_total);

   if(ShouldDrawCurvedVWAP())
      CalculateVWAP(rates_total, time, high, low, close, tick_volume);
   else
      ClearVWAPBuffers(rates_total);

   datetime now = TimeCurrent();
   bool newBar = (time[0] != g_lastBarTime);
   bool refreshDue = (now - g_lastDrawTime >= InpRefreshSeconds);

   if(newBar || refreshDue || prev_calculated == 0)
   {
      g_lastBarTime = time[0];
      g_lastDrawTime = now;
      RedrawObjects(rates_total, time, high, low, close, tick_volume);
   }

   return(rates_total);
}

//+------------------------------------------------------------------+
void ClearVWAPBuffers(const int rates_total)
{
   ClearBuffer(g_vwap, rates_total);
   ClearBuffer(g_vwapUpper, rates_total);
   ClearBuffer(g_vwapLower, rates_total);
}

//+------------------------------------------------------------------+
void ClearBuffer(double &buffer[], const int rates_total)
{
   int maxBars = MathMin(rates_total, InpMaxBarsToScan);
   for(int i = 0; i < maxBars; i++)
      buffer[i] = EMPTY_VALUE;
}

//+------------------------------------------------------------------+
bool ShouldDrawCurvedVWAP()
{
   // MT4 Period() returned minutes; MT5 Period() returns an enum, so derive minutes.
   return(InpDrawVWAP && InpDrawCurvedVWAP && (PeriodSeconds(PERIOD_CURRENT) / 60) <= InpCurvedVWAPMaxTFMin);
}

//+------------------------------------------------------------------+
void CalculateEMA50(const int rates_total)
{
   int maxBars = MathMin(rates_total - 1, InpMaxBarsToScan);
   int count = maxBars + 1;

   if(g_ema50Handle == INVALID_HANDLE)
   {
      ClearBuffer(g_ema50, rates_total);
      return;
   }

   double tmp[];
   ArraySetAsSeries(tmp, true);
   int copied = CopyBuffer(g_ema50Handle, 0, 0, count, tmp);

   for(int i = 0; i < count; i++)
      g_ema50[i] = (i < copied ? tmp[i] : EMPTY_VALUE);
}

//+------------------------------------------------------------------+
void CalculateVWAP(const int rates_total,
                   const datetime &time[],
                   const double &high[],
                   const double &low[],
                   const double &close[],
                   const long &tick_volume[])
{
   int maxBars = MathMin(rates_total - 1, InpMaxBarsToScan);
   double sumPV = 0.0;
   double sumP2V = 0.0;
   double sumV = 0.0;
   int lastDay = -1;

   for(int i = maxBars; i >= 0; i--)
   {
      int dayKey = TimeYear(time[i]) * 1000 + TimeDayOfYear(time[i]);
      if(InpVWAPResetDaily && dayKey != lastDay)
      {
         sumPV = 0.0;
         sumP2V = 0.0;
         sumV = 0.0;
         lastDay = dayKey;
      }

      double typical = (high[i] + low[i] + close[i]) / 3.0;
      double vol = MathMax(1.0, (double)tick_volume[i]);

      sumPV += typical * vol;
      sumP2V += typical * typical * vol;
      sumV += vol;

      if(sumV <= 0.0)
      {
         g_vwap[i] = EMPTY_VALUE;
         g_vwapUpper[i] = EMPTY_VALUE;
         g_vwapLower[i] = EMPTY_VALUE;
         continue;
      }

      double vwap = sumPV / sumV;
      double variance = MathMax(0.0, (sumP2V / sumV) - (vwap * vwap));
      double stdev = MathSqrt(variance);

      g_vwap[i] = vwap;
      if(InpDrawVWAPBands)
      {
         g_vwapUpper[i] = vwap + InpVWAPBandStdev * stdev;
         g_vwapLower[i] = vwap - InpVWAPBandStdev * stdev;
      }
      else
      {
         g_vwapUpper[i] = EMPTY_VALUE;
         g_vwapLower[i] = EMPTY_VALUE;
      }
   }
}

//+------------------------------------------------------------------+
void RedrawObjects(const int rates_total,
                   const datetime &time[],
                   const double &high[],
                   const double &low[],
                   const double &close[],
                   const long &tick_volume[])
{
   DeleteObjectsByPrefix(PREFIX);

   if(InpDrawVolumeProfiles)
   {
      if(EffectiveDrawDailyProfile())
         DrawProfile("D", PreviousCompletedTradingDayStart(TimeCurrent()),
                     PreviousCompletedTradingDayEnd(TimeCurrent()), InpDailyFallbackBars,
                     InpDailyPOCColor, InpDailyHVNColor, InpDailyLVNColor,
                     rates_total, time, high, low, close, tick_volume);
      if(EffectiveDrawWeeklyProfile())
         DrawProfile("W", PreviousWeekStart(TimeCurrent()), GetWeekStart(TimeCurrent()), InpWeeklyFallbackBars,
                     InpWeeklyPOCColor, InpWeeklyHVNColor, InpWeeklyLVNColor,
                     rates_total, time, high, low, close, tick_volume);
      if(EffectiveDrawMonthlyProfile())
         DrawProfile("M", PreviousMonthStart(TimeCurrent()), GetMonthStart(TimeCurrent()), InpMonthlyFallbackBars,
                     InpMonthlyPOCColor, InpMonthlyHVNColor, InpMonthlyLVNColor,
                     rates_total, time, high, low, close, tick_volume);
   }

   if(InpDrawVWAP && InpDrawVWAPLevels)
      DrawVWAPLevels(rates_total, time, high, low, close, tick_volume);

   if(InpDrawPrevDayHighLow)
      DrawPreviousDayLevels();

   if(InpDrawAsiaHighLow)
      DrawAsiaLevels(rates_total, time, high, low);

   if(InpDrawPivotLevels)
      DrawPivotLevels();

   if(InpDrawSupportResistance)
      DrawSupportResistance(rates_total, time, high, low, tick_volume);
}

//+------------------------------------------------------------------+
ENUM_TIMEFRAMES ProfileCalcTFForTag(const string tag)
{
   if(tag == "D")
      return(PERIOD_M15);
   if(tag == "W")
      return(PERIOD_H1);
   if(tag == "M")
      return(PERIOD_H1);

   return(PERIOD_H1);
}

//+------------------------------------------------------------------+
void DrawProfile(const string tag,
                 const datetime windowStart,
                 const datetime windowEnd,
                 const int fallbackBars,
                 const color pocColor,
                 const color hvnColor,
                 const color lvnColor,
                 const int rates_total,
                 const datetime &time[],
                 const double &high[],
                 const double &low[],
                 const double &close[],
                 const long &tick_volume[])
{
   // Static volume profile levels:
   // The profile is always calculated from a fixed internal timeframe,
   // so POC / HVN / LVN prices do not change when switching chart timeframes.
   ENUM_TIMEFRAMES calcTF = ProfileCalcTFForTag(tag);
   int bars = iBars(Symbol(), calcTF);
   if(bars <= 1)
      return;

   int maxBars = MathMin(MathMin(fallbackBars, InpMaxBarsToScan), bars - 1);
   if(maxBars < 2 || windowStart <= 0 || windowEnd <= windowStart)
      return;

   double rangeHigh = -DBL_MAX;
   double rangeLow = DBL_MAX;
   int found = 0;

   for(int i = 0; i <= maxBars; i++)
   {
      datetime barTime = iTime(Symbol(), calcTF, i);
      if(barTime <= 0)
         continue;
      if(barTime >= windowEnd)
         continue;
      if(barTime < windowStart)
         break;

      double h = iHigh(Symbol(), calcTF, i);
      double l = iLow(Symbol(), calcTF, i);
      double c = iClose(Symbol(), calcTF, i);
      if(h <= 0.0 || l <= 0.0 || c <= 0.0 || h < l)
         continue;

      rangeHigh = MathMax(rangeHigh, h);
      rangeLow = MathMin(rangeLow, l);
      found++;
   }

   if(found < 2 || rangeHigh <= rangeLow || rangeHigh <= -DBL_MAX / 2 || rangeLow >= DBL_MAX / 2)
      return;

   int bins = EffectiveProfileBins(tag, calcTF, rangeHigh, rangeLow);
   double binHeight = 0.0;
   double profile[];
   int pocBin = 0;
   double maxVol = 0.0;

   if(!BuildProfileForBins(calcTF, windowStart, windowEnd, maxBars, rangeLow, rangeHigh,
                           bins, profile, pocBin, maxVol, binHeight))
      return;

   // --- UI: horizontal volume-profile histogram from the left edge (toggle, no recalculation) ---
   if(InpShowVolumeHistogram)
      DrawVolumeHistogram(tag, windowStart, bins, profile, rangeLow, binHeight, maxVol);

   datetime leftTime = windowStart;
   datetime rightTime = ZoneProjectionTime();
   datetime labelTime = LineLabelTime();
   double pocPrice = BinMid(rangeLow, binHeight, pocBin);
   double finalPocPrice = pocPrice;
   double pocZoneLow = pocPrice;
   double pocZoneHigh = pocPrice;
   string pocConfidence = "Fixed";

   if(InpProfileBinMode == 1)
      pocConfidence = "Adaptive";

   if(InpProfileBinMode == 2)
      ResolveMultiResolutionPOC(tag, calcTF, windowStart, windowEnd, maxBars, rangeLow, rangeHigh,
                                finalPocPrice, pocZoneLow, pocZoneHigh, pocConfidence);

   DrawPOCResult(tag, leftTime, rightTime, labelTime, finalPocPrice, pocZoneLow, pocZoneHigh,
                 pocColor, pocConfidence);

   if(InpProfileDebug)
      PrintProfileDebug(tag, calcTF, windowStart, windowEnd, bins, profile, rangeLow, binHeight,
                        finalPocPrice, pocConfidence);

   bool used[];
   ArrayResize(used, bins);
   ArrayInitialize(used, false);
   used[pocBin] = true;

   for(int hvnCount = 0; hvnCount < EffectiveMaxHVNZonesEach(); hvnCount++)
   {
      int hvnBin = FindHighestUnusedBin(profile, used, bins, maxVol * InpHVNPercentOfPOC);
      if(hvnBin < 0 && hvnCount == 0)
         hvnBin = FindHighestUnusedBin(profile, used, bins, 0.0);
      if(hvnBin < 0)
         break;

      used[hvnBin] = true;
      double hvnTop = rangeLow + (hvnBin + 1) * binHeight;
      double hvnBottom = rangeLow + hvnBin * binHeight;
      double hvnMid = BinMid(rangeLow, binHeight, hvnBin);
      string hvnName = PREFIX + tag + "_HVN_" + IntegerToString(hvnCount + 1);
      DrawZone(hvnName, leftTime, rightTime, hvnTop, hvnBottom, hvnColor, tag + " HVN");
      DrawSegmentHLine(hvnName + "_LINE", leftTime, rightTime, hvnMid, hvnColor, STYLE_DOT, 1,
                       tag + " HVN " + DoubleToString(hvnMid, _Digits));
      DrawProfileText(hvnName + "_LABEL", tag, "HVN", labelTime, hvnMid, hvnColor);
   }

   for(int lvnCount = 0; lvnCount < EffectiveMaxLVNZonesEach(); lvnCount++)
   {
      int lvnBin = FindLowestUnusedBin(profile, used, bins, maxVol * InpLVNPercentOfPOC);
      if(lvnBin < 0 && lvnCount == 0)
         lvnBin = FindLowestUnusedBin(profile, used, bins, maxVol);
      if(lvnBin < 0)
         break;

      used[lvnBin] = true;
      double lvnTop = rangeLow + (lvnBin + 1) * binHeight;
      double lvnBottom = rangeLow + lvnBin * binHeight;
      double lvnMid = BinMid(rangeLow, binHeight, lvnBin);
      string lvnName = PREFIX + tag + "_LVN_" + IntegerToString(lvnCount + 1);
      DrawZone(lvnName, leftTime, rightTime, lvnTop, lvnBottom, lvnColor, tag + " LVN");
      DrawSegmentHLine(lvnName + "_LINE", leftTime, rightTime, lvnMid, lvnColor, STYLE_DOT, 1,
                       tag + " LVN " + DoubleToString(lvnMid, _Digits));
      DrawProfileText(lvnName + "_LABEL", tag, "LVN", labelTime, lvnMid, lvnColor);
   }
}

//+------------------------------------------------------------------+
bool BuildProfileForBins(const ENUM_TIMEFRAMES calcTF,
                         const datetime windowStart,
                         const datetime windowEnd,
                         const int maxBars,
                         const double rangeLow,
                         const double rangeHigh,
                         const int requestedBins,
                         double &profile[],
                         int &pocBin,
                         double &maxVol,
                         double &binHeight)
{
   int bins = ClampProfileBins(requestedBins);
   binHeight = (rangeHigh - rangeLow) / bins;
   if(binHeight <= _Point)
      return(false);

   ArrayResize(profile, bins);
   ArrayInitialize(profile, 0.0);

   for(int bar = 0; bar <= maxBars; bar++)
   {
      datetime barTime = iTime(Symbol(), calcTF, bar);
      if(barTime <= 0)
         continue;
      if(barTime >= windowEnd)
         continue;
      if(barTime < windowStart)
         break;

      double h = iHigh(Symbol(), calcTF, bar);
      double l = iLow(Symbol(), calcTF, bar);
      double c = iClose(Symbol(), calcTF, bar);
      double v = MathMax(1.0, (double)iVolume(Symbol(), calcTF, bar));
      if(h <= 0.0 || l <= 0.0 || c <= 0.0 || h < l)
         continue;

      double typical = (h + l + c) / 3.0;
      int bin = (int)MathFloor((typical - rangeLow) / binHeight);
      if(bin < 0)
         bin = 0;
      if(bin >= bins)
         bin = bins - 1;
      profile[bin] += v;
   }

   pocBin = 0;
   maxVol = profile[0];
   for(int b = 1; b < bins; b++)
   {
      if(profile[b] > maxVol)
      {
         maxVol = profile[b];
         pocBin = b;
      }
   }

   return(maxVol > 0.0);
}

//+------------------------------------------------------------------+
void ResolveMultiResolutionPOC(const string tag,
                               const ENUM_TIMEFRAMES calcTF,
                               const datetime windowStart,
                               const datetime windowEnd,
                               const int maxBars,
                               const double rangeLow,
                               const double rangeHigh,
                               double &finalPocPrice,
                               double &pocZoneLow,
                               double &pocZoneHigh,
                               string &pocConfidence)
{
   int testBins[4];
   testBins[0] = 24;
   testBins[1] = 30;
   testBins[2] = 36;
   testBins[3] = 48;

   double pocPrices[4];
   ArrayInitialize(pocPrices, 0.0);
   int valid = 0;
   string testedText = "";

   for(int i = 0; i < 4; i++)
   {
      double testProfile[];
      int testPocBin = 0;
      double testMaxVol = 0.0;
      double testBinHeight = 0.0;

      if(BuildProfileForBins(calcTF, windowStart, windowEnd, maxBars, rangeLow, rangeHigh,
                             testBins[i], testProfile, testPocBin, testMaxVol, testBinHeight))
      {
         double poc = BinMid(rangeLow, testBinHeight, testPocBin);
         pocPrices[valid] = poc;
         valid++;
         testedText += IntegerToString(testBins[i]) + "=" + DoubleToString(poc, _Digits) + " ";
      }
   }

   if(valid <= 0)
      return;

   double minPoc = pocPrices[0];
   double maxPoc = pocPrices[0];
   double sumPoc = 0.0;
   for(int p = 0; p < valid; p++)
   {
      minPoc = MathMin(minPoc, pocPrices[p]);
      maxPoc = MathMax(maxPoc, pocPrices[p]);
      sumPoc += pocPrices[p];
   }

   finalPocPrice = sumPoc / valid;
   pocZoneLow = minPoc;
   pocZoneHigh = maxPoc;

   double atr = GetATRValue(calcTF, 14, 1);
   if(atr <= 0.0)
      atr = GetATRValue(calcTF, 14, 0);
   if(atr <= 0.0)
      atr = MathMax(_Point * 10.0, (rangeHigh - rangeLow) / 6.0);

   double spread = maxPoc - minPoc;
   double highThreshold = MathMax(_Point * 2.0, atr * MathMax(0.01, InpPOCConsensusATR));
   double mediumThreshold = highThreshold * 2.0;

   if(spread <= highThreshold)
      pocConfidence = "High";
   else if(spread <= mediumThreshold)
      pocConfidence = "Medium";
   else
      pocConfidence = "Low / Mixed Profile";

   if(InpProfileDebug)
   {
      Print("VP DEBUG ", Symbol(), " ", tag, " calcTF=", TimeframeToText(calcTF),
            " window=", TimeToString(windowStart, TIME_DATE | TIME_MINUTES),
            " -> ", TimeToString(windowEnd, TIME_DATE | TIME_MINUTES),
            " bins tested: ", testedText,
            " final POC=", DoubleToString(finalPocPrice, _Digits),
            " confidence=", pocConfidence,
            " spread=", DoubleToString(spread, _Digits),
            " atr=", DoubleToString(atr, _Digits));
   }
}

//+------------------------------------------------------------------+
void DrawPOCResult(const string tag,
                   const datetime leftTime,
                   const datetime rightTime,
                   const datetime labelTime,
                   const double finalPocPrice,
                   const double pocZoneLow,
                   const double pocZoneHigh,
                   const color pocColor,
                   const string pocConfidence)
{
   bool useZone = (InpProfileBinMode == 2 &&
                   InpDrawPOCZone &&
                   pocConfidence != "High" &&
                   MathAbs(pocZoneHigh - pocZoneLow) > _Point);

   if(useZone)
   {
      string zoneLabel = (pocConfidence == "Low / Mixed Profile" ? "Mixed Profile" : "POC Zone");
      DrawZone(PREFIX + tag + "_POC_ZONE", leftTime, rightTime, pocZoneHigh, pocZoneLow, pocColor,
               tag + " " + zoneLabel + " " + DoubleToString(pocZoneLow, _Digits) + "-" + DoubleToString(pocZoneHigh, _Digits));

      string text = tag + " " + zoneLabel;
      if(tag == "D" || tag == "W")
         text += " " + DoubleToString(pocZoneLow, _Digits) + "-" + DoubleToString(pocZoneHigh, _Digits);
      if(InpDrawPOCConfidenceLabel)
         text += " " + pocConfidence;

      DrawTextSmall(PREFIX + tag + "_POC_LABEL", text, labelTime, finalPocPrice, pocColor);
      return;
   }

   DrawSegmentHLine(PREFIX + tag + "_POC", leftTime, rightTime, finalPocPrice, pocColor, STYLE_SOLID, 1,
                    tag + " POC " + DoubleToString(finalPocPrice, _Digits));

   string labelText = tag + " POC";
   if(tag == "D" || tag == "W")
      labelText += " " + DoubleToString(finalPocPrice, _Digits);
   if(InpProfileBinMode == 2 && InpDrawPOCConfidenceLabel)
      labelText += " " + pocConfidence;

   DrawTextSmall(PREFIX + tag + "_POC_LABEL", labelText, labelTime, finalPocPrice, pocColor);
}

//+------------------------------------------------------------------+
void PrintProfileDebug(const string tag,
                       const ENUM_TIMEFRAMES calcTF,
                       const datetime windowStart,
                       const datetime windowEnd,
                       const int bins,
                       const double &profile[],
                       const double rangeLow,
                       const double binHeight,
                       const double finalPocPrice,
                       const string pocConfidence)
{
   int count = ArraySize(profile);
   if(count <= 0)
      return;

   Print("VP DEBUG ", Symbol(), " ", tag,
         " calcTF=", TimeframeToText(calcTF),
         " window=", TimeToString(windowStart, TIME_DATE | TIME_MINUTES),
         " -> ", TimeToString(windowEnd, TIME_DATE | TIME_MINUTES),
         " selectedBins=", IntegerToString(bins),
         " finalPOC=", DoubleToString(finalPocPrice, _Digits),
         " confidence=", pocConfidence);

   bool used[];
   ArrayResize(used, count);
   ArrayInitialize(used, false);

   for(int rank = 1; rank <= MathMin(5, count); rank++)
   {
      int bestBin = -1;
      double bestVol = -1.0;
      for(int i = 0; i < count; i++)
      {
         if(used[i])
            continue;
         if(profile[i] > bestVol)
         {
            bestVol = profile[i];
            bestBin = i;
         }
      }

      if(bestBin < 0)
         break;

      used[bestBin] = true;
      Print("VP DEBUG ", Symbol(), " ", tag,
            " top", IntegerToString(rank),
            " bin=", IntegerToString(bestBin),
            " price=", DoubleToString(BinMid(rangeLow, binHeight, bestBin), _Digits),
            " volume=", DoubleToString(bestVol, 0));
   }
}

//+------------------------------------------------------------------+
int EffectiveProfileBins(const string tag,
                         const ENUM_TIMEFRAMES calcTF,
                         const double rangeHigh,
                         const double rangeLow)
{
   if(InpProfileBinMode == 1)
      return(AdaptiveProfileBins(calcTF, rangeHigh, rangeLow));

   return(EffectiveFixedProfileBins());
}

//+------------------------------------------------------------------+
int EffectiveFixedProfileBins()
{
   if(InpProfilePreset == 1)
      return(24);
   if(InpProfilePreset == 2)
      return(30);
   if(InpProfilePreset == 3)
      return(36);

   int fixedBins = InpProfileBinsFixed;
   if(fixedBins == 24 && InpProfileBins != 24)
      fixedBins = InpProfileBins;
   if(fixedBins <= 0)
      fixedBins = InpProfileBins;

   return(ClampProfileBins(fixedBins));
}

//+------------------------------------------------------------------+
int AdaptiveProfileBins(const ENUM_TIMEFRAMES calcTF, const double rangeHigh, const double rangeLow)
{
   if(InpProfilePreset == 1)
      return(24);
   if(InpProfilePreset == 2)
      return(30);
   if(InpProfilePreset == 3)
      return(36);

   double atr = GetATRValue(calcTF, 14, 1);
   if(atr <= 0.0)
      atr = GetATRValue(calcTF, 14, 0);
   if(atr <= 0.0)
      return(EffectiveFixedProfileBins());

   double profileRange = MathMax(_Point, rangeHigh - rangeLow);
   double rangeATR = profileRange / atr;

   if(IsHeavyProfileSymbol() || rangeATR > 4.0)
      return(36);
   if(rangeATR > 2.5)
      return(30);
   return(24);
}

//+------------------------------------------------------------------+
int ClampProfileBins(const int bins)
{
   return(MathMax(8, MathMin(120, bins)));
}

//+------------------------------------------------------------------+
bool EffectiveDrawDailyProfile()
{
   if(InpProfilePreset >= 1 && InpProfilePreset <= 3)
      return(true);
   return(InpDrawDailyProfile);
}

//+------------------------------------------------------------------+
bool EffectiveDrawWeeklyProfile()
{
   if(InpProfilePreset >= 1 && InpProfilePreset <= 3)
      return(true);
   return(InpDrawWeeklyProfile);
}

//+------------------------------------------------------------------+
bool EffectiveDrawMonthlyProfile()
{
   if(InpProfilePreset >= 1 && InpProfilePreset <= 3)
      return(false);
   return(InpDrawMonthlyProfile);
}

//+------------------------------------------------------------------+
int EffectiveMaxHVNZonesEach()
{
   if(InpProfilePreset == 3)
      return(2);
   return(InpMaxHVNZonesEach);
}

//+------------------------------------------------------------------+
int EffectiveMaxLVNZonesEach()
{
   if(InpProfilePreset == 3)
      return(2);
   return(InpMaxLVNZonesEach);
}

//+------------------------------------------------------------------+
double EffectiveSRMinVolumeMultiplier()
{
   if(InpProfilePreset == 3)
      return(MathMax(InpSRMinVolumeMultiplier, 1.20));
   return(InpSRMinVolumeMultiplier);
}

//+------------------------------------------------------------------+
bool IsHeavyProfileSymbol()
{
   string symbol = Symbol();
   StringToUpper(symbol);
   if(StringFind(symbol, "XAU") >= 0 || StringFind(symbol, "GOLD") >= 0 ||
      StringFind(symbol, "XAG") >= 0 || StringFind(symbol, "SILVER") >= 0 ||
      StringFind(symbol, "NAS") >= 0 || StringFind(symbol, "US100") >= 0 ||
      StringFind(symbol, "USTEC") >= 0 || StringFind(symbol, "US30") >= 0 ||
      StringFind(symbol, "DJ30") >= 0 || StringFind(symbol, "SPX") >= 0 ||
      StringFind(symbol, "SP500") >= 0 || StringFind(symbol, "US500") >= 0 ||
      StringFind(symbol, "GER40") >= 0 || StringFind(symbol, "DAX") >= 0 ||
      StringFind(symbol, "BTC") >= 0 || StringFind(symbol, "ETH") >= 0)
      return(true);

   return(false);
}

//+------------------------------------------------------------------+
string TimeframeToText(const int tf)
{
   if(tf == PERIOD_M1) return("M1");
   if(tf == PERIOD_M5) return("M5");
   if(tf == PERIOD_M15) return("M15");
   if(tf == PERIOD_M30) return("M30");
   if(tf == PERIOD_H1) return("H1");
   if(tf == PERIOD_H4) return("H4");
   if(tf == PERIOD_D1) return("D1");
   if(tf == PERIOD_W1) return("W1");
   if(tf == PERIOD_MN1) return("MN1");
   return(IntegerToString(tf));
}

//+------------------------------------------------------------------+
int FindHighestUnusedBin(const double &profile[],
                         const bool &used[],
                         const int bins,
                         const double minVolume)
{
   int bestBin = -1;
   double bestVol = -1.0;
   for(int i = 0; i < bins; i++)
   {
      if(used[i])
         continue;
      if(profile[i] < minVolume)
         continue;
      if(profile[i] > bestVol)
      {
         bestVol = profile[i];
         bestBin = i;
      }
   }
   return(bestBin);
}

//+------------------------------------------------------------------+
int FindLowestUnusedBin(const double &profile[],
                        const bool &used[],
                        const int bins,
                        const double maxVolume)
{
   int bestBin = -1;
   double bestVol = 999999999999.0;
   for(int i = 0; i < bins; i++)
   {
      if(used[i])
         continue;
      if(profile[i] <= 0.0 || profile[i] > maxVolume)
         continue;
      if(profile[i] < bestVol)
      {
         bestVol = profile[i];
         bestBin = i;
      }
   }
   return(bestBin);
}

//+------------------------------------------------------------------+
double CalculateFixedTFVWAPLevel(const datetime windowStart, const ENUM_TIMEFRAMES calcTF, const int maxScanBars)
{
   int bars = iBars(Symbol(), calcTF);
   if(bars <= 0)
      return(0.0);

   int scanBars = MathMin(bars - 1, MathMax(10, maxScanBars));
   double sumPV = 0.0;
   double sumV = 0.0;
   int found = 0;

   for(int i = 0; i <= scanBars; i++)
   {
      datetime barTime = iTime(Symbol(), calcTF, i);
      if(barTime <= 0)
         continue;

      if(barTime < windowStart)
         break;

      double h = iHigh(Symbol(), calcTF, i);
      double l = iLow(Symbol(), calcTF, i);
      double c = iClose(Symbol(), calcTF, i);
      double v = MathMax(1.0, (double)iVolume(Symbol(), calcTF, i));

      if(h <= 0.0 || l <= 0.0 || c <= 0.0)
         continue;

      double typical = (h + l + c) / 3.0;
      sumPV += typical * v;
      sumV += v;
      found++;
   }

   if(found <= 0 || sumV <= 0.0)
      return(0.0);

   return(sumPV / sumV);
}

//+------------------------------------------------------------------+
void DrawVWAPLevels(const int rates_total,
                    const datetime &time[],
                    const double &high[],
                    const double &low[],
                    const double &close[],
                    const long &tick_volume[])
{
   if(InpDrawDailyVWAPLevel)
      DrawVWAPLevelForWindow("Daily", GetDayStart(TimeCurrent()), InpDailyFallbackBars,
                             rates_total, time, high, low, close, tick_volume);

   if(InpDrawWeeklyVWAPLevel)
      DrawVWAPLevelForWindow("Weekly", GetWeekStart(TimeCurrent()), InpWeeklyFallbackBars,
                             rates_total, time, high, low, close, tick_volume);

   if(InpDrawMonthlyVWAPLevel)
      DrawVWAPLevelForWindow("Monthly", GetMonthStart(TimeCurrent()), InpMonthlyFallbackBars,
                             rates_total, time, high, low, close, tick_volume);
}

//+------------------------------------------------------------------+
void DrawVWAPLevelForWindow(const string tag,
                            const datetime windowStart,
                            const int fallbackBars,
                            const int rates_total,
                            const datetime &time[],
                            const double &high[],
                            const double &low[],
                            const double &close[],
                            const long &tick_volume[])
{
   double vwap = CalculateFixedTFVWAPLevel(windowStart, InpVWAPLevelCalcTF, InpVWAPLevelMaxBars);

   // Fallback: if MT5 has not loaded enough lower-timeframe history yet,
   // use the current chart timeframe so the line still appears.
   if(vwap <= 0.0)
   {
      int lastBar = FindOldestBarInWindow(windowStart, fallbackBars, rates_total, time);
      if(lastBar < 1)
         return;

      double sumPV = 0.0;
      double sumV = 0.0;
      for(int i = 0; i <= lastBar; i++)
      {
         double typical = (high[i] + low[i] + close[i]) / 3.0;
         double vol = MathMax(1.0, (double)tick_volume[i]);
         sumPV += typical * vol;
         sumV += vol;
      }

      if(sumV <= 0.0)
         return;

      vwap = sumPV / sumV;
   }

   datetime labelTime = LineLabelTime();
   string name = PREFIX + tag + "_VWAP_LEVEL";
   DrawHLine(name, vwap, InpVWAPLevelColor, STYLE_SOLID, 1,
             tag + " VWAP " + DoubleToString(vwap, _Digits));
   DrawText(name + "_LABEL", tag + " VWAP", labelTime, vwap, InpVWAPLevelColor);
}

//+------------------------------------------------------------------+
void DrawPreviousDayLevels()
{
   double prevHigh = iHigh(Symbol(), PERIOD_D1, 1);
   double prevLow = iLow(Symbol(), PERIOD_D1, 1);
   datetime labelTime = LineLabelTime();

   if(prevHigh > 0.0)
   {
      DrawShortHLine(PREFIX + "PDH", prevHigh, InpPrevDayColor, STYLE_DASH, 2,
                     "Previous Day High " + DoubleToString(prevHigh, _Digits), InpHighLowShortLineBars);
      DrawText(PREFIX + "PDH_LABEL", "PDH", labelTime, prevHigh, InpPrevDayColor);
   }

   if(prevLow > 0.0)
   {
      DrawShortHLine(PREFIX + "PDL", prevLow, InpPrevDayColor, STYLE_DASH, 2,
                     "Previous Day Low " + DoubleToString(prevLow, _Digits), InpHighLowShortLineBars);
      DrawText(PREFIX + "PDL_LABEL", "PDL", labelTime, prevLow, InpPrevDayColor);
   }
}

//+------------------------------------------------------------------+
void DrawAsiaLevels(const int rates_total,
                    const datetime &time[],
                    const double &high[],
                    const double &low[])
{
   int startMin = 0;
   int endMin = 360;
   if(!ParseSessionMinutes(InpAsiaSession, startMin, endMin))
      return;

   datetime dayStart = GetDayStart(TimeCurrent());
   double asiaHigh = -DBL_MAX;
   double asiaLow = DBL_MAX;
   int found = 0;
   int maxBars = MathMin(rates_total - 1, InpMaxBarsToScan);

   for(int i = 0; i <= maxBars; i++)
   {
      if(time[i] < dayStart)
         break;

      int minutes = TimeHour(time[i]) * 60 + TimeMinute(time[i]);
      bool inSession = false;
      if(startMin <= endMin)
         inSession = (minutes >= startMin && minutes <= endMin);
      else
         inSession = (minutes >= startMin || minutes <= endMin);

      if(inSession)
      {
         asiaHigh = MathMax(asiaHigh, high[i]);
         asiaLow = MathMin(asiaLow, low[i]);
         found++;
      }
   }

   if(found <= 0 || asiaHigh <= -DBL_MAX / 2 || asiaLow >= DBL_MAX / 2)
      return;

   datetime labelTime = LineLabelTime();
   DrawShortHLine(PREFIX + "ASIA_HIGH", asiaHigh, InpAsiaColor, STYLE_DASH, 2,
                  "Asia High " + DoubleToString(asiaHigh, _Digits), InpHighLowShortLineBars);
   DrawShortHLine(PREFIX + "ASIA_LOW", asiaLow, InpAsiaColor, STYLE_DASH, 2,
                  "Asia Low " + DoubleToString(asiaLow, _Digits), InpHighLowShortLineBars);
   DrawText(PREFIX + "ASIA_HIGH_LABEL", "Asia H", labelTime, asiaHigh, InpAsiaColor);
   DrawText(PREFIX + "ASIA_LOW_LABEL", "Asia L", labelTime, asiaLow, InpAsiaColor);
}

//+------------------------------------------------------------------+
void DrawPivotLevels()
{
   ENUM_TIMEFRAMES tf = InpPivotSourceTF;
   if(tf <= 0)
      tf = PERIOD_D1;

   double prevHigh = iHigh(Symbol(), tf, 1);
   double prevLow = iLow(Symbol(), tf, 1);
   double prevClose = iClose(Symbol(), tf, 1);

   if(prevHigh <= 0.0 || prevLow <= 0.0 || prevClose <= 0.0 || prevHigh <= prevLow)
      return;

   double pp = (prevHigh + prevLow + prevClose) / 3.0;
   double r1 = (2.0 * pp) - prevLow;
   double s1 = (2.0 * pp) - prevHigh;
   double range = prevHigh - prevLow;
   double r2 = pp + range;
   double s2 = pp - range;
   double r3 = prevHigh + 2.0 * (pp - prevLow);
   double s3 = prevLow - 2.0 * (prevHigh - pp);

   DrawPivotLine("PP", pp, InpPivotColor, STYLE_DASH);
   DrawPivotLine("R1", r1, InpPivotResistanceColor, STYLE_DOT);
   DrawPivotLine("S1", s1, InpPivotSupportColor, STYLE_DOT);

   if(InpDrawFullPivotSet)
   {
      DrawPivotLine("R2", r2, InpPivotResistanceColor, STYLE_DOT);
      DrawPivotLine("R3", r3, InpPivotResistanceColor, STYLE_DOT);
      DrawPivotLine("S2", s2, InpPivotSupportColor, STYLE_DOT);
      DrawPivotLine("S3", s3, InpPivotSupportColor, STYLE_DOT);
   }
}

//+------------------------------------------------------------------+
void DrawPivotLine(const string label, const double price, const color lineColor, const int style)
{
   string name = PREFIX + "PIVOT_" + label;
   string tip = label + " " + DoubleToString(price, _Digits);

   int width = (label == "PP" ? 2 : 1);
   int pivotStyle = (label == "PP" ? STYLE_SOLID : style);

   if(InpDrawPivotShortLines)
      DrawShortHLine(name, price, lineColor, pivotStyle, width, tip, InpPivotShortLineBars);
   else
      DrawHLine(name, price, lineColor, pivotStyle, width, tip);

   DrawText(name + "_LABEL", label, LineLabelTime(), price, lineColor);
}

//+------------------------------------------------------------------+
bool ParseSessionMinutes(const string sessionText, int &startMin, int &endMin)
{
   string parts[];
   int count = StringSplit(sessionText, '-', parts);
   if(count != 2)
      return(false);

   startMin = ParseHHMM(parts[0]);
   endMin = ParseHHMM(parts[1]);
   return(startMin >= 0 && endMin >= 0);
}

//+------------------------------------------------------------------+
int ParseHHMM(string value)
{
   StringTrimLeft(value);
   StringTrimRight(value);
   string parts[];
   int count = StringSplit(value, ':', parts);
   if(count != 2)
      return(-1);

   int hh = (int)StringToInteger(parts[0]);
   int mm = (int)StringToInteger(parts[1]);
   if(hh < 0 || hh > 23 || mm < 0 || mm > 59)
      return(-1);
   return(hh * 60 + mm);
}

//+------------------------------------------------------------------+
void DrawSupportResistance(const int rates_total,
                           const datetime &time[],
                           const double &high[],
                           const double &low[],
                           const long &tick_volume[])
{
   ENUM_TIMEFRAMES srTF = ResolveSRCalculationTF();
   int srBars = iBars(Symbol(), srTF);
   int lookback = MathMin(MathMin(InpSRLookbackBars, InpMaxBarsToScan), srBars - InpPivotStrength - 2);
   if(lookback <= InpPivotStrength * 2)
      return;

   double atr = GetATRValue(srTF, 14, 0);
   if(atr <= 0.0)
      atr = 20.0 * _Point;

   double mergeDistance = MathMax(_Point * 5.0, atr * InpMergeATRMultiple);
   double zonePadding = MathMax(_Point * 3.0, atr * InpZoneATRPadding);

   double levels[];
   double zoneHighs[];
   double zoneLows[];
   int touches[];
   int kind[];
   int oldestTouchIndex[];
   int newestTouchIndex[];
   double weights[];
   double scores[];
   ArrayResize(levels, 0);
   ArrayResize(zoneHighs, 0);
   ArrayResize(zoneLows, 0);
   ArrayResize(touches, 0);
   ArrayResize(kind, 0);
   ArrayResize(oldestTouchIndex, 0);
   ArrayResize(newestTouchIndex, 0);
   ArrayResize(weights, 0);
   ArrayResize(scores, 0);

   for(int i = InpPivotStrength; i <= lookback; i++)
   {
      if(IsPivotHighTF(srTF, i))
      {
         double highLevel = iHigh(Symbol(), srTF, i);
         double highVolume = MathMax(1.0, (double)iVolume(Symbol(), srTF, i));
         double highVolumeRatio = PivotVolumeRatio(srTF, i, lookback);
         if(!InpSRUseVolumeFilter || highVolumeRatio >= EffectiveSRMinVolumeMultiplier())
            AddCluster(highLevel, 1, highVolume, highVolumeRatio, i, mergeDistance,
                       levels, zoneHighs, zoneLows, touches, kind, oldestTouchIndex, newestTouchIndex, weights, scores);
      }

      if(IsPivotLowTF(srTF, i))
      {
         double lowLevel = iLow(Symbol(), srTF, i);
         double lowVolume = MathMax(1.0, (double)iVolume(Symbol(), srTF, i));
         double lowVolumeRatio = PivotVolumeRatio(srTF, i, lookback);
         if(!InpSRUseVolumeFilter || lowVolumeRatio >= EffectiveSRMinVolumeMultiplier())
            AddCluster(lowLevel, -1, lowVolume, lowVolumeRatio, i, mergeDistance,
                       levels, zoneHighs, zoneLows, touches, kind, oldestTouchIndex, newestTouchIndex, weights, scores);
      }
   }

   int count = ArraySize(levels);
   if(count <= 0)
      return;

   SortClusters(levels, zoneHighs, zoneLows, touches, kind, oldestTouchIndex, newestTouchIndex, weights, scores);

   datetime rightTime = (InpSRExtendToCurrentOnly ? iTime(_Symbol, _Period, 0) : ZoneProjectionTime());
   int drawn = 0;

   for(int idx = 0; idx < count && drawn < InpMaxSRZones; idx++)
   {
      if(touches[idx] < InpMinTouches)
         continue;
      if(scores[idx] < InpSRMinScore)
         continue;

      string side = (kind[idx] > 0 ? "Resistance" : "Support");
      color zoneColor = (kind[idx] > 0 ? InpResistanceColor : InpSupportColor);
      string name = PREFIX + "SR_" + side + "_" + IntegerToString(drawn + 1);
      datetime leftTime = iTime(Symbol(), srTF, MathMin(lookback, MathMax(0, oldestTouchIndex[idx])));
      if(leftTime <= 0)
         leftTime = iTime(_Symbol, _Period, 0) - PeriodSecondsSafe() * InpHighLowShortLineBars;
      double zoneTop = zoneHighs[idx] + zonePadding;
      double zoneBottom = zoneLows[idx] - zonePadding;
      DrawZone(name, leftTime, rightTime, zoneTop, zoneBottom, zoneColor,
               side + " touches=" + IntegerToString(touches[idx]) + " score=" + DoubleToString(scores[idx], 1));
      if(InpDrawSRMidlines)
         DrawSegmentHLine(name + "_MID", leftTime, rightTime, levels[idx], zoneColor, STYLE_DASH, 1,
                          side + " midpoint " + DoubleToString(levels[idx], _Digits));
      DrawTextSmall(name + "_LABEL", SRShortLabel(side) + " x" + IntegerToString(touches[idx]),
                    LineLabelTime(), levels[idx], zoneColor);
      drawn++;
   }
}

//+------------------------------------------------------------------+
ENUM_TIMEFRAMES ResolveSRCalculationTF()
{
   ENUM_TIMEFRAMES tf = InpSRCalculationTF;
   if(tf <= 0)
      tf = Period();
   return(tf);
}

//+------------------------------------------------------------------+
bool IsPivotHigh(const int index, const double &high[])
{
   for(int k = 1; k <= InpPivotStrength; k++)
   {
      if(high[index] <= high[index - k])
         return(false);
      if(high[index] < high[index + k])
         return(false);
   }
   return(true);
}

//+------------------------------------------------------------------+
bool IsPivotHighTF(const ENUM_TIMEFRAMES tf, const int index)
{
   double pivotHigh = iHigh(Symbol(), tf, index);
   if(pivotHigh <= 0.0)
      return(false);

   for(int k = 1; k <= InpPivotStrength; k++)
   {
      if(pivotHigh <= iHigh(Symbol(), tf, index - k))
         return(false);
      if(pivotHigh < iHigh(Symbol(), tf, index + k))
         return(false);
   }
   return(true);
}

//+------------------------------------------------------------------+
bool IsPivotLow(const int index, const double &low[])
{
   for(int k = 1; k <= InpPivotStrength; k++)
   {
      if(low[index] >= low[index - k])
         return(false);
      if(low[index] > low[index + k])
         return(false);
   }
   return(true);
}

//+------------------------------------------------------------------+
bool IsPivotLowTF(const ENUM_TIMEFRAMES tf, const int index)
{
   double pivotLow = iLow(Symbol(), tf, index);
   if(pivotLow <= 0.0)
      return(false);

   for(int k = 1; k <= InpPivotStrength; k++)
   {
      if(pivotLow >= iLow(Symbol(), tf, index - k))
         return(false);
      if(pivotLow > iLow(Symbol(), tf, index + k))
         return(false);
   }
   return(true);
}

//+------------------------------------------------------------------+
double PivotVolumeRatio(const ENUM_TIMEFRAMES tf, const int index, const int maxIndex)
{
   double pivotVolume = MathMax(1.0, (double)iVolume(Symbol(), tf, index));
   double sumVolume = 0.0;
   int found = 0;
   int avgBars = MathMax(5, InpSRVolumeAverageBars);

   for(int j = index + 1; j <= MathMin(maxIndex, index + avgBars); j++)
   {
      double volume = (double)iVolume(Symbol(), tf, j);
      if(volume <= 0.0)
         continue;
      sumVolume += volume;
      found++;
   }

   if(found <= 0 || sumVolume <= 0.0)
      return(1.0);

   double averageVolume = sumVolume / found;
   if(averageVolume <= 0.0)
      return(1.0);

   return(pivotVolume / averageVolume);
}

//+------------------------------------------------------------------+
string SRShortLabel(const string side)
{
   if(side == "Resistance")
      return("R");
   return("S");
}

//+------------------------------------------------------------------+
void AddCluster(const double level,
                const int levelKind,
                const double weight,
                const double volumeRatio,
                const int barIndex,
                const double mergeDistance,
                double &levels[],
                double &zoneHighs[],
                double &zoneLows[],
                int &touches[],
                int &kind[],
                int &oldestTouchIndex[],
                int &newestTouchIndex[],
                double &weights[],
                double &scores[])
{
   int count = ArraySize(levels);
   for(int i = 0; i < count; i++)
   {
      if(kind[i] == levelKind && MathAbs(levels[i] - level) <= mergeDistance)
      {
         double oldWeight = MathMax(1.0, weights[i]);
         levels[i] = ((levels[i] * oldWeight) + (level * weight)) / (oldWeight + weight);
         zoneHighs[i] = MathMax(zoneHighs[i], level);
         zoneLows[i] = MathMin(zoneLows[i], level);
         weights[i] = oldWeight + weight;
         touches[i]++;
         oldestTouchIndex[i] = MathMax(oldestTouchIndex[i], barIndex);
         newestTouchIndex[i] = MathMin(newestTouchIndex[i], barIndex);
         scores[i] += 1.0 + MathMin(2.0, MathMax(0.0, volumeRatio));
         return;
      }
   }

   ArrayResize(levels, count + 1);
   ArrayResize(zoneHighs, count + 1);
   ArrayResize(zoneLows, count + 1);
   ArrayResize(touches, count + 1);
   ArrayResize(kind, count + 1);
   ArrayResize(oldestTouchIndex, count + 1);
   ArrayResize(newestTouchIndex, count + 1);
   ArrayResize(weights, count + 1);
   ArrayResize(scores, count + 1);

   levels[count] = level;
   zoneHighs[count] = level;
   zoneLows[count] = level;
   touches[count] = 1;
   kind[count] = levelKind;
   oldestTouchIndex[count] = barIndex;
   newestTouchIndex[count] = barIndex;
   weights[count] = weight;
   scores[count] = 1.0 + MathMin(2.0, MathMax(0.0, volumeRatio));
}

//+------------------------------------------------------------------+
void SortClusters(double &levels[],
                  double &zoneHighs[],
                  double &zoneLows[],
                  int &touches[],
                  int &kind[],
                  int &oldestTouchIndex[],
                  int &newestTouchIndex[],
                  double &weights[],
                  double &scores[])
{
   int count = ArraySize(levels);
   for(int i = 0; i < count - 1; i++)
   {
      for(int j = i + 1; j < count; j++)
      {
         bool swapNeeded = false;
         if(scores[j] > scores[i])
            swapNeeded = true;
         else if(MathAbs(scores[j] - scores[i]) < 0.0001 && touches[j] > touches[i])
            swapNeeded = true;
         else if(MathAbs(scores[j] - scores[i]) < 0.0001 && touches[j] == touches[i] && weights[j] > weights[i])
            swapNeeded = true;

         if(swapNeeded)
         {
            double tmpLevel = levels[i];
            double tmpHigh = zoneHighs[i];
            double tmpLow = zoneLows[i];
            int tmpTouches = touches[i];
            int tmpKind = kind[i];
            int tmpOldest = oldestTouchIndex[i];
            int tmpNewest = newestTouchIndex[i];
            double tmpWeight = weights[i];
            double tmpScore = scores[i];

            levels[i] = levels[j];
            zoneHighs[i] = zoneHighs[j];
            zoneLows[i] = zoneLows[j];
            touches[i] = touches[j];
            kind[i] = kind[j];
            oldestTouchIndex[i] = oldestTouchIndex[j];
            newestTouchIndex[i] = newestTouchIndex[j];
            weights[i] = weights[j];
            scores[i] = scores[j];

            levels[j] = tmpLevel;
            zoneHighs[j] = tmpHigh;
            zoneLows[j] = tmpLow;
            touches[j] = tmpTouches;
            kind[j] = tmpKind;
            oldestTouchIndex[j] = tmpOldest;
            newestTouchIndex[j] = tmpNewest;
            weights[j] = tmpWeight;
            scores[j] = tmpScore;
         }
      }
   }
}

//+------------------------------------------------------------------+
int FindOldestBarInWindow(const datetime windowStart,
                          const int fallbackBars,
                          const int rates_total,
                          const datetime &time[])
{
   int oldest = 0;
   int maxBars = MathMin(MathMin(fallbackBars, InpMaxBarsToScan), rates_total - 1);

   for(int i = 0; i <= maxBars; i++)
   {
      if(time[i] >= windowStart)
         oldest = i;
      else
         break;
   }

   if(oldest < MathMin(12, maxBars))
      oldest = maxBars;

   return(oldest);
}

//+------------------------------------------------------------------+
datetime GetDayStart(const datetime value)
{
   return(StringToTime(TimeToString(value, TIME_DATE)));
}

//+------------------------------------------------------------------+
datetime PreviousDayStart(const datetime value)
{
   return(GetDayStart(value) - 86400);
}

//+------------------------------------------------------------------+
datetime PreviousCompletedTradingDayStart(const datetime value)
{
   datetime todayStart = GetDayStart(value);

   for(int daysBack = 1; daysBack <= 10; daysBack++)
   {
      datetime candidateStart = todayStart - daysBack * 86400;
      datetime candidateEnd = candidateStart + 86400;
      if(HasBarsInWindow(PERIOD_M15, candidateStart, candidateEnd, InpDailyFallbackBars))
         return(candidateStart);
   }

   return(PreviousDayStart(value));
}

//+------------------------------------------------------------------+
datetime PreviousCompletedTradingDayEnd(const datetime value)
{
   return(PreviousCompletedTradingDayStart(value) + 86400);
}

//+------------------------------------------------------------------+
bool HasBarsInWindow(const ENUM_TIMEFRAMES calcTF,
                     const datetime windowStart,
                     const datetime windowEnd,
                     const int maxScanBars)
{
   int bars = iBars(Symbol(), calcTF);
   if(bars <= 1)
      return(false);

   int scanBars = MathMin(MathMin(maxScanBars, InpMaxBarsToScan), bars - 1);
   for(int i = 0; i <= scanBars; i++)
   {
      datetime barTime = iTime(Symbol(), calcTF, i);
      if(barTime <= 0)
         continue;
      if(barTime >= windowEnd)
         continue;
      if(barTime < windowStart)
         break;
      return(true);
   }

   return(false);
}

//+------------------------------------------------------------------+
datetime GetWeekStart(const datetime value)
{
   datetime dayStart = GetDayStart(value);
   int dow = TimeDayOfWeek(value);
   int daysBack = (dow == 0 ? 6 : dow - 1);
   return(dayStart - daysBack * 86400);
}

//+------------------------------------------------------------------+
datetime PreviousWeekStart(const datetime value)
{
   return(GetWeekStart(value) - 7 * 86400);
}

//+------------------------------------------------------------------+
datetime GetMonthStart(const datetime value)
{
   string yearText = IntegerToString(TimeYear(value));
   string monthText = IntegerToString(TimeMonth(value));
   if(StringLen(monthText) < 2)
      monthText = "0" + monthText;
   return(StringToTime(yearText + "." + monthText + ".01 00:00"));
}

//+------------------------------------------------------------------+
datetime PreviousMonthStart(const datetime value)
{
   int year = TimeYear(value);
   int month = TimeMonth(value) - 1;
   if(month < 1)
   {
      month = 12;
      year--;
   }

   string yearText = IntegerToString(year);
   string monthText = IntegerToString(month);
   if(StringLen(monthText) < 2)
      monthText = "0" + monthText;
   return(StringToTime(yearText + "." + monthText + ".01 00:00"));
}

//+------------------------------------------------------------------+
double BinMid(const double rangeLow, const double binHeight, const int bin)
{
   return(rangeLow + (bin + 0.5) * binHeight);
}

//+------------------------------------------------------------------+
int PeriodSecondsSafe()
{
   int seconds = PeriodSeconds(PERIOD_CURRENT);
   if(seconds <= 0)
      seconds = 3600;
   return(seconds);
}

//+------------------------------------------------------------------+
datetime ZoneProjectionTime()
{
   return(iTime(_Symbol, _Period, 0) + PeriodSecondsSafe() * InpProjectionBars);
}

//+------------------------------------------------------------------+
datetime LineLabelTime()
{
   int offsetBars = MathMax(0, MathMin(20, InpLineLabelOffsetBars));
   return(iTime(_Symbol, _Period, 0) + PeriodSecondsSafe() * offsetBars);
}

//+------------------------------------------------------------------+
void DrawVolumeHistogram(const string tag,
                         const datetime windowStart,
                         const int bins,
                         const double &profile[],
                         const double rangeLow,
                         const double binHeight,
                         const double maxVol)
{
   if(bins <= 0 || maxVol <= 0.0 || binHeight <= 0.0)
      return;

   int    secPerBar = PeriodSeconds(PERIOD_CURRENT);
   if(secPerBar <= 0) secPerBar = 3600;
   datetime leftEdge = windowStart;

   int drawCap = InpHistogramMaxBars;
   if(drawCap < 1) drawCap = 1;

   double threshold = 0.0;
   if(bins > drawCap)
      threshold = maxVol * ((double)(bins - drawCap) / (double)bins) * 0.5;

   // Pre-extract gradient endpoint RGB channels (edge = light, POC = denser).
   uint ceEdge = (uint)InpHistogramColorEdge;
   uint cePOC  = (uint)InpHistogramColorPOC;
   int eR = (int)(ceEdge & 0xFF);
   int eG = (int)((ceEdge >> 8) & 0xFF);
   int eB = (int)((ceEdge >> 16) & 0xFF);
   int pR = (int)(cePOC & 0xFF);
   int pG = (int)((cePOC >> 8) & 0xFF);
   int pB = (int)((cePOC >> 16) & 0xFF);

   int drawn = 0;
   for(int i = 0; i < bins; i++)
   {
      if(drawn >= drawCap) break;
      double v = profile[i];
      if(v <= threshold) continue;

      double frac = v / maxVol;                 // 0..1 relative to POC
      if(frac <= 0.0) continue;

      double price = rangeLow + (i + 0.5) * binHeight;
      int    widthBars = (int)MathRound(frac * (double)InpHistogramWidthBars);
      if(widthBars < 1) widthBars = 1;
      datetime rightEnd = leftEdge + (datetime)(widthBars * secPerBar);

      // gradient blend: light at low frac -> denser near POC (frac near 1)
      int cR = eR + (int)((pR - eR) * frac);
      int cG = eG + (int)((pG - eG) * frac);
      int cB = eB + (int)((pB - eB) * frac);
      color barColor = (color)(cR | (cG << 8) | (cB << 16));

      string nm = PREFIX + tag + "_VHIST_" + IntegerToString(i);
      if(ObjectFind(0, nm) < 0)
         ObjectCreate(0, nm, OBJ_TREND, 0, leftEdge, price, rightEnd, price);
      ObjectSetInteger(0, nm, OBJPROP_TIME, 0, leftEdge);
      ObjectSetDouble (0, nm, OBJPROP_PRICE, 0, price);
      ObjectSetInteger(0, nm, OBJPROP_TIME, 1, rightEnd);
      ObjectSetDouble (0, nm, OBJPROP_PRICE, 1, price);
      ObjectSetInteger(0, nm, OBJPROP_COLOR, barColor);
      ObjectSetInteger(0, nm, OBJPROP_WIDTH, InpHistogramFillWidth);   // thicker = fills the gaps -> solid profile look
      ObjectSetInteger(0, nm, OBJPROP_RAY_RIGHT, false);
      ObjectSetInteger(0, nm, OBJPROP_BACK, true);
      ObjectSetInteger(0, nm, OBJPROP_SELECTABLE, false);
      drawn++;
   }
}

//+------------------------------------------------------------------+
void DrawZone(const string name,
              const datetime leftTime,
              const datetime rightTime,
              const double top,
              const double bottom,
              const color zoneColor,
              const string tooltip)
{
   ObjectCreate(0, name, OBJ_RECTANGLE, 0, leftTime, top, rightTime, bottom);
   ObjectSetInteger(0, name, OBJPROP_COLOR, zoneColor);
   ObjectSetInteger(0, name, OBJPROP_STYLE, STYLE_SOLID);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, 1);
   ObjectSetInteger(0, name, OBJPROP_BACK, true);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
   ObjectSetString(0, name, OBJPROP_TOOLTIP, tooltip);
}

//+------------------------------------------------------------------+
void DrawShortHLine(const string name,
                    const double price,
                    const color lineColor,
                    const int style,
                    const int width,
                    const string tooltip,
                    const int barsForward)
{
   datetime leftTime = iTime(_Symbol, _Period, 0);
   datetime rightTime = iTime(_Symbol, _Period, 0) + PeriodSecondsSafe() * MathMax(3, barsForward);

   ObjectCreate(0, name, OBJ_TREND, 0, leftTime, price, rightTime, price);
   ObjectSetInteger(0, name, OBJPROP_COLOR, lineColor);
   ObjectSetInteger(0, name, OBJPROP_STYLE, style);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, width);
   ObjectSetInteger(0, name, OBJPROP_RAY_RIGHT, false);
   ObjectSetInteger(0, name, OBJPROP_BACK, true);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
   ObjectSetString(0, name, OBJPROP_TOOLTIP, tooltip);
}

//+------------------------------------------------------------------+
void DrawSegmentHLine(const string name,
                      const datetime leftTime,
                      const datetime rightTime,
                      const double price,
                      const color lineColor,
                      const int style,
                      const int width,
                      const string tooltip)
{
   ObjectCreate(0, name, OBJ_TREND, 0, leftTime, price, rightTime, price);
   ObjectSetInteger(0, name, OBJPROP_COLOR, lineColor);
   ObjectSetInteger(0, name, OBJPROP_STYLE, style);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, width);
   ObjectSetInteger(0, name, OBJPROP_RAY_RIGHT, false);
   ObjectSetInteger(0, name, OBJPROP_BACK, true);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
   ObjectSetString(0, name, OBJPROP_TOOLTIP, tooltip);
}

//+------------------------------------------------------------------+
void DrawHLine(const string name,
               const double price,
               const color lineColor,
               const int style,
               const int width,
               const string tooltip)
{
   ObjectCreate(0, name, OBJ_HLINE, 0, 0, price);
   ObjectSetInteger(0, name, OBJPROP_COLOR, lineColor);
   ObjectSetInteger(0, name, OBJPROP_STYLE, style);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, width);
   ObjectSetInteger(0, name, OBJPROP_BACK, true);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
   ObjectSetString(0, name, OBJPROP_TOOLTIP, tooltip);
}

//+------------------------------------------------------------------+
void DrawProfileText(const string name,
                     const string tag,
                     const string levelType,
                     const datetime textTime,
                     const double price,
                     const color textColor)
{
   string text = tag + " " + levelType;
   if(tag == "D" || tag == "W")
      text = text + " " + DoubleToString(price, _Digits);

   DrawTextSmall(name, text, textTime, price, textColor);
}

//+------------------------------------------------------------------+
void DrawTextSmall(const string name,
                   const string text,
                   const datetime textTime,
                   const double price,
                   const color textColor)
{
   if(!InpDrawLabels)
      return;

   ObjectCreate(0, name, OBJ_TEXT, 0, textTime, price);
   ObjectSetString(0, name, OBJPROP_TEXT, text);
   ObjectSetInteger(0, name, OBJPROP_COLOR, textColor);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, 6);
   ObjectSetString(0, name, OBJPROP_FONT, "Arial");
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
}

//+------------------------------------------------------------------+
void DrawText(const string name,
              const string text,
              const datetime textTime,
              const double price,
              const color textColor)
{
   if(!InpDrawLabels)
      return;

   ObjectCreate(0, name, OBJ_TEXT, 0, textTime, price);
   ObjectSetString(0, name, OBJPROP_TEXT, text);
   ObjectSetInteger(0, name, OBJPROP_COLOR, textColor);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, MathMax(6, MathMin(12, InpLineLabelFontSize)));
   ObjectSetString(0, name, OBJPROP_FONT, "Arial Bold");
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
}

//+------------------------------------------------------------------+
void DeleteObjectsByPrefix(const string prefix)
{
   for(int i = ObjectsTotal(0, -1, -1) - 1; i >= 0; i--)
   {
      string name = ObjectName(0, i, -1, -1);
      if(StringFind(name, prefix, 0) == 0)
         ObjectDelete(0, name);
   }
}

//+------------------------------------------------------------------+
