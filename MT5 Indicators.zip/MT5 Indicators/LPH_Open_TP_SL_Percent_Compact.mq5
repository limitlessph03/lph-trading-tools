//+------------------------------------------------------------------+
//|                     LPH_Open_TP_SL_Percent_Compact.mq4           |
//|                     Standalone compact TP/SL account exposure     |
//|                     Built for MT4 Build 600+                      |
//+------------------------------------------------------------------+
#include "../Include/LPH_MQL4Compat.mqh"
#property indicator_chart_window
#property indicator_plots 0

//---- Scope
input bool   CurrentSymbolOnly       = false;     // true = only this chart symbol, false = all open market trades
input int    MagicNumberFilter       = -1;        // -1 = all magic numbers
input bool   UseEquityAsBase         = true;      // true = % of equity, false = % of balance
input bool   IncludeCommissionSwap   = false;     // adds current commission/swap estimate to open floating only

//---- Pip/point display
input double CustomPipSize           = 0.0;       // 0 = auto. XAU/indices can use 1.0, 0.10, or 0.01 depending broker preference
input bool   ShowPips                = true;
input bool   UseLotWeightedPips      = false;     // false = raw summed pips, true = pips x lots

//---- Display
input bool   ShowBackgroundPanel     = true;
input int    PanelCorner             = 1;         // 0=top-left, 1=top-right, 2=bottom-left, 3=bottom-right
input int    PanelX                  = 10;
input int    PanelY                  = 18;
input int    PanelWidth              = 235;
input int    FontSize                = 8;
input string FontName                = "Arial";
input color  PanelBgColor            = clrBlack;
input color  PanelBorderColor        = clrDimGray;
input color  HeaderColor             = clrDeepSkyBlue;
input color  TextColor               = clrGainsboro;
input color  ProfitColor             = clrMediumSeaGreen;
input color  LossColor               = clrTomato;
input color  WarningColor            = clrGold;
input color  NeutralColor            = clrSilver;

//---- Refresh
input int    RefreshSeconds          = 1;

string PREFIX = "LPH_TPSL_COMPACT_";
int    lineStep = 14;

//+------------------------------------------------------------------+
int OnInit()
{
   IndicatorShortName("LPH Open TP/SL % Compact");
   DeleteObjects();
   if(RefreshSeconds > 0) EventSetTimer(RefreshSeconds);
   UpdatePanel();
   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   EventKillTimer();
   DeleteObjects();
}

//+------------------------------------------------------------------+
void OnTimer()
{
   UpdatePanel();
   ChartRedraw(0);
}

//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
   UpdatePanel();
   return(rates_total);
}

//+------------------------------------------------------------------+
void UpdatePanel()
{
   double base = UseEquityAsBase ? AccountEquity() : AccountBalance();
   if(base <= 0.0) base = 1.0;

   double tpMoney = 0.0;
   double slMoney = 0.0;
   double floatMoney = 0.0;
   double tpPips = 0.0;
   double slPips = 0.0;

   int marketTrades = 0;
   int missingTP = 0;
   int missingSL = 0;

   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;

      int type = OrderType();
      if(type != OP_BUY && type != OP_SELL) continue;

      string sym = OrderSymbol();
      if(CurrentSymbolOnly && sym != Symbol()) continue;
      if(MagicNumberFilter >= 0 && OrderMagicNumber() != MagicNumberFilter) continue;

      marketTrades++;

      double curFloat = OrderProfit();
      if(IncludeCommissionSwap) curFloat += OrderSwap() + OrderCommission();
      floatMoney += curFloat;

      double lots = OrderLots();
      double pipSize = GetPipSize(sym);
      double pipWeight = UseLotWeightedPips ? lots : 1.0;

      double tp = OrderTakeProfit();
      double sl = OrderStopLoss();
      double openPrice = OrderOpenPrice();

      if(tp > 0.0)
      {
         double tpVal = ProfitAtPrice(sym, type, lots, openPrice, tp);
         tpMoney += tpVal;
         if(pipSize > 0.0) tpPips += MathAbs(tp - openPrice) / pipSize * pipWeight;
      }
      else
      {
         missingTP++;
      }

      if(sl > 0.0)
      {
         double slVal = ProfitAtPrice(sym, type, lots, openPrice, sl);
         slMoney += slVal;
         if(pipSize > 0.0) slPips -= MathAbs(sl - openPrice) / pipSize * pipWeight;
      }
      else
      {
         missingSL++;
      }
   }

   double tpPct = tpMoney / base * 100.0;
   double slPct = slMoney / base * 100.0;
   double flPct = floatMoney / base * 100.0;

   int lines = 5;
   int panelHeight = 14 + lines * lineStep + 8;

   if(ShowBackgroundPanel)
      DrawPanel(PREFIX + "BG", PanelX, PanelY, PanelWidth, panelHeight);
   else
      ObjectDelete(0, PREFIX + "BG");

   string scope = CurrentSymbolOnly ? Symbol() : "ALL";
   string baseTxt = UseEquityAsBase ? "EQ" : "BAL";

   DrawLabel(PREFIX + "L0", "LPH TP/SL %  |  " + scope + "  |  " + baseTxt,
             8, HeaderColor, 0);

   string tpLine = "TP: " + MoneyString(tpMoney) + " | " + PctString(tpPct);
   if(ShowPips) tpLine += " | " + PipsString(tpPips);
   DrawLabel(PREFIX + "L1", tpLine, 8, MoneyColor(tpMoney), 1);

   string slLine = "SL: " + MoneyString(slMoney) + " | " + PctString(slPct);
   if(ShowPips) slLine += " | " + PipsString(slPips);
   DrawLabel(PREFIX + "L2", slLine, 8, MoneyColor(slMoney), 2);

   string flLine = "FLOAT: " + MoneyString(floatMoney) + " | " + PctString(flPct);
   DrawLabel(PREFIX + "L3", flLine, 8, MoneyColor(floatMoney), 3);

   string warn = "Trades: " + IntegerToString(marketTrades) + " | No TP: " + IntegerToString(missingTP) + " | No SL: " + IntegerToString(missingSL);
   color warnColor = (missingTP > 0 || missingSL > 0) ? WarningColor : NeutralColor;
   DrawLabel(PREFIX + "L4", warn, 8, warnColor, 4);
}

//+------------------------------------------------------------------+
double ProfitAtPrice(string sym, int type, double lots, double openPrice, double targetPrice)
{
   double tickSize  = MarketInfo(sym, MODE_TICKSIZE);
   double tickValue = MarketInfo(sym, MODE_TICKVALUE);

   if(tickSize <= 0.0) tickSize = MarketInfo(sym, MODE_POINT);
   if(tickSize <= 0.0 || tickValue <= 0.0 || lots <= 0.0) return(0.0);

   double ticks = 0.0;
   if(type == OP_BUY)
      ticks = (targetPrice - openPrice) / tickSize;
   else if(type == OP_SELL)
      ticks = (openPrice - targetPrice) / tickSize;

   return(ticks * tickValue * lots);
}

//+------------------------------------------------------------------+
double GetPipSize(string sym)
{
   if(CustomPipSize > 0.0) return(CustomPipSize);

   int digits = (int)MarketInfo(sym, MODE_DIGITS);
   double point = MarketInfo(sym, MODE_POINT);
   if(point <= 0.0) return(0.0);

   // Standard FX 5/3 digit handling.
   if(digits == 5 || digits == 3) return(point * 10.0);

   // Conservative default for CFDs/metals: one broker point.
   // Override with CustomPipSize for XAU, XAG, NAS100, US30, SPX, etc.
   return(point);
}

//+------------------------------------------------------------------+
string MoneyString(double value)
{
   string sign = value > 0.0 ? "+" : "";
   return(sign + "$" + DoubleToString(value, 2));
}

//+------------------------------------------------------------------+
string PctString(double value)
{
   string sign = value > 0.0 ? "+" : "";
   return(sign + DoubleToString(value, 2) + "%");
}

//+------------------------------------------------------------------+
string PipsString(double value)
{
   string sign = value > 0.0 ? "+" : "";
   string suffix = UseLotWeightedPips ? " lp" : " p";
   return(sign + DoubleToString(value, 1) + suffix);
}

//+------------------------------------------------------------------+
color MoneyColor(double value)
{
   if(value > 0.00001) return(ProfitColor);
   if(value < -0.00001) return(LossColor);
   return(NeutralColor);
}

//+------------------------------------------------------------------+
void DrawPanel(string name, int x, int y, int w, int h)
{
   if(ObjectFind(0, name) < 0)
   {
      ObjectCreate(0, name, OBJ_RECTANGLE_LABEL, 0, 0, 0);
      ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
      ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   }

   ObjectSetInteger(0, name, OBJPROP_CORNER, PanelCorner);
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, name, OBJPROP_XSIZE, w);
   ObjectSetInteger(0, name, OBJPROP_YSIZE, h);
   ObjectSetInteger(0, name, OBJPROP_BGCOLOR, PanelBgColor);
   ObjectSetInteger(0, name, OBJPROP_COLOR, PanelBorderColor);
   ObjectSetInteger(0, name, OBJPROP_BORDER_TYPE, BORDER_FLAT);
   ObjectSetInteger(0, name, OBJPROP_BACK, false);
}

//+------------------------------------------------------------------+
void DrawLabel(string name, string text, int fSize, color clr, int line)
{
   if(ObjectFind(0, name) < 0)
   {
      ObjectCreate(0, name, OBJ_LABEL, 0, 0, 0);
      ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
      ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   }

   ObjectSetInteger(0, name, OBJPROP_CORNER, PanelCorner);
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE, PanelX + 8);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE, PanelY + 6 + (line * lineStep));
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, fSize);
   ObjectSetString(0, name, OBJPROP_FONT, FontName);
   ObjectSetString(0, name, OBJPROP_TEXT, text);
}

//+------------------------------------------------------------------+
void DeleteObjects()
{
   for(int i = ObjectsTotal(0, -1, -1) - 1; i >= 0; i--)
   {
      string name = ObjectName(0, i, -1, -1);
      if(StringFind(name, PREFIX) == 0)
         ObjectDelete(0, name);
   }
}
//+------------------------------------------------------------------+
