//+------------------------------------------------------------------+
//| LPH_entry_exit_shade_with_pips.mq5 - native MT5 position overlay |
//| Draws open-position entry/TP/SL zones and running pip totals.     |
//+------------------------------------------------------------------+
#property strict
#property indicator_chart_window
#property indicator_plots 0
input bool OnlyCurrentSymbol=true,ShowOpenTrades=true,ShowHistoryTrades=false;
input int HistoryDaysBack=30,ExtendOpenBars=80;
input color EntryToTpColor=clrPaleGreen,EntryToSlColor=clrMistyRose;
input bool DrawBehindCandles=true;
input int BorderWidth=1;
input bool UseBasketShadingForOpenTrades=true,ShowIndividualOpenPipsLabels=true,ShowBasketPipsLabel=false;
input bool ShowRunningPips=true,ShowClosedPips=true,ShowTotalOpenPips=true;
input double CustomPipSize=0.0;
input int PipsDecimals=1,PipsLabelFontSize=9,PipsLabelShiftBars=3;
input string PipsLabelFont="Arial Bold";
input double PipsLabelSpacingPips=5.0;
input color ProfitPipsColor=clrLimeGreen,LossPipsColor=clrTomato,BreakevenPipsColor=clrSilver;
input ENUM_BASE_CORNER TotalLabelCorner=CORNER_LEFT_UPPER;
input int TotalLabelX=12,TotalLabelY=18;
string Prefix="EntryTpSlShade_";
double PipSize(){if(CustomPipSize>0)return(CustomPipSize);int d=(int)SymbolInfoInteger(_Symbol,SYMBOL_DIGITS);return((d==3||d==5)?_Point*10.0:_Point);}
void Del(){ObjectsDeleteAll(0,Prefix);}
void Box(const string n,datetime t1,double p1,datetime t2,double p2,color c){if(ObjectFind(0,n)<0)ObjectCreate(0,n,OBJ_RECTANGLE,0,t1,p1,t2,p2);else{ObjectMove(0,n,0,t1,p1);ObjectMove(0,n,1,t2,p2);}ObjectSetInteger(0,n,OBJPROP_COLOR,c);ObjectSetInteger(0,n,OBJPROP_WIDTH,BorderWidth);ObjectSetInteger(0,n,OBJPROP_BACK,DrawBehindCandles);ObjectSetInteger(0,n,OBJPROP_FILL,true);}
void Text(const string n,datetime t,double p,const string s,color c){if(ObjectFind(0,n)<0)ObjectCreate(0,n,OBJ_TEXT,0,t,p);else ObjectMove(0,n,0,t,p);ObjectSetString(0,n,OBJPROP_TEXT,s);ObjectSetString(0,n,OBJPROP_FONT,PipsLabelFont);ObjectSetInteger(0,n,OBJPROP_FONTSIZE,PipsLabelFontSize);ObjectSetInteger(0,n,OBJPROP_COLOR,c);}
int OnInit(){Del();IndicatorSetString(INDICATOR_SHORTNAME,"LPH Entry TP/SL Shading + Running Pips");return(INIT_SUCCEEDED);}
void OnDeinit(const int r){Del();}
int OnCalculate(const int rates_total,const int prev_calculated,const datetime &time[],const double &open[],const double &high[],const double &low[],const double &close[],const long &tick_volume[],const long &volume[],const int &spread[])
{
  Del();if(!ShowOpenTrades)return(rates_total);MqlTick q;if(!SymbolInfoTick(_Symbol,q))return(rates_total);double pip=PipSize(),total=0;int count=0;datetime end=time[0]+(datetime)MathMax(1,PeriodSeconds(_Period))*ExtendOpenBars;
  for(int i=PositionsTotal()-1;i>=0;i--){ulong ticket=PositionGetTicket(i);if(ticket==0)continue;string sym=PositionGetString(POSITION_SYMBOL);if(OnlyCurrentSymbol&&sym!=_Symbol)continue;ENUM_POSITION_TYPE typ=(ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);double entry=PositionGetDouble(POSITION_PRICE_OPEN),tp=PositionGetDouble(POSITION_TP),sl=PositionGetDouble(POSITION_SL),lots=PositionGetDouble(POSITION_VOLUME);datetime ot=(datetime)PositionGetInteger(POSITION_TIME);double px=(typ==POSITION_TYPE_BUY?q.bid:q.ask);double pp=(typ==POSITION_TYPE_BUY?(px-entry):(entry-px))/pip;total+=pp*lots;count++;string id=Prefix+(string)ticket;double hi=MathMax(entry,tp>0?tp:entry),lo=MathMin(entry,tp>0?tp:entry);if(tp>0)Box(id+"_TP",ot,hi,end,entry,EntryToTpColor);if(sl>0){hi=MathMax(entry,sl);lo=MathMin(entry,sl);Box(id+"_SL",ot,entry,end,lo,EntryToSlColor);}if(ShowIndividualOpenPipsLabels&&ShowRunningPips)Text(id+"_TXT",end,entry,DoubleToString(pp,PipsDecimals)+" pips",pp>0?ProfitPipsColor:(pp<0?LossPipsColor:BreakevenPipsColor));}
  if(ShowTotalOpenPips&&count>0){string n=Prefix+"TOTAL";if(ObjectFind(0,n)<0)ObjectCreate(0,n,OBJ_LABEL,0,0,0);ObjectSetInteger(0,n,OBJPROP_CORNER,TotalLabelCorner);ObjectSetInteger(0,n,OBJPROP_XDISTANCE,TotalLabelX);ObjectSetInteger(0,n,OBJPROP_YDISTANCE,TotalLabelY);ObjectSetInteger(0,n,OBJPROP_FONTSIZE,PipsLabelFontSize);ObjectSetString(0,n,OBJPROP_FONT,PipsLabelFont);ObjectSetInteger(0,n,OBJPROP_COLOR,total>=0?ProfitPipsColor:LossPipsColor);ObjectSetString(0,n,OBJPROP_TEXT,"Open pips: "+DoubleToString(total,PipsDecimals)+" ("+(string)count+" positions)");}
  return(rates_total);
}
