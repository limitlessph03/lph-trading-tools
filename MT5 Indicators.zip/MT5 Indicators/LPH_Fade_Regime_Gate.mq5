//+------------------------------------------------------------------+
//|                                    LPH_Fade_Regime_Gate.mq5       |
//|                       Limitless PH - Discretionary Fade Guard     |
//|                                                                  |
//|  Faithful 1:1 port of the MT4 indicator. Same inputs, same        |
//|  object names/prefix, same calculations and visual output.        |
//|  Only MT4 -> MT5 API translations were applied.                   |
//|                                                                  |
//|  PURPOSE (READ FIRST):                                            |
//|  Display-only decision aid for the discretionary "Asia/London     |
//|  push -> NY fade" metals/FX book. It does NOT trade. There is     |
//|  no OrderSend, no OrderModify, no trade-permission input, and it  |
//|  cannot place, close, or modify a single position. It reads the   |
//|  chart and tells you, per-symbol, whether the fade regime is ON,  |
//|  CAUTION, or OFF, and flags stale fade trades past their session. |
//|                                                                  |
//|  It exists to close ONE specific gap that cost account 500237     |
//|  ~-2,350 in June 2026: a conditional thesis ("fade metals on      |
//|  escalation") run unconditionally after the transmission flipped  |
//|  from risk-off (bearish gold) to inflation/oil-shock (bullish     |
//|  gold). The fade is an INTRADAY tactic; it must be gated by the   |
//|  DAILY regime and by a macro flag, and killed when stale.         |
//|                                                                  |
//|  THREE GATES:                                                     |
//|   1. TREND  - Daily 50 EMA slope + price side. Fade-short is OFF  |
//|               when the daily is in a rising uptrend regime.       |
//|   2. MACRO  - Manual oil-shock / inflation-regime flag. When set, |
//|               the "escalation = short gold" reflex is disabled.   |
//|               (Manual by design - you read the heatmap, you set   |
//|               it. No auto data feed = no silent-failure risk.)    |
//|   3. STALE  - Fade trades are intraday. Any open position past    |
//|               the staleness window (default 24h) is flagged: the  |
//|               NY-fade thesis has already been falsified by tape.  |
//|                                                                  |
//|  Uses house style: HTF bias, 50 EMA reactions, optional TDI       |
//|  (RSI-on-price proxy) confirmation read.                          |
//+------------------------------------------------------------------+
#property copyright "Limitless PH"
#property link      "https://limitlessphtraining.com"
#property version   "1.00"
#property indicator_chart_window
#property indicator_plots 0

//==================================================================
// INPUTS
//==================================================================
//--- Regime: Daily trend gate ------------------------------------
input string  __TREND__            = "===== DAILY TREND GATE =====";
input int     InpDailyEmaPeriod    = 50;      // Daily EMA period (house 50 EMA)
input double  InpSlopeAtrFrac      = 0.15;    // Min |EMA slope| in ATR to call a trend (per bar)
input int     InpSlopeLookback     = 5;       // Bars back to measure EMA slope
input int     InpAtrPeriodD1       = 14;      // Daily ATR period for slope normalization

//--- Regime: Macro / oil-shock flag ------------------------------
input string  __MACRO__            = "===== MACRO REGIME FLAG =====";
input bool    InpInflationRegime   = false;   // TRUE = oil-shock/inflation ON -> disable short-gold reflex
input bool    InpMacroAppliesMetalsOnly = true; // Macro flag gates XAU/XAG (and oil) only, not all FX

//--- Fade staleness timer ----------------------------------------
input string  __STALE__            = "===== FADE STALENESS =====";
input double  InpStaleHours        = 24.0;    // Hrs after which an open fade trade is 'stale'
input double  InpWarnHours         = 12.0;    // Hrs after which to pre-warn (amber)
input int     InpMagicFilter       = 0;       // 0 = all magics; else only this magic
input bool    InpThisSymbolOnly    = false;   // TRUE = count stale trades for chart symbol only

//--- Stack-depth gate (averaging-down guard) ---------------------
input string  __STACK__            = "===== STACK DEPTH (avg-down guard) =====";
input bool    InpShowStackGate     = true;    // Show same-symbol same-direction stack depth
input int     InpStackWarnAt       = 2;       // Amber at this depth on chart symbol+dir
input int     InpStackOffAt        = 4;       // Red at this depth (the -764 leak lived >=4)
input bool    InpStackChartDirOnly = false;   // TRUE=only score direction implied by daily trend

//--- TDI / momentum read (optional confirmation) -----------------
input string  __TDI__              = "===== TDI READ (optional) =====";
input bool    InpShowTdi           = true;    // Show RSI(price) momentum read
input int     InpTdiRsiPeriod      = 13;      // RSI period (TDI base)
input ENUM_TIMEFRAMES InpTdiTf     = PERIOD_H1; // Timeframe for the TDI read

//--- NY session window (for context, exchange/server time) -------
input string  __SESSION__          = "===== NY SESSION (server time) =====";
input int     InpNyOpenHour        = 13;      // NY open (server hour) - context only
input int     InpNyCloseHour       = 22;      // NY close (server hour) - context only

//--- Panel cosmetics ---------------------------------------------
input string  __PANEL__            = "===== PANEL =====";
input int     InpCorner            = 0;       // 0=TL 1=TR 2=BL 3=BR
input int     InpX                 = 12;      // X offset
input int     InpY                 = 20;      // Y offset
input int     InpFontSize          = 9;       // Font size
input string  InpFont              = "Consolas";
input color   InpColHead           = clrGainsboro;
input color   InpColOn             = C'40,180,110';   // green-ish
input color   InpColCaution        = C'230,180,60';   // amber
input color   InpColOff            = C'220,70,70';     // red
input color   InpColText           = clrSilver;
input color   InpColDim            = clrGray;

//==================================================================
// GLOBALS
//==================================================================
string  gPrefix = "LPHFRG_";
int     gLines  = 0;

//==================================================================
int OnInit()
{
   ObjectsDeleteAll(0, gPrefix);
   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason)
{
   ObjectsDeleteAll(0, gPrefix);
}

//==================================================================
// Buffer-less panel indicator: MT5 OnCalculate variant with price[]
//==================================================================
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const int begin,
                const double &price[])
{
   RenderPanel();
   return(rates_total);
}

//==================================================================
// Symbol classification (fade-relevant families)
//==================================================================
bool SymIsMetal(string s)
{
   string u = SymUpper(s);
   return (StringFind(u,"XAU")>=0 || StringFind(u,"XAG")>=0 ||
           StringFind(u,"GOLD")>=0 || StringFind(u,"SILVER")>=0);
}
bool SymIsOil(string s)
{
   string u = SymUpper(s);
   return (StringFind(u,"WTI")>=0 || StringFind(u,"OIL")>=0 ||
           StringFind(u,"BRENT")>=0 || StringFind(u,"USOIL")>=0 ||
           StringFind(u,"UKOIL")>=0);
}
string SymUpper(string s)
{
   string r=s; StringToUpper(r); return r;
}

//==================================================================
// Daily trend regime for chart symbol
//  returns: +1 rising uptrend, -1 falling downtrend, 0 range/neutral
//  MT5: iMA()/iATR() return indicator handles -> CopyBuffer()
//==================================================================
int DailyTrendState(double &emaNow, double &slopeAtr)
{
   emaNow = 0; slopeAtr = 0;
   int hEma = iMA(Symbol(), PERIOD_D1, InpDailyEmaPeriod, 0, MODE_EMA, PRICE_CLOSE);
   int hAtr = iATR(Symbol(), PERIOD_D1, InpAtrPeriodD1);
   if(hEma==INVALID_HANDLE || hAtr==INVALID_HANDLE) return 0;

   double buf[1];
   if(CopyBuffer(hEma, 0, 0, 1, buf) < 1)  return 0;
   emaNow = buf[0];
   if(CopyBuffer(hEma, 0, InpSlopeLookback, 1, buf) < 1) return 0;
   double emaBack = buf[0];
   if(CopyBuffer(hAtr, 0, 1, 1, buf) < 1) return 0;
   double atrD = buf[0];
   if(atrD <= 0) { slopeAtr = 0; return 0; }

   double slopePerBar = (emaNow - emaBack) / MathMax(InpSlopeLookback,1);
   slopeAtr = slopePerBar / atrD;   // slope in ATRs per bar

   double px = iClose(Symbol(), PERIOD_D1, 0);
   bool priceAbove = (px > emaNow);

   if(slopeAtr >= InpSlopeAtrFrac && priceAbove)  return +1;  // rising uptrend
   if(slopeAtr <= -InpSlopeAtrFrac && !priceAbove) return -1; // falling downtrend
   return 0; // range / mixed
}

//==================================================================
// TDI-lite read: RSI direction on chosen TF
//==================================================================
string TdiRead(double &rsiVal)
{
   rsiVal = 0;
   int hRsi = iRSI(Symbol(), InpTdiTf, InpTdiRsiPeriod, PRICE_CLOSE);
   if(hRsi==INVALID_HANDLE) return "n/a";

   double buf[2];
   if(CopyBuffer(hRsi, 0, 0, 2, buf) < 2) return "n/a";
   rsiVal   = buf[0];   // current bar
   double rsiPrev = buf[1]; // previous bar

   string dir = (rsiVal >= rsiPrev) ? "up" : "down";
   string zone;
   if(rsiVal >= 60)      zone = "strong-up";
   else if(rsiVal >= 50) zone = "up-bias";
   else if(rsiVal > 40)  zone = "down-bias";
   else                  zone = "strong-down";
   return zone + " (" + dir + ")";
}

//==================================================================
// Stale-trade scan across open positions
//==================================================================
void StaleScan(int &nOpen, int &nWarn, int &nStale, double &floating,
               string &worstSym, double &worstHrs)
{
   nOpen=0; nWarn=0; nStale=0; floating=0; worstSym=""; worstHrs=0;
   int total = PositionsTotal();
   for(int i=0; i<total; i++)
   {
      if(PositionGetTicket(i)==0) continue;
      long type = PositionGetInteger(POSITION_TYPE);
      if(type!=POSITION_TYPE_BUY && type!=POSITION_TYPE_SELL) continue;
      if(InpMagicFilter!=0 && (long)PositionGetInteger(POSITION_MAGIC)!=InpMagicFilter) continue;
      if(InpThisSymbolOnly && PositionGetString(POSITION_SYMBOL)!=Symbol()) continue;

      nOpen++;
      floating += PositionGetDouble(POSITION_PROFIT) + PositionGetDouble(POSITION_SWAP) + PositionGetDouble(POSITION_COMMISSION);

      double hrs = (double)(TimeCurrent() - (datetime)PositionGetInteger(POSITION_TIME)) / 3600.0;
      if(hrs >= InpStaleHours) nStale++;
      else if(hrs >= InpWarnHours) nWarn++;

      if(hrs > worstHrs) { worstHrs = hrs; worstSym = PositionGetString(POSITION_SYMBOL); }
   }
}

//==================================================================
// Stack-depth scan for the CHART symbol
//  Counts how many same-symbol positions are already open in each
//  direction. The averaging-down mechanic (depth >=4) was the
//  -764 realized leak on 500237. This gate does not stop an entry
//  (display-only) - it turns red BEFORE you add the layer.
//==================================================================
void StackScan(int &buyDepth, int &sellDepth, double &buyLots, double &sellLots)
{
   buyDepth=0; sellDepth=0; buyLots=0; sellLots=0;
   int total = PositionsTotal();
   for(int i=0; i<total; i++)
   {
      if(PositionGetTicket(i)==0) continue;
      if(PositionGetString(POSITION_SYMBOL)!=Symbol()) continue;
      if(InpMagicFilter!=0 && (long)PositionGetInteger(POSITION_MAGIC)!=InpMagicFilter) continue;
      long type = PositionGetInteger(POSITION_TYPE);
      if(type==POSITION_TYPE_BUY)  { buyDepth++;  buyLots  += PositionGetDouble(POSITION_VOLUME); }
      if(type==POSITION_TYPE_SELL) { sellDepth++; sellLots += PositionGetDouble(POSITION_VOLUME); }
   }
}

//==================================================================
// Fade verdict for the chart symbol
//==================================================================
string FadeVerdict(int trendState, color &outCol, string &reason)
{
   bool isMetal = SymIsMetal(Symbol());
   bool isOil   = SymIsOil(Symbol());
   bool macroGates = (!InpMacroAppliesMetalsOnly) || isMetal || isOil;

   // Macro flag first - overriding kill for the short-fade reflex
   if(InpInflationRegime && macroGates)
   {
      outCol = InpColOff;
      reason = "Inflation/oil-shock regime ON -> short-gold reflex disabled";
      return "FADE-SHORT: OFF";
   }

   // Trend gate
   if(trendState == +1)
   {
      outCol = InpColOff;
      reason = "Daily rising uptrend -> do NOT short into it (June 11 setup)";
      return "FADE-SHORT: OFF";
   }
   if(trendState == -1)
   {
      outCol = InpColOn;
      reason = "Daily downtrend -> fade-short aligned with regime";
      return "FADE-SHORT: ON";
   }

   outCol = InpColCaution;
   reason = "Daily range/mixed -> fade OK but no trend tailwind; keep intraday";
   return "FADE-SHORT: CAUTION";
}

//==================================================================
// PANEL RENDER
//==================================================================
void RenderPanel()
{
   gLines = 0;

   double emaNow=0, slopeAtr=0;
   int trend = DailyTrendState(emaNow, slopeAtr);
   string trendTxt = (trend==+1?"RISING UPTREND":(trend==-1?"DOWNTREND":"RANGE/MIXED"));
   color trendCol  = (trend==+1?InpColOff:(trend==-1?InpColOn:InpColCaution));

   color verdCol; string verdReason;
   string verdict = FadeVerdict(trend, verdCol, verdReason);

   int nOpen,nWarn,nStale; double floating; string worstSym; double worstHrs;
   StaleScan(nOpen,nWarn,nStale,floating,worstSym,worstHrs);

   double rsiVal=0; string tdi = InpShowTdi ? TdiRead(rsiVal) : "";

   bool nyOpen = SessionIsNy();

   // ---- draw ----
   Row("LPH FADE REGIME GATE", InpColHead, true);
   Row(Symbol()+"  |  NY session: "+(nyOpen?"OPEN":"closed"), InpColDim, false);
   Sep();

   Row(verdict, verdCol, true);
   Row(" "+verdReason, InpColText, false);
   Sep();

   Row("Daily 50 EMA regime: "+trendTxt, trendCol, false);
   Row(StringFormat(" slope %.2f ATR/bar  (thr %.2f)", slopeAtr, InpSlopeAtrFrac), InpColDim, false);

   string macroTxt = InpInflationRegime ? "INFLATION/OIL-SHOCK: ON" : "inflation/oil-shock: off";
   Row(macroTxt, InpInflationRegime?InpColOff:InpColDim, false);
   if(InpMacroAppliesMetalsOnly)
      Row(" (gates metals/oil only)", InpColDim, false);

   if(InpShowTdi)
      Row(StringFormat("TDI %s RSI %.1f  [%s]", EnumToString(InpTdiTf), rsiVal, tdi), InpColText, false);
   Sep();

   // stale block
   color staleCol = (nStale>0?InpColOff:(nWarn>0?InpColCaution:InpColOn));
   Row(StringFormat("Open %d  |  warn(>%.0fh) %d  |  STALE(>%.0fh) %d",
                    nOpen, InpWarnHours, nWarn, InpStaleHours, nStale), staleCol, false);
   Row(StringFormat("Floating: %.2f", floating), (floating<0?InpColOff:InpColOn), false);
   if(worstHrs>0)
      Row(StringFormat("Oldest: %s  %.1fh", worstSym, worstHrs),
          (worstHrs>=InpStaleHours?InpColOff:InpColDim), false);

   if(nStale>0)
   {
      Sep();
      Row(">> "+IntegerToString(nStale)+" stale fade(s): thesis falsified.", InpColOff, true);
      Row(">> NY did not fade. Close or re-justify.", InpColOff, false);
   }

   // stack-depth gate (this chart symbol)
   if(InpShowStackGate)
   {
      Sep();
      int bDepth,sDepth; double bLots,sLots;
      StackScan(bDepth,sDepth,bLots,sLots);

      // Determine which direction(s) to surface. Default: both.
      // If InpStackChartDirOnly, only show the direction the daily trend
      // implies you'd fade (down-regime -> shorts; up-regime -> longs).
      bool showBuy=true, showSell=true;
      if(InpStackChartDirOnly)
      {
         if(trend==+1) showSell=false;   // uptrend: you shouldn't be short-stacking
         if(trend==-1) showBuy=false;
      }

      Row("Stack depth ("+Symbol()+"):", InpColHead, false);
      if(showBuy)
         Row(StringFormat("  BUY  x%d  (%.2f lots)  %s",
             bDepth, bLots, StackTag(bDepth)), StackCol(bDepth), false);
      if(showSell)
         Row(StringFormat("  SELL x%d  (%.2f lots)  %s",
             sDepth, sLots, StackTag(sDepth)), StackCol(sDepth), false);

      // Hedge-lock callout: both directions open = the un-high-risk move
      if(bDepth>0 && sDepth>0)
         Row(">> HEDGE-LOCKED both ways: decide, don't lock.", InpColCaution, true);

      int maxDepth = MathMax(bDepth,sDepth);
      if(maxDepth>=InpStackOffAt)
         Row(">> AVG-DOWN ZONE: do not add. This is the -764 leak.", InpColOff, true);
   }
}

//==================================================================
// Stack colour / tag helpers
//==================================================================
color StackCol(int depth)
{
   if(depth>=InpStackOffAt)  return InpColOff;
   if(depth>=InpStackWarnAt) return InpColCaution;
   return InpColOn;
}
string StackTag(int depth)
{
   if(depth>=InpStackOffAt)  return "STOP ADDING";
   if(depth>=InpStackWarnAt) return "caution";
   return "ok";
}

//==================================================================
bool SessionIsNy()
{
   datetime t = TimeCurrent();
   MqlDateTime dt;
   TimeToStruct(t, dt);
   int h = dt.hour;
   if(InpNyOpenHour <= InpNyCloseHour)
      return (h >= InpNyOpenHour && h < InpNyCloseHour);
   // wrap over midnight
   return (h >= InpNyOpenHour || h < InpNyCloseHour);
}

//==================================================================
// Row/Sep helpers - label objects stacked vertically
//==================================================================
void Row(string txt, color col, bool bold)
{
   string name = gPrefix + "L" + IntegerToString(gLines);
   int yStep = InpFontSize + 6;
   int yy = InpY + gLines * yStep;

   if(ObjectFind(0, name) < 0)
      ObjectCreate(0, name, OBJ_LABEL, 0, 0, 0);
   ObjectSetInteger(0, name, OBJPROP_CORNER, InpCorner);
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE, InpX);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE, yy);
   ObjectSetInteger(0, name, OBJPROP_COLOR, col);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, InpFontSize);
   ObjectSetString (0, name, OBJPROP_FONT, bold ? InpFont+" Bold" : InpFont);
   ObjectSetString (0, name, OBJPROP_TEXT, txt);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_BACK, false);
   gLines++;
}
void Sep()
{
   Row("--------------------------------", InpColDim, false);
}
//+------------------------------------------------------------------+
