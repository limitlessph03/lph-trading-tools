//+------------------------------------------------------------------+
//|                    LPH_Weekend_Open_Pending.mq5                   |
//|   Places one WTI Buy Stop and one Gold Sell Stop after each      |
//|   symbol has been tradable for the configured delay.             |
//|   Attach to ONE MT5 chart only. Keep MT5/VPS running/connected.  |
//|   Converted from MQL4 by AI bot                                  |
//+------------------------------------------------------------------+
#property strict
#property version   "1.00"
#property description "Places configurable WTI Buy Stop and Gold Sell Stop after market open."

#include <Trade\Trade.mqh>

//---------------------------- General --------------------------------
input int      DelayMinutesAfterOpen = 30;
input int      TimerIntervalSeconds  = 5;
input int      SlippagePoints        = 30;
input int      PendingExpiryMinutes  = 0;      // 0 = Good Till Cancelled
input bool     RunEveryWeek          = true;
input bool     DeleteOldEAOrdersBeforeNewWeek = false;
input int      MagicNumber           = 7260712;
input string   OrderCommentPrefix    = "LPH Weekend Open";

//---------------------------- WTI ------------------------------------
input bool     EnableWTI             = true;
input string   WTISymbol             = "USWTIzero";
input double   WTILots               = 0.10;
input bool     WTIUseFixedEntry       = false;
input double   WTIFixedBuyStopPrice   = 0.0;
input double   WTIBuyStopOffsetPrice  = 0.50;   // e.g. $0.50 above Ask
input double   WTIStopLossPrice       = 0.0;    // 0 = no SL
input double   WTITakeProfitPrice     = 0.0;    // 0 = no TP

//---------------------------- GOLD -----------------------------------
input bool     EnableGold             = true;
input string   GoldSymbol             = "XAUUSD";
input double   GoldLots               = 0.10;
input bool     GoldUseFixedEntry       = false;
input double   GoldFixedSellStopPrice  = 0.0;
input double   GoldSellStopOffsetPrice = 5.00;  // e.g. $5 below Bid
input double   GoldStopLossPrice       = 0.0;    // 0 = no SL
input double   GoldTakeProfitPrice     = 0.0;    // 0 = no TP

CTrade trade;

datetime g_wtiOpenTime  = 0;
datetime g_goldOpenTime = 0;
int      g_weekKey      = -1;

//+------------------------------------------------------------------+
int OnInit()
{
   if(DelayMinutesAfterOpen < 0 || TimerIntervalSeconds < 1)
   {
      Print("Invalid delay/timer input.");
      return(INIT_PARAMETERS_INCORRECT);
   }

   trade.SetExpertMagicNumber(MagicNumber);
   trade.SetDeviationInPoints(SlippagePoints);

   SymbolSelect(WTISymbol, true);
   SymbolSelect(GoldSymbol, true);

   EventSetTimer(TimerIntervalSeconds);
   g_weekKey = CurrentWeekKey(TimeCurrent());
   LoadState();

   Print("LPH Weekend Open Pending initialized. WeekKey=", g_weekKey);
   return(INIT_SUCCEEDED);
}
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   EventKillTimer();
}
//+------------------------------------------------------------------+
void OnTick()
{
   Process();
}
//+------------------------------------------------------------------+
void OnTimer()
{
   Process();
}
//+------------------------------------------------------------------+
void Process()
{
   datetime now = TimeCurrent();
   if(now <= 0) return;

   int wk = CurrentWeekKey(now);
   if(wk != g_weekKey)
   {
      g_weekKey = wk;
      g_wtiOpenTime = 0;
      g_goldOpenTime = 0;

      if(DeleteOldEAOrdersBeforeNewWeek)
         DeleteExistingPendingOrders();

      SaveState();
      Print("New trading week detected. State reset. WeekKey=", g_weekKey);
   }

   if(EnableWTI)
      ProcessWTI(now);

   if(EnableGold)
      ProcessGold(now);
}
//+------------------------------------------------------------------+
void ProcessWTI(datetime now)
{
   if(!IsSymbolTradable(WTISymbol))
      return;

   if(g_wtiOpenTime == 0)
   {
      g_wtiOpenTime = now;
      SaveState();
      Print(WTISymbol, " first tradable time detected: ",
            TimeToString(g_wtiOpenTime, TIME_DATE|TIME_SECONDS));
   }

   if(now < g_wtiOpenTime + DelayMinutesAfterOpen * 60)
      return;

   if(HasManagedOrder(WTISymbol, ORDER_TYPE_BUY_STOP))
      return;

   if(!RunEveryWeek && HasAnyHistoricalManagedOrder(WTISymbol, ORDER_TYPE_BUY_STOP))
      return;

   PlaceWTIBuyStop();
}
//+------------------------------------------------------------------+
void ProcessGold(datetime now)
{
   if(!IsSymbolTradable(GoldSymbol))
      return;

   if(g_goldOpenTime == 0)
   {
      g_goldOpenTime = now;
      SaveState();
      Print(GoldSymbol, " first tradable time detected: ",
            TimeToString(g_goldOpenTime, TIME_DATE|TIME_SECONDS));
   }

   if(now < g_goldOpenTime + DelayMinutesAfterOpen * 60)
      return;

   if(HasManagedOrder(GoldSymbol, ORDER_TYPE_SELL_STOP))
      return;

   if(!RunEveryWeek && HasAnyHistoricalManagedOrder(GoldSymbol, ORDER_TYPE_SELL_STOP))
      return;

   PlaceGoldSellStop();
}
//+------------------------------------------------------------------+
bool IsSymbolTradable(string symbol)
{
   if(!SymbolSelect(symbol, true))
      return(false);

   double bid = SymbolInfoDouble(symbol, SYMBOL_BID);
   double ask = SymbolInfoDouble(symbol, SYMBOL_ASK);
   long tradeMode = SymbolInfoInteger(symbol, SYMBOL_TRADE_MODE);

   if(tradeMode == SYMBOL_TRADE_MODE_DISABLED || bid <= 0 || ask <= 0 || ask <= bid)
      return(false);

   return(true);
}
//+------------------------------------------------------------------+
void PlaceWTIBuyStop()
{
   double ask       = SymbolInfoDouble(WTISymbol, SYMBOL_ASK);
   double point     = SymbolInfoDouble(WTISymbol, SYMBOL_POINT);
   int    digits    = (int)SymbolInfoInteger(WTISymbol, SYMBOL_DIGITS);
   int    stopLevel = (int)SymbolInfoInteger(WTISymbol, SYMBOL_TRADE_STOPS_LEVEL);

   double minEntry = ask + stopLevel * point;
   double entry = WTIUseFixedEntry ? WTIFixedBuyStopPrice
                                   : ask + WTIBuyOffsetSafe();

   if(entry <= minEntry)
   {
      Print("WTI Buy Stop not placed: entry ", DoubleToString(entry, digits),
            " must be above minimum ", DoubleToString(minEntry, digits),
            ". Increase the entry/offset.");
      return;
   }

   entry = NormalizeDouble(entry, digits);
   double sl = NormalizeOptionalPrice(WTIStopLossPrice, digits);
   double tp = NormalizeOptionalPrice(WTITakeProfitPrice, digits);

   if(sl > 0 && sl >= entry)
   {
      Print("WTI Buy Stop not placed: SL must be below entry.");
      return;
   }
   if(tp > 0 && tp <= entry)
   {
      Print("WTI Buy Stop not placed: TP must be above entry.");
      return;
   }

   double lots = NormalizeLots(WTISymbol, WTILots);
   datetime expiry = PendingExpiry();
   ENUM_ORDER_TYPE_TIME typeTime = (PendingExpiryMinutes <= 0) ? ORDER_TIME_GTC : ORDER_TIME_SPECIFIED;

   bool ok = trade.BuyStop(lots, entry, WTISymbol, sl, tp, typeTime, expiry, OrderCommentPrefix + " WTI");

   if(!ok)
      Print("WTI Buy Stop OrderSend failed. Error=", GetLastError(),
            " Entry=", DoubleToString(entry, digits));
   else
      Print("WTI Buy Stop placed. Entry=", DoubleToString(entry, digits),
            " Lots=", DoubleToString(lots, 2));
}
//+------------------------------------------------------------------+
void PlaceGoldSellStop()
{
   double bid       = SymbolInfoDouble(GoldSymbol, SYMBOL_BID);
   double point     = SymbolInfoDouble(GoldSymbol, SYMBOL_POINT);
   int    digits    = (int)SymbolInfoInteger(GoldSymbol, SYMBOL_DIGITS);
   int    stopLevel = (int)SymbolInfoInteger(GoldSymbol, SYMBOL_TRADE_STOPS_LEVEL);

   double maxEntry = bid - stopLevel * point;
   double entry = GoldUseFixedEntry ? GoldFixedSellStopPrice
                                    : bid - GoldSellStopOffsetPrice;

   if(entry >= maxEntry)
   {
      Print("Gold Sell Stop not placed: entry ", DoubleToString(entry, digits),
            " must be below maximum ", DoubleToString(maxEntry, digits),
            ". Increase the entry/offset.");
      return;
   }

   entry = NormalizeDouble(entry, digits);
   double sl = NormalizeOptionalPrice(GoldStopLossPrice, digits);
   double tp = NormalizeOptionalPrice(GoldTakeProfitPrice, digits);

   if(sl > 0 && sl <= entry)
   {
      Print("Gold Sell Stop not placed: SL must be above entry.");
      return;
   }
   if(tp > 0 && tp >= entry)
   {
      Print("Gold Sell Stop not placed: TP must be below entry.");
      return;
   }

   double lots = NormalizeLots(GoldSymbol, GoldLots);
   datetime expiry = PendingExpiry();
   ENUM_ORDER_TYPE_TIME typeTime = (PendingExpiryMinutes <= 0) ? ORDER_TIME_GTC : ORDER_TIME_SPECIFIED;

   bool ok = trade.SellStop(lots, entry, GoldSymbol, sl, tp, typeTime, expiry, OrderCommentPrefix + " GOLD");

   if(!ok)
      Print("Gold Sell Stop OrderSend failed. Error=", GetLastError(),
            " Entry=", DoubleToString(entry, digits));
   else
      Print("Gold Sell Stop placed. Entry=", DoubleToString(entry, digits),
            " Lots=", DoubleToString(lots, 2));
}
//+------------------------------------------------------------------+
// Helper prevents accidental negative offset.
double WTIBuyOffsetSafe()
{
   if(WTIBuyStopOffsetPrice < 0) return(0);
   return(WTIBuyStopOffsetPrice);
}
//+------------------------------------------------------------------+
void RefreshRatesFor(string symbol)
{
   SymbolSelect(symbol, true);
   // RefreshRates() is MQL4-only and removed in MQL5
}
//+------------------------------------------------------------------+
double NormalizeOptionalPrice(double price, int digits)
{
   if(price <= 0) return(0.0);
   return(NormalizeDouble(price, digits));
}
//+------------------------------------------------------------------+
double NormalizeLots(string symbol, double requestedLots)
{
   double minLot  = SymbolInfoDouble(symbol, SYMBOL_VOLUME_MIN);
   double maxLot  = SymbolInfoDouble(symbol, SYMBOL_VOLUME_MAX);
   double lotStep = SymbolInfoDouble(symbol, SYMBOL_VOLUME_STEP);

   if(lotStep <= 0) lotStep = 0.01;

   double lots = MathMax(minLot, MathMin(maxLot, requestedLots));
   lots = MathFloor(lots / lotStep + 0.0000001) * lotStep;

   int lotDigits = 2;
   if(lotStep >= 1.0) lotDigits = 0;
   else if(lotStep >= 0.1) lotDigits = 1;
   else if(lotStep >= 0.01) lotDigits = 2;
   else lotDigits = 3;

   return(NormalizeDouble(lots, lotDigits));
}
//+------------------------------------------------------------------+
datetime PendingExpiry()
{
   if(PendingExpiryMinutes <= 0) return(0);
   return(TimeCurrent() + PendingExpiryMinutes * 60);
}
//+------------------------------------------------------------------+
bool HasManagedOrder(string symbol, ENUM_ORDER_TYPE orderType)
{
   for(int i = OrdersTotal()-1; i >= 0; i--)
   {
      if(OrderGetTicket(i) == 0)
         continue;

      if((long)OrderGetInteger(ORDER_MAGIC) == MagicNumber &&
         OrderGetString(ORDER_SYMBOL) == symbol &&
         (ENUM_ORDER_TYPE)OrderGetInteger(ORDER_TYPE) == orderType)
         return(true);
   }
   return(false);
}
//+------------------------------------------------------------------+
bool HasAnyHistoricalManagedOrder(string symbol, ENUM_ORDER_TYPE orderType)
{
   if(!HistorySelect(0, TimeCurrent()))
      return(false);

   for(int i = HistoryOrdersTotal()-1; i >= 0; i--)
   {
      ulong ticket = HistoryOrderGetTicket(i);
      if(ticket == 0)
         continue;

      if((long)HistoryOrderGetInteger(ticket, ORDER_MAGIC) == MagicNumber &&
         HistoryOrderGetString(ticket, ORDER_SYMBOL) == symbol &&
         (ENUM_ORDER_TYPE)HistoryOrderGetInteger(ticket, ORDER_TYPE) == orderType)
         return(true);
   }
   return(false);
}
//+------------------------------------------------------------------+
void DeleteExistingPendingOrders()
{
   for(int i = OrdersTotal()-1; i >= 0; i--)
   {
      if(OrderGetTicket(i) == 0)
         continue;

      long type = OrderGetInteger(ORDER_TYPE);
      if((long)OrderGetInteger(ORDER_MAGIC) != MagicNumber)
         continue;

      if(type != ORDER_TYPE_BUY_LIMIT && type != ORDER_TYPE_SELL_LIMIT &&
         type != ORDER_TYPE_BUY_STOP  && type != ORDER_TYPE_SELL_STOP)
         continue;

      ulong ticket = (ulong)OrderGetInteger(ORDER_TICKET);
      if(!trade.OrderDelete(ticket))
         Print("Could not delete old pending ticket ", ticket,
               ". Error=", GetLastError());
   }
}
//+------------------------------------------------------------------+
int CurrentWeekKey(datetime t)
{
   MqlDateTime dt;
   TimeToStruct(t, dt);

   // Monday-based week anchor.
   int daysSinceMonday = (dt.day_of_week + 6) % 7;
   datetime midnight = t - (dt.hour*3600 + dt.min*60 + dt.sec);
   datetime monday = midnight - daysSinceMonday*86400;

   MqlDateTime md;
   TimeToStruct(monday, md);
   return(md.year*10000 + md.mon*100 + md.day);
}
//+------------------------------------------------------------------+
string StatePrefix()
{
   return("LPH_WOPEN_" + IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN)) + "_" +
          IntegerToString(MagicNumber) + "_");
}
//+------------------------------------------------------------------+
void SaveState()
{
   string p = StatePrefix();
   GlobalVariableSet(p+"WEEK", g_weekKey);
   GlobalVariableSet(p+"WTI_OPEN", g_wtiOpenTime);
   GlobalVariableSet(p+"GOLD_OPEN", g_goldOpenTime);
}
//+------------------------------------------------------------------+
void LoadState()
{
   string p = StatePrefix();

   if(GlobalVariableCheck(p+"WEEK"))
   {
      int savedWeek = (int)GlobalVariableGet(p+"WEEK");
      if(savedWeek == g_weekKey)
      {
         if(GlobalVariableCheck(p+"WTI_OPEN"))
            g_wtiOpenTime = (datetime)GlobalVariableGet(p+"WTI_OPEN");
         if(GlobalVariableCheck(p+"GOLD_OPEN"))
            g_goldOpenTime = (datetime)GlobalVariableGet(p+"GOLD_OPEN");
      }
   }
}
//+------------------------------------------------------------------+
