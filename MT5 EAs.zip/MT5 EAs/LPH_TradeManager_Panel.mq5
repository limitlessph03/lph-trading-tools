//+------------------------------------------------------------------+
//|                                      LPH_TradeManagerPanel.mq5   |
//|            LimitlessPH - MT5 convenience panel (MT4 parity)      |
//|  Manages EXISTING positions only. Does not open trades.          |
//|  Converted from MQL4 by AI bot                                   |
//+------------------------------------------------------------------+
#property copyright "LimitlessPH"
#property version   "1.10"
#property strict

#include <Trade\Trade.mqh>

//--- Trade permission (kept for audit parity; panel cannot open trades)
input bool   InpAllowTrading      = true;   // Master switch for modify/close actions
input bool   InpCurrentSymbolOnly = true;   // Restrict actions to chart symbol
input int    InpMagicFilter       = -1;     // -1 = all magics, else only this magic
input int    InpSlippagePoints    = 30;     // Slippage for close ops (points)
input double InpMaxSpreadPoints   = 50;     // Reject close/modify if spread wider (0=off)
input int    InpDefaultSLPips     = 200;    // Default SL pips in input box
input int    InpDefaultTPPips     = 400;    // Default TP pips in input box
input double InpPartialPercent    = 50.0;   // Default partial close percent
input double InpBEOffsetPips      = 0.0;    // BE offset: + = lock profit, - = tighter SL
input bool   InpBECoverCosts      = true;   // Auto-add spread+commission to BE offset
input int    InpPanelX            = 10;     // Panel X offset
input int    InpPanelY            = 20;     // Panel Y offset
input color  InpPanelBg           = C'25,25,25';
input color  InpTextColor         = clrWhite;

#define PFX "LPHTMP_"

//--- runtime state
double g_pip       = 0.0;   // pip size in price terms
int    g_pipDigits = 0;

CTrade trade;

// 0 = use InpCurrentSymbolOnly, 1 = force current symbol, 2 = force all symbols
int g_scopeOverride = 0;

//+------------------------------------------------------------------+
//| Symbol info helpers (MQL5 replacements for MarketInfo)           |
//+------------------------------------------------------------------+
double SymBid(string sym)        { return(SymbolInfoDouble(sym, SYMBOL_BID)); }
double SymAsk(string sym)        { return(SymbolInfoDouble(sym, SYMBOL_ASK)); }
double SymPoint(string sym)      { return(SymbolInfoDouble(sym, SYMBOL_POINT)); }
double SymStopLevel(string sym)  { return((double)SymbolInfoInteger(sym, SYMBOL_TRADE_STOPS_LEVEL)); }
double SymTickValue(string sym)  { return(SymbolInfoDouble(sym, SYMBOL_TRADE_TICK_VALUE)); }
double SymTickSize(string sym)   { return(SymbolInfoDouble(sym, SYMBOL_TRADE_TICK_SIZE)); }
double SymLotStep(string sym)    { return(SymbolInfoDouble(sym, SYMBOL_VOLUME_STEP)); }
double SymMinLot(string sym)     { return(SymbolInfoDouble(sym, SYMBOL_VOLUME_MIN)); }
int    SymDigits(string sym)     { return((int)SymbolInfoInteger(sym, SYMBOL_DIGITS)); }
double SymPipFor(string sym)
{
   int dg = SymDigits(sym);
   double pt = SymPoint(sym);
   return((dg == 3 || dg == 5) ? pt * 10.0 : pt);
}

//+------------------------------------------------------------------+
//| Resolve pip size (handles 3/5-digit brokers and metals)          |
//+------------------------------------------------------------------+
void ResolvePipSize()
{
   int    dg  = SymDigits(_Symbol);
   double pt  = SymPoint(_Symbol);

   if(pt <= 0.0) pt = SymbolInfoDouble(_Symbol, SYMBOL_POINT);
   if(dg <= 0)   dg = (int)SymbolInfoInteger(_Symbol, SYMBOL_DIGITS);

   // 3 and 5 digit quotes: 1 pip = 10 points. Otherwise 1 pip = 1 point.
   if(dg == 3 || dg == 5) g_pip = pt * 10.0;
   else                   g_pip = pt;

   g_pipDigits = dg;
}

//+------------------------------------------------------------------+
//| Spread guard                                                     |
//+------------------------------------------------------------------+
bool SpreadOK(string sym)
{
   if(InpMaxSpreadPoints <= 0.0) return(true);
   double pt = SymPoint(sym);
   if(pt <= 0.0) return(true);
   double spr = (SymAsk(sym) - SymBid(sym)) / pt;
   if(spr > InpMaxSpreadPoints)
   {
      Print("[LPH Panel] Blocked: spread ", DoubleToString(spr,1),
            " pts > max ", DoubleToString(InpMaxSpreadPoints,1), " on ", sym);
      return(false);
   }
   return(true);
}

//+------------------------------------------------------------------+
//| Position passes filters?                                         |
//+------------------------------------------------------------------+
bool ScopeCurrentSymbol()
{
   if(g_scopeOverride == 1) return(true);
   if(g_scopeOverride == 2) return(false);
   return(InpCurrentSymbolOnly);
}

bool PositionInScope()
{
   if(ScopeCurrentSymbol() && PositionGetString(POSITION_SYMBOL) != _Symbol) return(false);
   if(InpMagicFilter >= 0 && (int)PositionGetInteger(POSITION_MAGIC) != InpMagicFilter) return(false);
   return(true);
}

//+------------------------------------------------------------------+
//| Pending order passes filters?                                    |
//+------------------------------------------------------------------+
bool OrderInScope()
{
   if(ScopeCurrentSymbol() && OrderGetString(ORDER_SYMBOL) != _Symbol) return(false);
   if(InpMagicFilter >= 0 && (int)OrderGetInteger(ORDER_MAGIC) != InpMagicFilter) return(false);
   return(true);
}

//+------------------------------------------------------------------+
//| UI helpers                                                       |
//+------------------------------------------------------------------+
void MakeLabel(string name, string text, int x, int y, color clr, int size=8)
{
   string n = PFX + name;
   if(ObjectFind(0, n) < 0) ObjectCreate(0, n, OBJ_LABEL, 0, 0, 0);
   ObjectSetInteger(0, n, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, n, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, n, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, n, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, n, OBJPROP_FONTSIZE, size);
   ObjectSetInteger(0, n, OBJPROP_SELECTABLE, false);
   ObjectSetString (0, n, OBJPROP_TEXT, text);
   ObjectSetString (0, n, OBJPROP_FONT, "Tahoma");
}

void MakeButton(string name, string text, int x, int y, int w, int h, color bg)
{
   string n = PFX + name;
   if(ObjectFind(0, n) < 0) ObjectCreate(0, n, OBJ_BUTTON, 0, 0, 0);
   ObjectSetInteger(0, n, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, n, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, n, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, n, OBJPROP_XSIZE, w);
   ObjectSetInteger(0, n, OBJPROP_YSIZE, h);
   ObjectSetInteger(0, n, OBJPROP_BGCOLOR, bg);
   ObjectSetInteger(0, n, OBJPROP_COLOR, clrWhite);
   ObjectSetInteger(0, n, OBJPROP_FONTSIZE, 8);
   ObjectSetInteger(0, n, OBJPROP_BORDER_COLOR, clrDimGray);
   ObjectSetInteger(0, n, OBJPROP_STATE, false);
   ObjectSetString (0, n, OBJPROP_TEXT, text);
   ObjectSetString (0, n, OBJPROP_FONT, "Tahoma");
}

void MakeEdit(string name, string text, int x, int y, int w, int h)
{
   string n = PFX + name;
   if(ObjectFind(0, n) < 0) ObjectCreate(0, n, OBJ_EDIT, 0, 0, 0);
   ObjectSetInteger(0, n, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, n, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, n, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, n, OBJPROP_XSIZE, w);
   ObjectSetInteger(0, n, OBJPROP_YSIZE, h);
   ObjectSetInteger(0, n, OBJPROP_BGCOLOR, clrBlack);
   ObjectSetInteger(0, n, OBJPROP_COLOR, clrWhite);
   ObjectSetInteger(0, n, OBJPROP_ALIGN, ALIGN_CENTER);
   ObjectSetInteger(0, n, OBJPROP_FONTSIZE, 8);
   ObjectSetString (0, n, OBJPROP_TEXT, text);
}

void MakeRect(string name, int x, int y, int w, int h, color bg)
{
   string n = PFX + name;
   if(ObjectFind(0, n) < 0) ObjectCreate(0, n, OBJ_RECTANGLE_LABEL, 0, 0, 0);
   ObjectSetInteger(0, n, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, n, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, n, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, n, OBJPROP_XSIZE, w);
   ObjectSetInteger(0, n, OBJPROP_YSIZE, h);
   ObjectSetInteger(0, n, OBJPROP_BGCOLOR, bg);
   ObjectSetInteger(0, n, OBJPROP_BORDER_TYPE, BORDER_FLAT);
   ObjectSetInteger(0, n, OBJPROP_COLOR, clrDimGray);
   ObjectSetInteger(0, n, OBJPROP_BACK, false);
   ObjectSetInteger(0, n, OBJPROP_SELECTABLE, false);
}

string EditVal(string name)
{
   return(ObjectGetString(0, PFX + name, OBJPROP_TEXT));
}

void ResetButton(string name)
{
   ObjectSetInteger(0, PFX + name, OBJPROP_STATE, false);
}

//+------------------------------------------------------------------+
//| Build panel                                                      |
//+------------------------------------------------------------------+
void BuildPanel()
{
   int x = InpPanelX, y = InpPanelY;
   MakeRect("bg", x-5, y-5, 250, 266, InpPanelBg);

   MakeLabel("title", "LPH TRADE MANAGER", x, y, clrGold, 9);
   y += 20;
   MakeLabel("pipinfo", "1 pip = " + DoubleToString(g_pip, g_pipDigits) +
             "   (" + _Symbol + ")", x, y, clrSilver, 7);

   //--- SL/TP section
   y += 18;
   MakeLabel("lblsl", "SL (pips)", x, y+3, InpTextColor, 8);
   MakeEdit ("edsl", IntegerToString(InpDefaultSLPips), x+60, y, 55, 18);
   MakeLabel("lbltp", "TP (pips)", x+125, y+3, InpTextColor, 8);
   MakeEdit ("edtp", IntegerToString(InpDefaultTPPips), x+185, y, 55, 18);

   y += 24;
   MakeButton("btnsltp", "Apply SL/TP", x, y, 118, 22, C'20,80,140');
   MakeButton("btnclrsltp", "Clear SL/TP", x+122, y, 118, 22, C'70,70,70');

   //--- Partial close section
   y += 30;
   MakeLabel("lblpc", "Partial %", x, y+3, InpTextColor, 8);
   MakeEdit ("edpc", DoubleToString(InpPartialPercent,1), x+60, y, 55, 18);
   MakeButton("btnpc", "Partial Close", x+122, y-2, 118, 22, C'150,110,20');

   //--- Breakeven section
   y += 30;
   MakeLabel("lblbe", "BE offset", x, y+3, InpTextColor, 8);
   MakeEdit ("edbe", DoubleToString(InpBEOffsetPips,1), x+60, y, 55, 18);
   MakeButton("btnbe", "Move to BE", x+122, y-2, 118, 22, C'30,110,110');

   //--- Close section
   y += 30;
   MakeButton("btnclosesym", "Close Symbol", x, y, 118, 22, C'120,40,40');
   MakeButton("btncloseall", "Close ALL", x+122, y, 118, 22, C'160,30,30');

   y += 26;
   MakeButton("btnprofit", "Close Profitable", x, y, 118, 22, C'30,110,50');
   MakeButton("btnloss", "Close Losing", x+122, y, 118, 22, C'110,60,30');

   y += 26;
   MakeButton("btnpend", "Delete Pendings", x, y, 240, 22, C'70,70,90');

   y += 26;
   MakeLabel("status", "Ready.", x, y, clrSilver, 8);

   ChartRedraw(0);
}

//+------------------------------------------------------------------+
void SetStatus(string s, color c = clrSilver)
{
   ObjectSetString (0, PFX+"status", OBJPROP_TEXT, s);
   ObjectSetInteger(0, PFX+"status", OBJPROP_COLOR, c);
   ChartRedraw(0);
}

//+------------------------------------------------------------------+
int OnInit()
{
   trade.SetDeviationInPoints(InpSlippagePoints);
   ResolvePipSize();
   BuildPanel();
   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason)
{
   ObjectsDeleteAll(0, PFX);
   ChartRedraw(0);
}

void OnTick()
{
   // Panel is event-driven; nothing required per tick.
}

//+------------------------------------------------------------------+
//| Apply SL/TP in pips to all in-scope market positions             |
//+------------------------------------------------------------------+
void ApplySLTP(bool clearInstead)
{
   double slPips = clearInstead ? 0 : StringToDouble(EditVal("edsl"));
   double tpPips = clearInstead ? 0 : StringToDouble(EditVal("edtp"));

   if(!clearInstead && slPips <= 0 && tpPips <= 0)
   { SetStatus("Nothing to apply (SL and TP both 0).", clrOrange); return; }

   int done = 0, failed = 0, skipped = 0;

   for(int i = PositionsTotal()-1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0) continue;
      if(PositionGetInteger(POSITION_TYPE) != POSITION_TYPE_BUY &&
         PositionGetInteger(POSITION_TYPE) != POSITION_TYPE_SELL) continue;
      if(!PositionInScope()) continue;

      string sym = PositionGetString(POSITION_SYMBOL);
      if(!SpreadOK(sym)) { skipped++; continue; }

      int    dg   = SymDigits(sym);
      double pt   = SymPoint(sym);
      double pip  = SymPipFor(sym);
      double stopLvl = SymStopLevel(sym) * pt;
      double bid  = SymBid(sym);
      double ask  = SymAsk(sym);
      double open = PositionGetDouble(POSITION_PRICE_OPEN);

      double newSL = 0.0, newTP = 0.0;

      if(!clearInstead)
      {
         if(PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY)
         {
            if(slPips > 0) newSL = NormalizeDouble(open - slPips*pip, dg);
            if(tpPips > 0) newTP = NormalizeDouble(open + tpPips*pip, dg);
            // Broker stop-level validation
            if(newSL > 0 && newSL > bid - stopLvl)
            { Print("[LPH Panel] SL too close for #", ticket); failed++; continue; }
            if(newTP > 0 && newTP < ask + stopLvl)
            { Print("[LPH Panel] TP too close for #", ticket); failed++; continue; }
         }
         else // POSITION_TYPE_SELL
         {
            if(slPips > 0) newSL = NormalizeDouble(open + slPips*pip, dg);
            if(tpPips > 0) newTP = NormalizeDouble(open - tpPips*pip, dg);
            if(newSL > 0 && newSL < ask + stopLvl)
            { Print("[LPH Panel] SL too close for #", ticket); failed++; continue; }
            if(newTP > 0 && newTP > bid - stopLvl)
            { Print("[LPH Panel] TP too close for #", ticket); failed++; continue; }
         }

         // Preserve existing level if that side left blank
         if(slPips <= 0) newSL = PositionGetDouble(POSITION_SL);
         if(tpPips <= 0) newTP = PositionGetDouble(POSITION_TP);
      }

      // Skip if no actual change
      if(MathAbs(newSL - PositionGetDouble(POSITION_SL))   < pt*0.5 &&
         MathAbs(newTP - PositionGetDouble(POSITION_TP)) < pt*0.5)
      { skipped++; continue; }

      if(trade.PositionModify(ticket, newSL, newTP)) done++;
      else { Print("[LPH Panel] PositionModify failed #", ticket,
                   " err=", GetLastError()); failed++; }
   }

   SetStatus(StringFormat("SL/TP: %d ok, %d fail, %d skip", done, failed, skipped),
             failed > 0 ? clrOrange : clrLime);
}

//+------------------------------------------------------------------+
//| Move SL to breakeven +/- offset (direction-aware)                |
//| offsetPips: positive = lock profit, negative = leave risk on     |
//+------------------------------------------------------------------+
void ApplyBreakeven()
{
   double offPips = StringToDouble(EditVal("edbe"));
   int done = 0, failed = 0, skipped = 0;

   for(int i = PositionsTotal()-1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0) continue;
      if(PositionGetInteger(POSITION_TYPE) != POSITION_TYPE_BUY &&
         PositionGetInteger(POSITION_TYPE) != POSITION_TYPE_SELL) continue;
      if(!PositionInScope()) continue;

      string sym = PositionGetString(POSITION_SYMBOL);
      if(!SpreadOK(sym)) { skipped++; continue; }

      int    dg  = SymDigits(sym);
      double pt  = SymPoint(sym);
      double pip = SymPipFor(sym);
      double stopLvl = SymStopLevel(sym) * pt;
      double bid = SymBid(sym);
      double ask = SymAsk(sym);
      double open = PositionGetDouble(POSITION_PRICE_OPEN);

      //--- Cost cushion so BE is a real BE, not a small loss
      double cushionPips = 0.0;
      if(InpBECoverCosts)
      {
         double sprPips = ((ask - bid) / pip);

         // Commission + swap expressed in pips for THIS ticket
         double tickVal = SymTickValue(sym);
         double tickSz  = SymTickSize(sym);
         if(tickSz <= 0) tickSz = pt;
         double pipValue = tickVal * (pip / tickSz) * PositionGetDouble(POSITION_VOLUME);  // $ per pip

         double costMoney = MathAbs(PositionGetDouble(POSITION_COMMISSION)) + MathAbs(PositionGetDouble(POSITION_SWAP));
         double costPips  = (pipValue > 0.0) ? (costMoney / pipValue) : 0.0;

         cushionPips = sprPips + costPips;
      }

      double totalOffset = offPips + cushionPips;
      double newSL = 0.0;

      if(PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY)
      {
         newSL = NormalizeDouble(open + totalOffset*pip, dg);

         if(newSL > bid - stopLvl)
         {
            Print("[LPH BE] #", ticket, " not enough room. Need bid >= ",
                  DoubleToString(newSL + stopLvl, dg), ", have ", DoubleToString(bid, dg));
            skipped++; continue;
         }
         // Never loosen an existing protective stop
         if(PositionGetDouble(POSITION_SL) > 0 && newSL <= PositionGetDouble(POSITION_SL))
         { skipped++; continue; }
      }
      else // POSITION_TYPE_SELL
      {
         newSL = NormalizeDouble(open - totalOffset*pip, dg);

         if(newSL < ask + stopLvl)
         {
            Print("[LPH BE] #", ticket, " not enough room. Need ask <= ",
                  DoubleToString(newSL - stopLvl, dg), ", have ", DoubleToString(ask, dg));
            skipped++; continue;
         }
         if(PositionGetDouble(POSITION_SL) > 0 && newSL >= PositionGetDouble(POSITION_SL))
         { skipped++; continue; }
      }

      if(MathAbs(newSL - PositionGetDouble(POSITION_SL)) < pt*0.5) { skipped++; continue; }

      if(trade.PositionModify(ticket, newSL, PositionGetDouble(POSITION_TP)))
      {
         done++;
         Print("[LPH BE] #", ticket, " SL -> ", DoubleToString(newSL, dg),
               " (offset ", DoubleToString(offPips,1),
               " + cushion ", DoubleToString(cushionPips,1), " pips)");
      }
      else
      { Print("[LPH BE] PositionModify failed #", ticket,
              " err=", GetLastError()); failed++; }
   }

   SetStatus(StringFormat("BE: %d ok, %d fail, %d skip", done, failed, skipped),
             failed > 0 ? clrOrange : clrLime);
}

//+------------------------------------------------------------------+
//| Partial close by percentage                                      |
//+------------------------------------------------------------------+
void DoPartialClose()
{
   double pct = StringToDouble(EditVal("edpc"));
   if(pct <= 0.0 || pct >= 100.0)
   { SetStatus("Partial % must be between 0 and 100.", clrOrange); return; }

   int done = 0, failed = 0, skipped = 0;

   for(int i = PositionsTotal()-1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0) continue;
      if(PositionGetInteger(POSITION_TYPE) != POSITION_TYPE_BUY &&
         PositionGetInteger(POSITION_TYPE) != POSITION_TYPE_SELL) continue;
      if(!PositionInScope()) continue;

      string sym = PositionGetString(POSITION_SYMBOL);
      if(!SpreadOK(sym)) { skipped++; continue; }

      double lotStep = SymLotStep(sym);
      double lotMin  = SymMinLot(sym);
      if(lotStep <= 0) lotStep = 0.01;
      if(lotMin  <= 0) lotMin  = 0.01;

      double lots = PositionGetDouble(POSITION_VOLUME);
      double closeLots = lots * pct / 100.0;
      // Round DOWN to lot step so remainder stays valid
      closeLots = MathFloor(closeLots / lotStep) * lotStep;
      closeLots = NormalizeDouble(closeLots, 2);

      double remainder = NormalizeDouble(lots - closeLots, 2);

      if(closeLots < lotMin)
      { Print("[LPH Panel] Partial too small for #", ticket,
              " (", DoubleToString(closeLots,2), " < minlot)"); skipped++; continue; }

      if(remainder > 0.0 && remainder < lotMin)
      { Print("[LPH Panel] Remainder below minlot for #", ticket,
              " - skipped to avoid invalid volume"); skipped++; continue; }

      if(trade.PositionClosePartial(ticket, closeLots)) done++;
      else { Print("[LPH Panel] Partial close failed #", ticket,
                   " err=", GetLastError()); failed++; }
   }

   SetStatus(StringFormat("Partial: %d ok, %d fail, %d skip", done, failed, skipped),
             failed > 0 ? clrOrange : clrLime);
}

//+------------------------------------------------------------------+
//| Bulk close. mode: 0=all, 1=profitable, 2=losing                  |
//+------------------------------------------------------------------+
void DoBulkClose(int mode)
{
   int done = 0, failed = 0, skipped = 0;

   for(int pass = 0; pass < 3; pass++)   // retry passes for requotes
   {
      for(int i = PositionsTotal()-1; i >= 0; i--)
      {
         ulong ticket = PositionGetTicket(i);
         if(ticket == 0) continue;
         if(PositionGetInteger(POSITION_TYPE) != POSITION_TYPE_BUY &&
            PositionGetInteger(POSITION_TYPE) != POSITION_TYPE_SELL) continue;
         if(!PositionInScope()) continue;

         double net = PositionGetDouble(POSITION_PROFIT) + PositionGetDouble(POSITION_SWAP) + PositionGetDouble(POSITION_COMMISSION);
         if(mode == 1 && net <= 0.0) continue;
         if(mode == 2 && net >= 0.0) continue;

         string sym = PositionGetString(POSITION_SYMBOL);
         if(!SpreadOK(sym)) { if(pass==0) skipped++; continue; }

         if(trade.PositionClose(ticket))
            done++;
         else
         {
            int err = GetLastError();
            Print("[LPH Panel] Close failed #", ticket, " err=", err);
            if(pass == 2) failed++;
            Sleep(200);
         }
      }
   }

   SetStatus(StringFormat("Close: %d ok, %d fail, %d skip", done, failed, skipped),
             failed > 0 ? clrOrange : clrLime);
}

//+------------------------------------------------------------------+
//| Delete pending orders                                            |
//+------------------------------------------------------------------+
void DeletePendings()
{
   int done = 0, failed = 0;
   for(int i = OrdersTotal()-1; i >= 0; i--)
   {
      ulong ticket = OrderGetTicket(i);
      if(ticket == 0) continue;
      long type = OrderGetInteger(ORDER_TYPE);
      if(type == ORDER_TYPE_BUY || type == ORDER_TYPE_SELL) continue;
      if(!OrderInScope()) continue;

      if(trade.OrderDelete(ticket)) done++;
      else { Print("[LPH Panel] OrderDelete failed #", ticket,
                   " err=", GetLastError()); failed++; }
   }
   SetStatus(StringFormat("Pendings: %d deleted, %d failed", done, failed),
             failed > 0 ? clrOrange : clrLime);
}

//+------------------------------------------------------------------+
//| Chart events                                                     |
//+------------------------------------------------------------------+
void OnChartEvent(const int id, const long &lparam, const double &dparam,
                  const string &sparam)
{
   if(id != CHARTEVENT_OBJECT_CLICK) return;
   if(StringSubstr(sparam, 0, StringLen(PFX)) != PFX) return;

   string btn = StringSubstr(sparam, StringLen(PFX));
   ResetButton(btn);

   if(!InpAllowTrading)
   { SetStatus("BLOCKED: InpAllowTrading = false.", clrRed); return; }

   if(!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED))
   { SetStatus("BLOCKED: Terminal AutoTrading is off.", clrRed); return; }

   if(!MQLInfoInteger(MQL_TRADE_ALLOWED))
   { SetStatus("BLOCKED: Trade not allowed for this EA.", clrRed); return; }

   if(btn == "btnsltp")          ApplySLTP(false);
   else if(btn == "btnclrsltp")  ApplySLTP(true);
   else if(btn == "btnbe")       ApplyBreakeven();
   else if(btn == "btnpc")       DoPartialClose();
   else if(btn == "btnclosesym") { g_scopeOverride = 1; DoBulkClose(0); g_scopeOverride = 0; }
   else if(btn == "btncloseall") { g_scopeOverride = 2; DoBulkClose(0); g_scopeOverride = 0; }
   // btncloseall merged above
   // (merged)
   else if(btn == "btnprofit")   DoBulkClose(1);
   else if(btn == "btnloss")     DoBulkClose(2);
   else if(btn == "btnpend")     DeletePendings();

   ChartRedraw(0);
}
//+------------------------------------------------------------------+
